#!/usr/bin/env node
/**
 * Verifica los pares de tokens que la interfaz realmente produce. Corre dos controles
 * distintos, que no hay que confundir:
 *
 *   1. CONTRASTE WCAG 2.1 AA — accesibilidad. Umbrales: 4.5:1 texto normal, 3.0:1 texto
 *      grande y elementos de interfaz. Los controles deshabilitados están exentos por la
 *      propia norma (1.4.3) y no se miden.
 *   2. BORDES QUE NO DIBUJAN — no es accesibilidad. Un token de borde con el mismo valor
 *      que el fondo sobre el que se pinta es un no-op: la regla CSS existe, el borde no
 *      se ve, y ningún umbral de contraste lo detecta porque un borde decorativo no tiene
 *      umbral que incumplir. Se comprueba por igualdad, no por distancia, justamente para
 *      que nadie lo lea como un umbral relajado.
 *
 * Un sistema de diseño no "es accesible" porque el documento lo diga: lo es porque cada
 * combinación que un componente puede pintar está medida. Este script falla el build, así
 * que un cambio de marca que rompa un contraste no llega a publicarse.
 *
 * Y verifica una tercera cosa, que no es una medición sino una equivalencia: que
 * `dist/contraste.json` —el archivo que consume el catálogo de `aybar-front docs`— sea
 * exactamente el resultado de medir los tokens de este build. La lista y la aritmética
 * viven en pares-contraste.mjs y las usan el emisor y este verificador, así que el
 * catálogo no puede publicar un número que el build no respalde: si el archivo no
 * coincide con la medición, o le faltan pares, el build se para aquí.
 */
import { existsSync, readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

import { leerFuente, prepararApariencia, tokensDeFuente } from './origen-apariencia.mjs'
import { ESPERADOS, TEMAS, medir } from './pares-contraste.mjs'

// Contra el script y no contra el cwd: se invoca tanto por los scripts del paquete
// (cwd = el paquete) como desde la raíz del repo, y debe medir los mismos tokens en
// ambos casos.
const raiz = dirname(fileURLToPath(import.meta.url))
const origen = join(raiz, 'dist', 'tokens.json')
const emitido = join(raiz, 'dist', 'contraste.json')

// Sin build previo no hay nada que medir: decirlo es más útil que un ENOENT.
for (const archivo of [origen, emitido]) {
  if (existsSync(archivo)) continue
  console.error(`No existe ${archivo}.`)
  console.error('Ejecuta primero el build: node packages/tokens/build.mjs')
  process.exit(1)
}

const { temas, primitivas } = JSON.parse(readFileSync(origen, 'utf8'))

// Una sola medición, la misma función que usó el build para emitir el archivo. Las
// combinaciones de apariencia se miden desde la fuente (src/*.json) y no desde tokens.json:
// cada una vuelve a resolver los semánticos con las primitivas de su paleta, sus grises y su
// acento, y tokens.json solo trae los de la combinación por defecto.
let medicion
try {
  const fuente = leerFuente(raiz)
  const sinResolver = tokensDeFuente(fuente)
  const apariencia = prepararApariencia({ ...fuente, ...sinResolver })
  medicion = medir(temas, primitivas, { ...sinResolver, ...apariencia })
} catch (error) {
  // Un token de la lista que ya no existe en semantic.json: el build habría fallado
  // antes, pero este script también corre solo (`lint`) y un stack trace no señala nada.
  console.error(`\n${error.message}\n`)
  process.exit(1)
}
const { pares, bordes, prohibidos, combinaciones } = medicion

/*
 * El archivo emitido tiene que ser esta medición, byte a byte del JSON. No es paranoia
 * de checksum: es lo que impide que `dist/contraste.json` se quede atrás de un cambio de
 * marca. Si alguien edita el JSON a mano, o lo genera un paso que ya no corre, el
 * catálogo enseñaría contrastes de una paleta anterior con el aval de un build verde.
 */
const publicado = JSON.parse(readFileSync(emitido, 'utf8'))

// El recuento se declara en pares-contraste.mjs y se comprueba sobre el archivo
// publicado, que es el que lee el catálogo: una paleta a medias con todos sus umbrales
// cumplidos es peor que un fallo, porque dice que la interfaz está verificada.
// El reparto por tema se deriva, no se escribe: era una cifra literal que habría
// seguido diciendo lo mismo después de agregar pares.
const porTema = (total) => `${total / TEMAS.length} por tema`
const faltantes = []
if (publicado.pares?.length !== ESPERADOS.pares) {
  faltantes.push(`trae ${publicado.pares?.length ?? 0} pares y tiene que traer ${ESPERADOS.pares} (${porTema(ESPERADOS.pares)})`)
}
if (publicado.bordes?.length !== ESPERADOS.bordes) {
  faltantes.push(`trae ${publicado.bordes?.length ?? 0} bordes y tiene que traer ${ESPERADOS.bordes} (${porTema(ESPERADOS.bordes)})`)
}
if (publicado.combinaciones?.length !== ESPERADOS.combinaciones) {
  faltantes.push(
    `trae ${publicado.combinaciones?.length ?? 0} combinaciones de apariencia y tiene que traer ${ESPERADOS.combinaciones}`,
  )
}
if (faltantes.length) {
  console.error(`\n${emitido} no trae la paleta completa:`)
  for (const f of faltantes) console.error(`  - ${f}`)
  console.error(
    '\nEl catálogo de `aybar-front docs` publica este archivo. Reconstruye:\n' +
      '  node packages/tokens/build.mjs\n',
  )
  process.exit(1)
}

if (JSON.stringify(publicado) !== JSON.stringify(medicion)) {
  console.error(`\n${emitido} no corresponde a los tokens de este build.`)
  console.error(
    'Ese archivo es derivado: lo emite build.mjs desde pares-contraste.mjs, no se edita a\n' +
      'mano. Reconstruye: node packages/tokens/build.mjs',
  )
  process.exit(1)
}

/*
 * Los pares que se dejan fuera de la medición a conciencia ya no viven en un comentario
 * de este archivo: están en el bloque PROHIBIDOS de pares-contraste.mjs, con su razón
 * calculada, su umbral y el porqué de cada uno, y viajan en contraste.json para que el
 * catálogo los enseñe en lugar de que se pierdan aquí abajo.
 */

let fallos = 0
let nulos = 0

for (const tema of [...new Set(pares.map((p) => p.tema))]) {
  const filas = pares.filter((p) => p.tema === tema)
  const malos = filas.filter((f) => !f.cumple)
  fallos += malos.length

  console.log(`\n${tema.toUpperCase()} · ${filas.length - malos.length}/${filas.length} pares cumplen`)
  for (const f of malos) {
    console.log(
      `  FALLA  ${f.razon.toFixed(2)}:1 (min ${f.umbral})  ${f.para}\n` +
        `         ${f.hexFrente} sobre ${f.hexFondo}`,
    )
  }
  // El par más ajustado se reporta siempre: es el que se rompe con el próximo cambio.
  const ajustado = filas
    .filter((f) => f.cumple)
    .sort((x, y) => x.razon / x.umbral - y.razon / y.umbral)[0]
  if (ajustado) {
    console.log(
      `  más ajustado: ${ajustado.razon.toFixed(2)}:1 (min ${ajustado.umbral}) · ${ajustado.para}`,
    )
  }
}

// Control aparte, y presentado aparte: esto no mide accesibilidad, mide si el borde
// existe. Se compara por igualdad de valor resuelto —normalizando mayúsculas, porque las
// anclas del manual vienen en mayúsculas y las derivadas en minúsculas—, no por distancia:
// un umbral aquí invitaría a discutir cuánto es "poco", y la pregunta es otra.
console.log('\nBORDES QUE NO DIBUJAN · control estructural, no es WCAG')
for (const b of bordes) {
  if (b.dibuja) continue
  nulos++
  console.log(
    `  NO DIBUJA  ${b.tema}: ${b.borde} vale ${b.hexBorde}, igual que ${b.fondo}  ·  ${b.donde}\n` +
      '             la regla CSS existe pero el borde no se ve; ningún umbral lo detecta.',
  )
}
console.log(`  ${bordes.length} bordes comprobados, ${nulos} no dibujan nada.`)

/*
 * Lo que la doctrina descarta, con la razón recalculada. No es un control de la paleta
 * sino de la doctrina: si una de estas combinaciones empezara a CUMPLIR su umbral, el
 * texto que la prohíbe estaría describiendo unos colores que ya no existen. Lo que hay
 * que arreglar entonces es IDENTIDAD.md y la lista, no el JSON, y para eso hace falta que
 * el build lo diga en voz alta en lugar de publicar una prohibición caducada.
 */
console.log('\nCOMBINACIONES PROHIBIDAS · fuera de la medición a propósito')
const caducadas = prohibidos.filter((p) => p.cumple)
for (const p of prohibidos) {
  console.log(
    `  ${p.cumple ? 'YA CUMPLE' : 'descartada'}  ${p.razon.toFixed(2)}:1 (min ${p.umbral})  ` +
      `${p.tema}: ${p.para}\n             ${p.hexFrente} sobre ${p.hexFondo}`,
  )
}

/*
 * Las combinaciones de apariencia: cada una con los PARES y los BORDES completos, en los dos
 * temas. Una paleta que no cumple en una sola combinación no se publica: se ajusta el croma
 * de esa paleta (derivar-paletas.mjs), nunca el umbral.
 */
const malas = combinaciones.filter((c) => c.cumplen !== c.pares || c.dibujan !== c.bordes)
const nombreDe = (c) => `${Object.entries(c.apariencia).map(([eje, valor]) => `${eje}=${valor}`).join(' ')} ${c.tema}`
console.log(`\nAPARIENCIA · ${combinaciones.length - malas.length}/${combinaciones.length} combinaciones cumplen AA y dibujan sus bordes`)
for (const c of malas) {
  console.log(`  FALLA  ${nombreDe(c)}: ${c.cumplen}/${c.pares} pares, ${c.dibujan}/${c.bordes} bordes`)
}
const holgura = (c) => c.ajustado.razon / c.ajustado.umbral
const masAjustada = [...combinaciones].sort((x, y) => holgura(x) - holgura(y))[0]
console.log(
  `  más ajustada: ${masAjustada.ajustado.razon.toFixed(2)}:1 (min ${masAjustada.ajustado.umbral}) · ` +
    `${masAjustada.ajustado.para} · ${nombreDe(masAjustada)}`,
)

console.log(`\n${pares.length} pares medidos, ${fallos} incumplen WCAG 2.1 AA.`)
if (fallos) {
  console.error('\nUn contraste por debajo del umbral no se publica.\n')
}
if (nulos) {
  console.error('\nUn borde del color de su fondo es una regla que no hace nada. No se publica.\n')
}
if (caducadas.length) {
  console.error(
    `\n${caducadas.length} combinación(es) del bloque PROHIBIDOS ya cumplen su umbral.\n` +
      'Una prohibición que la paleta actual desmiente no se publica: revisa la sección\n' +
      '"La mandarina no es un color de acción" de docs/IDENTIDAD.md y la lista PROHIBIDOS\n' +
      'de packages/tokens/pares-contraste.mjs antes de seguir.\n',
  )
}
if (malas.length) {
  console.error(
    `\n${malas.length} combinación(es) de apariencia no cumplen. Ajusta el croma de su paleta en\n` +
      'derivar-paletas.mjs (y regenera src/paletas.json), nunca el umbral.\n',
  )
}
if (fallos || nulos || caducadas.length || malas.length) process.exit(1)

#!/usr/bin/env node
/**
 * Comprueba que lo que dist/ dice sobre la tipografía sea verdad. Corre en el build,
 * después de build.mjs, así que un desajuste no llega a publicarse.
 *
 * Qué mide, y por qué cada cosa:
 *
 *   1. REFERENCIAS MUERTAS. Un @font-face cuyo .woff2 no existe no produce ningún error:
 *      el navegador sintetiza la cara a partir de otra y la pantalla sale con una
 *      tipografía que no es la de la marca. Es el fallo silencioso que hay que atrapar
 *      aquí porque no lo atrapa nada más.
 *   2. BINARIOS HUÉRFANOS. Un .woff2 en dist/fonts/ que ningún @font-face nombra viaja
 *      en cada instalación del paquete sin que nadie lo descargue nunca. Es exactamente
 *      lo que pasaba cuando el build sobrescribía el CSS auto-hospedado y dejaba los
 *      binarios donde estaban.
 *   3. COHERENCIA DEL MODO. dist/fuentes.css es una copia de la variante activa: si su
 *      cabecera dice un modo y su cuerpo trae otro —porque alguien editó a mano lo que
 *      dice NO EDITAR A MANO—, «¿desde dónde sirve este paquete Montserrat?» vuelve a
 *      ser una pregunta que hay que adivinar.
 *   4. QUE EL PAQUETE LO PROMETA Y LO EMPAQUETE. Los tres subpaths tienen que apuntar a
 *      estos tres archivos, y `files` no puede excluir dist/fonts: un @font-face correcto
 *      que no viaja en el tarball rompe en el consumidor y no aquí.
 */
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const raiz = dirname(fileURLToPath(import.meta.url))
const dist = join(raiz, 'dist')

const VARIANTES = {
  '.': 'fuentes.css',
  cdn: 'fuentes-cdn.css',
  locales: 'fuentes-locales.css',
}

const fallos = []
const falla = (m) => fallos.push(m)

for (const archivo of Object.values(VARIANTES)) {
  if (!existsSync(join(dist, archivo))) {
    console.error(`No existe dist/${archivo}.`)
    console.error('Ejecuta primero el build: node packages/tokens/build.mjs')
    process.exit(1)
  }
}

/** Lee una variante: su modo declarado y las url() que promete. */
function leer(archivo) {
  const texto = readFileSync(join(dist, archivo), 'utf8')
  const modo = texto.match(/@aybar-fuentes modo=(\w+)/)?.[1]
  if (!modo) falla(`dist/${archivo} no declara su modo en la cabecera (@aybar-fuentes modo=…)`)
  // Se cuenta sobre el CSS sin comentarios: las cabeceras hablan de @font-face y de
  // rutas, y contarlas ahí daría un desajuste inventado.
  const css = texto.replace(/\/\*[\s\S]*?\*\//g, '')
  const caras = (css.match(/@font-face\s*\{/g) ?? []).length
  const urls = [...css.matchAll(/url\('([^']+)'\)/g)].map((m) => m[1])
  return { archivo, texto, modo, caras, urls }
}

const activa = leer(VARIANTES['.'])
const cdn = leer(VARIANTES.cdn)
const locales = leer(VARIANTES.locales)

// 1. Referencias muertas. Solo las relativas: el @import al CDN es una url remota.
const relativas = (v) => v.urls.filter((u) => u.startsWith('./'))
const muertas = []
for (const v of [activa, cdn, locales]) {
  for (const u of relativas(v)) {
    if (!existsSync(join(dist, u))) muertas.push(`dist/${v.archivo} → ${u}`)
  }
  // Cada @font-face declara exactamente un src: si no cuadran, alguien editó a mano.
  if (v.caras !== relativas(v).length) {
    falla(`dist/${v.archivo} declara ${v.caras} @font-face y ${relativas(v).length} url() locales`)
  }
}
for (const m of muertas) falla(`Referencia muerta: ${m}`)

// 2. Binarios huérfanos.
const nombrados = new Set(relativas(locales).map((u) => u.replace('./fonts/', '')))
const enDisco = existsSync(join(dist, 'fonts'))
  ? readdirSync(join(dist, 'fonts')).filter((n) => !n.startsWith('.'))
  : []
for (const n of enDisco) {
  if (!nombrados.has(n)) falla(`Binario huérfano: dist/fonts/${n} no lo nombra ningún @font-face`)
}

// 3. Coherencia del modo.
const modoEsperado = enDisco.length ? 'locales' : 'cdn'
if (activa.modo !== modoEsperado) {
  falla(`dist/fuentes.css se declara modo=${activa.modo} y en dist/ hay ${enDisco.length} caras`)
}
const cuerpo = (v) => v.texto.slice(v.texto.indexOf('*/') + 2).trim()
if (cuerpo(activa) !== cuerpo(activa.modo === 'locales' ? locales : cdn)) {
  falla(`dist/fuentes.css no es copia de dist/${VARIANTES[activa.modo]}: su cuerpo difiere`)
}
const enJson = JSON.parse(readFileSync(join(dist, 'tokens.json'), 'utf8')).fuentes
if (enJson?.modo !== activa.modo) {
  falla(`dist/tokens.json dice fuentes.modo=${enJson?.modo} y dist/fuentes.css dice ${activa.modo}`)
}

// 4. Lo que el package.json promete y empaqueta.
const pkg = JSON.parse(readFileSync(join(raiz, 'package.json'), 'utf8'))
/**
 * El destino de un subpath de hoja de estilos, sea la forma corta —una cadena— o la
 * condicional que necesita TypeScript 6: `{ types, default }`. Se comprueba `default`,
 * porque es la rama que resuelve el empaquetador y la que acaba en el navegador; que la
 * condición `types` esté es asunto del guardián de abajo.
 */
function destinoCss(valor) {
  if (typeof valor === 'string') return valor
  if (valor !== null && typeof valor === 'object') return valor.default ?? null
  return null
}

const TIPOS_HOJA = './dist/hoja-de-estilos.d.ts'

for (const [clave, archivo] of Object.entries(VARIANTES)) {
  const subpath = clave === '.' ? './fonts' : `./fonts/${clave}`
  const declarado = pkg.exports[subpath]
  const destino = destinoCss(declarado)
  if (destino !== `./dist/${archivo}`) {
    falla(`exports["${subpath}"] debería resolver a ./dist/${archivo} y resuelve a ${destino ?? 'nada'}`)
  }
  // Sin la condición `types`, un `import '@aybarcorp/tokens/fonts'` —que es un import de
  // efecto— falla con TS2882 en TypeScript 6, que es lo que trae hoy la plantilla de
  // Vite. Este monorepo pinea 5.9.3, donde el error no existe, así que el fallo solo
  // aparece en el consumidor: por eso se verifica aquí y no se confía en el typecheck.
  if (destinoCss(declarado) !== null && declarado?.types !== TIPOS_HOJA) {
    falla(
      `exports["${subpath}"] no declara types: ${TIPOS_HOJA} — un import de efecto de este ` +
        'subpath da TS2882 en TypeScript 6',
    )
  }
}
if (!existsSync(join(dist, 'hoja-de-estilos.d.ts'))) {
  falla('falta dist/hoja-de-estilos.d.ts: los subpaths de hoja de estilos lo prometen en `types`')
}
const excluye = pkg.files.find((p) => p.startsWith('!') && 'dist/fonts'.startsWith(p.slice(1).replace(/\/$/, '')))
if (excluye) falla(`\`files\` excluye los binarios con "${excluye}": los @font-face no viajarían en el tarball`)
if (!pkg.files.includes('dist')) falla('`files` no incluye dist: el tarball saldría sin CSS de fuentes')

// ── Informe ───────────────────────────────────────────────────────────────────

const kb = (enDisco.reduce((s, n) => s + statSync(join(dist, 'fonts', n)).size, 0) / 1024).toFixed(1)
console.log(`\nFUENTES · modo ${activa.modo.toUpperCase()}${activa.modo === 'locales' ? ` · ${enDisco.length} caras · ${kb} kB` : ' · fonts.googleapis.com'}`)
for (const v of [activa, cdn, locales]) {
  console.log(`  dist/${v.archivo.padEnd(20)} modo=${String(v.modo).padEnd(8)} ${v.caras} @font-face, ${relativas(v).length} url() locales`)
}
console.log(`  dist/fonts/${' '.repeat(13)} ${enDisco.length} .woff2 en disco`)

if (fallos.length) {
  console.error(`\nERROR  ${fallos.length} incoherencia(s) en la tipografía:\n`)
  for (const f of fallos) console.error(`       - ${f}`)
  console.error(
    '\n       Los .woff2 se generan con `node generar-fuentes.mjs <ruta a los .ttf>` (escriben\n' +
      '       src/fonts/) y el CSS lo emite `node build.mjs` desde ellos. Nada de dist/ se edita\n' +
      '       a mano: es todo derivado.\n',
  )
  process.exit(1)
}
console.log('\n0 referencias muertas, 0 binarios huérfanos; el modo es el mismo en el CSS, en tokens.json y en dist/fonts/.')

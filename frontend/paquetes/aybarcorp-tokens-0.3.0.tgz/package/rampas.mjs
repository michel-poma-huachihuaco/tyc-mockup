/**
 * Cómo se construye una rampa de color, compartido por los dos scripts que derivan paletas:
 *
 *   derivar-marca.mjs    las rampas del manual (src/brand.json), con sus anclas
 *   derivar-paletas.mjs  las paletas alternativas de la apariencia (src/paletas.json)
 *
 * Vivía dentro de derivar-marca.mjs. Una paleta alternativa que copiara la función o la curva
 * sería una segunda definición de «cómo sube la luminosidad de 50 a 900», y la primera vez
 * que alguien afinara la curva de la marca las paletas dejarían de parecerse a ella sin que
 * nada fallara. Aquí la curva es una y las dos salidas la leen.
 */
import { hexARgb, hexAOklch, oklchAHex, rgbAOklab } from './color.mjs'

const radianes = (grados) => (grados * Math.PI) / 180

/**
 * Distancia de color en OKLab: norma euclídea sobre (L, a, b).
 *
 * Antes esto se medía con la razón de contraste WCAG, que es lo que había a mano y es
 * la métrica equivocada: el contraste solo mira luminancia, así que dos colores con la
 * misma L y distinto tono le dan ~1.00 por más que sean colores diferentes. Partiendo
 * de #02424E y rotando el tono a igual L y C se obtienen #363f18, #05443b y #183e57
 * —oliva, verde y azul— con razones de 1.0058, 1.0024 y 1.0141: los tres pasaban.
 * OKLab sí es perceptualmente uniforme en las tres coordenadas, que es exactamente lo
 * que el control quiere comprobar.
 */
export const distancia = (hexA, hexB) => {
  const [A, B] = [rgbAOklab(hexARgb(hexA)), rgbAOklab(hexARgb(hexB))]
  return Math.hypot(A[0] - B[0], A[1] - B[1], A[2] - B[2])
}

/**
 * Límite de continuidad, en ΔE OKLab.
 *
 * De dónde sale el número: el desvío real más grande de las rampas actuales es 0.0157
 * (secondary.600, la curva pasa por #cd7f00 y el manual dice #D37A07); los otros tres
 * pasos ancla dan 0.0000. 0.02 deja ~27% de margen sobre ese peor caso y sigue por
 * debajo del más pequeño de los tres colores rotados de arriba (0.0270), que es la clase
 * de error que hay que atrapar. Coincide además con el orden del umbral de percepción en
 * OKLab: por debajo de ~0.02 el escalón no se ve, que es la pregunta que se está haciendo.
 */
export const LIMITE_CONTINUIDAD = 0.02

/**
 * La curva de la rampa petróleo: luminosidad OKLab y factor de croma de cada paso. Es la de
 * la marca (derivar-marca.mjs le pone las anclas del manual en 700 y 800) y la de todas las
 * paletas de la apariencia, que solo cambian el tono y el croma de referencia: así un 700
 * de cualquier paleta tiene la misma luminosidad que el petróleo y los contrastes medidos
 * sobre la marca se mueven poco al cambiar de paleta.
 */
export const CURVA_PETROLEO = {
  50:  { L: 0.975, cf: 0.25 },
  100: { L: 0.945, cf: 0.40 },
  200: { L: 0.895, cf: 0.60 },
  300: { L: 0.825, cf: 0.85 },
  400: { L: 0.735, cf: 1.05 },
  500: { L: 0.585, cf: 1.15 },
  600: { L: 0.465, cf: 1.10 },
  700: { L: 0.349, cf: 1.00 },
  800: { L: 0.292, cf: 0.82 },
  900: { L: 0.230, cf: 0.72 },
}

/** La curva de la mandarina, con las anclas del manual en 400 y 600 (derivar-marca.mjs). */
export const CURVA_MANDARINA = {
  50:  { L: 0.975, cf: 0.15 },
  100: { L: 0.945, cf: 0.28 },
  200: { L: 0.900, cf: 0.50 },
  300: { L: 0.855, cf: 0.75 },
  400: { L: 0.797, cf: 1.00 },
  500: { L: 0.730, cf: 0.98 },
  600: { L: 0.663, cf: 0.92 },
  700: { L: 0.560, cf: 0.85 },
  800: { L: 0.460, cf: 0.72 },
  900: { L: 0.360, cf: 0.60 },
}

/** Pone anclas sobre una curva: `{ 700: '#02424E' }` marca ese paso como color del manual. */
export function anclar(curva, anclas) {
  return Object.fromEntries(
    Object.entries(curva).map(([paso, p]) => [paso, anclas[paso] ? { ...p, ancla: anclas[paso] } : p]),
  )
}

/**
 * Una rampa se define por su tono y, para cada paso, una luminosidad OKLab y un
 * factor de croma. Los pasos marcados `ancla` deben reproducir el hex del manual.
 *
 * El tono y el croma de referencia salen de `hueDe` (un color del manual) o se dan en
 * `tono` (grados) y `croma`, que es como se declaran las paletas alternativas.
 */
export function rampa({ hueDe, tono, croma, pasos }) {
  const h = hueDe ? hexAOklch(hueDe).h : radianes(tono)
  const salida = {}
  for (const [paso, { L, cf, ancla }] of Object.entries(pasos)) {
    const cRef = hueDe ? hexAOklch(ancla ?? hueDe).C : croma
    const hex = ancla ?? oklchAHex({ L, C: cRef * cf, h })
    if (ancla) {
      // El paso ancla se copia literal; se verifica que la curva pase por él para
      // que la rampa sea continua y no tenga un escalón donde entra el color real.
      const derivado = oklchAHex({ L, C: hexAOklch(ancla).C, h })
      const desvio = distancia(derivado, ancla)
      if (desvio > LIMITE_CONTINUIDAD) {
        throw new Error(
          `El paso ${paso} declara el ancla ${ancla} pero la curva pasa por ${derivado} ` +
            `(ΔE OKLab ${desvio.toFixed(4)} > ${LIMITE_CONTINUIDAD}). ` +
            'Ajusta L o el tono de la rampa: un salto ahí se ve como un escalón.',
        )
      }
    }
    salida[paso] = hex
  }
  return salida
}

/**
 * Un gris a la luminosidad L. Sin `tinte` es puro —el manual da los grises sin matiz y no se
 * les inventa uno—; con `{ tono, croma }` (grados y croma OKLab) es el gris cálido o frío de
 * la apariencia, con el croma justo para que se note el matiz sin que deje de ser gris.
 */
export function gris(L, tinte) {
  return tinte ? oklchAHex({ L, C: tinte.croma, h: radianes(tinte.tono) }) : oklchAHex({ L, C: 0, h: 0 })
}

/**
 * La luminosidad OKLab de cada paso de la escala de grises. El 0 es siempre blanco puro, y el
 * 100 y el 800 son los grises del manual (#F6F6F6 y #2F2F2F, pág. 36): los pone quien llama,
 * como anclas.
 */
export const CURVA_GRIS = {
  50: 0.985,
  200: 0.930,
  300: 0.870,
  400: 0.760,
  // Los dos pasos intermedios son el texto tenue (fg-subtle), uno por tema. El 600 claro
  // daba 4.48:1 sobre la superficie hundida y el 500 oscuro 3.98:1 sobre la elevada: los
  // dos por debajo de 4.5. Un paso entero más hacia el contraste lo igualaba a fg-muted
  // (700 y 400), y entonces el tenue dejaba de distinguirse del secundario.
  450: 0.700,
  500: 0.640,
  600: 0.520,
  650: 0.490,
  700: 0.410,
  // Entre el gris oscuro del manual y el 900: la superficie del tema oscuro, para que
  // el fondo, las tarjetas y lo elevado sean tres grises distintos sin recurrir al petróleo.
  850: 0.270,
  900: 0.230,
  1000: 0.160,
}

/**
 * La escala de grises completa. Las `anclas` (los grises del manual) se copian literales en
 * la escala pura; con `tinte`, se toma su luminosidad y se tiñen como los demás pasos, para
 * que el 100 y el 800 de un gris cálido no sean los únicos neutros de la rampa.
 */
export function grises({ anclas = {}, tinte } = {}) {
  const salida = { 0: '#ffffff' }
  for (const [paso, L] of Object.entries(CURVA_GRIS)) salida[paso] = gris(L, tinte)
  for (const [paso, hex] of Object.entries(anclas)) {
    salida[paso] = tinte ? gris(hexAOklch(hex).L, tinte) : hex
  }
  return salida
}

/**
 * Colores funcionales. El manual no los define: son necesidad de interfaz, no de
 * marca. Se eligen los tonos por distinguibilidad —el naranja mandarina ya ocupa
 * 70°, así que el ámbar de advertencia se separa a 85° y el rojo de error a 28°—
 * y se construyen con la misma curva para que convivan con las rampas de marca.
 */
export function funcional(hue, cMax) {
  const h = radianes(hue)
  const p = (L, cf) => oklchAHex({ L, C: cMax * cf, h })
  return {
    50: p(0.972, 0.18), 100: p(0.935, 0.35), 300: p(0.820, 0.80),
    500: p(0.640, 1.00), 600: p(0.560, 0.95), 700: p(0.480, 0.88),
    900: p(0.320, 0.62),
  }
}

#!/usr/bin/env node
/**
 * Deriva src/paletas.json: las ramas primitivas que redefine cada valor de los ejes de color
 * de la apariencia (src/apariencia.json).
 *
 *   palette  `color.primary.*` de Océano, Jade y Grafito. La curva L/cf es la del petróleo
 *            (CURVA_PETROLEO, rampas.mjs) y solo cambian el tono y el croma de referencia:
 *            el 700 de cualquier paleta tiene la luminosidad del petróleo, y los contrastes
 *            medidos sobre la marca se mueven poco al cambiar de paleta.
 *   accent   monocromo: `color.secondary.*` deja la mandarina y pasa a colgar de
 *            `color.primary.*`, con la luminancia de la mandarina (ver `monocromo()`).
 *   neutral  `color.neutral.*` cálidos y fríos: la escala del manual con un croma mínimo.
 *
 * Como derivar-marca.mjs, existe como script y no como JSON escrito a mano para que la
 * procedencia sea auditable, y falla si una paleta deja de dar el 700 que se le pidió. El
 * archivo se versiona; `node build.mjs --strict` lo regenera en memoria y no publica si el
 * que hay en src/ quedó atrás de la marca o de la curva.
 *
 * Que cada combinación cumpla AA no se comprueba aquí sino en el build: las 96 combinaciones
 * se miden con los mismos pares que la paleta por defecto (pares-contraste.mjs). Si una no
 * cumple, se ajusta el croma de su paleta, nunca el umbral.
 */
import { readFileSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

import { hexAOklch, luminancia, mezclar } from './color.mjs'
import { CURVA_PETROLEO, grises, rampa } from './rampas.mjs'

const raiz = dirname(fileURLToPath(import.meta.url))
const grados = (radianes) => (radianes * 180) / Math.PI

/**
 * Las paletas alternativas: tono y croma de referencia, y el 700 que tienen que dar. El 700
 * es el color de acción (`action-primary-bg`, `bg-brand`, `fg-link`): fijarlo aquí hace que
 * afinar el croma sea una decisión explícita en lugar de un efecto lateral.
 */
function paletas(petroleo) {
  return {
    oceano: { tono: 245, croma: 0.085, esperado700: '#043d63' },
    jade: { tono: 178, croma: 0.065, esperado700: '#00453a' },
    // El tono del petróleo con un 30% de su croma: un gris azulado que sigue siendo de la marca.
    grafito: { tono: grados(petroleo.h), croma: petroleo.C * 0.3, esperado700: '#303d40' },
  }
}

/**
 * Los grises teñidos. El croma es mínimo a propósito —se nota en una superficie grande, no en
 * un texto—: un gris con más tinte compite con el color de marca y deja de ser neutro.
 */
const TINTES = {
  calido: { tono: 75, croma: 0.008 },
  frio: { tono: 240, croma: 0.007 },
}

/**
 * El acento monocromo: cada paso de `secondary` cuelga de `primary`.
 *
 * No es `secondary.N = primary.N`. Los semánticos de acento eligen pasos de la mandarina por su
 * luminosidad, que es otra curva: el botón de acento lleva texto oscuro (`primary.900`) sobre
 * secondary.400/500/600 y el borde de acento es secondary.600 sobre blanco. Con
 * `secondary.600 = primary.600` el botón activo daba 2.45:1 y con el 500, 4.05:1: los dos por
 * debajo de AA. Así que cada paso se escribe como la mezcla en OKLab de los dos pasos de
 * `primary` que tienen la misma luminancia relativa que ese paso de la mandarina: sigue a la
 * paleta elegida (es una referencia, no un hex) y conserva los contrastes que la mandarina ya
 * medía, porque el contraste WCAG solo depende de la luminancia.
 *
 * Se iguala la luminancia relativa y no la L de OKLab: a igual L, un verde azulado es un poco
 * más claro que un naranja, y el borde de acento (secondary.600 sobre blanco, 3.20:1 con la
 * mandarina) se quedaba en 2.96:1 con Jade. Los pesos se calculan sobre el petróleo; las otras
 * paletas comparten su curva y dan contrastes a ±0.05 —el build mide las 96 combinaciones—.
 */
function monocromo(marca) {
  const primario = marca.color.primary
  const pasos = Object.keys(primario)
  const secundario = {}
  for (const [paso, hex] of Object.entries(marca.color.secondary)) {
    const objetivo = luminancia(hex)
    const i = pasos.findIndex((p) => luminancia(primario[p]) < objetivo)
    if (i < 0) throw new Error(`secondary.${paso} es más oscuro que primary.${pasos.at(-1)}: no hay mezcla que lo iguale`)
    if (i === 0) {
      secundario[paso] = `{color.primary.${pasos[0]}}`
      continue
    }
    const [claro, oscuro] = [pasos[i - 1], pasos[i]]
    // La luminancia de la mezcla baja con el peso del más oscuro: bisección sobre el peso.
    let [desde, hasta] = [0, 1]
    for (let n = 0; n < 40; n++) {
      const medio = (desde + hasta) / 2
      if (luminancia(mezclar(primario[claro], primario[oscuro], medio)) > objetivo) desde = medio
      else hasta = medio
    }
    const peso = Math.round(desde * 100)
    secundario[paso] =
      peso === 0
        ? `{color.primary.${claro}}`
        : peso === 100
          ? `{color.primary.${oscuro}}`
          : `mix({color.primary.${claro}}, {color.primary.${oscuro}}, ${peso}%)`
  }
  return secundario
}

/** El contenido de src/paletas.json, derivado de la marca vigente. Puro: no escribe nada. */
export function derivarPaletas(marca) {
  const anclas = marca._anclas
  const petroleo = hexAOklch(anclas.principal)

  const palette = {}
  for (const [id, { tono, croma, esperado700 }] of Object.entries(paletas(petroleo))) {
    const primary = rampa({ tono, croma, pasos: CURVA_PETROLEO })
    if (primary[700] !== esperado700) {
      throw new Error(
        `La paleta ${id} da ${primary[700]} en primary.700 y tiene que dar ${esperado700}. ` +
          'Si el cambio de tono o de croma es intencionado, actualiza esperado700 en derivar-paletas.mjs.',
      )
    }
    palette[id] = {
      _tono: Number(tono.toFixed(4)),
      _croma: Number(croma.toFixed(4)),
      color: { primary },
    }
  }

  const neutral = {}
  for (const [id, tinte] of Object.entries(TINTES)) {
    neutral[id] = {
      _tono: tinte.tono,
      _croma: tinte.croma,
      color: { neutral: grises({ anclas: { 100: anclas.grisClaro, 800: anclas.grisOscuro }, tinte }) },
    }
  }

  return {
    _doc:
      'Ramas primitivas que redefine cada valor de los ejes de color de la apariencia ' +
      '(src/apariencia.json). build.mjs las emite como bloques :root:where([data-palette=…]) y ' +
      'mide las 96 combinaciones con los mismos pares que la paleta por defecto.',
    _generado:
      'No editar a mano: lo produce `node derivar-paletas.mjs` desde src/brand.json y la curva ' +
      'de rampas.mjs. `node build.mjs --strict` lo regenera en memoria y falla si quedó desactualizado.',
    palette,
    accent: {
      monocromo: {
        _doc:
          'secondary.* cuelga de primary.*: cada paso es la mezcla de los dos pasos de primary con ' +
          'la luminancia de ese paso de la mandarina, para conservar sus contrastes (ver derivar-paletas.mjs).',
        color: { secondary: monocromo(marca) },
      },
    },
    neutral,
  }
}

/** Lo que se escribe en disco, byte a byte: build.mjs --strict lo compara con src/paletas.json. */
export const serializar = (paletas) => `${JSON.stringify(paletas, null, 2)}\n`

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const marca = JSON.parse(readFileSync(join(raiz, 'src', 'brand.json'), 'utf8'))
  const resultado = derivarPaletas(marca)
  for (const [id, { color }] of Object.entries(resultado.palette)) {
    console.log(`${id.padEnd(9)} ${Object.entries(color.primary).map(([k, v]) => `${k}:${v}`).join('  ')}`)
  }
  for (const [id, { color }] of Object.entries(resultado.neutral)) {
    console.log(`${id.padEnd(9)} ${Object.entries(color.neutral).map(([k, v]) => `${k}:${v}`).join('  ')}`)
  }
  writeFileSync(join(raiz, 'src', 'paletas.json'), serializar(resultado))
  console.log('\nsrc/paletas.json escrito.')
}

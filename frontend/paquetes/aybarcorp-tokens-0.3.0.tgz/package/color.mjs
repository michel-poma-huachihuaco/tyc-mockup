/**
 * Utilidades de color en OKLab. Sin dependencias: son 60 líneas y evitan traer una
 * librería de color a un paquete que solo emite JSON.
 *
 * OKLab y no HSL porque en HSL dos colores con la misma `L` tienen luminosidad
 * percibida distinta según el tono: una rampa hecha en HSL sale con escalones
 * visualmente irregulares y con contrastes que no se pueden predecir.
 * Referencia: Björn Ottosson, "A perceptual color space for image processing" (2020).
 */

const aLineal = (c) => (c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4)
const aGamma = (c) => (c <= 0.0031308 ? c * 12.92 : 1.055 * c ** (1 / 2.4) - 0.055)
const limitar = (x, min = 0, max = 1) => Math.min(max, Math.max(min, x))

export function hexARgb(hex) {
  const h = hex.replace('#', '')
  const n = h.length === 3 ? h.split('').map((c) => c + c).join('') : h
  return [0, 2, 4].map((i) => parseInt(n.slice(i, i + 2), 16) / 255)
}

export function rgbAHex([r, g, b]) {
  const a = (v) => Math.round(limitar(v) * 255).toString(16).padStart(2, '0')
  return `#${a(r)}${a(g)}${a(b)}`
}

export function rgbAOklab([r, g, b]) {
  const [R, G, B] = [aLineal(r), aLineal(g), aLineal(b)]
  const l = Math.cbrt(0.4122214708 * R + 0.5363325363 * G + 0.0514459929 * B)
  const m = Math.cbrt(0.2119034982 * R + 0.6806995451 * G + 0.1073969566 * B)
  const s = Math.cbrt(0.0883024619 * R + 0.2817188376 * G + 0.6299787005 * B)
  return [
    0.2104542553 * l + 0.793617785 * m - 0.0040720468 * s,
    1.9779984951 * l - 2.428592205 * m + 0.4505937099 * s,
    0.0259040371 * l + 0.7827717662 * m - 0.808675766 * s,
  ]
}

export function oklabARgb([L, a, b]) {
  const l = (L + 0.3963377774 * a + 0.2158037573 * b) ** 3
  const m = (L - 0.1055613458 * a - 0.0638541728 * b) ** 3
  const s = (L - 0.0894841775 * a - 1.291485548 * b) ** 3
  return [
    aGamma(limitar(4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s)),
    aGamma(limitar(-1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s)),
    aGamma(limitar(-0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s)),
  ]
}

export function hexAOklch(hex) {
  const [L, a, b] = rgbAOklab(hexARgb(hex))
  return { L, C: Math.hypot(a, b), h: Math.atan2(b, a) }
}

export function oklchAHex({ L, C, h }) {
  return rgbAHex(oklabARgb([L, C * Math.cos(h), C * Math.sin(h)]))
}

/**
 * Mezcla dos colores en OKLab: `peso` es la parte de `hexB`, de 0 a 1. Es la aritmética de
 * `color-mix(in oklab, A, B 30%)` para dos colores opacos —con opacidad 1 la premultiplicación
 * de la norma no cambia nada—, así que el hex que mide el contraste es el color que pinta el
 * navegador, con la diferencia de redondeo de un octeto.
 */
export function mezclar(hexA, hexB, peso) {
  if (!(peso >= 0 && peso <= 1)) throw new Error(`mezclar: el peso tiene que ir de 0 a 1 y vale ${peso}`)
  const [A, B] = [rgbAOklab(hexARgb(hexA)), rgbAOklab(hexARgb(hexB))]
  return rgbAHex(oklabARgb(A.map((v, i) => v + (B[i] - v) * peso)))
}

/**
 * Una capa de `hexCapa` con opacidad `opacidad` (0 a 1) pintada encima de `hexFondo`: la mezcla
 * «source-over» que hace el navegador al componer, canal a canal en sRGB con su gamma. Es el
 * color que ve quien lee un texto sobre una superficie translúcida —el vidrio de una Card— y
 * por eso es el que se mide: la capa sola no tiene contraste, porque no es opaca.
 */
export function componer(hexCapa, opacidad, hexFondo) {
  if (!(opacidad >= 0 && opacidad <= 1)) throw new Error(`componer: la opacidad tiene que ir de 0 a 1 y vale ${opacidad}`)
  const [capa, fondo] = [hexARgb(hexCapa), hexARgb(hexFondo)]
  return rgbAHex(capa.map((c, i) => opacidad * c + (1 - opacidad) * fondo[i]))
}

/** Luminancia relativa WCAG 2.1. */
export function luminancia(hex) {
  const [r, g, b] = hexARgb(hex).map(aLineal)
  return 0.2126 * r + 0.7152 * g + 0.0722 * b
}

/** Razón de contraste WCAG 2.1, de 1 a 21. */
export function contraste(hexA, hexB) {
  const [a, b] = [luminancia(hexA), luminancia(hexB)]
  return (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05)
}

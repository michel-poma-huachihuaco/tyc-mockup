# @aybarcorp/tokens

Fuente única de la identidad visual de Aybar Corp: emite CSS custom properties,
constantes tipadas, un preset de Tailwind, JSON plano y la paleta medida par a par desde
los mismos archivos de origen.

Forma parte del **framework Aybar**, un monorepo de diez paquetes que se publican
juntos y comparten siempre la misma versión. La arquitectura y las decisiones de diseño
están documentadas en el [repositorio](https://github.com/AybarCorp/aybar-framework-desing-frontEnd).

> Los diez se versionan en bloque, y se instalan con versión exacta. Mezclar versiones
> de `@aybarcorp/*` —o dejar una copia anidada bajo otra dependencia— pone dos módulos
> donde debía haber uno, y los contextos de React del anfitrión y del remoto dejan de
> coincidir: `useAnfitrion()` falla teniendo su Provider justo encima.
> `npx @aybarcorp/cli doctor` recorre `node_modules` en profundidad y lo detecta.

## Instalación

Requiere acceso a GitHub Packages: un `.npmrc` con `@aybarcorp:registry=https://npm.pkg.github.com` y un
token con permiso `read:packages`. No hay instalación anónima.

```bash
npm install @aybarcorp/tokens
```

La vía recomendada no es instalarlo a mano, sino dejar que el CLI cablee el proyecto:

```bash
npx @aybarcorp/cli init --papel app
```

## Uso

```js
import '@aybarcorp/tokens/css'     // las custom properties --aybar-*
import '@aybarcorp/tokens/fonts'   // Montserrat, como lo sirva este paquete
```

```ts
import { setTheme, token } from '@aybarcorp/tokens'
setTheme('dark')                   // sin argumento vuelve a seguir al sistema; no lo recuerda
token.colorActionPrimaryBg         // -> "var(--aybar-color-action-primary-bg)"
```

Con Tailwind, el preset expone los tokens semánticos como utilidades. Hay una variante
CommonJS para un `tailwind.config.js` que no sea ESM:

```js
import aybar from '@aybarcorp/tokens/tailwind'      // ESM
const aybar = require('@aybarcorp/tokens/tailwind') // CJS
export default { presets: [aybar], content: [...] }
```

### Los dos temas

Sin `data-theme` en `<html>`, la hoja sigue `prefers-color-scheme`; `setTheme('light')` o
`setTheme('dark')` lo fija. Los proyectos que genera el SDK siguen al sistema —su plantilla
no declara `data-theme` y el botón de tema fija claro u oscuro a mano— y `init` anota
`tema.predeterminado: "sistema"` en `aybar.config.json`, un campo que hoy no lee ningún
paquete del framework.

El oscuro saca el fondo, las superficies y los bordes de los grises de la marca
—`neutral.900` el lienzo, `neutral.850` la superficie, `neutral.800` la superficie elevada y
el borde sutil— y deja el petróleo para lo que lo necesita: acciones, enlaces y marca.
`neutral.850` (`#262626`) se agregó a la rampa para separar el lienzo de la tarjeta. Antes
fondo, superficies, bordes y texto salían de la rampa petróleo, y el oscuro se veía
saturado y denso.

### Los semánticos son referencias

`aybar.css` escribe cada semántico como referencia a su primitiva, no como el color que
resulta: `--aybar-color-action-primary-bg: var(--aybar-color-primary-700)`. Así, redefinir una
rama primitiva recolorea todo lo que cuelga de ella. En `src/semantic.json` un valor es una
referencia (`{color.primary.700}`) o una expresión sobre ellas:

| Fuente | En `aybar.css` | En `tokens.json` (`temas`) |
|---|---|---|
| `{color.primary.700}` | `var(--aybar-color-primary-700)` | `#02424E` |
| `alpha({color.primary.800}, 22%)` | `color-mix(in oklab, var(--aybar-color-primary-800) 22%, transparent)` | `rgb(2 50 59 / 0.22)` |
| `mix({a}, {b}, 30%)` | `color-mix(in oklab, var(--a), var(--b) 30%)` | el hex de la mezcla en OKLab |

`tokens.json` sigue trayendo en `temas` el valor resuelto, que es lo que mide el contraste, y
suma `referencias` con las expresiones CSS de cada tema. `pruebas/referencias.test.mjs` sigue
los `var()` del CSS emitido, bloque a bloque, y exige que lleguen a los mismos valores.

### Apariencia: paletas y ejes

Además del tema y la densidad, la hoja trae siete ejes de apariencia. Cada uno se elige con
un atributo en `<html>`; sin atributo vale el de por defecto.

| Eje | Atributo | Valores (el primero, por defecto) |
|---|---|---|
| Paleta | `data-palette` | `petroleo`, `oceano`, `jade`, `grafito` |
| Acento | `data-accent` | `mandarina`, `monocromo` |
| Grises | `data-neutral` | `neutro`, `calido`, `frio` |
| Radio | `data-radius` | `suave`, `recto`, `redondo` |
| Tipografía | `data-font` | `marca`, `sistema` |
| Profundidad | `data-depth` | `profundo`, `plano` |
| Estilo | `data-style` | `estandar`, `sobrio` |

```html
<html data-palette="oceano" data-neutral="frio">
```

- **Paletas.** Las cuatro usan la curva de luminosidad del petróleo; solo cambian el tono y el
  croma (`derivar-paletas.mjs` → `src/paletas.json`, generado y versionado). El 700 de cada una:
  `#02424e`, `#043d63`, `#00453a` y `#303d40`.
- **Acento monocromo.** `secondary.*` pasa a colgar de `primary.*`, pero no paso a paso: cada
  paso es la mezcla de los dos de `primary` con la luminancia de ese paso de la mandarina. Así
  conserva los contrastes que la mandarina ya medía. Con `secondary.600 = primary.600`, el
  botón de acento activo daba 2.45:1.
- **Radio, tipografía, profundidad y estilo** están en `src/modos.json`.
- **Profundidad.** `depth.*` describe la profundidad 3D que pintan Tilt, Parallax y el vidrio
  de `@aybarcorp/ui`: `perspective` (60rem), `tilt-max` (6deg), `parallax-shift` (1rem, lo que
  se mueve una capa de profundidad 1), `elevation` (1rem, lo que se acerca la superficie
  inclinada), `glass-blur` (0.75rem) y `glass-opacity` (88 %). `data-depth="plano"` deja la
  perspectiva en `none`, los ángulos y desplazamientos en cero y el vidrio opaco. La hoja hace
  lo mismo sola con `prefers-reduced-motion: reduce` (inclinación, paralaje y elevación) y con
  `prefers-reduced-transparency: reduce` (el vidrio), con los valores de la profundidad plana.
  La opacidad del vidrio es la que hace cumplir AA al texto por defecto y al atenuado sobre el
  vidrio compuesto encima de `bg-inverse`, el fondo contrario en cada tema: son cuatro de los
  112 pares medidos.
- **Estilo sobrio.** `data-style="sobrio"` baja `font.weight.display` (las cifras y los
  titulares grandes: Statistic, Stat Group, el código de Error Page) de 800 a 700 y pone a
  cero los `style.*` que decoran los rellenos de color: `fill-sheen` (el velo vertical, 8 %),
  `fill-edge` (el filo de luz, 14 %), `fill-shine` (el barrido del primario grande, 22 %),
  `fill-glow` (multiplicador de la sombra de color, 1) y `lift` (multiplicador de lo que suben
  botón y tarjeta al pasar, 1). Los componentes los consumen como porcentaje de `color-mix()`
  y como factor de `calc()`, sin literales. En oscuro, además, tiñe el lienzo, las superficies
  y el botón secundario con un 30 % del `primary` de la misma luminosidad (la hundida, un
  20 %): cambia el matiz, no el contraste. Sus 48 combinaciones se miden con todo lo demás.

Los bloques se emiten con `:root:where([data-…])` antes de la impresión: ganan a los temas por
orden y la impresión les sigue ganando. Los metadatos de los ejes (nombre visible, valor por
defecto, muestra) y los cuatro presets (Petróleo Aybar, Océano, Jade y Grafito sobrio) se
publican como `APPEARANCE`, con sus tipos (`PaletteId`, `AccentId`, `NeutralId`, `RadiusId`,
`FontId`, `StyleId` y `DepthId`):

```ts
import { APPEARANCE, type PaletteId } from '@aybarcorp/tokens'
APPEARANCE.axes.palette.values // [{ id: 'petroleo', label: 'Petróleo', swatch: '#02424e' }, …]
```

Cada build mide las **96 combinaciones** de los ejes de color (4 paletas × 2 acentos × 3 grises
× 2 estilos × 2 temas), con los mismos pares y bordes que la paleta por defecto, y no publica
si una no cumple AA. Si una paleta no cumple, se ajusta su croma, no el umbral.
`contraste.json` publica el resumen de cada una en `combinaciones`.

### El núcleo de apariencia: elegir, recordar y compartir

`@aybarcorp/tokens/apariencia` es el dueño de la apariencia en el navegador: hay un solo
estado por documento, en `document[Symbol.for('aybar.apariencia')]`. Lo comparten todas las
copias del paquete, la del anfitrión y las de cada remoto. Sobre él están `useTheme`,
`useDensity`, `usePalette` y `useAppearance` de `@aybarcorp/ui`, y `AyAppearanceService` de
`@aybarcorp/ui-angular`.

```ts
import {
  readAppearance, setPreference, resetAppearance, subscribeAppearance,
  configureAppearance, resolvedTheme, readColor,
} from '@aybarcorp/tokens/apariencia'

configureAppearance({ persist: true, storageKey: 'aybar:apariencia' }) // los de por omisión
setPreference('palette', 'oceano')    // aplica data-palette="oceano" y lo recuerda
readAppearance().palette              // 'oceano'
resolvedTheme()                       // 'light' | 'dark', con «system» resuelto
const dejar = subscribeAppearance((a) => console.log(a.theme))
resetAppearance()                     // olvida lo elegido: vuelve a lo que declara la página
readColor('color.action-primary-bg')  // '#043d63', aunque el token sea un color-mix()
```

- **Se recuerda por omisión.** Lo elegido se guarda en `localStorage['aybar:apariencia']` como
  `{ v: 1, … }`, validado contra `APPEARANCE`. Solo se guarda lo elegido a mano: elegir
  «system» como tema, o el valor que ya trae la página, quita la clave. `setTheme()` aplica el
  tema sin recordarlo.
- **Al iniciarse no escribe nada.** Parte de lo que declara `<html>` y solo aplica lo recordado.
- **Avisa con el evento `aybar:apariencia`** en `document`. Escucha `storage` para que lo
  elegido en una pestaña llegue a las demás, y `matchMedia` para el tema del sistema.
- **En SSR**, sin documento, devuelve los valores por defecto y no lanza.

Para que no parpadee al recargar, el script de arranque aplica lo recordado antes del primer
pintado. Es una IIFE sin dependencias y va en el `<head>`, antes de las hojas:

```html
<script src="/apariencia-arranque.js"></script>  <!-- copia de @aybarcorp/tokens/apariencia/arranque -->
```

Con otra clave, `data-storage-key="mi-app:apariencia"` en el `<script>`, y la misma en
`configureAppearance`.

### Densidad, móvil e impresión

La densidad es un modo, como el tema, y se elige en la raíz: `<html data-density="compact">`.
Redefine los tokens de control (`--aybar-control-height-*`, `--aybar-control-padding-*`,
`--aybar-control-gap`) y de densidad (`--aybar-density-row-height`,
`--aybar-density-section-gap`); los tamaños de fuente no cambian a propósito. Los valores
de `comfortable` están en `src/base.json` y los de `compact` en `src/density.json`, que
solo puede redefinir tokens que `base.json` ya declara: el build falla si no.

Los puntos de quiebre son `xs` 480px, `sm` 640px, `md` 768px, `lg` 1024px, `xl` 1280px y
`2xl` 1536px. `xs` es el más nuevo: lo pedía la rejilla de Layout (`--aybar-breakpoint-xs`)
y no existía, así que las rejillas de dos, tres y cuatro columnas se quedaban en una. Los
480px son una suposición: el diseño aprobado no fija ese valor.

Hasta `breakpoint.md` la separación de sección baja un paso, y al imprimir se reduce
otra vez. Al imprimir, además, la hoja fuerza el tema claro aunque la pantalla esté en
oscuro: un fondo oscuro en papel gasta tinta y deja el texto ilegible.

### El contraste medido, como dato

`verificar-contraste.mjs` mide en cada build los 112 pares de color que los componentes
pueden pintar —56 por tema— y los 30 bordes contra el fondo sobre el que se pintan, y falla
el build por debajo de 4.5:1 para texto y 3.0:1 para interfaz. Esos números salían por
consola y se perdían. Ahora el build los deja en `dist/contraste.json`, que es lo que
consume el catálogo de `npx @aybarcorp/cli docs`:

```js
import contraste from '@aybarcorp/tokens/contraste' with { type: 'json' }

contraste.umbrales            // { texto: 4.5, interfaz: 3 }
contraste.pares.length        // 112 — los que cumplen también, no solo los que fallan
contraste.bordes.length       // 30 — cada uno con `dibuja`, que es otra pregunta
contraste.prohibidos          // lo que el sistema descarta, con el número que lo descalifica
contraste.combinaciones       // 96 — el resumen de cada combinación de apariencia
```

| Bloque | Qué trae | Campo que decide |
|---|---|---|
| `pares` | `tema`, `frente`, `fondo`, `hexFrente`, `hexFondo`, `razon`, `umbral`, `para` | `cumple` — si alguno es `false`, el build no publica |
| `bordes` | `tema`, `borde`, `fondo`, `hexBorde`, `hexFondo`, `razon`, `donde` | `dibuja` — no es WCAG: es si el borde vale lo mismo que su fondo |
| `prohibidos` | los campos de `pares` más `porQue` | `cumple`, siempre `false` |
| `combinaciones` | `apariencia`, `tema`, `pares`, `bordes` y el par `ajustado` de cada una de las 96 | `cumplen` y `dibujan`, iguales a `pares` y `bordes` |

La lista y la aritmética están en `pares-contraste.mjs`, y de ahí las leen tanto el
verificador como el emisor: el catálogo no puede mostrar un contraste distinto del umbral
que de verdad corta el build, porque es el mismo número. El verificador además vuelve a
medir y compara con el archivo, así que un `contraste.json` editado a mano o heredado de un
build anterior detiene el build en lugar de publicar una paleta que ya no existe.

**`prohibidos` es el bloque que importa.** Son las combinaciones que la doctrina descarta
—blanco sobre la mandarina `#FFA726` del manual, 1.94:1, la que motivó que la mandarina no
sea color de acción— y que por eso no están en `pares`: medir como control algo que ya está
prohibido sería fallar el build a propósito. Sus razones se calculan de los tokens
resueltos, no se copian de `docs/IDENTIDAD.md`, y si alguna empezara a **cumplir** su
umbral el build también se para: una prohibición que la paleta actual desmiente hay que
reescribirla en el documento, no dejarla publicada. Un sistema de diseño que solo enseña lo
que funciona no impide que nadie pruebe lo que no.

### De dónde sale Montserrat

El manual prescribe Montserrat (OFL, se puede servir) y Proxima Nova (comercial, no se
empaqueta): ver [docs/IDENTIDAD.md](../../docs/IDENTIDAD.md). Montserrat se puede servir de
dos maneras y el paquete emite **las dos, con nombre propio**, más una copia de la que
quedó activa:

| Subpath | Archivo | Qué carga |
|---|---|---|
| `@aybarcorp/tokens/fonts` | `dist/fuentes.css` | La variante **activa de este build**: auto-hospedada si se generó, CDN si no |
| `@aybarcorp/tokens/fonts/cdn` | `dist/fuentes-cdn.css` | Siempre `fonts.googleapis.com`, aunque el paquete auto-hospede |
| `@aybarcorp/tokens/fonts/locales` | `dist/fuentes-locales.css` | Siempre los `.woff2` del paquete, y **nunca** una petición a un tercero |

`/fonts` es el que cablea `npx @aybarcorp/cli init` y el que conviene a casi todo el mundo. Los otros
dos existen para fijar la decisión desde el consumidor: `/cdn` para un entorno que no
puede servir binarios propios, y `/locales` para una app que no debe hablar con Google
bajo ninguna circunstancia —si el paquete instalado no auto-hospeda, ese subpath no
declara ninguna `@font-face` y la pantalla sale sin Montserrat, que es un fallo visible;
caer al CDN en silencio sería justo lo que se quiere evitar.

Para saber qué está sirviendo un paquete ya instalado, sin adivinar, la primera línea del
CSS lo dice y `dist/tokens.json` lo trae en `fuentes.modo`:

```bash
head -1 node_modules/@aybarcorp/tokens/dist/fuentes.css
# /* @aybar-fuentes modo=cdn caras=0 origen=fonts.googleapis.com activa=si
```

### Auto-hospedar (lo que conviene en producción)

Una dependencia de un CDN externo es una tercera parte que ve el tráfico de cada usuario
y un punto de fallo fuera de control. Para quitarla:

```bash
pip install 'fonttools[woff]'
node packages/tokens/generar-fuentes.mjs <ruta al directorio con los .ttf del manual>
node packages/tokens/build.mjs        # emite los @font-face y copia los .woff2 a dist/
git add packages/tokens/src/fonts     # se versionan una vez
```

Los `.woff2` viven en `src/fonts/`, **no** en `dist/`, y por eso el build no puede
pisarlos: `dist/` es derivado —está en `.gitignore`, `verificar-tarballs --limpio` lo
borra y el `prepack` de un runner recién clonado lo reconstruye—, así que un binario que
solo existiera ahí no sobreviviría a una publicación y el paquete volvería al CDN sin que
nadie lo pidiera. Es la misma regla que ya sigue `src/brand.json`: los generadores
escriben entradas del build, y el build es el único que escribe en `dist/`.

Del tarball se excluye `src/fonts` (`"!src/fonts"` en `files`) porque los mismos
binarios ya viajan en `dist/fonts/`; empaquetarlos dos veces es peso muerto en cada
instalación. Y `dist/fonts/` se rehace en cada build, así que no queda ningún `.woff2`
que ningún `@font-face` nombre.

`node build.mjs --strict` —el que usa CI al publicar— falla si el juego de caras está a
medias: con cuatro de los cinco pesos el navegador sintetiza el que falta y la tipografía
de la marca sale deformada sin ningún error en consola.

Los valores de marca no se editan a mano: `brand.json` lo genera `derivar-marca.mjs`
desde las seis anclas del manual de identidad, y el build falla si un ancla deja de
reproducirse en su paso o si algún par de color incumple WCAG 2.1 AA.

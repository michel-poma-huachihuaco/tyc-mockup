#!/usr/bin/env node
/**
 * Compila los tokens de Aybar a los cuatro formatos que consume el framework:
 *
 *   dist/aybar.css           custom properties — lo único que ve el shell Angular
 *   dist/index.js/.d.ts      constantes tipadas — lo que consumen los componentes React
 *   dist/tailwind-preset.js  preset — lo que consumen los remotos y el portal Next.js
 *   dist/tailwind-preset.cjs el mismo preset para un tailwind.config.js en CommonJS
 *   dist/tokens.json         plano y resuelto — insumo de auditoría y de Figma
 *   dist/contraste.json      la paleta medida par a par — insumo del catálogo `aybar-front docs`
 *
 * Y la tipografía, en dos variantes con nombre propio para que se distingan:
 *
 *   dist/fuentes-cdn.css     Montserrat desde fonts.googleapis.com — /fonts/cdn
 *   dist/fuentes-locales.css @font-face de los .woff2 de src/fonts/ — /fonts/locales
 *   dist/fonts/*.woff2       esas caras, copiadas desde src/fonts/ (solo si existen)
 *   dist/fuentes.css         copia de la variante activa — /fonts, el subpath de siempre
 *
 * aybar.css lleva, además de los dos temas, la densidad compacta (`data-density`, de
 * src/density.json), el paso de sección en móvil, los ejes de apariencia (`data-palette`,
 * `data-accent`, `data-neutral`, `data-radius`, `data-font`, `data-depth` y `data-style`, de
 * src/apariencia.json, src/paletas.json y src/modos.json), el papel claro de impresión y lo
 * que apagan prefers-reduced-motion y prefers-reduced-transparency.
 * Los metadatos de esos ejes salen como `APPEARANCE` en dist/apariencia-ejes.js.
 *
 * `node build.mjs --strict` falla si la marca sigue PROVISIONAL, si el juego de fuentes
 * auto-hospedadas está a medias o si src/paletas.json quedó atrás de la marca. CI lo usa al
 * publicar.
 */
import { readFileSync, writeFileSync, mkdirSync, copyFileSync, rmSync } from 'node:fs'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'

import { derivarPaletas, serializar } from './derivar-paletas.mjs'
import { aCss, resolver as resolverExpresion } from './expresiones.mjs'
import { DIR_FUENTES_DIST, caraCss, inventarioLocal } from './fuentes-comun.mjs'
import { aplanar, prepararApariencia, tokensDeCombinacion } from './origen-apariencia.mjs'
import { medir } from './pares-contraste.mjs'

const raiz = dirname(fileURLToPath(import.meta.url))
const src = (n) => JSON.parse(readFileSync(join(raiz, 'src', n), 'utf8'))
const estricto = process.argv.includes('--strict')

const base = src('base.json')
const brand = src('brand.json')
const semantic = src('semantic.json')
const densidad = src('density.json')

const PREFIJO = '--aybar'

const primitivas = { ...aplanar(base), ...aplanar(brand) }

/**
 * Resuelve `{color.primary.600}`, `alpha()` y `mix()` contra las primitivas, hasta el hex o
 * el `rgb(r g b / a)` final (expresiones.mjs). Detecta ciclos y referencias muertas.
 *
 * El valor resuelto es para tokens.json, el contraste y quien no tiene cascada. aybar.css
 * no lo usa: allí cada semántico se escribe como referencia (`var()`, `color-mix()`), para
 * que redefinir una rama primitiva —una paleta— recoloree todo lo que cuelga de ella.
 */
function resolver(valor, contexto) {
  try {
    return resolverExpresion(valor, (ref) => primitivas[ref], contexto)
  } catch (error) {
    throw new Error(`${error.message}. Los semánticos solo pueden nombrar tokens de base.json o de brand.json.`)
  }
}

/** Los semánticos tal como se escriben en semantic.json: referencias y expresiones. */
const fuenteTemas = {}
/** Y resueltos al color final. */
const temas = {}
for (const [tema, arbol] of Object.entries(semantic)) {
  if (tema.startsWith('_')) continue
  fuenteTemas[tema] = aplanar(arbol)
  temas[tema] = Object.fromEntries(
    Object.entries(fuenteTemas[tema]).map(([k, v]) => [k, resolver(v, `${tema}.${k}`)]),
  )
}
/** Lo que va a aybar.css: la misma fuente, escrita con `var()` y `color-mix()`. */
const referencias = Object.fromEntries(
  Object.entries(fuenteTemas).map(([tema, mapa]) => [
    tema,
    Object.fromEntries(Object.entries(mapa).map(([k, v]) => [k, aCss(v, `${tema}.${k}`)])),
  ]),
)
if (!temas.light || !temas.dark) {
  throw new Error('semantic.json debe declarar los temas `light` y `dark`')
}
const clavesLight = Object.keys(temas.light)
const faltanEnDark = clavesLight.filter((k) => !(k in temas.dark))
if (faltanEnDark.length) {
  throw new Error(`El tema oscuro no define: ${faltanEnDark.join(', ')}`)
}

/*
 * Densidad (ficha Foundations/Spacing): un modo, como el tema. base.json trae los valores
 * de comfortable; density.json solo puede redefinirlos. Un token que existiera solo en
 * compact dejaría a comfortable sin valor —var() vacío, el control sin alto— sin que nada
 * fallara, así que se corta aquí.
 */
const modosDensidad = {}
for (const [modo, arbol] of Object.entries(densidad)) {
  if (modo.startsWith('_')) continue
  const plano = aplanar(arbol)
  const ajenos = Object.keys(plano).filter((k) => !(k in primitivas))
  if (ajenos.length) {
    throw new Error(
      `density.json (${modo}) redefine tokens que base.json no declara: ${ajenos.join(', ')}. ` +
        'Declara primero el valor de comfortable en base.json.',
    )
  }
  modosDensidad[modo] = plano
}
for (const modo of ['compact', 'movil', 'impresion']) {
  if (!modosDensidad[modo]) throw new Error(`density.json debe declarar el bloque \`${modo}\``)
}

/*
 * Apariencia: paleta, acento, grises, radio, tipografía, profundidad y estilo. Cada valor que
 * no es el de por defecto redefine tokens —primitivas casi siempre— y se aplica con un
 * atributo en <html>. Como la densidad, solo puede redefinir tokens que ya existen: lo
 * comprueba prepararApariencia(), que comparte con verificar-contraste.mjs.
 */
const apariencia = prepararApariencia({
  apariencia: src('apariencia.json'),
  paletas: src('paletas.json'),
  modos: src('modos.json'),
  primitivas,
  semanticos: fuenteTemas,
})
const fuenteApariencia = { primitivas, semanticos: fuenteTemas, ...apariencia }

const varCss = (nombre) => `${PREFIJO}-${nombre.replace(/\./g, '-')}`
const bloque = (mapa, sangria) =>
  Object.entries(mapa)
    .map(([k, v]) => `${sangria}${varCss(k)}: ${v};`)
    .join('\n')

/** Un bloque de declaraciones escrito como referencias: los literales pasan tal cual. */
const bloqueCss = (mapa, sangria, contexto) =>
  bloque(Object.fromEntries(Object.entries(mapa).map(([k, v]) => [k, aCss(v, `${contexto} ${k}`)])), sangria)

/*
 * Un bloque por valor de cada eje, con `:root:where([data-…])`. El :where() deja la
 * especificidad en la de :root, así que el orden decide: estos bloques van después de los
 * temas y la densidad —redefinen primitivas que aquellos no tocan— y antes de la impresión,
 * que tiene que seguir ganando. Lo que depende del tema se repite combinado con
 * data-theme y con prefers-color-scheme, con la misma especificidad que el tema al que
 * corrige y declarado después.
 */
function bloquesDeApariencia() {
  const salida = []
  for (const [eje, definicion] of Object.entries(apariencia.ejes)) {
    for (const [valor, modo] of Object.entries(apariencia.modos[eje] ?? {})) {
      const sel = `:root:where([data-${eje}='${valor}'])`
      const nombre = definicion.values.find((v) => v.id === valor).label
      const contexto = `${eje}.${valor}`
      const vacio = [modo.primitivas, modo.temas.light, modo.temas.dark].every((m) => !Object.keys(m).length)
      const partes = []
      if (vacio) {
        partes.push(`${sel} {\n  /* Sin tokens todavía: el atributo ya se puede fijar y el bloque crece cuando los tenga. */\n}`)
      }
      if (Object.keys(modo.primitivas).length) {
        partes.push(`${sel} {\n${bloqueCss(modo.primitivas, '  ', contexto)}\n}`)
      }
      if (Object.keys(modo.temas.light).length) {
        partes.push(`${sel},\n${sel}[data-theme='light'] {\n${bloqueCss(modo.temas.light, '  ', contexto)}\n}`)
      }
      if (Object.keys(modo.temas.dark).length) {
        const oscuro = bloqueCss(modo.temas.dark, '    ', contexto)
        partes.push(`@media (prefers-color-scheme: dark) {\n  ${sel}:not([data-theme='light']) {\n${oscuro}\n  }\n}`)
        partes.push(`${sel}[data-theme='dark'] {\n${bloqueCss(modo.temas.dark, '  ', contexto)}\n}`)
      }
      salida.push(`/* ${definicion.label}: ${nombre} */\n${partes.join('\n\n')}`)
    }
  }
  return salida.join('\n\n')
}

/*
 * Las preferencias del sistema que apagan la profundidad 3D. Los valores no se repiten aquí:
 * son los de la profundidad plana (src/modos.json → depth.plano), que ya dice cuánto vale
 * «sin profundidad». Movimiento reducido apaga lo que se mueve (inclinación, paralaje y
 * elevación) y transparencia reducida, lo que deja ver el fondo (el vidrio). La perspectiva no
 * va en ninguno: sin ángulos no deforma nada.
 */
function deLaProfundidadPlana(claves, preferencia) {
  const plano = apariencia.modos.depth?.plano?.primitivas ?? {}
  const faltan = claves.filter((k) => !(k in plano))
  if (faltan.length) {
    throw new Error(
      `src/modos.json (depth.plano) no declara ${faltan.join(', ')}, que ${preferencia} necesita para apagar la profundidad.`,
    )
  }
  return Object.fromEntries(claves.map((k) => [k, plano[k]]))
}
const sinMovimiento = deLaProfundidadPlana(['depth.tilt-max', 'depth.parallax-shift', 'depth.elevation'], 'prefers-reduced-motion')
const sinTransparencia = deLaProfundidadPlana(['depth.glass-opacity', 'depth.glass-blur'], 'prefers-reduced-transparency')

const advertencia =
  brand._estado === 'PROVISIONAL'
    ? `\n * ADVERTENCIA: la identidad visual es PROVISIONAL. Los valores de marca son\n * neutros de sustitución, no la paleta aprobada de Aybar.\n`
    : ''

const css = `/**
 * @aybarcorp/tokens ${JSON.parse(readFileSync(join(raiz, 'package.json'), 'utf8')).version}
 * Generado por build.mjs — NO editar a mano. La fuente es packages/tokens/src/*.json.
 *${advertencia} */

:root {
  color-scheme: light dark;

  /* Primitivas: idénticas en ambos temas */
${bloque(primitivas, '  ')}

  /* Semánticos — tema claro. Referencias a las primitivas, no su valor: así una paleta que
     redefine una rama primitiva recolorea los dos temas sin repetir un solo semántico. */
${bloque(referencias.light, '  ')}
}

/* Preferencia del sistema, salvo que el usuario haya elegido claro explícitamente */
@media (prefers-color-scheme: dark) {
  :root:not([data-theme='light']) {
${bloque(referencias.dark, '    ')}
  }
}

/* Elección explícita: gana sobre la preferencia del sistema en ambas direcciones */
:root[data-theme='dark'] {
${bloque(referencias.dark, '    ')}
}

:root[data-theme='light'] {
${bloque(referencias.light, '    ')}
}

/* Densidad compacta: alturas, padding y gap. Los tamaños de fuente NO cambian. */
:root[data-density='compact'] {
${bloque(modosDensidad.compact, '  ')}
}

/* En móvil los valores de sección bajan un paso, declarados en el contenedor. */
@media (max-width: ${primitivas['breakpoint.md']}) {
  :root {
${bloque(modosDensidad.movil, '    ')}
  }
}

/* Apariencia (src/apariencia.json). Cada eje se elige con un atributo en <html>; sin
   atributo vale el de por defecto, que son los tokens de arriba. :where() deja estos bloques
   con la especificidad de :root: ganan por orden a lo anterior, y la impresión, que va
   después, les sigue ganando a ellos. */
${bloquesDeApariencia()}

/* Impresión. El papel es siempre claro, aunque la pantalla no lo sea: un fondo oscuro
   impreso gasta tinta y deja el texto ilegible en muchas impresoras. Los selectores
   repiten los del tema oscuro para ganarles por orden con la misma especificidad. */
@media print {
  :root,
  :root:not([data-theme='light']),
  :root[data-theme='dark'] {
    color-scheme: light;
${bloque(referencias.light, '    ')}
  }

  :root,
  :root[data-density='compact'] {
${bloque(modosDensidad.impresion, '    ')}
  }
}

/* Anillo de foco único del framework: accesibilidad no negociable. El contraste de
   border-focus contra lienzo y superficie está medido, no declarado — ver docs/IDENTIDAD.md. */
:where(a, button, input, select, textarea, summary, [tabindex]):focus-visible {
  outline: var(${PREFIJO}-focus-ring-width) solid var(${PREFIJO}-color-border-focus);
  outline-offset: var(${PREFIJO}-focus-ring-offset);
}

@media (prefers-reduced-motion: reduce) {
  :root {
    ${PREFIJO}-motion-duration-fast: 0ms;
    ${PREFIJO}-motion-duration-base: 0ms;
    ${PREFIJO}-motion-duration-slow: 0ms;
    /* La profundidad 3D también es movimiento: la de la profundidad plana. */
${bloque(sinMovimiento, '    ')}
  }
}

/* Transparencia reducida: el vidrio es una superficie opaca, como en la profundidad plana. */
@media (prefers-reduced-transparency: reduce) {
  :root {
${bloque(sinTransparencia, '    ')}
  }
}
`

/* --- constantes tipadas: los componentes usan var(), nunca el hex resuelto --- */
const identificador = (n) => n.replace(/[.-](\w)/g, (_, c) => c.toUpperCase()).replace(/\./g, '')
const constantes = {}
for (const nombre of [...Object.keys(primitivas), ...clavesLight]) {
  constantes[identificador(nombre)] = `var(${varCss(nombre)})`
}

/*
 * --- los metadatos de la apariencia: APPEARANCE ----------------------------------------
 *
 * Lo que un panel de apariencia necesita para pintarse sin escribir a mano ningún valor:
 * los ejes, sus valores con nombre visible, el de por defecto y una muestra. La muestra es
 * una referencia a un token (`swatch` en apariencia.json) resuelta con los tokens de ese
 * valor, así que el hex de Océano sale de su paleta y no de una copia. Va en un módulo
 * aparte, dist/apariencia-ejes.js, porque lo importan tanto index.js como el núcleo de
 * apariencia, y ninguno de los dos debe importar al otro.
 */
function metadatosDeApariencia() {
  const axes = {}
  for (const [id, eje] of Object.entries(apariencia.ejes)) {
    axes[id] = {
      attribute: eje.attribute,
      label: eje.label,
      description: eje.description,
      default: eje.default,
      values: eje.values.map((v) => {
        if (!eje.swatch) return { id: v.id, label: v.label }
        const { primitivas: tokens } = tokensDeCombinacion(fuenteApariencia, { [id]: v.id })
        const muestra = resolverExpresion(eje.swatch, (ref) => tokens[ref], `${id}.${v.id} (swatch)`)
        return { id: v.id, label: v.label, swatch: muestra.startsWith('#') ? muestra.toLowerCase() : muestra }
      }),
    }
  }
  const presets = apariencia.presets.map(({ id, label, values }) => ({ id, label, values }))
  return { axes, presets }
}
const APPEARANCE = metadatosDeApariencia()

/** El tipo de los valores de cada eje: `PaletteId`, `AccentId`… El del tema es el de siempre. */
const TIPO_DE_EJE = { theme: 'ThemePreference', density: 'DensityId' }
const tipoDeEje = (eje) => TIPO_DE_EJE[eje] ?? `${eje[0].toUpperCase()}${eje.slice(1)}Id`
const union = (valores) => valores.map((v) => `'${v}'`).join(' | ')

const ejesJs = `// Generado por build.mjs — NO editar a mano. La fuente es src/apariencia.json.
const congelar = (valor) => {
  if (valor && typeof valor === 'object') {
    for (const hijo of Object.values(valor)) congelar(hijo)
    Object.freeze(valor)
  }
  return valor
}

/** Los ejes de la apariencia y sus presets: lo que pinta un panel de apariencia. */
export const APPEARANCE = congelar(${JSON.stringify(APPEARANCE, null, 2)})
`

const ejesDts = `// Generado por build.mjs — NO editar a mano. La fuente es src/apariencia.json.
${Object.entries(APPEARANCE.axes)
  .map(([eje, { values, label }]) => `/** ${label}: los valores de \`${eje}\`. */\nexport type ${tipoDeEje(eje)} = ${union(values.map((v) => v.id))}`)
  .join('\n')}

/** El valor elegido en cada eje. */
export interface AppearanceValues {
${Object.keys(APPEARANCE.axes).map((eje) => `  readonly ${eje}: ${tipoDeEje(eje)}`).join('\n')}
}
/** Un eje de la apariencia: \`theme\`, \`palette\`, \`radius\`… */
export type AppearanceAxis = keyof AppearanceValues
/** Un preset: ${APPEARANCE.presets.map((p) => p.label).join(', ')}. */
export type AppearancePresetId = ${union(APPEARANCE.presets.map((p) => p.id))}

/** Un valor de un eje, con su nombre visible y, si el eje la tiene, su muestra (un hex o un valor CSS). */
export interface AppearanceOption<V extends string = string> {
  readonly id: V
  readonly label: string
  readonly swatch?: string
}
/** Un eje: el atributo de <html> que lo aplica, su valor por defecto y sus valores. */
export interface AppearanceAxisMeta<V extends string = string> {
  readonly attribute: string
  readonly label: string
  readonly description: string
  readonly default: V
  readonly values: readonly AppearanceOption<V>[]
}
/** Un preset fija los ejes de color a la vez. */
export interface AppearancePreset {
  readonly id: AppearancePresetId
  readonly label: string
  readonly values: Partial<AppearanceValues>
}
/** Los ejes de la apariencia y sus presets, con las muestras ya resueltas. */
export declare const APPEARANCE: {
  readonly axes: { readonly [A in AppearanceAxis]: AppearanceAxisMeta<AppearanceValues[A]> }
  readonly presets: readonly AppearancePreset[]
}
`

/*
 * El script de arranque: src/apariencia-arranque.js con los ejes dentro. No importa nada
 * —corre en el <head>, antes que cualquier módulo—, así que los ejes van escritos en él.
 */
const ejesDeArranque = Object.fromEntries(
  Object.entries(APPEARANCE.axes).map(([id, eje]) => [
    id,
    { atributo: eje.attribute, porDefecto: eje.default, valores: eje.values.map((v) => v.id) },
  ]),
)
const plantillaArranque = readFileSync(join(raiz, 'src', 'apariencia-arranque.js'), 'utf8')
if (!plantillaArranque.includes('/*EJES*/ {}')) {
  throw new Error('src/apariencia-arranque.js perdió el marcador /*EJES*/ {} donde build.mjs escribe los ejes')
}
const arranque = `// Generado por build.mjs — NO editar a mano. La fuente es src/apariencia-arranque.js.\n${plantillaArranque.replace(
  '/*EJES*/ {}',
  JSON.stringify(ejesDeArranque),
)}`

const js = `// Generado por build.mjs — NO editar a mano.
import { setPreference } from './apariencia.js'

export { APPEARANCE } from './apariencia-ejes.js'

export const token = ${JSON.stringify(constantes, null, 2)}

/**
 * Aplica un tema explícito. Sin argumento vuelve a seguir la preferencia del sistema.
 * Delega en el núcleo de apariencia (@aybarcorp/tokens/apariencia) sin recordarlo: para que
 * se recuerde al recargar, setPreference('theme', …).
 */
export function setTheme(tema) {
  setPreference('theme', tema ?? 'system', { persist: false })
}
`

const dts = `// Generado por build.mjs — NO editar a mano.
export declare const token: {
${Object.keys(constantes).map((k) => `  readonly ${k}: string`).join('\n')}
}
export type TokenName = keyof typeof token
export type Theme = 'light' | 'dark'
export declare function setTheme(tema?: Theme): void
export { APPEARANCE } from './apariencia-ejes.js'
export type {
${[...Object.keys(APPEARANCE.axes).map(tipoDeEje), 'AppearanceValues', 'AppearanceAxis', 'AppearancePresetId', 'AppearanceOption', 'AppearanceAxisMeta', 'AppearancePreset'].map((t) => `  ${t},`).join('\n')}
} from './apariencia-ejes.js'
`

/* --- preset de Tailwind: expone los semánticos, no los hex --- */
const agrupar = (prefijo) =>
  Object.fromEntries(
    clavesLight
      .filter((k) => k.startsWith(`color.${prefijo}`))
      .map((k) => [k.replace(`color.${prefijo}-`, ''), `var(${varCss(k)})`]),
  )

const preset = `// Generado por build.mjs — NO editar a mano.
export default {
  theme: {
    extend: {
      colors: {
        bg: ${JSON.stringify(agrupar('bg'), null, 8)},
        fg: ${JSON.stringify(agrupar('fg'), null, 8)},
        border: ${JSON.stringify(agrupar('border'), null, 8)},
        action: ${JSON.stringify(agrupar('action'), null, 8)},
        feedback: ${JSON.stringify(agrupar('feedback'), null, 8)}
      },
      spacing: ${JSON.stringify(mapVar(base.space, 'space'), null, 8)},
      borderRadius: ${JSON.stringify(mapVar(base.radius, 'radius'), null, 8)},
      fontSize: ${JSON.stringify(mapVar(base.font.size, 'font.size'), null, 8)},
      fontWeight: ${JSON.stringify(mapVar(base.font.weight, 'font.weight'), null, 8)},
      fontFamily: ${JSON.stringify(mapVar(brand.family, 'family'), null, 8)},
      boxShadow: ${JSON.stringify(mapVar(semantic.light.shadow, 'shadow'), null, 8)},
      zIndex: ${JSON.stringify(mapVar(base.z, 'z'), null, 8)}
    }
  }
}
`
function mapVar(nodo, prefijo) {
  return Object.fromEntries(
    Object.keys(nodo)
      .filter((k) => !k.startsWith('_'))
      .map((k) => [k, `var(${varCss(`${prefijo}.${k}`)})`]),
  )
}

const dist = join(raiz, 'dist')
mkdirSync(dist, { recursive: true })
writeFileSync(join(dist, 'aybar.css'), css)

// Los subpaths de hoja de estilos (./css, ./fonts y sus dos variantes) declaran este
// .d.ts en su condicion `types`. Sin el, TypeScript 6 rechaza con TS2882 los imports de
// efecto que `aybar-front init` escribe en el punto de entrada del consumidor. El porque
// completo esta en el propio archivo.
writeFileSync(
  join(dist, 'hoja-de-estilos.d.ts'),
  readFileSync(join(raiz, 'src', 'hoja-de-estilos.d.ts'), 'utf8'),
)
writeFileSync(join(dist, 'index.js'), js)
writeFileSync(join(dist, 'index.d.ts'), dts)
writeFileSync(join(dist, 'apariencia-ejes.js'), ejesJs)
writeFileSync(join(dist, 'apariencia-ejes.d.ts'), ejesDts)
// El núcleo de apariencia se escribe a mano en src/ y se publica tal cual: no tiene nada que
// generar, y así se lee y se prueba como el JavaScript que es.
copyFileSync(join(raiz, 'src', 'apariencia.js'), join(dist, 'apariencia.js'))
copyFileSync(join(raiz, 'src', 'apariencia.d.ts'), join(dist, 'apariencia.d.ts'))
writeFileSync(join(dist, 'apariencia-arranque.js'), arranque)
// Un import de efecto (`import '@aybarcorp/tokens/apariencia/arranque'`) necesita tipos con
// TypeScript 6, igual que las hojas de estilo.
writeFileSync(join(dist, 'apariencia-arranque.d.ts'), 'export {}\n')
writeFileSync(join(dist, 'tailwind-preset.js'), preset)
// Gemelo CommonJS. El paquete es `type: module`, así que un tailwind.config.js en CJS
// —que sigue siendo el que genera la mayoría de las plantillas— no puede hacer
// `require` del preset ESM: falla con ERR_REQUIRE_ESM y el mensaje no señala la causa.
// Se emite desde la misma fuente para que no haya dos presets que se desincronicen.
writeFileSync(
  join(dist, 'tailwind-preset.cjs'),
  preset.replace('export default {', 'module.exports = {'),
)
/* --- tipografía: dos variantes con nombre propio, y una copia de la activa -------
 *
 * El build es el ÚNICO que escribe en dist/. `generar-fuentes.mjs` escribe los .woff2 en
 * src/fonts/, así que este paso no puede pisar su trabajo: lo lee, igual que lee los
 * .json que produce derivar-marca.mjs. Antes el generador escribía un dist/fuentes.css
 * que el build sobrescribía con el @import al CDN, y nadie se enteraba hasta ver las
 * peticiones a fonts.googleapis.com en producción.
 *
 * Y las dos variantes se emiten con nombres distintos porque antes compartían nombre:
 * mirar dist/fuentes.css no decía si el paquete auto-hospedaba o no sin leerse el
 * contenido y compararlo con dos posibles orígenes. Ahora el modo está en la primera
 * línea de cada archivo (`@aybar-fuentes modo=…`), en el nombre del archivo y en
 * dist/tokens.json.
 */
function emitirFuentes() {
  const { caras, faltantes, ajenos } = inventarioLocal()
  const modo = caras.length ? 'locales' : 'cdn'

  // dist/fonts/ se rehace en cada build: un .woff2 que sobra de un build anterior
  // —o de la época en que el generador escribía aquí— viajaría en el tarball sin que
  // ningún @font-face lo nombre, que es peso muerto en cada instalación.
  rmSync(DIR_FUENTES_DIST, { recursive: true, force: true })

  // Sin espacio suelto al final de las líneas vacías del comentario.
  const cabecera = (lineas) =>
    `/* ${lineas[0]}\n${lineas
      .slice(1)
      .map((l) => (l ? ` * ${l}` : ' *'))
      .join('\n')}\n */\n`

  const cuerpoCdn = readFileSync(join(raiz, 'src', 'fuentes-cdn.css'), 'utf8')

  let cuerpoLocales
  if (caras.length) {
    mkdirSync(DIR_FUENTES_DIST, { recursive: true })
    for (const cara of caras) copyFileSync(cara.ruta, join(DIR_FUENTES_DIST, cara.archivo))
    // Un @font-face por cara que existe de verdad, y por ninguna más: el src/ se lee del
    // disco en vez de darse por supuesto, así que no puede quedar una referencia muerta.
    cuerpoLocales = `${caras.map((c) => caraCss(c.peso)).join('\n\n')}\n`
  } else {
    cuerpoLocales = cabecera([
      'src/fonts/ no trae ningún .woff2, así que esta variante no declara ninguna cara.',
      '',
      'No hay @font-face a propósito: uno que apunte a un archivo ausente es una',
      'referencia muerta que el navegador resuelve en silencio sintetizando la',
      'tipografía, y caer al CDN desde aquí sería reintroducir la dependencia que este',
      'subpath existe para quitar. Importar este archivo tal cual no carga Montserrat.',
      '',
      'Para poblarlo:',
      "  node generar-fuentes.mjs <ruta a los .ttf del manual>   # escribe src/fonts/",
      '  node build.mjs                                          # emite los @font-face',
    ])
  }

  const variantes = {
    cdn: {
      archivo: 'fuentes-cdn.css',
      cuerpo: cuerpoCdn,
      marca: 'modo=cdn caras=0 origen=fonts.googleapis.com',
      nota: 'Sirve Montserrat desde un CDN externo: un tercero ve el tráfico de cada usuario.',
    },
    locales: {
      archivo: 'fuentes-locales.css',
      cuerpo: cuerpoLocales,
      marca: `modo=locales caras=${caras.length} origen=./fonts/`,
      nota: caras.length
        ? 'Sirve Montserrat desde el propio dominio: ninguna petición a un tercero.'
        : 'Sin caras generadas: no declara ninguna @font-face. Ver el cuerpo del archivo.',
    },
  }

  for (const [nombre, v] of Object.entries(variantes)) {
    writeFileSync(
      join(dist, v.archivo),
      cabecera([
        `@aybar-fuentes ${v.marca}`,
        'Generado por build.mjs — NO editar a mano.',
        `Subpath: @aybarcorp/tokens/fonts/${nombre}`,
        v.nota,
      ]) + v.cuerpo,
    )
  }

  // dist/fuentes.css es la variante activa, no una tercera versión: el subpath /fonts
  // que ya consume el CLI sigue funcionando y ahora dice en su cabecera qué está
  // sirviendo. Se copia el cuerpo en lugar de hacer @import de la variante para no
  // encadenar una segunda descarga antes del primer @font-face.
  const activa = variantes[modo]
  writeFileSync(
    join(dist, 'fuentes.css'),
    cabecera([
      `@aybar-fuentes ${activa.marca} activa=si`,
      'Generado por build.mjs — NO editar a mano. Copia de la variante activa de este build:',
      `@aybarcorp/tokens/fonts == @aybarcorp/tokens/fonts/${modo}`,
      activa.nota,
      modo === 'cdn'
        ? 'Para auto-hospedar: node generar-fuentes.mjs <ruta a los .ttf> && node build.mjs'
        : 'Para volver al CDN en un consumidor concreto: importar @aybarcorp/tokens/fonts/cdn',
    ]) + activa.cuerpo,
  )

  return { modo, caras, faltantes, ajenos }
}

const fuentes = emitirFuentes()

writeFileSync(
  join(dist, 'tokens.json'),
  JSON.stringify(
    {
      primitivas,
      temas,
      // Los mismos semánticos tal como los escribe aybar.css: `var()` y `color-mix()`. `temas`
      // dice qué color sale; `referencias`, de qué primitiva cuelga y por eso qué lo recolorea.
      referencias,
      // Los modos de densidad no son temas —no cambian color— y por eso no van en
      // `temas`: el catálogo recorre `temas` para su conmutador claro/oscuro.
      densidad: modosDensidad,
      marca: { estado: brand._estado ?? 'APROBADA' },
      // En el artefacto de auditoría porque "¿este paquete llama a Google?" es una
      // pregunta que se hace desde fuera del repo, sobre un tarball ya instalado.
      fuentes: {
        modo: fuentes.modo,
        caras: fuentes.caras.map((c) => ({ peso: c.peso, archivo: `fonts/${c.archivo}` })),
      },
    },
    null,
    2,
  ),
)

/* --- la paleta medida: el mismo dato que corta el build, como archivo ------------
 *
 * `verificar-contraste.mjs` medía los pares y los bordes en cada build, decidía si el build
 * pasaba, y lo imprimía por consola y lo olvidaba. El catálogo de `aybar-front docs` necesita
 * esos mismos números; recalcularlos en el CLI sería una segunda implementación del
 * umbral que de verdad corta el build, y se desincronizaría en el primer cambio de marca.
 *
 * Así que la lista y la aritmética están en pares-contraste.mjs y este build las ejecuta
 * una vez: lo que se escribe aquí es exactamente lo que el verificador vuelve a medir y a
 * comparar con este archivo antes de dejar publicar. El catálogo no puede enseñar un
 * contraste que el build no respalde, porque es el mismo número.
 *
 * Incluye los pares que CUMPLEN, no solo los que fallan —un catálogo que solo enseña
 * problemas no sirve para elegir un color— y un tercer bloque, `prohibidos`, con las
 * combinaciones que la doctrina descarta (blanco sobre la mandarina del manual, y las
 * demás) con la razón recalculada, no copiada del documento: un sistema de diseño que
 * enseña lo que no se puede hacer, con el número que lo descalifica, evita que alguien lo
 * intente.
 */
const contraste = medir(temas, primitivas, fuenteApariencia)
writeFileSync(join(dist, 'contraste.json'), `${JSON.stringify(contraste, null, 2)}\n`)

const total = Object.keys(primitivas).length + clavesLight.length
console.log(`@aybarcorp/tokens · ${total} tokens (${Object.keys(primitivas).length} primitivas, ${clavesLight.length} semánticos × 2 temas)`)

console.log(
  `contraste · ${contraste.pares.length} pares medidos, ${contraste.bordes.length} bordes comprobados y ` +
    `${contraste.prohibidos.length} combinaciones prohibidas → dist/contraste.json`,
)
{
  const { combinaciones } = contraste
  const enAA = combinaciones.filter((c) => c.cumplen === c.pares && c.dibujan === c.bordes).length
  const peor = [...combinaciones].sort((x, y) => x.ajustado.razon / x.ajustado.umbral - y.ajustado.razon / y.ajustado.umbral)[0]
  console.log(
    `apariencia · ${combinaciones.length} combinaciones medidas, ${enAA} cumplen AA y dibujan todos sus bordes; ` +
      `la más ajustada: ${peor.ajustado.razon.toFixed(2)}:1 (min ${peor.ajustado.umbral}) · ${peor.ajustado.para} · ` +
      `${Object.values(peor.apariencia).join('/')} ${peor.tema}`,
  )
}

const kb = (fuentes.caras.reduce((suma, c) => suma + c.bytes, 0) / 1024).toFixed(1)
console.log(
  fuentes.modo === 'locales'
    ? `fuentes · modo LOCALES · ${fuentes.caras.length} caras (${kb} kB) de src/fonts/ → dist/fonts/`
    : `fuentes · modo CDN · fonts.googleapis.com · src/fonts/ está vacío`,
)

/* --- lo que no se publica ---------------------------------------------------------
 * Los controles se acumulan y se informan juntos: en modo normal son avisos, y con
 * --strict ninguno deja publicar. Fallar en el primero escondería los demás.
 */
const bloqueantes = []

if (brand._estado === 'PROVISIONAL') {
  bloqueantes.push({
    mensaje:
      'La identidad visual es PROVISIONAL: packages/tokens/src/brand.json no tiene los valores del manual de marca.',
    motivo: 'Una versión no se publica con marca provisional.',
  })
}

// Un juego a medias es peor que ninguno: el navegador sintetiza los pesos ausentes a
// partir de los presentes y la tipografía de la marca sale deformada, sin ningún error.
if (fuentes.caras.length && fuentes.faltantes.length) {
  bloqueantes.push({
    mensaje: `Fuentes auto-hospedadas incompletas: src/fonts/ trae ${fuentes.caras.length} de ${
      fuentes.caras.length + fuentes.faltantes.length
    } caras; faltan los pesos ${fuentes.faltantes.join(', ')}.`,
    motivo:
      'El navegador sintetizaría los pesos ausentes. Regenera el juego completo:\n       node generar-fuentes.mjs <ruta a los .ttf del manual>',
  })
}

// src/paletas.json se versiona generado. Si la marca o la curva cambiaron y nadie corrió
// derivar-paletas.mjs, las paletas alternativas serían las de la marca anterior: se regenera
// en memoria y se compara byte a byte con lo que hay en disco.
const paletasAlDia = serializar(derivarPaletas(brand))
if (readFileSync(join(raiz, 'src', 'paletas.json'), 'utf8') !== paletasAlDia) {
  bloqueantes.push({
    mensaje: 'src/paletas.json no corresponde a la marca ni a la curva actuales (rampas.mjs).',
    motivo: 'Las paletas alternativas serían las de una marca anterior. Regenera:\n       node derivar-paletas.mjs',
  })
}

if (fuentes.ajenos.length) {
  console.warn(
    `AVISO  src/fonts/ tiene archivos que ningún peso de base.json reclama y que no se empaquetan: ${fuentes.ajenos.join(', ')}`,
  )
}

if (bloqueantes.length) {
  if (estricto) {
    for (const b of bloqueantes) console.error(`\nERROR  ${b.mensaje}\n       ${b.motivo}`)
    console.error('')
    process.exit(1)
  }
  for (const b of bloqueantes) console.warn(`AVISO  ${b.mensaje}`)
}

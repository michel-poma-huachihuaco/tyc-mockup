#!/usr/bin/env node
/**
 * Deriva src/brand.json desde las anclas del Manual de Identidad Corporativa Aybar 2023.
 *
 * Existe como script y no como JSON escrito a mano para que la procedencia sea
 * auditable: cada rampa sale de un color del manual, y el script FALLA si un paso
 * ancla no reproduce exactamente el hex del manual. Así nadie "ajusta a ojo" el
 * color corporativo sin que se note.
 *
 * Fuente: BRANDBOOK DIGITAL LIGERO 2023 - Aybar Corp, pág. 27 (principal),
 * pág. 29 (secundario), pág. 31 (complementarios), pág. 36 (escala de grises).
 */
import { writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { CURVA_MANDARINA, CURVA_PETROLEO, anclar, funcional, grises, rampa } from './rampas.mjs'

// Las rutas se resuelven contra el script, no contra el cwd: el README documenta
// invocarlo desde la raíz del repo y así no escribe un src/brand.json donde no va.
const raiz = dirname(fileURLToPath(import.meta.url))

/*
 * Cómo se construye una rampa —la curva, el control de continuidad de las anclas, los
 * grises y los funcionales— vive en rampas.mjs, compartido con derivar-paletas.mjs: las
 * paletas de la apariencia usan la misma curva que la marca y no pueden divergir de ella.
 */

/** Colores del manual. Ninguno se toca: son la marca. */
const MANUAL = {
  principal: '#02424E',      // "azul verdoso" · pág. 27
  secundario: '#FFA726',     // "naranja mandarina" · pág. 29
  complNaranja: '#D37A07',   // pág. 31
  complTeal: '#02323B',      // pág. 31
  grisOscuro: '#2F2F2F',     // pág. 36
  grisClaro: '#F6F6F6',      // pág. 36
}

/**
 * Paso exacto donde va cada ancla. Fuente: docs/IDENTIDAD.md, tabla «Colores del manual»,
 * que cita las páginas del brandbook.
 *
 * El paso es parte del ancla, no un detalle de la rampa. `semantic.json` referencia pasos
 * concretos —`bg-brand` y `action-primary-bg` son `{color.primary.700}`—, así que mover
 * `ancla: MANUAL.principal` de 700 a 500 dejaría el hex presente en la rampa, la
 * verificación contenta, y el botón primario pintado de otro azul. Comprobar solo que el
 * hex aparezca «en alguna parte» no verifica nada de lo que importa.
 */
const PASOS_ANCLA = {
  principal: 'primary.700',
  secundario: 'secondary.400',
  complNaranja: 'secondary.600',
  complTeal: 'primary.800',
  grisOscuro: 'neutral.800',
  grisClaro: 'neutral.100',
}

/* Anclas del manual en su paso natural por luminosidad:
   #02424E L=0.349 → 700 · #02323B L=0.292 → 800
   #FFA726 L=0.797 → 400 · #D37A07 L=0.663 → 600
   #F6F6F6 L=0.973 → 100 · #2F2F2F L=0.305 → 800                              */

const petroleo = rampa({
  hueDe: MANUAL.principal,
  pasos: anclar(CURVA_PETROLEO, { 700: MANUAL.principal, 800: MANUAL.complTeal }),
})

const mandarina = rampa({
  hueDe: MANUAL.secundario,
  pasos: anclar(CURVA_MANDARINA, { 400: MANUAL.secundario, 600: MANUAL.complNaranja }),
})

/**
 * Grises puros: el manual los da sin matiz y no se les inventa uno. La luminosidad de cada
 * paso, y por qué existen el 450, el 650 y el 850, está en CURVA_GRIS (rampas.mjs); el 100 y
 * el 800 son los grises del manual, copiados literales.
 */
const neutral = grises({ anclas: { 100: MANUAL.grisClaro, 800: MANUAL.grisOscuro } })

const marca = {
  _doc: 'Identidad visual de Aybar Corp. ÚNICO archivo que cambia si cambia la marca.',
  _estado: 'APROBADA',
  _fuente:
    'BRANDBOOK DIGITAL LIGERO 2023 - Aybar Corp · principal pág. 27, secundario pág. 29, ' +
    'complementarios pág. 31, grises pág. 36, tipografía págs. 21 y 23.',
  _generado:
    'No editar a mano: lo produce `node derivar-marca.mjs`. Las anclas del manual se ' +
    'copian literales y el script falla si un paso ancla no las reproduce.',
  _anclas: MANUAL,
  color: {
    neutral,
    primary: petroleo,
    secondary: mandarina,
    success: funcional(150, 0.15),
    warning: funcional(85, 0.16),
    danger: funcional(28, 0.17),
    info: petroleo,
  },
  family: {
    // El manual prescribe Montserrat para títulos (Bold) y subtítulos (Regular), pág. 21.
    heading: "'Montserrat', system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif",
    // Y Proxima Nova para cuerpos de texto, pág. 23. El framework NO empaqueta sus
    // archivos: los .otf del manual son licencia de escritorio, no de web. Se declara
    // primera en la pila para que resuelva donde exista licencia (kit de Adobe Fonts),
    // y cae a Montserrat, que sí es OFL y sí se puede servir.
    // Guía visual v2: entre Proxima Nova (sin licencia web todavía) y Montserrat va Figtree,
    // OFL y de la misma familia geométrica-humanista: Montserrat es ancha para leer párrafos.
    sans: "'Proxima Nova', 'Figtree', 'Montserrat', system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif",
    mono: "ui-monospace, 'SFMono-Regular', Menlo, Consolas, monospace",
  },
}

const linea = (n, r) =>
  `${n.padEnd(10)} ${Object.entries(r).map(([k, v]) => `${k}:${v}`).join('  ')}`
console.log('Rampas derivadas del manual:\n')
console.log(linea('petroleo', petroleo))
console.log(linea('mandarina', mandarina))
console.log(linea('neutral', neutral))
const RAMPAS = { primary: petroleo, secondary: mandarina, neutral }

console.log('\nAnclas del manual, en el paso que el manual les da:')
for (const [nombre, hex] of Object.entries(MANUAL)) {
  const paso = PASOS_ANCLA[nombre]
  if (!paso) {
    throw new Error(`El ancla ${nombre} (${hex}) no declara su paso en PASOS_ANCLA`)
  }
  const [familia, escalon] = paso.split('.')
  const valor = RAMPAS[familia]?.[escalon]
  if (!valor) {
    throw new Error(`El ancla ${nombre} declara el paso ${paso}, que no existe en las rampas`)
  }
  if (valor.toLowerCase() !== hex.toLowerCase()) {
    throw new Error(
      `El ancla ${nombre} debe reproducir ${hex} en ${paso}, pero ahí hay ${valor}. ` +
        'semantic.json referencia pasos concretos, así que mover un ancla de paso publica ' +
        'un color de marca equivocado aunque el hex siga apareciendo en otro escalón.',
    )
  }
  // Que aparezca además en otro paso no es un fallo, pero conviene verlo: significa que
  // la rampa tiene dos escalones del mismo color y por tanto un tramo plano.
  const otros = Object.entries(RAMPAS)
    .flatMap(([f, r]) => Object.entries(r).map(([k, v]) => [`${f}.${k}`, v]))
    .filter(([k, v]) => k !== paso && v.toLowerCase() === hex.toLowerCase())
    .map(([k]) => k)
  console.log(
    `  ${hex}  ${nombre.padEnd(14)} → ${paso}${otros.length ? `  (repetido en ${otros.join(', ')})` : ''}`,
  )
}

// Se escribe al final, después de que las anclas hayan pasado: si el archivo se generara
// antes, un fallo dejaría en disco un brand.json con el color de marca equivocado y el
// siguiente build lo consumiría sin volver a derivarlo.
writeFileSync(join(raiz, 'src', 'brand.json'), `${JSON.stringify(marca, null, 2)}\n`)
console.log('\nsrc/brand.json escrito.')

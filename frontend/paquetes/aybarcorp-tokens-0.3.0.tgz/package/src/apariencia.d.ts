/**
 * El núcleo de apariencia de @aybarcorp/tokens: un estado por documento, compartido por todas
 * las copias del paquete (anfitrión y remotos), recordado en localStorage y sincronizado
 * entre pestañas. Ver src/apariencia.js.
 */
import type { AppearanceAxis, AppearanceValues } from './apariencia-ejes.js'

export { APPEARANCE } from './apariencia-ejes.js'
export type {
  AccentId,
  AppearanceAxis,
  AppearanceAxisMeta,
  AppearanceOption,
  AppearancePreset,
  AppearancePresetId,
  AppearanceValues,
  DensityId,
  DepthId,
  FontId,
  NeutralId,
  PaletteId,
  RadiusId,
  StyleId,
  ThemePreference,
} from './apariencia-ejes.js'

/** El tema que se ve: «system» ya resuelto. */
export type ResolvedTheme = 'light' | 'dark'

/** El evento que avisa de un cambio, en `document`. Su `detail` trae `appearance` y `resolvedTheme`. */
export declare const APPEARANCE_EVENT: 'aybar:apariencia'

/** Los valores por defecto de cada eje: lo que se ve sin atributos ni preferencias (y en SSR). */
export declare const DEFAULT_APPEARANCE: AppearanceValues

/** La apariencia vigente. Devuelve el mismo objeto, congelado, hasta que algo cambia. */
export declare function readAppearance(): AppearanceValues

/** El tema que se ve, con «system» resuelto por prefers-color-scheme. En SSR, `light`. */
export declare function resolvedTheme(): ResolvedTheme

export interface SetPreferenceOptions {
  /** `false` aplica sin recordar: lo que hace `setTheme()`. Por omisión se recuerda. */
  readonly persist?: boolean
}

/**
 * Elige un valor, lo aplica en `<html>` y lo recuerda. Elegir «system» como tema, o el valor
 * que ya trae la página, quita la clave. Devuelve `false` si el eje o el valor no existen (y
 * los ignora) o si no hay documento.
 */
export declare function setPreference<A extends AppearanceAxis>(
  axis: A,
  value: AppearanceValues[A],
  options?: SetPreferenceOptions,
): boolean

/** Olvida lo elegido y vuelve a lo que declara la página (o a los valores por defecto). */
export declare function resetAppearance(): void

/** Avisa de cada cambio, venga de donde venga. Devuelve la función que deja de escuchar. */
export declare function subscribeAppearance(listener: (appearance: AppearanceValues) => void): () => void

export interface AppearanceConfig {
  /** Recordar lo elegido en localStorage. Por omisión, `true`. */
  readonly persist?: boolean
  /** La clave de localStorage. Por omisión, `aybar:apariencia`. */
  readonly storageKey?: string
}

/** Configura el recuerdo. Conviene llamarla al arrancar, antes de leer nada. */
export declare function configureAppearance(config?: AppearanceConfig): void

/**
 * El color final de un token como `#rrggbb` (`'color.action-primary-bg'` o
 * `'--aybar-color-action-primary-bg'`), aunque sea un `color-mix()`. La opacidad se descarta.
 * Devuelve `''` si el token no existe o no es un color.
 */
export declare function readColor(token: string): string

/**
 * Declaración de tipos de una hoja de estilos que se importa por su efecto.
 *
 * No describe una API: un `import '@aybarcorp/tokens/css'` no trae ningún valor. Existe
 * porque TypeScript 6 rechaza un import de efecto cuyo especificador no resuelve a
 * ningún tipo —error TS2882, «Cannot find module or type declarations for side-effect
 * import»—, y las tres líneas que `aybar-front init` escribe en el punto de entrada son
 * exactamente eso. Sin este archivo, `tsc` falla en un proyecto recién instalado.
 *
 * TypeScript 5.9 no daba el error y por eso no se vio antes: este monorepo pinea 5.9.3
 * en todos sus paquetes, así que su propio `typecheck` pasaba mientras el consumidor
 * —cuya plantilla de Vite ya trae TypeScript 6— no compilaba. Se descubrió corriendo
 * `init` sin `--dry-run` contra el registro, no leyendo el código.
 *
 * `export {}` es lo que lo convierte en módulo. Un .d.ts sin ningún export es un script
 * global, y un import de efecto contra un script global vuelve a no resolver a nada.
 */
export {}

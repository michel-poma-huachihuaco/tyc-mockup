/**
 * El núcleo de apariencia de @aybarcorp/tokens (`@aybarcorp/tokens/apariencia`): tema,
 * densidad, paleta, acento, grises, radio, tipografía, profundidad y estilo, con un solo dueño
 * por documento y recordados en el navegador.
 *
 * Por qué existe. Antes cada pieza guardaba lo suyo: `useTheme` tenía la preferencia en una
 * variable del módulo de React, `useDensity` en un estado de cada componente (y al montarse
 * escribía `comfortable` encima de un `compact` declarado), el servicio de Angular la suya, y
 * nada se recordaba al recargar. Con microfrontends es peor: el anfitrión y cada remoto
 * cargan su propia copia de estos paquetes, y dos copias con dos estados se contradicen.
 *
 *   Estado      uno por documento, en `document[Symbol.for('aybar.apariencia')]`. Symbol.for
 *               es el registro global de símbolos: todas las copias del módulo —la del
 *               anfitrión y las de los remotos— llegan al mismo objeto.
 *   Aviso       el evento `aybar:apariencia` en `document`. Quien se suscribe con una copia se
 *               entera de lo que cambia otra.
 *   Recuerdo    `localStorage['aybar:apariencia']`, `{ v: 1, … }`. Solo lo elegido a mano: elegir
 *               «system» como tema, o el valor que ya trae la página, quita la clave, para que
 *               un cambio de los valores por defecto llegue a quien nunca eligió nada.
 *   Pestañas    el evento `storage`: lo que se elige en una pestaña llega a las demás.
 *   Sistema     `matchMedia('(prefers-color-scheme: dark)')`: con el tema en «system», quien
 *               se suscribe se entera de que el tema resuelto cambió.
 *
 * Los atributos se escriben en `<html>`: el valor por defecto de un eje no lleva atributo
 * (`data-theme` ausente es «system», que la hoja resuelve con prefers-color-scheme) y los
 * demás sí (`data-palette="oceano"`). Al iniciarse no escribe nada que la página no haya
 * elegido: lee lo declarado en `<html>` y solo aplica lo recordado.
 *
 * Sin documento (SSR) todo devuelve los valores por defecto y nada lanza.
 */
import { APPEARANCE } from './apariencia-ejes.js'

export { APPEARANCE }

const ESTADO = Symbol.for('aybar.apariencia')
/** Lo que la página declaraba en <html> antes de que el script de arranque aplicara lo recordado. */
const DECLARADO = Symbol.for('aybar.apariencia.declarado')
/** El evento que avisa de un cambio, en `document`. */
export const APPEARANCE_EVENT = 'aybar:apariencia'
const VERSION = 1
const CLAVE_POR_DEFECTO = 'aybar:apariencia'

const EJES = Object.keys(APPEARANCE.axes)

/** Los valores por defecto de cada eje: lo que se ve sin atributos ni preferencias. */
export const DEFAULT_APPEARANCE = Object.freeze(
  Object.fromEntries(EJES.map((eje) => [eje, APPEARANCE.axes[eje].default])),
)

const hayDocumento = () => typeof document !== 'undefined' && document !== null && !!document.documentElement

function esValido(eje, valor) {
  if (typeof valor !== 'string' || !Object.prototype.hasOwnProperty.call(APPEARANCE.axes, eje)) return false
  return APPEARANCE.axes[eje].values.some((v) => v.id === valor)
}

/** El estado del documento; lo crea la primera copia del módulo que lo pide. */
function almacen() {
  let a = document[ESTADO]
  if (!a) {
    a = {
      version: VERSION,
      config: { persist: true, storageKey: CLAVE_POR_DEFECTO },
      iniciado: false,
      /** Lo que declara la página: el punto al que vuelve `resetAppearance()`. */
      base: null,
      /** Lo elegido a mano, que es lo único que se recuerda. */
      elegido: {},
      /** Lo que se ve: `base` con lo elegido encima. Congelado: cambia de identidad al cambiar. */
      estado: null,
      sistema: null,
      lienzo: undefined,
    }
    Object.defineProperty(document, ESTADO, { value: a, configurable: true })
  }
  return a
}

function iniciar(a) {
  if (a.iniciado) return a
  a.iniciado = true
  a.base = Object.freeze(declarado())
  a.elegido = a.config.persist ? leerGuardado(a.config.storageKey) : {}
  a.estado = Object.freeze({ ...a.base, ...a.elegido })
  aplicar(a.estado)
  const ventana = document.defaultView
  if (ventana) {
    ventana.addEventListener('storage', (evento) => sincronizar(a, evento))
    if (typeof ventana.matchMedia === 'function') {
      a.sistema = ventana.matchMedia('(prefers-color-scheme: dark)')
      // Solo avisa si el tema sigue al sistema: si está fijado, el sistema no cambia nada.
      a.sistema?.addEventListener?.('change', () => {
        if (a.estado.theme === 'system') emitir(a)
      })
    }
  }
  return a
}

/** Lo que la página declara en <html>, o lo que el script de arranque vio antes de tocarlo. */
function declarado() {
  const registrado = document[DECLARADO]
  const raiz = document.documentElement
  const base = {}
  for (const eje of EJES) {
    const { attribute, default: porDefecto } = APPEARANCE.axes[eje]
    const valor = registrado ? registrado[eje] : raiz.getAttribute(attribute)
    base[eje] = esValido(eje, valor) ? valor : porDefecto
  }
  return base
}

/** Escribe en <html> solo los atributos que cambian: menos ruido para quien observa data-theme. */
function aplicar(estado) {
  const raiz = document.documentElement
  for (const eje of EJES) {
    const { attribute, default: porDefecto } = APPEARANCE.axes[eje]
    const deseado = estado[eje] === porDefecto ? null : estado[eje]
    if (raiz.getAttribute(attribute) === deseado) continue
    if (deseado === null) raiz.removeAttribute(attribute)
    else raiz.setAttribute(attribute, deseado)
  }
}

function emitir(a) {
  const Evento = document.defaultView?.CustomEvent ?? globalThis.CustomEvent
  if (typeof Evento !== 'function') return
  document.dispatchEvent(
    new Evento(APPEARANCE_EVENT, { detail: { appearance: a.estado, resolvedTheme: temaResuelto(a) } }),
  )
}

/** Cambia los ejes indicados, los aplica y avisa. No toca lo recordado. */
function actualizar(a, cambios) {
  const siguiente = { ...a.estado, ...cambios }
  if (EJES.every((eje) => siguiente[eje] === a.estado[eje])) return
  a.estado = Object.freeze(siguiente)
  aplicar(a.estado)
  emitir(a)
}

/** El almacenamiento puede no existir, estar lleno o lanzar al tocarlo (modo privado, iframes). */
function almacenamiento() {
  try {
    return document.defaultView?.localStorage ?? null
  } catch {
    return null
  }
}

function leerGuardado(clave) {
  try {
    const crudo = almacenamiento()?.getItem(clave)
    if (!crudo) return {}
    const datos = JSON.parse(crudo)
    if (!datos || typeof datos !== 'object' || datos.v !== VERSION) return {}
    const elegido = {}
    for (const eje of EJES) if (esValido(eje, datos[eje])) elegido[eje] = datos[eje]
    return elegido
  } catch {
    return {}
  }
}

function guardar(a) {
  if (!a.config.persist) return
  try {
    const destino = almacenamiento()
    if (!destino) return
    if (Object.keys(a.elegido).length) destino.setItem(a.config.storageKey, JSON.stringify({ v: VERSION, ...a.elegido }))
    else destino.removeItem(a.config.storageKey)
  } catch {
    // Sin espacio o sin permiso: la elección se aplica igual, solo que no se recuerda.
  }
}

/** Vuelve a leer lo recordado y aplica solo los ejes que cambiaron ahí. */
function releer(a) {
  const nuevo = leerGuardado(a.config.storageKey)
  const cambios = {}
  for (const eje of EJES) {
    if (a.elegido[eje] !== nuevo[eje]) cambios[eje] = nuevo[eje] ?? a.base[eje]
  }
  a.elegido = nuevo
  actualizar(a, cambios)
}

function sincronizar(a, evento) {
  if (!a.config.persist) return
  // key null es un localStorage.clear() en otra pestaña.
  if (evento.key !== null && evento.key !== a.config.storageKey) return
  releer(a)
}

function temaResuelto(a) {
  const tema = a.estado.theme
  if (tema === 'light' || tema === 'dark') return tema
  return a.sistema?.matches ? 'dark' : 'light'
}

/** La apariencia vigente. El mismo objeto (congelado) hasta que algo cambia. */
export function readAppearance() {
  if (!hayDocumento()) return DEFAULT_APPEARANCE
  return iniciar(almacen()).estado
}

/** El tema que se ve: «system» resuelto con prefers-color-scheme. */
export function resolvedTheme() {
  if (!hayDocumento()) return 'light'
  return temaResuelto(iniciar(almacen()))
}

/**
 * Elige un valor en un eje, lo aplica en <html> y lo recuerda. Un eje o un valor que no están
 * en APPEARANCE se ignoran y devuelve `false`. Con `{ persist: false }` se aplica sin
 * recordarlo, que es lo que hace `setTheme()`.
 */
export function setPreference(eje, valor, opciones = {}) {
  if (!esValido(eje, valor) || !hayDocumento()) return false
  const a = iniciar(almacen())
  if (opciones.persist !== false && a.config.persist) {
    const elegido = { ...a.elegido }
    // Elegir lo que la página ya trae —«system», o el valor por defecto— no es una elección
    // que haya que recordar: se quita la clave.
    if (valor === a.base[eje]) delete elegido[eje]
    else elegido[eje] = valor
    a.elegido = elegido
    guardar(a)
  }
  actualizar(a, { [eje]: valor })
  return true
}

/** Olvida lo elegido y vuelve a lo que declara la página (o a los valores por defecto). */
export function resetAppearance() {
  if (!hayDocumento()) return
  const a = iniciar(almacen())
  a.elegido = {}
  guardar(a)
  actualizar(a, { ...a.base })
}

/**
 * Avisa de cada cambio, venga de esta copia del módulo, de otra o de otra pestaña. Devuelve
 * la función que deja de escuchar.
 */
export function subscribeAppearance(escucha) {
  if (!hayDocumento()) return () => {}
  iniciar(almacen())
  const manejador = () => escucha(readAppearance())
  document.addEventListener(APPEARANCE_EVENT, manejador)
  return () => document.removeEventListener(APPEARANCE_EVENT, manejador)
}

/**
 * Configura el recuerdo. Conviene llamarla antes de leer nada (al arrancar la aplicación):
 * con `persist: false` no se lee ni se escribe localStorage; `storageKey` cambia la clave.
 */
export function configureAppearance({ persist = true, storageKey = CLAVE_POR_DEFECTO } = {}) {
  if (!hayDocumento()) return
  const a = almacen()
  const anterior = a.config
  a.config = { persist: persist !== false, storageKey: typeof storageKey === 'string' && storageKey ? storageKey : CLAVE_POR_DEFECTO }
  if (a.iniciado && a.config.persist && (!anterior.persist || anterior.storageKey !== a.config.storageKey)) releer(a)
}

/**
 * El color final de un token como `#rrggbb`: `readColor('color.action-primary-bg')` o
 * `readColor('--aybar-color-action-primary-bg')`. Para quien pinta fuera de CSS —un visor 3D,
 * un canvas— y necesita un hex aunque el token sea un `color-mix()` o un `oklch()`: el
 * navegador lo normaliza pintándolo en un lienzo de 1×1. La opacidad se descarta. Devuelve
 * '' si el token no existe o no es un color.
 */
export function readColor(token) {
  if (!hayDocumento() || typeof token !== 'string') return ''
  const nombre = token.startsWith('--') ? token : `--aybar-${token.replace(/\./g, '-')}`
  const valor = document.defaultView?.getComputedStyle(document.documentElement).getPropertyValue(nombre).trim()
  if (!valor) return ''
  const hex = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(valor)
  if (hex) {
    const digitos = hex[1].length === 3 ? [...hex[1]].map((c) => c + c).join('') : hex[1]
    return `#${digitos.toLowerCase()}`
  }
  const a = almacen()
  if (a.lienzo === undefined) a.lienzo = crearLienzo()
  const contexto = a.lienzo
  if (!contexto) return ''
  // Un color que el lienzo no entiende deja fillStyle como estaba: se detecta con un testigo.
  const testigo = '#010203'
  contexto.fillStyle = testigo
  contexto.fillStyle = valor
  if (String(contexto.fillStyle).toLowerCase() === testigo && valor.toLowerCase() !== testigo) return ''
  contexto.clearRect(0, 0, 1, 1)
  contexto.fillRect(0, 0, 1, 1)
  const [r, g, b] = contexto.getImageData(0, 0, 1, 1).data
  return `#${[r, g, b].map((c) => c.toString(16).padStart(2, '0')).join('')}`
}

function crearLienzo() {
  try {
    const lienzo = document.createElement('canvas')
    lienzo.width = 1
    lienzo.height = 1
    return lienzo.getContext('2d', { willReadFrequently: true }) ?? null
  } catch {
    return null
  }
}

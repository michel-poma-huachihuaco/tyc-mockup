/**
 * El mini-lenguaje de los valores de src/semantic.json y de los modos de apariencia.
 *
 *   {color.primary.700}                                 referencia a otro token
 *   alpha({color.primary.800}, 22%)                     ese color con un 22% de opacidad
 *   mix({color.neutral.900}, {color.primary.900}, 30%)  el primero con un 30% del segundo, en OKLab
 *
 * Una expresión se lee una vez y se escribe de dos maneras, que tienen que decir lo mismo:
 *
 *   aCss()      lo que va a aybar.css: `var()` y `color-mix()`. El valor queda enlazado a su
 *               primitiva, así que redefinir una rama primitiva —una paleta, unos grises—
 *               recolorea todo lo que cuelga de ella sin repetir un solo semántico. Con el hex
 *               escrito en su lugar, cambiar `--aybar-color-primary-700` no movía nada.
 *   resolver()  el valor final: hex, o `rgb(r g b / a)` si lleva opacidad. Es lo que mide el
 *               contraste, lo que va a tokens.json y lo que lee quien no tiene cascada (Figma,
 *               el catálogo de `aybar-front docs`).
 *
 * pruebas/referencias.test.mjs sigue los `var()` del CSS emitido y comprueba que llegan al
 * mismo valor que tokens.json: si las dos salidas se separaran, el contraste estaría
 * midiendo una paleta que el navegador no pinta.
 *
 * Fuera de alpha() y mix() el texto pasa tal cual, de modo que una sombra puede llevar una
 * expresión dentro de su lista: `0 8px 24px -10px alpha({color.primary.800}, 22%)`.
 */
import { hexARgb, mezclar } from './color.mjs'

const ARIDAD = { alpha: 2, mix: 3 }
const ES_HEX = /^#(?:[0-9a-f]{3}|[0-9a-f]{6})$/i

/** El nombre de la custom property de un token: `color.primary.700` → `--aybar-color-primary-700`. */
export const varDe = (nombre) => `--aybar-${nombre.replace(/\./g, '-')}`

/** Convierte el texto en nodos: texto literal, referencias y llamadas a alpha() o mix(). */
export function analizar(texto, contexto = texto) {
  let i = 0
  const fallar = (motivo) => {
    throw new Error(`Expresión inválida en ${contexto}: ${motivo} («${texto}»)`)
  }

  /** Lee nodos hasta encontrar, fuera de paréntesis, uno de los caracteres de `hasta`. */
  function nodos(hasta = '') {
    const salida = []
    let literal = ''
    const volcar = () => {
      if (literal) salida.push({ tipo: 'texto', valor: literal })
      literal = ''
    }
    while (i < texto.length) {
      const c = texto[i]
      if (hasta.includes(c)) break
      if (c === '{') {
        const fin = texto.indexOf('}', i)
        if (fin < 0) fallar('una llave sin cerrar')
        volcar()
        salida.push({ tipo: 'ref', nombre: texto.slice(i + 1, fin).trim() })
        i = fin + 1
        continue
      }
      const llamada = /^(alpha|mix)\(/.exec(texto.slice(i))
      if (llamada && !/[\w-]/.test(texto[i - 1] ?? '')) {
        volcar()
        i += llamada[0].length
        const args = []
        for (;;) {
          args.push(recortar(nodos(',)')))
          if (texto[i] === ',') {
            i++
            continue
          }
          if (texto[i] === ')') {
            i++
            break
          }
          fallar(`${llamada[1]}() sin cerrar`)
        }
        if (args.length !== ARIDAD[llamada[1]]) {
          fallar(`${llamada[1]}() recibe ${ARIDAD[llamada[1]]} argumentos y tiene ${args.length}`)
        }
        const porcentaje = porcentajeDe(args.at(-1), llamada[1], fallar)
        salida.push(
          llamada[1] === 'alpha'
            ? { tipo: 'alpha', color: args[0], porcentaje }
            : { tipo: 'mix', a: args[0], b: args[1], porcentaje },
        )
        continue
      }
      if (c === '(') {
        // Un paréntesis literal —el `rgb(11 31 35 / 0.05)` de una sombra— se copia entero:
        // sus comas no separan argumentos.
        let profundidad = 0
        do {
          if (texto[i] === '(') profundidad++
          else if (texto[i] === ')') profundidad--
          literal += texto[i++]
        } while (profundidad > 0 && i < texto.length)
        if (profundidad > 0) fallar('un paréntesis sin cerrar')
        continue
      }
      literal += c
      i++
    }
    volcar()
    return salida
  }

  const resultado = nodos()
  if (i < texto.length) fallar(`un «${texto[i]}» que sobra`)
  return resultado
}

/** Quita el espacio de los bordes de un argumento: `alpha( {x} , 22% )` vale lo mismo. */
function recortar(lista) {
  const copia = lista.map((n) => ({ ...n }))
  if (copia[0]?.tipo === 'texto') copia[0].valor = copia[0].valor.trimStart()
  if (copia.at(-1)?.tipo === 'texto') copia.at(-1).valor = copia.at(-1).valor.trimEnd()
  return copia.filter((n) => n.tipo !== 'texto' || n.valor)
}

function porcentajeDe(arg, funcion, fallar) {
  const texto = arg.length === 1 && arg[0].tipo === 'texto' ? arg[0].valor : ''
  const m = /^(\d+(?:\.\d+)?)%$/.exec(texto)
  if (!m) fallar(`el último argumento de ${funcion}() es un porcentaje, como 22%`)
  const valor = Number(m[1])
  if (valor > 100) fallar(`${funcion}() no admite más de 100%`)
  return valor
}

/** La forma CSS: `var()` para las referencias y `color-mix(in oklab, …)` para alpha() y mix(). */
export function aCss(valor, contexto) {
  return escribirCss(analizar(valor, contexto))
}

function escribirCss(nodos) {
  return nodos
    .map((n) => {
      if (n.tipo === 'texto') return n.valor
      if (n.tipo === 'ref') return `var(${varDe(n.nombre)})`
      if (n.tipo === 'alpha') {
        return `color-mix(in oklab, ${escribirCss(n.color)} ${n.porcentaje}%, transparent)`
      }
      return `color-mix(in oklab, ${escribirCss(n.a)}, ${escribirCss(n.b)} ${n.porcentaje}%)`
    })
    .join('')
}

/** ¿El valor lleva alguna referencia o expresión, o es un literal? */
export const esExpresion = (valor) => /[{]|(?:^|[^\w-])(?:alpha|mix)\(/.test(valor)

/**
 * Resuelve el valor a su forma final. `buscar(nombre)` devuelve el valor crudo de un token
 * —que a su vez puede ser una expresión— o `undefined` si no existe. Detecta ciclos y
 * referencias muertas, como hacía el resolutor de build.mjs.
 *
 * Una referencia suelta devuelve el valor tal cual está declarado (`#02424E`, con sus
 * mayúsculas): tokens.json no cambia por pasar de hex a referencia. alpha() da
 * `rgb(r g b / a)` con dos decimales, que es como estaban escritos los literales que sustituye,
 * y mix() da el hex en minúsculas.
 */
export function resolver(valor, buscar, contexto, vistos = new Set()) {
  const resolverNodos = (nodos) => nodos.map((n) => resolverNodo(n)).join('')
  const color = (nodos, funcion) => {
    const hex = resolverNodos(nodos).trim()
    if (!ES_HEX.test(hex)) {
      throw new Error(`${funcion}() en ${contexto} necesita un color hex y recibió «${hex}»`)
    }
    return hex
  }
  function resolverNodo(n) {
    if (n.tipo === 'texto') return n.valor
    if (n.tipo === 'ref') {
      if (vistos.has(n.nombre)) throw new Error(`Referencia cíclica en ${contexto}: {${n.nombre}}`)
      const destino = buscar(n.nombre)
      if (destino === undefined) throw new Error(`Referencia muerta en ${contexto}: {${n.nombre}} no existe`)
      return resolver(destino, buscar, contexto, new Set([...vistos, n.nombre]))
    }
    if (n.tipo === 'alpha') {
      const [r, g, b] = hexARgb(color(n.color, 'alpha')).map((c) => Math.round(c * 255))
      return `rgb(${r} ${g} ${b} / ${opacidad(n.porcentaje)})`
    }
    return mezclar(color(n.a, 'mix'), color(n.b, 'mix'), n.porcentaje / 100)
  }
  return resolverNodos(analizar(valor, contexto))
}

/** 22 → «0.22», 30 → «0.30»: dos decimales como los literales; más solo si el porcentaje los trae. */
function opacidad(porcentaje) {
  return Number.isInteger(porcentaje) ? (porcentaje / 100).toFixed(2) : String(porcentaje / 100)
}

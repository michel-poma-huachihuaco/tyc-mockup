/**
 * La lista de combinaciones que la interfaz puede pintar, y la medición de todas.
 *
 * Por qué este módulo existe aparte del verificador. Los mismos 112 pares y los mismos 30
 * bordes los necesitan dos consumidores: `verificar-contraste.mjs`, que corta el build por
 * debajo del umbral, y `build.mjs`, que emite `dist/contraste.json` para que el catálogo de
 * `aybar-front docs` muestre el número de cada par. Con la lista duplicada en los dos sitios, el
 * catálogo acabaría publicando una paleta que el build ya no mide —o midiendo un umbral que
 * el catálogo no refleja— y nadie se enteraría, porque las dos mitades pasarían por su
 * cuenta. Aquí la lista es una, la aritmética es una, y el archivo emitido es su resultado.
 *
 * Tres bloques, que no hay que confundir:
 *
 *   PARES       contraste WCAG 2.1 AA. Tiene umbral y decide si el build pasa.
 *   BORDES      control estructural: que el borde no valga lo mismo que su fondo. No tiene
 *               umbral porque la pregunta no es "¿se distingue bastante?" sino "¿se
 *               distingue en absoluto?".
 *   PROHIBIDOS  combinaciones que la doctrina descarta y que por eso NO están en PARES.
 *               No son un control: son documentación ejecutable. Se miden para que el
 *               catálogo enseñe el número que las descalifica en lugar de repetir una cifra
 *               copiada a mano de un documento.
 */
import { componer, contraste } from './color.mjs'
import { combinacionesMedidas, resolverCombinacion } from './origen-apariencia.mjs'

/**
 * Los dos umbrales de WCAG 2.1 AA que aplican aquí. Se nombran una sola vez y de aquí
 * salen tanto la columna `umbral` de cada par como el bloque `umbrales` del JSON emitido:
 * el catálogo no puede mostrar un umbral distinto del que corta el build.
 *
 *   texto     4.5:1 — texto normal (1.4.3)
 *   interfaz  3.0:1 — texto grande, bordes y componentes de interfaz (1.4.3, 1.4.11)
 *
 * Los controles deshabilitados están exentos por la propia norma y no se miden.
 */
export const UMBRALES = { texto: 4.5, interfaz: 3.0 }

const { texto, interfaz } = UMBRALES

/**
 * El vidrio (Card surface="glass" y .ay-glass) no es un color: es bg-surface con la opacidad
 * depth.glass-opacity, y lo que se lee es esa capa compuesta encima de lo que haya detrás. Se
 * mide como un fondo compuesto, «capa al opacidad sobre fondo», resuelto con la misma mezcla
 * que hace el navegador (componer(), en color.mjs).
 *
 * Detrás se pone bg-inverse, y no el lienzo: es por definición el fondo contrario al texto en
 * cada tema —petróleo 800 en claro, gris 100 en oscuro—, el más desfavorable que el sistema
 * pinta. Cubre la banda de marca, una foto oscura en claro o una clara en oscuro y las formas
 * decorativas de un Parallax; si el texto cumple aquí, cumple sobre cualquier fondo del
 * sistema. Es lo que fija depth.glass-opacity (88 %): con menos, el texto atenuado del oscuro
 * no llega a 4.5:1. El texto tenue no se mide sobre el vidrio porque no se pinta allí: la hoja
 * lo sube a fg-muted dentro de .ay-glass y .ay-card--glass.
 *
 * Sin la profundidad (data-depth="plano", prefers-reduced-transparency, sin backdrop-filter)
 * el vidrio es bg-surface opaco, que ya está en los pares de arriba.
 */
export const VIDRIO = 'color.bg-surface al depth.glass-opacity sobre color.bg-inverse'

const COMPUESTO = /^(\S+) al (\S+) sobre (\S+)$/

/** Los tokens de un fondo compuesto («capa al opacidad sobre fondo»), o `null` si es un token suelto. */
export function fondoCompuesto(nombre) {
  const m = COMPUESTO.exec(nombre)
  return m ? { capa: m[1], opacidad: m[2], fondo: m[3] } : null
}

/** «88%» → 0.88. La opacidad del vidrio es un token de porcentaje. */
export function opacidadDe(valor, token = 'la opacidad') {
  const m = /^(\d+(?:\.\d+)?)%$/.exec(String(valor).trim())
  if (!m || Number(m[1]) > 100) throw new Error(`${token} tiene que ser un porcentaje de 0% a 100% y vale «${valor}»`)
  return Number(m[1]) / 100
}

/** [primer plano, fondo, umbral, para qué] */
export const PARES = [
  ['color.fg-default', 'color.bg-canvas', texto, 'texto sobre el lienzo'],
  ['color.fg-default', 'color.bg-surface', texto, 'texto sobre superficie'],
  ['color.fg-default', 'color.bg-surface-raised', texto, 'texto sobre superficie elevada'],
  ['color.fg-default', 'color.bg-surface-sunken', texto, 'texto sobre superficie hundida'],
  ['color.fg-muted', 'color.bg-surface', texto, 'texto secundario'],
  ['color.fg-muted', 'color.bg-canvas', texto, 'texto secundario sobre lienzo'],
  // El texto secundario y el tenue se pintan también dentro de popovers, menús y diálogos
  // (superficie elevada) y sobre pozos, cabeceras de tabla y campos deshabilitados
  // (superficie hundida). Medirlos solo sobre la superficie y el lienzo dejaba pasar
  // fg-subtle a 4.48:1 en claro sobre la hundida y a 3.98:1 en oscuro sobre la elevada.
  ['color.fg-muted', 'color.bg-surface-raised', texto, 'texto secundario sobre superficie elevada'],
  ['color.fg-muted', 'color.bg-surface-sunken', texto, 'texto secundario sobre superficie hundida'],
  ['color.fg-subtle', 'color.bg-surface', texto, 'texto tenue (ayuda de formulario)'],
  ['color.fg-subtle', 'color.bg-canvas', texto, 'texto tenue sobre lienzo'],
  ['color.fg-subtle', 'color.bg-surface-raised', texto, 'texto tenue sobre superficie elevada (ayuda en un diálogo, día de otro mes)'],
  ['color.fg-subtle', 'color.bg-surface-sunken', texto, 'texto tenue sobre superficie hundida'],
  ['color.fg-link', 'color.bg-surface', texto, 'enlace'],
  ['color.fg-link', 'color.bg-canvas', texto, 'enlace sobre lienzo'],
  ['color.fg-link', 'color.bg-surface-raised', texto, 'enlace sobre superficie elevada'],
  // El fondo tonal de marca lleva fg-link encima: botón suave, ítem activo de la navegación,
  // tramo del calendario y fila elegida.
  ['color.fg-link', 'color.bg-brand-subtle', texto, 'texto de marca sobre su fondo tonal'],
  ['color.fg-accent', 'color.bg-surface', texto, 'texto de acento'],
  ['color.fg-accent', 'color.bg-canvas', texto, 'texto de acento sobre lienzo'],
  ['color.fg-accent', 'color.bg-accent-subtle', texto, 'texto de acento sobre su fondo'],
  // Un aviso sin leer (Notification) va sobre el fondo de acento: su detalle y su hora se
  // pintan en fg-muted. fg-subtle ahí daba 4.11:1 en oscuro.
  ['color.fg-muted', 'color.bg-accent-subtle', texto, 'texto secundario sobre el fondo de acento (detalle y hora de un aviso sin leer)'],
  ['color.fg-inverse', 'color.bg-inverse', texto, 'texto invertido'],
  ['color.fg-on-brand', 'color.bg-brand', texto, 'texto sobre superficie de marca'],
  // fg-on-accent es el nombre que alguien cogerá para "texto sobre acento" sin mirar la
  // paleta. Se mide sobre los tres estados del fondo de acento aunque hoy no lo consuma
  // ningún componente: en claro valía blanco, que sobre #FFA726 da 1.94:1 —el par que
  // IDENTIDAD.md declara ilegible— y nadie lo habría notado hasta pintarlo.
  ['color.fg-on-accent', 'color.action-accent-bg', texto, 'texto sobre acento'],
  ['color.fg-on-accent', 'color.action-accent-bg-hover', texto, 'texto sobre acento en hover'],
  ['color.fg-on-accent', 'color.action-accent-bg-active', texto, 'texto sobre acento activo'],

  ['color.action-primary-fg', 'color.action-primary-bg', texto, 'botón primario'],
  ['color.action-primary-fg', 'color.action-primary-bg-hover', texto, 'botón primario en hover'],
  ['color.action-primary-fg', 'color.action-primary-bg-active', texto, 'botón primario activo'],
  ['color.action-accent-fg', 'color.action-accent-bg', texto, 'botón de acento (mandarina)'],
  ['color.action-accent-fg', 'color.action-accent-bg-hover', texto, 'botón de acento en hover'],
  ['color.action-accent-fg', 'color.action-accent-bg-active', texto, 'botón de acento activo'],
  ['color.action-secondary-fg', 'color.action-secondary-bg', texto, 'botón secundario'],
  ['color.action-secondary-fg', 'color.action-secondary-bg-hover', texto, 'botón secundario en hover'],
  ['color.action-secondary-fg', 'color.action-secondary-bg-active', texto, 'botón secundario activo'],
  ['color.action-danger-fg', 'color.action-danger-bg', texto, 'botón destructivo'],
  ['color.action-danger-fg', 'color.action-danger-bg-hover', texto, 'botón destructivo en hover'],
  ['color.action-danger-fg', 'color.action-danger-bg-active', texto, 'botón destructivo activo'],

  ['color.feedback-success-fg', 'color.feedback-success-bg', texto, 'mensaje de éxito'],
  ['color.feedback-warning-fg', 'color.feedback-warning-bg', texto, 'mensaje de advertencia'],
  ['color.feedback-danger-fg', 'color.feedback-danger-bg', texto, 'mensaje de error'],
  ['color.feedback-info-fg', 'color.feedback-info-bg', texto, 'mensaje informativo'],

  ['color.border-default', 'color.bg-surface', interfaz, 'borde de campo de formulario'],
  // Un campo dentro de un diálogo o de un panel lateral se pinta sobre la superficie
  // elevada, y su foco también.
  ['color.border-default', 'color.bg-surface-raised', interfaz, 'borde de campo sobre superficie elevada'],
  ['color.border-strong', 'color.bg-surface', interfaz, 'borde en hover'],
  ['color.border-focus', 'color.bg-surface', interfaz, 'anillo de foco sobre superficie'],
  ['color.border-focus', 'color.bg-canvas', interfaz, 'anillo de foco sobre lienzo'],
  ['color.border-focus', 'color.bg-surface-raised', interfaz, 'anillo de foco sobre superficie elevada'],
  ['color.border-accent', 'color.bg-surface', interfaz, 'borde de acento'],
  ['color.action-secondary-border', 'color.bg-surface', interfaz, 'borde de botón secundario'],
  ['color.feedback-success-border', 'color.feedback-success-bg', interfaz, 'borde de mensaje: éxito'],
  ['color.feedback-warning-border', 'color.feedback-warning-bg', interfaz, 'borde de mensaje: advertencia'],
  ['color.feedback-danger-border', 'color.feedback-danger-bg', interfaz, 'borde de mensaje: error'],
  ['color.feedback-info-border', 'color.feedback-info-bg', interfaz, 'borde de mensaje: info'],
  ['color.action-primary-bg', 'color.bg-surface', interfaz, 'botón primario contra la superficie'],

  // El vidrio, compuesto sobre el fondo contrario (ver VIDRIO): el texto de una Card de vidrio.
  ['color.fg-default', VIDRIO, texto, 'texto sobre el vidrio, con el fondo contrario detrás'],
  ['color.fg-muted', VIDRIO, texto, 'texto atenuado sobre el vidrio, con el fondo contrario detrás'],
]

/**
 * Bordes y el fondo sobre el que cada uno se pinta de verdad, según ui.css.
 * Esta lista NO lleva umbral: no es un control de accesibilidad. Comprueba que el borde
 * no sea literalmente el mismo color que su fondo, que es un defecto de otra clase —la
 * regla CSS no dibuja nada— y que ningún umbral de contraste atrapa, porque un borde
 * decorativo como el de .ay-card no tiene umbral que incumplir.
 *
 * La última entrada no es un borde sino un relleno, y está aquí por la misma pregunta:
 * bg-brand-subtle es el estado tonal (ítem activo, fila elegida, botón suave) y, si valiera
 * lo mismo que la superficie, el estado existiría en el DOM y no en la pantalla.
 *
 * [token de borde, token de fondo, dónde se pinta]
 */
export const BORDES = [
  ['color.border-subtle', 'color.bg-surface', 'borde de tarjeta (.ay-card)'],
  ['color.border-subtle', 'color.bg-surface-raised', 'borde de popover, menú y desplegable'],
  ['color.border-subtle', 'color.bg-surface-sunken', 'borde de tarjeta sobre una banda hundida (.ay-band--sunken)'],
  ['color.border-default', 'color.bg-surface', 'borde de campo (.ay-field__control)'],
  ['color.border-strong', 'color.bg-surface', 'borde de campo en hover'],
  ['color.border-focus', 'color.bg-surface', 'anillo de foco sobre superficie'],
  ['color.border-focus', 'color.bg-canvas', 'anillo de foco sobre lienzo'],
  ['color.feedback-danger-border', 'color.bg-surface', 'borde de campo inválido'],
  ['color.action-secondary-border', 'color.action-secondary-bg', 'borde del botón secundario sobre su relleno'],
  ['color.action-secondary-border', 'color.bg-surface', 'borde del botón secundario contra la superficie'],
  ['color.feedback-success-border', 'color.feedback-success-bg', 'borde de mensaje: éxito'],
  ['color.feedback-warning-border', 'color.feedback-warning-bg', 'borde de mensaje: advertencia'],
  ['color.feedback-danger-border', 'color.feedback-danger-bg', 'borde de mensaje: error'],
  ['color.feedback-info-border', 'color.feedback-info-bg', 'borde de mensaje: info'],
  ['color.bg-brand-subtle', 'color.bg-surface', 'el estado tonal (ítem activo, fila elegida) contra la superficie'],
]

/**
 * Lo que el sistema descarta a conciencia. Estas combinaciones NO están en PARES —medir
 * como control algo que la doctrina ya prohíbe sería fallar el build a propósito— pero sí
 * se miden y se publican, porque un sistema de diseño que solo enseña lo que funciona no
 * impide que alguien pruebe lo que no.
 *
 * Cada entrada nombra tokens, no hexadecimales: la razón se calcula del valor resuelto del
 * build, así que si mañana la marca cambia el número cambia con ella. Las cifras que
 * IDENTIDAD.md cita en prosa no se copian aquí; se recalculan, y el verificador falla si
 * alguna de estas combinaciones dejara de incumplir —porque entonces la prohibición estaría
 * describiendo una paleta que ya no existe y hay que reescribir la doctrina, no el JSON.
 *
 * [tema, primer plano, fondo, umbral, para qué, por qué se descarta]
 */
/*
 * El detalle largo de los dos que más cuesta explicar, que antes vivía en un comentario de
 * verificar-contraste.mjs:
 *
 *   border-accent sobre bg-canvas — 2.96:1 en claro, contra 3.0. No se mide porque NINGÚN
 *   componente pinta border-accent: no aparece en packages/ui/src/ui.css ni en ningún otro
 *   consumidor. Medir lo que nadie dibuja es ruido. Lo que sí hay que resolver es por qué
 *   existe el token; está anotado en el reporte de la revisión.
 *
 *   action-accent-bg sobre bg-surface — 1.94:1 en claro. Aquí sí hay componente
 *   (.ay-btn--accent) y el número es real, pero el arreglo no es técnico: exigirle 3.0
 *   obliga a bajar el fondo de acento a secondary.700 o más oscuro, o sea a renunciar a
 *   #FFA726, que es el "naranja mandarina" del manual (pág. 29). Eso es una decisión de
 *   marca, no de tokens. El botón de acento se identifica por su etiqueta —petróleo sobre
 *   mandarina, 8.56:1 y semibold—, no por el contorno de su relleno.
 */
export const PROHIBIDOS = [
  [
    'light',
    'color.neutral.0',
    'color.action-accent-bg',
    texto,
    'texto blanco sobre el fondo de acento',
    'Es el par que IDENTIDAD.md declara ilegible y el motivo de que la mandarina no sea color de acción: fg-on-accent vale petróleo, nunca blanco.',
  ],
  [
    'dark',
    'color.neutral.0',
    'color.action-accent-bg',
    texto,
    'texto blanco sobre el fondo de acento',
    'El acento es la misma mandarina del manual en los dos temas, así que el tema oscuro no salva la combinación: mide exactamente lo mismo.',
  ],
  [
    'light',
    'color.secondary.400',
    'color.neutral.0',
    texto,
    'la mandarina del manual como texto sobre blanco',
    'La misma pareja de colores en el otro orden, que da la misma razón; el texto de acento es secondary.800 (7.28:1) precisamente porque secondary.400 no llega.',
  ],
  [
    'light',
    'color.action-accent-bg',
    'color.bg-surface',
    interfaz,
    'el relleno del botón de acento contra la superficie',
    'Exigirle 3.0 obligaría a renunciar a #FFA726, que es decisión de marca y no de tokens: el botón de acento se identifica por su etiqueta —petróleo, 8.56:1 y semibold—, no por el contorno de su relleno.',
  ],
  [
    'light',
    'color.border-accent',
    'color.bg-canvas',
    interfaz,
    'el borde de acento sobre el lienzo',
    'Se queda a un pelo del umbral, pero no se mide como control porque ningún componente pinta border-accent sobre el lienzo; lo que hay que resolver es por qué existe el token.',
  ],
]

/**
 * Cuántas mediciones tiene que haber. Se declara y no solo se deriva de las listas porque
 * las cifras están escritas en docs/ARQUITECTURA.md §2.1 y en docs/IDENTIDAD.md: borrar
 * media docena de pares por descuido dejaría un `contraste.json` más pequeño que seguiría
 * cumpliendo todos sus umbrales, y el catálogo publicaría una paleta "100% verificada" con
 * un tercio de la interfaz sin medir. La comprobación es del emisor y del verificador.
 */
/*
 * Y cuántas combinaciones de apariencia: 4 paletas × 2 acentos × 3 grises × 2 estilos × 2
 * temas. Esta sí se escribe literal, porque sale de src/apariencia.json y no de las listas de
 * aquí: un valor que desapareciera del archivo reduciría la medición sin que nada fallara.
 */
export const ESPERADOS = { pares: PARES.length * 2, bordes: BORDES.length * 2, combinaciones: 96 }
if (ESPERADOS.pares !== 112 || ESPERADOS.bordes !== 30) {
  throw new Error(
    `Las listas de contraste declaran ${ESPERADOS.pares} pares y ${ESPERADOS.bordes} bordes, ` +
      'pero la documentación (docs/ARQUITECTURA.md §2.1, docs/IDENTIDAD.md) dice 112 y 30. ' +
      'Si el cambio es intencionado, actualiza los dos documentos en el mismo commit.',
  )
}

/** Los temas que se miden, y en este orden: es el que sale en el JSON emitido. */
export const TEMAS = ['light', 'dark']

/**
 * El valor de un token en un tema, en minúsculas, o un error que dice qué lista lo nombra. Un
 * fondo compuesto (VIDRIO) se resuelve componiendo sus tres tokens.
 */
function lector(temas, primitivas = {}) {
  const leer = lectorSimple(temas, primitivas)
  return (tema, token) => {
    const compuesto = fondoCompuesto(token)
    if (!compuesto) return leer(tema, token)
    const opacidad = opacidadDe(leer(tema, compuesto.opacidad), compuesto.opacidad)
    return componer(leer(tema, compuesto.capa), opacidad, leer(tema, compuesto.fondo))
  }
}

function lectorSimple(temas, primitivas) {
  return (tema, token) => {
    const hex = temas[tema]?.[token] ?? primitivas[token]
    if (!hex) {
      throw new Error(
        `No existe el token ${token} en el tema ${tema} ni entre las primitivas. ` +
          'Las listas de packages/tokens/pares-contraste.mjs nombran tokens que src/semantic.json ' +
          'o src/base.json tienen que definir.',
      )
    }
    // Minúsculas: las anclas del manual vienen en mayúsculas (`#FFA726`) y las derivadas
    // en minúsculas, y un consumidor que compare hexes no debería tropezar con eso.
    return hex.toLowerCase()
  }
}

const razonDe = (a, b) => Math.round(contraste(a, b) * 100) / 100

/** Los PARES y los BORDES de los dos temas, medidos con `valor(tema, token)`. */
function medirParesYBordes(valor) {
  const pares = []
  const bordes = []

  for (const tema of TEMAS) {
    for (const [frente, fondo, umbral, para] of PARES) {
      const hexFrente = valor(tema, frente)
      const hexFondo = valor(tema, fondo)
      pares.push({
        tema,
        frente,
        fondo,
        hexFrente,
        hexFondo,
        razon: razonDe(hexFrente, hexFondo),
        umbral,
        para,
        cumple: contraste(hexFrente, hexFondo) >= umbral,
      })
    }
  }

  for (const tema of TEMAS) {
    for (const [borde, fondo, donde] of BORDES) {
      const hexBorde = valor(tema, borde)
      const hexFondo = valor(tema, fondo)
      bordes.push({
        tema,
        borde,
        fondo,
        hexBorde,
        hexFondo,
        razon: razonDe(hexBorde, hexFondo),
        // Por igualdad y no por distancia, igual que el control del verificador: un
        // umbral aquí invitaría a discutir cuánto es "poco", y la pregunta es otra.
        dibuja: hexBorde !== hexFondo,
        donde,
      })
    }
  }

  return { pares, bordes }
}

/**
 * Mide todo y devuelve el objeto que se publica tal cual como `dist/contraste.json`.
 *
 * `primitivas` hace falta además de `temas` porque los PROHIBIDOS nombran alguna primitiva
 * (`color.neutral.0`, `color.secondary.400`): la doctrina habla del blanco y de la
 * mandarina del manual, no de un alias semántico que hoy resulte valer eso.
 *
 * `razon` va redondeada a dos decimales —es lo que se muestra— pero `cumple` se decide con
 * el valor exacto, que es el mismo con el que el verificador corta el build. Al contrario,
 * un par de 4.4951 se publicaría como 4.5 y como cumplido, y el catálogo estaría dando por
 * bueno un número que el build rechaza.
 *
 * Con `fuente` (los tokens sin resolver y la apariencia preparada, origen-apariencia.mjs)
 * añade `combinaciones`: el resumen de las 96 combinaciones de apariencia. `pares`, `bordes`
 * y `prohibidos` siguen siendo los de la combinación por defecto, con todo su detalle.
 */
export function medir(temas, primitivas = {}, fuente) {
  const valor = lector(temas, primitivas)
  const { pares, bordes } = medirParesYBordes(valor)

  const prohibidos = PROHIBIDOS.map(([tema, frente, fondo, umbral, para, porQue]) => {
    const hexFrente = valor(tema, frente)
    const hexFondo = valor(tema, fondo)
    return {
      tema,
      frente,
      fondo,
      hexFrente,
      hexFondo,
      razon: razonDe(hexFrente, hexFondo),
      umbral,
      para,
      cumple: contraste(hexFrente, hexFondo) >= umbral,
      porQue,
    }
  })

  const medicion = { umbrales: UMBRALES, pares, bordes, prohibidos }
  if (fuente) medicion.combinaciones = medirCombinaciones(fuente)
  return medicion
}

/**
 * Las combinaciones de los ejes que cambian color —paleta, acento, grises y estilo— en los
 * dos temas, cada una con los PARES y los BORDES completos. Se publica un resumen por
 * combinación (cuántos cumplen, cuántos dibujan y el par más ajustado): el detalle de 96 ×
 * 55 pares no le sirve a nadie, y el número que importa es el que se rompe primero.
 *
 * Cada combinación usa sus propias primitivas, no solo sus semánticos: el vidrio compone con
 * depth.glass-opacity, y un eje que redefiniera una primitiva que no es color también contaría.
 */
export function medirCombinaciones(fuente) {
  const combinaciones = []
  for (const apariencia of combinacionesMedidas(fuente.ejes)) {
    const { temas, primitivas } = resolverCombinacion(fuente, apariencia)
    const { pares, bordes } = medirParesYBordes(lector(temas, primitivas))
    for (const tema of TEMAS) {
      const filas = pares.filter((p) => p.tema === tema)
      const suyos = bordes.filter((b) => b.tema === tema)
      const ajustado = filas
        .map((p) => ({ p, holgura: contraste(p.hexFrente, p.hexFondo) / p.umbral }))
        .sort((x, y) => x.holgura - y.holgura)[0].p
      combinaciones.push({
        apariencia,
        tema,
        pares: filas.length,
        cumplen: filas.filter((p) => p.cumple).length,
        bordes: suyos.length,
        dibujan: suyos.filter((b) => b.dibuja).length,
        ajustado: {
          frente: ajustado.frente,
          fondo: ajustado.fondo,
          hexFrente: ajustado.hexFrente,
          hexFondo: ajustado.hexFondo,
          razon: ajustado.razon,
          umbral: ajustado.umbral,
          para: ajustado.para,
        },
      })
    }
  }
  if (combinaciones.length !== ESPERADOS.combinaciones) {
    throw new Error(
      `src/apariencia.json da ${combinaciones.length} combinaciones medidas y tienen que ser ` +
        `${ESPERADOS.combinaciones} (4 paletas × 2 acentos × 3 grises × 2 estilos × 2 temas). ` +
        'Si el cambio es intencionado, actualiza ESPERADOS en pares-contraste.mjs y el catálogo.',
    )
  }
  return combinaciones
}

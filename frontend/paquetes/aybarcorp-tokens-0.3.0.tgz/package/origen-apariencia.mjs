/**
 * Lee y valida la fuente de la apariencia: los ejes (src/apariencia.json) y los tokens que
 * redefine cada valor (src/paletas.json, generado, y src/modos.json). Lo usan build.mjs, que
 * emite los bloques CSS y los metadatos, y verificar-contraste.mjs, que vuelve a medir las
 * combinaciones: los dos tienen que partir exactamente de la misma fuente, o el verificador
 * estaría aprobando una medición que el build no hizo.
 */
import { readFileSync } from 'node:fs'
import { join } from 'node:path'

import { resolver } from './expresiones.mjs'

/** Claves de un valor de modo que no son primitivas sino semánticos de ese tema. */
const TEMAS_DE_MODO = ['light', 'dark']

/** Aplana un árbol a `a.b.c` → valor, descartando las claves de documentación (`_*`). */
export function aplanar(nodo, camino = [], salida = {}) {
  for (const [clave, valor] of Object.entries(nodo)) {
    if (clave.startsWith('_')) continue
    const siguiente = [...camino, clave]
    if (valor !== null && typeof valor === 'object') aplanar(valor, siguiente, salida)
    else salida[siguiente.join('.')] = String(valor)
  }
  return salida
}

/** Los archivos fuente de los tokens, tal cual. */
export function leerFuente(raiz) {
  const src = (nombre) => JSON.parse(readFileSync(join(raiz, 'src', nombre), 'utf8'))
  return {
    base: src('base.json'),
    brand: src('brand.json'),
    semantic: src('semantic.json'),
    densidad: src('density.json'),
    apariencia: src('apariencia.json'),
    paletas: src('paletas.json'),
    modos: src('modos.json'),
  }
}

/** Primitivas y semánticos sin resolver: lo que necesita medir una combinación. */
export function tokensDeFuente({ base, brand, semantic }) {
  const primitivas = { ...aplanar(base), ...aplanar(brand) }
  const semanticos = {}
  for (const [tema, arbol] of Object.entries(semantic)) {
    if (!tema.startsWith('_')) semanticos[tema] = aplanar(arbol)
  }
  return { primitivas, semanticos }
}

/**
 * Valida los ejes y junta los tokens de cada valor en `{ primitivas, temas: { light, dark } }`.
 * Falla —con un mensaje que dice qué tocar— si un valor declarado no tiene tokens, si hay
 * tokens para un valor que no se declaró, o si un valor redefine un token que no existe.
 */
export function prepararApariencia({ apariencia, paletas, modos, primitivas, semanticos }) {
  const ejes = {}
  for (const [id, eje] of Object.entries(apariencia.axes)) {
    const ids = eje.values.map((v) => v.id)
    if (eje.attribute !== `data-${id}`) {
      throw new Error(`apariencia.json: el eje ${id} se aplica con data-${id}, no con ${eje.attribute}`)
    }
    if (new Set(ids).size !== ids.length) throw new Error(`apariencia.json: el eje ${id} repite valores`)
    if (!ids.includes(eje.default)) {
      throw new Error(`apariencia.json: el valor por defecto de ${id} (${eje.default}) no está entre sus valores`)
    }
    ejes[id] = eje
  }

  // Tema y densidad son los modos de siempre: sus tokens están en semantic.json y density.json.
  const PROPIOS = { theme: 'semantic.json', density: 'density.json' }
  const modosPorEje = {}
  for (const [archivo, contenido] of [
    ['paletas.json', paletas],
    ['modos.json', modos],
  ]) {
    for (const [eje, valores] of Object.entries(contenido)) {
      if (eje.startsWith('_')) continue
      if (!ejes[eje] || PROPIOS[eje]) throw new Error(`${archivo} declara tokens para el eje ${eje}, que apariencia.json no tiene`)
      if (modosPorEje[eje]) throw new Error(`El eje ${eje} tiene tokens en dos archivos: paletas.json y modos.json`)
      modosPorEje[eje] = {}
      for (const [valor, arbol] of Object.entries(valores)) {
        if (valor.startsWith('_')) continue
        if (!ejes[eje].values.some((v) => v.id === valor)) {
          throw new Error(`${archivo}: ${eje}.${valor} no es un valor declarado en apariencia.json`)
        }
        if (valor === ejes[eje].default) {
          throw new Error(
            `${archivo}: ${eje}.${valor} es el valor por defecto y no redefine nada: sus tokens son los de base.json y brand.json`,
          )
        }
        modosPorEje[eje][valor] = separar(arbol, `${archivo} (${eje}.${valor})`, primitivas, semanticos)
      }
    }
  }
  for (const [id, eje] of Object.entries(ejes)) {
    if (PROPIOS[id]) continue
    for (const { id: valor } of eje.values) {
      if (valor !== eje.default && !modosPorEje[id]?.[valor]) {
        throw new Error(
          `apariencia.json declara ${id}.${valor}, pero ni paletas.json ni modos.json le dan tokens. ` +
            'Un valor sin tokens es un atributo que no hace nada; si todavía no tiene, decláralo vacío en modos.json.',
        )
      }
    }
  }

  const presets = apariencia.presets
  const idsPreset = presets.map((p) => p.id)
  if (new Set(idsPreset).size !== idsPreset.length) throw new Error('apariencia.json repite el id de un preset')
  for (const preset of presets) {
    for (const [eje, valor] of Object.entries(preset.values)) {
      if (!ejes[eje]?.values.some((v) => v.id === valor)) {
        throw new Error(`apariencia.json: el preset ${preset.id} pide ${eje}=${valor}, que no existe`)
      }
    }
  }
  const primero = presets[0]
  for (const [eje, valor] of Object.entries(primero?.values ?? {})) {
    if (ejes[eje].default !== valor) {
      throw new Error(`apariencia.json: el primer preset (${primero.id}) es el de por defecto y pide ${eje}=${valor}`)
    }
  }

  return { ejes, presets, modos: modosPorEje }
}

/** Separa el árbol de un valor de modo en primitivas y semánticos por tema, y los valida. */
function separar(arbol, contexto, primitivas, semanticos) {
  const sinTemas = Object.fromEntries(Object.entries(arbol).filter(([k]) => !TEMAS_DE_MODO.includes(k)))
  const propias = aplanar(sinTemas)
  const ajenas = Object.keys(propias).filter((k) => !(k in primitivas))
  if (ajenas.length) {
    throw new Error(
      `${contexto} redefine tokens que base.json y brand.json no declaran: ${ajenas.join(', ')}. ` +
        'Declara primero el valor por defecto, o el token quedaría vacío sin el atributo.',
    )
  }
  const temas = {}
  for (const tema of TEMAS_DE_MODO) {
    temas[tema] = aplanar(arbol[tema] ?? {})
    const desconocidos = Object.keys(temas[tema]).filter((k) => !(k in semanticos[tema]))
    if (desconocidos.length) {
      throw new Error(`${contexto}.${tema} redefine semánticos que semantic.json no tiene: ${desconocidos.join(', ')}`)
    }
  }
  return { primitivas: propias, temas }
}

/** Los tokens con los que se pinta una combinación de valores (`{ palette: 'jade', … }`). */
export function tokensDeCombinacion({ primitivas, semanticos, modos }, combinacion) {
  const prim = { ...primitivas }
  const temas = Object.fromEntries(Object.entries(semanticos).map(([t, mapa]) => [t, { ...mapa }]))
  for (const [eje, valor] of Object.entries(combinacion)) {
    const modo = modos[eje]?.[valor]
    if (!modo) continue
    Object.assign(prim, modo.primitivas)
    for (const tema of Object.keys(temas)) Object.assign(temas[tema], modo.temas[tema])
  }
  return { primitivas: prim, temas }
}

/** Resuelve los semánticos de una combinación a su color final, como los mide el contraste. */
export function resolverCombinacion(fuente, combinacion) {
  const { primitivas, temas } = tokensDeCombinacion(fuente, combinacion)
  const buscar = (ref) => primitivas[ref]
  const resueltas = Object.fromEntries(
    Object.keys(primitivas).map((k) => [k, resolver(primitivas[k], buscar, k)]),
  )
  const resueltos = Object.fromEntries(
    Object.entries(temas).map(([tema, mapa]) => [
      tema,
      Object.fromEntries(Object.entries(mapa).map(([k, v]) => [k, resolver(v, buscar, `${tema}.${k}`)])),
    ]),
  )
  return { primitivas: resueltas, temas: resueltos }
}

/** Todas las combinaciones de los ejes que cambian color (`measured`), en el orden de apariencia.json. */
export function combinacionesMedidas(ejes) {
  let combinaciones = [{}]
  for (const [id, eje] of Object.entries(ejes)) {
    if (!eje.measured) continue
    combinaciones = combinaciones.flatMap((c) => eje.values.map((v) => ({ ...c, [id]: v.id })))
  }
  return combinaciones
}

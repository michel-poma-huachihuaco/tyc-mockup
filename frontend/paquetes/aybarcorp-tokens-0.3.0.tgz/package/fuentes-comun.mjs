/**
 * Lo que build.mjs y generar-fuentes.mjs necesitan saber los dos sobre las fuentes.
 *
 * Existe para que el juego de pesos y el nombre de cada archivo se declaren una sola
 * vez. Si el generador escribiera `montserrat-600.woff2` y el build emitiera un
 * @font-face que pide `Montserrat-SemiBold.woff2`, el navegador no avisaría de nada:
 * sintetizaría la seminegrita a partir del peso regular y la pantalla saldría con una
 * tipografía que no es la de la marca. Un desajuste así no lo detecta ninguna prueba
 * de las que corren hoy, así que el nombre se calcula, no se escribe dos veces.
 *
 * Los pesos tampoco son una lista propia: salen de `src/base.json` → `font.weight`,
 * que es lo que el sistema de diseño declara usar. Montserrat publica nueve pesos;
 * empaquetar los nueve son cientos de kB de red por visita para pesos que ningún
 * componente aplica.
 */
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

/** Todo cuelga del paquete, no del cwd: estos scripts se invocan desde la raíz del repo. */
export const RAIZ_PAQUETE = dirname(fileURLToPath(import.meta.url))

/**
 * Los .woff2 auto-hospedados viven en `src/`, no en `dist/`.
 *
 * `dist/` es derivado y desechable: está en .gitignore, `verificar-tarballs --limpio`
 * lo borra y el `prepack` de un runner recién clonado lo reconstruye desde cero. Un
 * binario que solo exista ahí no sobrevive a un release —y el paquete publicado
 * volvería al CDN sin que nadie lo pidiera—. En `src/` los .woff2 se versionan una vez,
 * igual que `src/brand.json`, que también lo produce un script (derivar-marca.mjs) y
 * también es entrada del build y no salida.
 */
export const DIR_FUENTES_SRC = join(RAIZ_PAQUETE, 'src', 'fonts')

/** Subdirectorio de dist/ al que el build copia lo que haya en src/fonts/. */
export const DIR_FUENTES_DIST = join(RAIZ_PAQUETE, 'dist', 'fonts')

/** El nombre de familia es uno: cambiarlo aquí y no en brand.json rompe la pila CSS. */
export const FAMILIA = 'Montserrat'

/**
 * Los cinco pesos que el sistema declara, en el orden de la escala. La clave del token
 * (`regular`, `semibold`…) es también la que nombra el .ttf del manual, así que el
 * mapeo es explícito: Montserrat los publica como `Montserrat-SemiBold.ttf` y no como
 * `Montserrat-Semibold.ttf`. `display` es el 800 de las cifras y los titulares grandes
 * (el estilo sobrio lo baja a 700, que ya está en el juego).
 */
const TTF_POR_CLAVE = {
  regular: 'Montserrat-Regular.ttf',
  medium: 'Montserrat-Medium.ttf',
  semibold: 'Montserrat-SemiBold.ttf',
  bold: 'Montserrat-Bold.ttf',
  display: 'Montserrat-ExtraBold.ttf',
}

const base = JSON.parse(readFileSync(join(RAIZ_PAQUETE, 'src', 'base.json'), 'utf8'))

export const PESOS = Object.entries(base.font.weight)
  .filter(([clave]) => !clave.startsWith('_'))
  .map(([clave, peso]) => ({ clave, peso: Number(peso), ttf: TTF_POR_CLAVE[clave] }))
  .sort((a, b) => a.peso - b.peso)

/** Un peso nuevo en base.json sin su .ttf declarado se detiene aquí y no en el navegador. */
export const pesosSinTtf = () => PESOS.filter((p) => !p.ttf).map((p) => p.clave)

/** El nombre del .woff2 de un peso. Única definición: el generador escribe y el build lee. */
export const nombreWoff2 = (peso) => `${FAMILIA.toLowerCase()}-${peso}.woff2`

/**
 * Qué hay realmente en src/fonts/. El build emite @font-face para las caras que
 * existen y solo para esas: un @font-face que apunta a un .woff2 ausente es una
 * referencia muerta que el navegador resuelve en silencio.
 */
export function inventarioLocal() {
  const esperados = new Map(PESOS.map((p) => [nombreWoff2(p.peso), p]))
  const presentes = existsSync(DIR_FUENTES_SRC)
    ? readdirSync(DIR_FUENTES_SRC).filter((n) => !n.startsWith('.'))
    : []

  const caras = []
  for (const { peso } of PESOS) {
    const archivo = nombreWoff2(peso)
    if (!presentes.includes(archivo)) continue
    const ruta = join(DIR_FUENTES_SRC, archivo)
    caras.push({ peso, archivo, ruta, bytes: statSync(ruta).size })
  }

  return {
    caras,
    faltantes: PESOS.filter(({ peso }) => !presentes.includes(nombreWoff2(peso))).map((p) => p.peso),
    ajenos: presentes.filter((n) => !esperados.has(n)),
  }
}

/** El bloque @font-face de una cara. La url es relativa al CSS, que vive junto a fonts/. */
export const caraCss = (peso) => `@font-face {
  font-family: '${FAMILIA}';
  font-style: normal;
  font-weight: ${peso};
  font-display: swap;
  src: url('./fonts/${nombreWoff2(peso)}') format('woff2');
}`

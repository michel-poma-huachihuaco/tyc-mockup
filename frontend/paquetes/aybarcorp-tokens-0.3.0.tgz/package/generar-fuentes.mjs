#!/usr/bin/env node
/**
 * Convierte los .ttf de Montserrat del manual a .woff2 en `src/fonts/`, para que el
 * build pueda servir la tipografía desde el propio dominio y no desde un CDN externo.
 *
 *   node generar-fuentes.mjs <ruta al directorio con los .ttf>
 *   node build.mjs                # emite los @font-face locales y copia los .woff2 a dist/
 *
 * Requiere fonttools con soporte woff2:
 *   pip install 'fonttools[woff]'
 *
 * No corre en el build: producir binarios en cada build es innecesario y los .woff2 se
 * versionan una vez.
 *
 * ESCRIBE EN src/, NO EN dist/, y no escribe CSS.
 *
 * Antes escribía los .woff2 y un `dist/fuentes.css` con los @font-face en dist/, que es
 * el directorio que el build reconstruye: el siguiente `build` —y el `prepack` de
 * cualquier publicación— devolvía el @import al CDN de Google Fonts y dejaba los .woff2
 * viajando en el tarball sin que ningún CSS los nombrara. El equipo creía haber
 * eliminado la dependencia del CDN y el paquete publicado seguía dependiendo de él.
 * Además dist/ está en .gitignore, así que aquellos binarios "que se versionan una vez"
 * no se versionaban: no sobrevivían a un clon limpio.
 *
 * Ahora este script solo produce entradas del build, igual que derivar-marca.mjs con
 * src/brand.json. El build es el único que escribe en dist/, y por eso no puede pisar
 * nada de esto.
 */
import { execFileSync } from 'node:child_process'
import { existsSync, mkdirSync, statSync } from 'node:fs'
import { join, relative, resolve } from 'node:path'

import {
  DIR_FUENTES_SRC,
  PESOS,
  RAIZ_PAQUETE,
  nombreWoff2,
  pesosSinTtf,
} from './fuentes-comun.mjs'

// El origen es obligatorio y no tiene valor por omisión. Lo tuvo —la ruta absoluta
// del portátil de un desarrollador, y encima a otro repositorio— y este script se
// publica dentro de @aybarcorp/tokens: ese valor viajaba en el tarball, no funcionaba
// en ninguna otra máquina y filtraba la estructura de un directorio ajeno.
const ORIGEN = process.argv[2] ? resolve(process.argv[2]) : null

const uso = 'Uso: node generar-fuentes.mjs <ruta al directorio con los .ttf de Montserrat>'

if (!ORIGEN) {
  console.error('Falta la ruta al directorio con los .ttf de Montserrat del manual de marca.')
  console.error(uso)
  process.exit(1)
}
if (!existsSync(ORIGEN)) {
  console.error(`No existe el directorio de fuentes: ${ORIGEN}`)
  console.error(uso)
  process.exit(1)
}

const sinTtf = pesosSinTtf()
if (sinTtf.length) {
  console.error(
    `src/base.json declara los pesos ${sinTtf.join(', ')} y fuentes-comun.mjs no sabe de qué .ttf salen.`,
  )
  console.error('Declara el archivo del manual en TTF_POR_CLAVE antes de generar.')
  process.exit(1)
}

mkdirSync(DIR_FUENTES_SRC, { recursive: true })

const generadas = []
for (const { peso, ttf } of PESOS) {
  const entrada = join(ORIGEN, ttf)
  if (!existsSync(entrada)) {
    console.error(`Falta ${ttf} en ${ORIGEN}`)
    console.error('Se generan todos los pesos o ninguno: un juego a medias hace que el')
    console.error('navegador sintetice los pesos ausentes y la marca sale deformada.')
    process.exit(1)
  }
  const salida = join(DIR_FUENTES_SRC, nombreWoff2(peso))
  try {
    execFileSync('fonttools', ['ttLib.woff2', 'compress', '-o', salida, entrada], {
      stdio: 'inherit',
    })
  } catch {
    console.error("\nfonttools no está disponible. Instala con: pip install 'fonttools[woff]'")
    process.exit(1)
  }
  generadas.push({ archivo: nombreWoff2(peso), kb: (statSync(salida).size / 1024).toFixed(1) })
  console.log(`  src/fonts/${nombreWoff2(peso)}`)
}

const total = generadas.reduce((suma, g) => suma + Number(g.kb), 0).toFixed(1)
console.log(`\n${generadas.length} caras en ${relative(process.cwd(), DIR_FUENTES_SRC)}/ · ${total} kB`)
console.log('Versiona esos .woff2 y corre el build para que dist/ los sirva:')
console.log(`  node ${relative(process.cwd(), join(RAIZ_PAQUETE, 'build.mjs'))}`)
console.log('El build emitirá dist/fuentes-locales.css y dist/fuentes.css en modo locales.')

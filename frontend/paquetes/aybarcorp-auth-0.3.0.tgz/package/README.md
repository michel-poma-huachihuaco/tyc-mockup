# @aybarcorp/auth

Inicio de sesión OIDC del framework: Authorization Code con PKCE S256 para un cliente
público, neutral de emisor, que entrega la `Sesion` del contrato del core con el mismo
mapeo de claims que el backend del SDK. Y, para desarrollo local sin emisor, un modo demo
con la misma interfaz (`crearAutenticacionDemo`).

Forma parte del **framework Aybar**, un monorepo de diez paquetes que se publican
juntos y comparten siempre la misma versión. La arquitectura y las decisiones de diseño
están documentadas en el [repositorio](https://github.com/AybarCorp/aybar-framework-desing-frontEnd).

> Los diez se versionan en bloque, y se instalan con versión exacta. Mezclar versiones
> de `@aybarcorp/*` pone dos copias de `@aybarcorp/core` donde debía haber una.

## Instalación

Requiere acceso a GitHub Packages: un `.npmrc` con `@aybarcorp:registry=https://npm.pkg.github.com` y un
token con permiso `read:packages`. No hay instalación anónima.

```bash
npm install @aybarcorp/auth
```

Lo usa el anfitrión (o la aplicación sin federación). Un remoto no lo importa: recibe la
`Sesion` en su contexto y nunca guarda ni renueva el token.

## Uso

```ts
import { crearAutenticacion } from '@aybarcorp/auth'

export const autenticacion = crearAutenticacion({
  emisor: import.meta.env.VITE_OIDC_EMISOR,        // el issuer exacto
  clienteId: import.meta.env.VITE_OIDC_CLIENTE_ID, // cliente público, sin secreto
  redirectUri: `${location.origin}/auth/retorno`,
  postLogoutRedirectUri: `${location.origin}/`,
  audiencia: 'aybar-api',                          // opcional: exige que el access token la traiga
})

const sesion = await autenticacion.iniciar() // procesa el retorno o restaura; null si no hay
if (!sesion) await autenticacion.entrar()    // redirige al emisor
```

Qué emisor se usa lo decide el ADR de cada servicio. El framework no supone ninguno:
descubre los endpoints en `<emisor>/.well-known/openid-configuration`. Keycloak es solo el
entorno local (`http://localhost:8080/realms/<realm>`, cliente público `aybar-web`); http
se admite únicamente contra `localhost`, cualquier otro emisor va por https.

### React

```tsx
import { ProveedorAutenticacion, useSesion, useAutenticacion } from '@aybarcorp/auth/react'

<ProveedorAutenticacion autenticacion={autenticacion} cargando={<Spinner />}>
  <BrowserRouter>...</BrowserRouter>
</ProveedorAutenticacion>

const sesion = useSesion()                              // SesionAutenticada | null
const { fase, error, entrar, salir } = useAutenticacion()
```

Con `cargando`, los hijos no se montan hasta que `iniciar()` termina: el retorno del
emisor reescribe la URL (quita `code` y `state`, vuelve al destino) y el router tiene que
leerla después. En Next.js (App Router) se importa desde un componente `'use client'`.

### Angular

Sin enlace propio: `crearAutenticacion` se llama desde un servicio, e `iniciar()` desde
un `provideAppInitializer` para que el router arranque con la URL ya limpia. Es lo que
escribe `npx @aybarcorp/cli init --con-auth` en `src/app/aybar/autenticacion.ts`
(`proveerAutenticacionAybar()`, con los tokens `AUTENTICACION`, `AUTENTICACION_DEMO` y
`ERROR_AUTENTICACION`).

## Modo demo: `crearAutenticacionDemo`

Un inicio de sesión simulado para desarrollo local, mientras no hay emisor OIDC: la
pantalla de login es de la propia aplicación —el Login Form del sistema de diseño— y la
contraseña se compara en el navegador contra una lista de usuarios de prueba.

```ts
import { crearAutenticacion, crearAutenticacionDemo } from '@aybarcorp/auth'

const usuario = import.meta.env.VITE_AYBAR_DEMO_USUARIO as string | undefined
const clave = import.meta.env.VITE_AYBAR_DEMO_CLAVE as string | undefined

/** La del modo demo, o `null` fuera de `npm run dev` o sin usuario de prueba. */
export const autenticacionDemo =
  import.meta.env.DEV && usuario && clave
    ? crearAutenticacionDemo({ usuarios: [{ usuario, clave, roles: ['USER'] }] })
    : null

export const autenticacion =
  autenticacionDemo ??
  crearAutenticacion({
    emisor: import.meta.env.VITE_AYBAR_EMISOR as string,
    clienteId: import.meta.env.VITE_AYBAR_CLIENTE_ID as string,
    redirectUri: `${location.origin}/`,
  })

/** El botón «Ingresar» del Login Form, en la ruta `autenticacionDemo.rutaLogin`. */
export async function ingresar(usuarioEscrito: string, claveEscrita: string) {
  await autenticacionDemo?.ingresar(usuarioEscrito, claveEscrita)
}
```

**Misma interfaz que `crearAutenticacion`**: `iniciar`, `entrar`, `salir`, `sesion` y
`alCambiar`, así que `ProveedorAutenticacion`, `useSesion` y el cliente de
`@aybarcorp/http` no saben cuál tienen detrás; pasar al emisor real es cambiar la
configuración, no el código. Añade `demo: true`, `rutaLogin` (`/ingresar` por omisión) e
`ingresar(usuario, clave)`, que abre la sesión o lanza `credenciales-invalidas` —el mismo
error para usuario inexistente y clave errónea—. `entrar(destino)` redirige a `rutaLogin`
con `?destino=`. La sesión se restaura al recargar: en `sessionStorage` se guarda solo el
usuario, nunca la clave.

Cada usuario necesita `usuario` y `clave` no vacíos —`nombre`, `roles` (`['USER']` por
omisión), `empresaId`, `rolesPorEmpresa` y `atributos` son opcionales—; sin ellos,
`crearAutenticacionDemo` lanza `configuracion` en el momento de crearla, que en lo que
escribe el CLI es al cargar el módulo. La sesión lleva `atributos.demo: true`, para que la
pantalla pueda avisar que es simulada.

**Lo que no es: seguridad.** La lista de usuarios viaja en el bundle y cualquiera la lee.
Por eso tiene tres frenos:

- **Solo localhost.** `iniciar`, `entrar` e `ingresar` fallan con `demo-fuera-de-local`
  fuera de `localhost`, `127.0.0.1`, `[::1]` o un `*.localhost`: un build publicado con el
  modo demo encendido no muestra un login falso, falla.
- **Sin token.** `sesion.obtenerToken()` rechaza con `sin-token-demo`: un backend protegido
  responde 401 a todo lo que se le pida con esta sesión.
- **Solo en desarrollo**, en lo que escribe `init --con-auth`: en Vite, detrás de
  `import.meta.env.DEV` con los usuarios en `.env.development` (varios en
  `VITE_AYBAR_DEMO_USUARIOS`, o uno con `VITE_AYBAR_DEMO_USUARIO`, `_CLAVE`, `_NOMBRE`,
  `_ROLES`), que no entra en `vite build`; en Angular, detrás de `isDevMode()` con uno o
  varios en `environment.development.ts`, mientras `environment.ts` —el de producción—
  lleva `demo: null`.

Los usuarios de prueba son sintéticos y locales; nunca credenciales reales de nadie.

## La sesión

| Campo | Claim por defecto | Regla |
|---|---|---|
| `usuarioId` | `user_account_id` | Si no viene, el `sub`: en el core `usuarioId === null` significa «sin sesión». |
| `nombre` | `preferred_username` | Si no viene, el `sub` (como el nombre de la autenticación en el backend). |
| `empresaId` | `companyId` | |
| `roles` | `realm_access.roles` + `company_roles[empresaId]` | Los mismos que el backend convierte en authorities: los de otras empresas no cuentan. |
| `rolesPorEmpresa` | `company_roles` | Objeto o String JSON. |
| `atributos` | `claims.adicionales` | Solo los declarados y presentes, inmutables. |
| `sesionId` | `sid` | |

Los nombres se cambian con `claims: { usuario, nombreUsuario, empresa, roles,
rolesPorEmpresa, sesion, adicionales }`, con las reglas de `aybar.security.claims.*` del
backend: un nombre con puntos es una ruta anidada (`realm_access.roles`), y un claim de
primer nivel que se llame literalmente así **no** la suplanta; solo un nombre con `/` o
`:` (`https://aybar.example/roles`) se lee literal. Un claim con forma inválida no abre
sesión, igual que el backend responde 401.

Los claims salen del ID token y, encima, del access token si es un JWT: los roles y la
empresa que decide la API están en el access token. Su firma no se verifica aquí —lo
hace la API, que es para quien es—, así que lo que se lee solo decide la interfaz.

## Qué se valida

- Retorno del emisor: `state`, `iss` de RFC 9207 si el emisor lo anuncia, y su `error`.
- ID token (oauth4webapi): `iss`, `aud` = `clienteId`, `azp`, `exp`, `iat`, `nonce`; y su
  firma contra el JWKS del emisor (`verificarFirma: false` solo si el JWKS no admite CORS).
- Access token JWT: emitido por el mismo emisor, no vencido, y con la `audiencia` si se
  pidió. Con `audiencia` y un access token opaco no se abre sesión.
- PKCE S256 siempre; un emisor que no lo admite se rechaza.

Cada fallo es un `ErrorAutenticacion` con un `codigo` estable (`estado-invalido`,
`token-invalido`, `audiencia-invalida`, `sesion-expirada`...). Ninguno arrastra tokens ni
claims en su causa.

## Dónde viven los tokens

**`almacenamiento: 'memoria'` (por defecto).** Solo en esta instancia. Un script
inyectado no los encuentra en ningún almacén, pero recargar la página cierra la sesión
local; `entrar()` la recupera con una ida y vuelta al emisor sin pedir credenciales si su
sesión sigue viva.

**`almacenamiento: 'sesion'`.** Además en `sessionStorage`: sobreviven a la recarga, no a
cerrar la pestaña. El riesgo es concreto: cualquier XSS en el origen puede leer el access
token y el refresh token y usarlos fuera del navegador hasta que venzan. Úsalo solo si
la recarga frecuente es un problema real y el origen tiene una CSP estricta.

En los dos modos, la transacción de un inicio de sesión en curso (state, nonce,
verificador PKCE) va a `sessionStorage`, porque tiene que sobrevivir a la redirección; se
borra al volver.

`obtenerToken()` renueva con el refresh token si al access token le quedan menos de 30
s, con una sola renovación en vuelo aunque lo pidan diez peticiones a la vez. Si el
emisor rechaza la renovación, la sesión se cierra y `alCambiar` avisa con `null`; si el
emisor no responde, la sesión sigue y la próxima petición lo reintenta.

## Por qué oauth4webapi

El protocolo —validar la respuesta de autorización y el ID token— es el código donde un
descuido no se ve en ninguna prueba feliz. oauth4webapi está certificado por la OpenID
Foundation para el perfil Basic RP (el de este flujo), no tiene dependencias y corre
igual en el navegador y en Node. Este paquete pone encima lo que es de Aybar: el mapeo
de claims, la `Sesion`, el almacenamiento y la renovación.

/**
 * De qué claims sale la identidad, con las MISMAS reglas que el backend del SDK
 * (aybar-starter-security: `MapeoClaims`, `AybarUserContext.desdeJwt`,
 * `ConversorRolesAybar`).
 *
 * No es una preferencia de estilo: la pantalla decide qué botón enseñar con estos roles
 * y el backend decide si la operación pasa con los suyos. Si los dos leyeran el token de
 * forma distinta —una ruta anidada aquí, un claim literal allá—, el usuario vería un
 * botón que el backend le rechaza con 403, o al revés. Cada regla de abajo tiene su
 * gemela en Java, y las pruebas fijan las que más fácil se rompen.
 *
 * Los nombres por defecto son los del broker de identidad corporativo (Keycloak con los
 * mappers de Aybar). El framework no supone ese emisor: otro emisor OIDC se integra
 * cambiando nombres en `claims`, no código.
 */

export interface MapeoClaims {
  /** Identificador de la cuenta. Por defecto `user_account_id`. */
  readonly usuario: string
  /** Nombre de usuario. Por defecto `preferred_username`. */
  readonly nombreUsuario: string
  /** Empresa activa. Por defecto `companyId`. */
  readonly empresa: string
  /** Roles globales. Por defecto `realm_access.roles` (ruta anidada). */
  readonly roles: string
  /** Mapa empresa → roles. Por defecto `company_roles`. */
  readonly rolesPorEmpresa: string
  /** Identificador de sesión del emisor. Por defecto `sid`. */
  readonly sesion: string
  /**
   * Claims propios del servicio que se copian a `Sesion.atributos`. Vacío por defecto:
   * lo que la aplicación lee del token queda escrito en su configuración, no repartido
   * por el código (la misma regla que `aybar.security.claims.adicionales`).
   */
  readonly adicionales: readonly string[]
}

/** Los de `MapeoClaims.POR_DEFECTO` del backend, uno por uno. */
export const MAPEO_CLAIMS_POR_DEFECTO: MapeoClaims = Object.freeze({
  usuario: 'user_account_id',
  nombreUsuario: 'preferred_username',
  empresa: 'companyId',
  roles: 'realm_access.roles',
  rolesPorEmpresa: 'company_roles',
  sesion: 'sid',
  adicionales: Object.freeze([]) as readonly string[],
})

/** Nombre de cada campo tal como se configura en el backend, para que el error lo diga. */
const PROPIEDAD_BACKEND: Record<Exclude<keyof MapeoClaims, 'adicionales'>, string> = {
  usuario: 'usuario',
  nombreUsuario: 'nombre-usuario',
  empresa: 'empresa',
  roles: 'roles',
  rolesPorEmpresa: 'roles-por-empresa',
  sesion: 'sesion',
}

/**
 * Completa un mapeo parcial con los valores por defecto y lo valida. Un nombre vacío se
 * rechaza, como en el backend: un claim sin nombre no se puede leer y dejarlo pasar
 * daría una sesión vacía en silencio.
 */
export function resolverMapeo(parcial: Partial<MapeoClaims> = {}): MapeoClaims {
  const resultado = { ...MAPEO_CLAIMS_POR_DEFECTO, ...definidos(parcial) }
  for (const campo of Object.keys(PROPIEDAD_BACKEND) as (keyof typeof PROPIEDAD_BACKEND)[]) {
    const valor = resultado[campo]
    if (typeof valor !== 'string' || valor.trim() === '') {
      throw new TypeError(
        `claims.${campo} no puede estar vacío: es el nombre del claim que se lee (por defecto ` +
          `${MAPEO_CLAIMS_POR_DEFECTO[campo]}; en el backend, aybar.security.claims.` +
          `${PROPIEDAD_BACKEND[campo]}). Quítalo para usar el valor por defecto.`,
      )
    }
  }
  const adicionales: string[] = []
  ;(resultado.adicionales ?? []).forEach((nombre, i) => {
    if (typeof nombre !== 'string' || nombre.trim() === '') {
      throw new TypeError(`claims.adicionales[${i}] está vacío: cada elemento es el nombre de un claim.`)
    }
    if (!adicionales.includes(nombre)) adicionales.push(nombre)
  })
  return Object.freeze({ ...resultado, adicionales: Object.freeze(adicionales) })
}

function definidos<T extends object>(objeto: T): Partial<T> {
  return Object.fromEntries(Object.entries(objeto).filter(([, v]) => v !== undefined)) as Partial<T>
}

export type Claims = Readonly<Record<string, unknown>>

/** Un claim que el backend rechazaría por su forma. El backend responde 401; aquí no se abre sesión. */
export class ErrorClaims extends Error {
  override readonly name = 'ErrorClaims'
}

function esObjeto(valor: unknown): valor is Record<string, unknown> {
  return typeof valor === 'object' && valor !== null && !Array.isArray(valor)
}

/** Solo propiedades propias: `__proto__` o `constructor` como nombre de claim no leen el prototipo. */
function propia(objeto: Record<string, unknown>, clave: string): unknown {
  return Object.hasOwn(objeto, clave) ? objeto[clave] : undefined
}

/**
 * El valor del claim `nombre`. Gemela de `AybarUserContext.valor`:
 *
 * - con forma de URI (contiene `/` o `:`): el claim de ese nombre literal, para emisores
 *   que publican claims con espacio de nombres (`https://aybar.example/roles`);
 * - sin puntos: el claim de ese nombre;
 * - con puntos: SIEMPRE ruta de objetos anidados (`realm_access.roles`); si un tramo
 *   falta, `null`. Nunca se cae al nombre literal: un claim de primer nivel llamado
 *   `realm_access.roles` no puede aportar roles. El modo lo decide la configuración, no
 *   la forma del token.
 *
 * Una ruta que atraviesa algo que no es un objeto lanza `ErrorClaims`.
 */
export function leerClaim(claims: Claims, nombre: string): unknown {
  if (nombre.includes('/') || nombre.includes(':') || !nombre.includes('.')) {
    return propia(claims as Record<string, unknown>, nombre) ?? null
  }
  let actual: unknown = claims
  let recorrido = ''
  for (const segmento of nombre.split('.')) {
    if (actual === null || actual === undefined) return null
    if (!esObjeto(actual)) {
      throw new ErrorClaims(`El claim ${recorrido} debe ser un objeto JSON para leer ${nombre}`)
    }
    actual = propia(actual, segmento)
    recorrido = recorrido === '' ? segmento : `${recorrido}.${segmento}`
  }
  return actual ?? null
}

/** Lo que se lee del token, antes de convertirlo en una `Sesion`. */
export interface IdentidadAybar {
  readonly usuarioId: string | null
  readonly nombreUsuario: string | null
  readonly empresaId: string | null
  /** Solo los globales; la `Sesion` les suma los de la empresa activa. */
  readonly rolesGlobales: readonly string[]
  readonly rolesPorEmpresa: Readonly<Record<string, readonly string[]>>
  readonly sesionId: string | null
  readonly atributos: Readonly<Record<string, unknown>>
}

/**
 * Gemela de `AybarUserContext.desdeJwt`. Un claim ausente no es un error —da `null` o
 * una colección vacía—; uno con forma inválida sí, como en el backend.
 */
export function identidadDesdeClaims(claims: Claims, mapeo: MapeoClaims = MAPEO_CLAIMS_POR_DEFECTO): IdentidadAybar {
  return Object.freeze({
    usuarioId: texto(claims, mapeo.usuario),
    nombreUsuario: texto(claims, mapeo.nombreUsuario),
    empresaId: texto(claims, mapeo.empresa),
    rolesGlobales: rolesGlobales(claims, mapeo.roles),
    rolesPorEmpresa: rolesPorEmpresa(leerClaim(claims, mapeo.rolesPorEmpresa), mapeo.rolesPorEmpresa),
    sesionId: texto(claims, mapeo.sesion),
    atributos: adicionales(claims, mapeo.adicionales),
  })
}

/**
 * Los roles que autoriza el backend: los globales más los de la empresa activa, sin
 * duplicados y en ese orden (`ConversorRolesAybar.authoritiesDe`). Los de otras empresas
 * no cuentan: la pantalla ve el tenant activo, no el holding entero, igual que
 * `@PreAuthorize`.
 */
export function rolesEfectivos(identidad: IdentidadAybar): readonly string[] {
  const roles = new Set(identidad.rolesGlobales)
  if (identidad.empresaId !== null) {
    for (const rol of identidad.rolesPorEmpresa[identidad.empresaId] ?? []) roles.add(rol)
  }
  return Object.freeze([...roles])
}

/** Misma conversión a texto que `Jwt#getClaimAsString`: un número o un booleano se escriben. */
function texto(claims: Claims, nombre: string): string | null {
  const valor = leerClaim(claims, nombre)
  if (valor === null) return null
  if (typeof valor === 'string') return valor
  if (typeof valor === 'object') return JSON.stringify(valor)
  return String(valor)
}

function rolesGlobales(claims: Claims, nombre: string): readonly string[] {
  const roles = leerClaim(claims, nombre)
  if (roles === null) return Object.freeze([])
  if (!Array.isArray(roles)) throw new ErrorClaims(`${nombre} debe ser una colección`)
  return Object.freeze(roles.map((r) => String(r)))
}

function rolesPorEmpresa(claim: unknown, nombre: string): Readonly<Record<string, readonly string[]>> {
  if (claim === null) return Object.freeze({})
  if (typeof claim === 'string') {
    if (claim.trim() === '') return Object.freeze({})
    let parseado: unknown
    try {
      parseado = JSON.parse(claim)
    } catch {
      throw new ErrorClaims(`El claim ${nombre} no contiene JSON válido`)
    }
    if (!esObjeto(parseado)) throw new ErrorClaims(`El claim ${nombre} no contiene JSON válido`)
    return convertir(parseado, nombre)
  }
  if (esObjeto(claim)) return convertir(claim, nombre)
  throw new ErrorClaims(`El claim ${nombre} debe ser un objeto JSON o un String JSON`)
}

/**
 * Los mapas se arman con `Object.fromEntries` y no asignando clave por clave: una empresa
 * llamada `__proto__` en el token cambiaría el prototipo del objeto con una asignación, y
 * `fromEntries` la define como propiedad propia.
 */
function convertir(crudo: Record<string, unknown>, nombre: string): Readonly<Record<string, readonly string[]>> {
  const entradas = Object.entries(crudo).map(([empresa, valor]): [string, readonly string[]] => {
    if (valor === null || valor === undefined) return [empresa, Object.freeze([])]
    if (!Array.isArray(valor)) {
      throw new ErrorClaims(`cada valor de ${nombre} debe ser una lista de roles`)
    }
    return [empresa, Object.freeze(valor.map((r) => String(r)))]
  })
  return Object.freeze(Object.fromEntries(entradas))
}

function adicionales(claims: Claims, nombres: readonly string[]): Readonly<Record<string, unknown>> {
  const encontrados: [string, unknown][] = []
  for (const nombre of nombres) {
    const valor = leerClaim(claims, nombre)
    if (valor !== null) encontrados.push([nombre, congelar(structuredClone(valor))])
  }
  return Object.freeze(Object.fromEntries(encontrados))
}

/** Copia inmutable y profunda: un atributo anidado tampoco se puede modificar. */
function congelar<T>(valor: T): T {
  if (typeof valor === 'object' && valor !== null) {
    for (const interno of Object.values(valor)) congelar(interno)
    Object.freeze(valor)
  }
  return valor
}

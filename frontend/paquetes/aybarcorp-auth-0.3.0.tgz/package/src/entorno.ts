/**
 * Lo único que la autenticación toca del navegador, detrás de una interfaz.
 *
 * Existe por dos motivos. El primero es que el módulo se pueda importar en un servidor
 * —un `import` de Next.js durante el render, una prueba en Node— sin que nada lea
 * `window` hasta que de verdad se inicie sesión. El segundo es poder probar el flujo
 * completo contra un emisor de verdad sin un navegador de por medio.
 */

/** El subconjunto de `Storage` que se usa. `sessionStorage` lo cumple. */
export interface AlmacenClaveValor {
  getItem(clave: string): string | null
  setItem(clave: string, valor: string): void
  removeItem(clave: string): void
}

export interface EntornoNavegador {
  /** URL actual, completa. */
  url(): string
  /** Navegación de página completa: sale de la aplicación hacia el emisor. */
  redirigir(url: string): void
  /** Reemplaza la URL visible sin recargar: quita `code` y `state` tras el retorno. */
  reemplazarUrl(url: string): void
  /**
   * Almacén por pestaña que sobrevive a la redirección. Guarda la transacción en curso
   * (state, nonce, verificador PKCE) y, solo con `almacenamiento: 'sesion'`, los tokens.
   */
  readonly almacen: AlmacenClaveValor
}

function ventana(): Window {
  if (typeof window === 'undefined') {
    throw new Error(
      '@aybarcorp/auth necesita un navegador para iniciar sesión: no hay `window`. ' +
        'Si esto corre en el servidor (SSR) llama a iniciar() y entrar() solo en el cliente, ' +
        'o pasa un `entorno` propio a crearAutenticacion.',
    )
  }
  return window
}

/** El entorno real: `location`, `history` y `sessionStorage`, leídos en cada uso. */
export function entornoNavegador(): EntornoNavegador {
  return {
    url: () => ventana().location.href,
    redirigir: (url) => ventana().location.assign(url),
    reemplazarUrl: (url) => {
      const w = ventana()
      w.history.replaceState(w.history.state, '', url)
    },
    almacen: {
      getItem: (clave) => ventana().sessionStorage.getItem(clave),
      setItem: (clave, valor) => ventana().sessionStorage.setItem(clave, valor),
      removeItem: (clave) => ventana().sessionStorage.removeItem(clave),
    },
  }
}

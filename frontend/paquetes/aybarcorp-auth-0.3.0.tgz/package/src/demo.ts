import { entornoNavegador } from './entorno.js'
import type { EntornoNavegador } from './entorno.js'
import { ErrorAutenticacion } from './errores.js'
import type { Autenticacion, SesionAutenticada } from './autenticacion.js'

/**
 * Autenticación simulada para desarrollo local: la pantalla de login es de la propia
 * aplicación (el Login Form del sistema de diseño) y la contraseña se compara en el
 * navegador contra una lista de usuarios de prueba.
 *
 * Existe para poder recorrer la aplicación mientras no hay emisor OIDC en local. Tiene
 * la misma interfaz que `crearAutenticacion`, así que el resto de la aplicación
 * —`ProveedorAutenticacion`, `useSesion`, el cliente HTTP— no sabe cuál de las dos
 * tiene detrás: pasar al emisor real es cambiar la configuración, no el código.
 *
 * Lo que NO es: seguridad. La lista de usuarios viaja en el bundle, cualquiera la lee, y
 * la sesión no tiene access token —`obtenerToken()` falla con `sin-token-demo`—, así que
 * un backend protegido responde 401 a todo lo que se le pida con ella. Por eso:
 *
 * - Se niega a arrancar fuera de localhost (`demo-fuera-de-local`): un build que se
 *   publique con el modo demo encendido no muestra un login falso, falla.
 * - Las plantillas del SDK solo la crean en desarrollo (`import.meta.env.DEV`,
 *   `isDevMode()`), con usuarios leídos de `.env.development`, que no entra en el build
 *   de producción.
 *
 * ```ts
 * const autenticacion = import.meta.env.DEV && import.meta.env.VITE_AYBAR_DEMO_USUARIO
 *   ? crearAutenticacionDemo({ usuarios: [{ usuario, clave, nombre, roles }] })
 *   : crearAutenticacion({ emisor, clienteId, redirectUri })
 * ```
 */

export interface UsuarioDemo {
  /** Lo que se escribe en el campo usuario. Se compara sin distinguir mayúsculas. */
  readonly usuario: string
  /** Contraseña de prueba. Se compara tal cual, en el navegador. */
  readonly clave: string
  /** Nombre visible; por defecto, el usuario. */
  readonly nombre?: string
  /** Roles globales; por defecto `['USER']`. */
  readonly roles?: readonly string[]
  readonly empresaId?: string
  readonly rolesPorEmpresa?: Readonly<Record<string, readonly string[]>>
  readonly atributos?: Readonly<Record<string, unknown>>
}

export interface OpcionesAutenticacionDemo {
  /** Usuarios de prueba. Al menos uno. */
  readonly usuarios: readonly UsuarioDemo[]
  /** Ruta de la pantalla de login de la aplicación. Por defecto `/ingresar`. */
  readonly rutaLogin?: string
  /** Por defecto la ventana real, con `sessionStorage`: la sesión sobrevive a recargar. */
  readonly entorno?: EntornoNavegador
}

export interface AutenticacionDemo extends Autenticacion {
  /** Siempre `true`: la pantalla puede avisar que la sesión es simulada. */
  readonly demo: true
  /** Ruta de la pantalla de login de la aplicación. */
  readonly rutaLogin: string
  /**
   * Lo que hace el botón «Ingresar» del Login Form. Abre la sesión o lanza
   * `ErrorAutenticacion` con código `credenciales-invalidas`.
   */
  ingresar(usuario: string, clave: string): Promise<SesionAutenticada>
}

/** Solo el usuario, nunca la clave: lo justo para restaurar la sesión al recargar. */
const CLAVE_ALMACEN = 'aybar.auth.demo.usuario'

const HOSTS_LOCALES = new Set(['localhost', '127.0.0.1', '[::1]', '::1'])

function esLocal(url: string): boolean {
  const { hostname } = new URL(url)
  return HOSTS_LOCALES.has(hostname) || hostname.endsWith('.localhost')
}

export function crearAutenticacionDemo(opciones: OpcionesAutenticacionDemo): AutenticacionDemo {
  if (!opciones || !Array.isArray(opciones.usuarios) || opciones.usuarios.length === 0) {
    throw new ErrorAutenticacion('configuracion', 'crearAutenticacionDemo necesita al menos un usuario de prueba.')
  }
  for (const [i, u] of opciones.usuarios.entries()) {
    if (!u || typeof u.usuario !== 'string' || !u.usuario.trim() || typeof u.clave !== 'string' || !u.clave) {
      throw new ErrorAutenticacion('configuracion', `usuarios[${i}] necesita usuario y clave no vacíos.`)
    }
  }
  const entorno = opciones.entorno ?? entornoNavegador()
  const rutaLogin = opciones.rutaLogin ?? '/ingresar'
  if (!rutaLogin.startsWith('/') || rutaLogin.startsWith('//')) {
    throw new ErrorAutenticacion('configuracion', `rutaLogin debe ser una ruta relativa al sitio ("/ingresar"), no "${rutaLogin}".`)
  }

  let actual: SesionAutenticada | null = null
  const escuchas = new Set<(sesion: SesionAutenticada | null) => void>()
  const avisar = () => {
    for (const escucha of [...escuchas]) escucha(actual)
  }

  const exigirLocal = () => {
    if (!esLocal(entorno.url())) {
      throw new ErrorAutenticacion(
        'demo-fuera-de-local',
        'La autenticación demo solo corre en localhost. Este build tiene el modo demo encendido ' +
          'fuera de desarrollo: configura el emisor OIDC (crearAutenticacion) para este ambiente.',
      )
    }
  }

  const buscar = (usuario: string) => {
    const nombre = usuario.trim().toLowerCase()
    return opciones.usuarios.find((u) => u.usuario.trim().toLowerCase() === nombre) ?? null
  }

  const sesionDe = (u: UsuarioDemo): SesionAutenticada => {
    const roles = Object.freeze([...(u.roles ?? ['USER'])])
    return Object.freeze({
      usuarioId: u.usuario,
      nombre: u.nombre ?? u.usuario,
      roles,
      empresaId: u.empresaId,
      rolesPorEmpresa: u.rolesPorEmpresa,
      atributos: Object.freeze({ ...(u.atributos ?? {}), demo: true }),
      sesionId: 'demo',
      obtenerToken: () =>
        Promise.reject(
          new ErrorAutenticacion(
            'sin-token-demo',
            'La sesión demo no tiene access token: el backend protegido la rechaza. ' +
              'Para llamarlo hace falta el emisor OIDC real.',
          ),
        ),
      tieneRol: (rol: string) => roles.includes(rol),
    })
  }

  let iniciada: Promise<SesionAutenticada | null> | null = null

  return {
    demo: true,
    rutaLogin,
    iniciar() {
      iniciada ??= Promise.resolve().then(() => {
        exigirLocal()
        const guardado = entorno.almacen.getItem(CLAVE_ALMACEN)
        const u = guardado ? buscar(guardado) : null
        if (u) {
          actual = sesionDe(u)
          avisar()
        } else if (guardado) {
          // El usuario guardado ya no está en la lista: la sesión no se restaura.
          entorno.almacen.removeItem(CLAVE_ALMACEN)
        }
        return actual
      })
      return iniciada
    },
    async ingresar(usuario, clave) {
      exigirLocal()
      const u = buscar(usuario)
      // El mismo error para usuario inexistente y clave errónea: el Login Form no debe
      // revelar cuál de los dos falló.
      if (!u || u.clave !== clave) {
        throw new ErrorAutenticacion('credenciales-invalidas', 'Usuario o contraseña incorrectos.')
      }
      actual = sesionDe(u)
      entorno.almacen.setItem(CLAVE_ALMACEN, u.usuario)
      avisar()
      return actual
    },
    async entrar(destino) {
      exigirLocal()
      const url = new URL(rutaLogin, entorno.url())
      if (destino && destino.startsWith('/') && !destino.startsWith('//')) url.searchParams.set('destino', destino)
      entorno.redirigir(url.toString())
    },
    async salir() {
      actual = null
      entorno.almacen.removeItem(CLAVE_ALMACEN)
      avisar()
    },
    sesion: () => actual,
    alCambiar(escucha) {
      escuchas.add(escucha)
      return () => {
        escuchas.delete(escucha)
      }
    },
  }
}

import { createContext, useContext, useEffect, useMemo, useState } from 'react'
import type { ReactNode } from 'react'
import type { Autenticacion, SesionAutenticada } from './autenticacion.js'

/**
 * Enlace React de la autenticación. Angular no necesita este módulo: usa
 * `crearAutenticacion` directamente desde un servicio o un `APP_INITIALIZER`.
 *
 * ```tsx
 * const autenticacion = crearAutenticacion({ emisor, clienteId, redirectUri })
 *
 * <ProveedorAutenticacion autenticacion={autenticacion} cargando={<Spinner />}>
 *   <BrowserRouter>...</BrowserRouter>
 * </ProveedorAutenticacion>
 * ```
 *
 * Con `cargando`, los hijos no se montan hasta que `iniciar()` termina. Es lo que se
 * quiere casi siempre: el router lee la URL al montarse, y el retorno del emisor la
 * reescribe (quita `code` y `state`, vuelve al destino) antes de resolver.
 *
 * En Next.js (App Router) este módulo se importa desde un componente `'use client'`.
 */

export type FaseAutenticacion = 'iniciando' | 'lista' | 'error'

export interface EstadoAutenticacion {
  readonly fase: FaseAutenticacion
  readonly sesion: SesionAutenticada | null
  /** El error de `iniciar()`, si la fase es `error`. */
  readonly error: unknown
  readonly entrar: (destino?: string) => Promise<void>
  readonly salir: () => Promise<void>
}

const ContextoAutenticacion = createContext<EstadoAutenticacion | null>(null)

export function ProveedorAutenticacion({
  autenticacion,
  cargando,
  fallo,
  children,
}: {
  /** Una sola instancia por aplicación, creada fuera del árbol de React. */
  autenticacion: Autenticacion
  /** Qué mostrar mientras `iniciar()` trabaja. Sin él, los hijos se montan de inmediato. */
  cargando?: ReactNode
  /** Qué mostrar si `iniciar()` falla. Sin él, los hijos se montan y leen `error`. */
  fallo?: (error: unknown) => ReactNode
  children: ReactNode
}) {
  const [estado, setEstado] = useState<{ fase: FaseAutenticacion; sesion: SesionAutenticada | null; error: unknown }>(
    () => ({ fase: 'iniciando', sesion: autenticacion.sesion(), error: null }),
  )

  useEffect(() => {
    let vigente = true
    const baja = autenticacion.alCambiar((sesion) => {
      if (vigente) setEstado((previo) => ({ ...previo, sesion }))
    })
    // iniciar() es idempotente: el doble efecto del modo estricto no canjea dos veces.
    autenticacion.iniciar().then(
      () => {
        if (vigente) setEstado({ fase: 'lista', sesion: autenticacion.sesion(), error: null })
      },
      (error: unknown) => {
        if (vigente) setEstado({ fase: 'error', sesion: autenticacion.sesion(), error })
      },
    )
    return () => {
      vigente = false
      baja()
    }
  }, [autenticacion])

  const valor = useMemo<EstadoAutenticacion>(
    () => ({
      ...estado,
      entrar: (destino) => autenticacion.entrar(destino),
      salir: () => autenticacion.salir(),
    }),
    [estado, autenticacion],
  )

  if (estado.fase === 'iniciando' && cargando !== undefined) return <>{cargando}</>
  if (estado.fase === 'error' && fallo) return <>{fallo(estado.error)}</>
  return <ContextoAutenticacion.Provider value={valor}>{children}</ContextoAutenticacion.Provider>
}

/** Fase, sesión, error y las acciones de entrar y salir. */
export function useAutenticacion(): EstadoAutenticacion {
  const valor = useContext(ContextoAutenticacion)
  if (!valor) {
    throw new Error('useAutenticacion y useSesion requieren un <ProveedorAutenticacion> por encima.')
  }
  return valor
}

/** La sesión vigente, o `null`. Se actualiza al abrir, renovar y cerrar sesión. */
export function useSesion(): SesionAutenticada | null {
  return useAutenticacion().sesion
}

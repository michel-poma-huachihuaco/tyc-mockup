/**
 * Los errores de autenticación, con un `codigo` estable por el que la aplicación decide
 * qué mostrar. El mensaje es para el desarrollador; la pantalla decide por el código.
 *
 * Ninguno arrastra tokens ni claims. Los errores de oauth4webapi sí los traen en su
 * `cause` —el cuerpo de la respuesta del token endpoint, los claims del ID token que no
 * validó—, y un error que acaba en la consola o en la observabilidad del anfitrión los
 * filtraría. Por eso no se encadenan tal cual: se copia su mensaje y su código, nada más.
 */

export type CodigoErrorAutenticacion =
  /** Opciones de `crearAutenticacion` inválidas. */
  | 'configuracion'
  /** No se pudo leer `.well-known/openid-configuration` o no sirve para este flujo. */
  | 'descubrimiento'
  /** Volvió un código del emisor pero no hay inicio de sesión en curso en esta pestaña. */
  | 'sin-transaccion'
  /** El `state` del retorno no es el que se envió: posible CSRF o pestaña cruzada. */
  | 'estado-invalido'
  /** El emisor devolvió un error en la redirección (`access_denied`, ...). */
  | 'respuesta-autorizacion'
  /** La redirección de vuelta no es válida (p. ej. `iss` de RFC 9207 ajeno). */
  | 'respuesta-invalida'
  /** El token endpoint rechazó el intercambio del código o no se pudo contactar. */
  | 'intercambio'
  /** El ID token o el access token no pasan la validación (iss, aud, nonce, exp, firma). */
  | 'token-invalido'
  /** Se pidió `audiencia` y el access token no la trae o no se puede comprobar. */
  | 'audiencia-invalida'
  /** Los claims corporativos tienen una forma que el backend también rechazaría. */
  | 'claims-malformados'
  /** Se pidió un token sin sesión abierta, o la sesión ya se cerró. */
  | 'sin-sesion'
  /** El token venció y no se pudo renovar: el emisor rechazó la renovación. */
  | 'sesion-expirada'
  /** La renovación falló por la red; la sesión sigue y se reintenta en la próxima petición. */
  | 'renovacion'
  /** Modo demo: usuario o contraseña no coinciden con ningún usuario de la lista local. */
  | 'credenciales-invalidas'
  /** Modo demo: la sesión simulada no tiene access token; el backend protegido la rechaza. */
  | 'sin-token-demo'
  /** Modo demo fuera de localhost: se niega a arrancar para no publicar un login falso. */
  | 'demo-fuera-de-local'

export class ErrorAutenticacion extends Error {
  override readonly name = 'ErrorAutenticacion'
  readonly codigo: CodigoErrorAutenticacion
  /** El `error` de OAuth cuando el emisor lo devolvió: `access_denied`, `invalid_grant`... */
  readonly errorOAuth: string | null

  constructor(
    codigo: CodigoErrorAutenticacion,
    mensaje: string,
    opciones: { cause?: unknown; errorOAuth?: string | null } = {},
  ) {
    super(mensaje, opciones.cause === undefined ? undefined : { cause: opciones.cause })
    this.codigo = codigo
    this.errorOAuth = opciones.errorOAuth ?? null
  }
}

/**
 * La causa sin datos: nombre, mensaje y código del error original. El `cause` de un
 * error de oauth4webapi puede contener el cuerpo con los tokens o los claims.
 */
export function causaSaneada(error: unknown): Error | undefined {
  if (error === undefined || error === null) return undefined
  if (!(error instanceof Error)) return new Error(String(error))
  const copia = new Error(error.message)
  copia.name = error.name
  const codigo = (error as { code?: unknown }).code
  if (typeof codigo === 'string') Object.defineProperty(copia, 'code', { value: codigo, enumerable: true })
  return copia
}

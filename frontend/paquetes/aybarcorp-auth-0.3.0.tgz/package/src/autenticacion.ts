import * as oauth from 'oauth4webapi'
import type { Sesion } from '@aybarcorp/core'
import { entornoNavegador } from './entorno.js'
import type { EntornoNavegador } from './entorno.js'
import { ErrorAutenticacion, causaSaneada } from './errores.js'
import { cargaJwtSinVerificar } from './jwt.js'
import { ErrorClaims, identidadDesdeClaims, resolverMapeo, rolesEfectivos } from './mapeo-claims.js'
import type { IdentidadAybar, MapeoClaims } from './mapeo-claims.js'

/**
 * Inicio de sesión OIDC en el navegador: Authorization Code con PKCE S256, para un
 * cliente público (sin secreto: una SPA no puede guardar uno).
 *
 * Es neutral de emisor. No sabe de Keycloak, de Entra ID ni de Cognito: descubre los
 * endpoints en `<emisor>/.well-known/openid-configuration` y lee la identidad con el
 * mismo mapeo de claims que el backend del SDK, configurable igual que allí. Qué emisor
 * se usa lo decide el ADR de cada servicio; Keycloak solo es el entorno local.
 *
 * Lo que valida, y quién:
 *   - la respuesta de autorización: `state` (aquí y en oauth4webapi), `iss` de RFC 9207
 *     cuando el emisor lo anuncia, y el `error` que devuelva el emisor;
 *   - el ID token: `iss`, `aud` (= clienteId), `azp`, `exp`, `iat` y `nonce`
 *     (oauth4webapi), y su firma contra el JWKS del emisor (`verificarFirma`, activo por
 *     defecto);
 *   - el access token, si es un JWT: que lo emitió el mismo emisor, que no llegó vencido
 *     y, si se pasa `audiencia`, que la trae. Su firma NO: la verifica la API, que es para
 *     quien es el token (ver jwt.ts).
 *
 * Dónde viven los tokens: en memoria por defecto. Ver `almacenamiento`.
 */

export type Almacenamiento = 'memoria' | 'sesion'

export interface OpcionesAutenticacion {
  /** Issuer exacto del emisor, p. ej. `https://idp.example/realms/aybar`. */
  readonly emisor: string
  /** Cliente público registrado en el emisor. */
  readonly clienteId: string
  /** URL absoluta a la que vuelve el emisor con el código. Debe estar registrada tal cual. */
  readonly redirectUri: string
  /** A dónde vuelve el emisor tras cerrar sesión. Debe estar registrada en el emisor. */
  readonly postLogoutRedirectUri?: string
  /** Por defecto `openid profile`. Tiene que incluir `openid`. */
  readonly alcance?: string
  /**
   * Audiencia que debe traer el access token (p. ej. `aybar-api`). Si se pasa y el
   * access token es opaco o no la trae, no se abre sesión: mejor fallar aquí que con un
   * 401 en cada petición.
   */
  readonly audiencia?: string
  /** Nombres de los claims, con los mismos valores por defecto que el backend. */
  readonly claims?: Partial<MapeoClaims>
  /**
   * `memoria` (por defecto): los tokens viven en el cierre de esta instancia. Un script
   * inyectado no los encuentra en ningún almacén, pero recargar la página cierra la
   * sesión local; `entrar()` la recupera con una ida y vuelta al emisor, sin pedir
   * credenciales si su sesión sigue viva.
   *
   * `sesion`: además se guardan en `sessionStorage` y sobreviven a la recarga (no a
   * cerrar la pestaña). El riesgo es concreto: cualquier XSS en el origen puede leer el
   * access token y el refresh token y usarlos fuera del navegador hasta que venzan. Úsalo
   * solo si la recarga frecuente es un problema real y el origen tiene una CSP estricta.
   */
  readonly almacenamiento?: Almacenamiento
  /**
   * Parámetros extra para el endpoint de autorización que algunos emisores necesitan
   * (`audience`, `resource`, `prompt`, `ui_locales`...). Los del protocolo no se pueden
   * pisar.
   */
  readonly parametrosAutorizacion?: Readonly<Record<string, string>>
  /**
   * Verifica la firma del ID token contra el JWKS del emisor. Activo por defecto.
   *
   * OIDC Core §3.1.3.7 permite omitirla cuando el ID token llega directo del token
   * endpoint por TLS, que es este caso. Desactívalo solo si el JWKS del emisor no admite
   * CORS desde el navegador; el resto de validaciones sigue igual.
   */
  readonly verificarFirma?: boolean
  /** Plazo de cada petición al emisor. Por defecto 15000. */
  readonly tiempoEsperaMs?: number
  /** El navegador detrás de una interfaz: para pruebas y para hosts que no son `window`. */
  readonly entorno?: EntornoNavegador
}

/**
 * La `Sesion` del contrato del core, con lo que el token dice además del usuario.
 *
 * Los tres opcionales de en medio son los que el core declara como opcionales en la
 * `Sesion` (empresa activa, roles por empresa, atributos): aquí se declaran con el mismo
 * tipo para que la interfaz siga siendo compatible tanto con un core que ya los tenga
 * como con uno que no.
 */
export interface SesionAutenticada extends Sesion {
  /** Empresa activa (claim `empresa` del mapeo). */
  readonly empresaId?: string
  /** Roles por empresa, completos: los de todas las empresas del usuario. */
  readonly rolesPorEmpresa?: Readonly<Record<string, readonly string[]>>
  /** Claims declarados en `claims.adicionales`, solo los presentes. */
  readonly atributos?: Readonly<Record<string, unknown>>
  /** Identificador de sesión del emisor (claim `sesion` del mapeo, `sid` por defecto). */
  readonly sesionId?: string
}

export interface Autenticacion {
  /**
   * Llamar una vez al arrancar la aplicación, antes de montar el router. Si la URL es el
   * retorno del emisor, intercambia el código y limpia la URL; si hay una sesión
   * guardada (`almacenamiento: 'sesion'`), la restaura. Devuelve la sesión o `null`.
   * Llamarla dos veces no repite el trabajo (React en modo estricto lo hace).
   */
  iniciar(): Promise<SesionAutenticada | null>
  /** Redirige al emisor. `destino` (ruta relativa) es a dónde volver; por defecto, aquí. */
  entrar(destino?: string): Promise<void>
  /** Cierra la sesión local y, si el emisor tiene `end_session_endpoint`, también la suya. */
  salir(): Promise<void>
  sesion(): SesionAutenticada | null
  /** Avisa al abrir, renovar o cerrar la sesión. Devuelve la función para dejar de escuchar. */
  alCambiar(escucha: (sesion: SesionAutenticada | null) => void): () => void
}

/** Un token que vence en menos que esto se renueva antes de entregarlo. */
const MARGEN_RENOVACION_MS = 30_000
/** La misma tolerancia de reloj que oauth4webapi aplica al ID token. */
const TOLERANCIA_RELOJ_MS = 30_000
/** Una transacción más vieja que esto no se acepta: nadie tarda tanto en escribir su clave. */
const VIDA_TRANSACCION_MS = 10 * 60_000
const TIEMPO_ESPERA_POR_DEFECTO_MS = 15_000

/** Los que arma este módulo; `parametrosAutorizacion` no puede reemplazarlos. */
const PARAMETROS_RESERVADOS = new Set([
  'response_type',
  'client_id',
  'redirect_uri',
  'scope',
  'state',
  'nonce',
  'code_challenge',
  'code_challenge_method',
])

/** Lo que el emisor añade a la URL de retorno y que no debe quedar en el historial. */
const PARAMETROS_DE_RETORNO = ['code', 'state', 'iss', 'session_state', 'error', 'error_description', 'error_uri']

interface Transaccion {
  readonly estado: string
  readonly nonce: string
  readonly verificador: string
  readonly destino: string
  readonly creada: number
}

interface Tokens {
  readonly accessToken: string
  readonly idToken: string
  readonly refreshToken: string | null
  /** Instante (ms) en que vence el access token; `null` si no se sabe. */
  readonly expiraEn: number | null
  readonly claimsId: Readonly<Record<string, unknown>>
  readonly emisor: string
}

interface Configuracion {
  readonly emisor: URL
  readonly clienteId: string
  readonly redirectUri: URL
  readonly postLogoutRedirectUri: string | null
  readonly alcance: string
  readonly audiencia: string | null
  readonly almacenamiento: Almacenamiento
  readonly parametrosAutorizacion: Readonly<Record<string, string>>
  readonly verificarFirma: boolean
  readonly tiempoEsperaMs: number
  /** http solo contra un emisor en esta máquina (Keycloak local en :8080). */
  readonly inseguroLocal: boolean
}

export function crearAutenticacion(opciones: OpcionesAutenticacion): Autenticacion {
  const config = validarOpciones(opciones)
  let mapeo: MapeoClaims
  try {
    mapeo = resolverMapeo(opciones.claims)
  } catch (error) {
    throw new ErrorAutenticacion('configuracion', (error as Error).message)
  }
  const entorno = opciones.entorno ?? entornoNavegador()
  const cliente: oauth.Client = { client_id: config.clienteId }
  const sinSecreto = oauth.None()
  const cacheJwks: oauth.JWKSCacheInput = {}
  const prefijo = `aybar.auth:${config.clienteId}`
  const claveTransaccion = `${prefijo}:transaccion`
  const claveSesion = `${prefijo}:sesion`

  let servidor: Promise<oauth.AuthorizationServer> | null = null
  let estado: Tokens | null = null
  let vista: SesionAutenticada | null = null
  /** Identifica la sesión abierta. Cambia al abrir y al cerrar; renovar la conserva. */
  let generacion = 0
  let contador = 0
  let inicio: Promise<unknown> | null = null
  let renovacion: Promise<void> | null = null
  const escuchas = new Set<(sesion: SesionAutenticada | null) => void>()

  const opcionesHttp = () => ({
    [oauth.allowInsecureRequests]: config.inseguroLocal,
    signal: () => AbortSignal.timeout(config.tiempoEsperaMs),
  })

  // ── Descubrimiento ──────────────────────────────────────────────────────────

  function descubrir(): Promise<oauth.AuthorizationServer> {
    servidor ??= (async () => {
      let as: oauth.AuthorizationServer
      try {
        const respuesta = await oauth.discoveryRequest(config.emisor, { algorithm: 'oidc', ...opcionesHttp() })
        as = await oauth.processDiscoveryResponse(config.emisor, respuesta)
      } catch (error) {
        throw new ErrorAutenticacion(
          'descubrimiento',
          `No se pudo leer la configuración OIDC de ${config.emisor.href}. Comprueba que \`emisor\` ` +
            'es el issuer exacto (con o sin barra final, tal como lo publica el emisor) y que responde.',
          { cause: causaSaneada(error) },
        )
      }
      if (!as.authorization_endpoint || !as.token_endpoint) {
        throw new ErrorAutenticacion('descubrimiento', 'El emisor no publica authorization_endpoint y token_endpoint.')
      }
      const metodos = as.code_challenge_methods_supported
      if (metodos !== undefined && !metodos.includes('S256')) {
        throw new ErrorAutenticacion(
          'descubrimiento',
          `El emisor no admite PKCE S256 (anuncia: ${metodos.join(', ') || 'ninguno'}). Sin PKCE un ` +
            'cliente público no es seguro, y este paquete no lo desactiva.',
        )
      }
      return as
    })().catch((error: unknown) => {
      servidor = null // un emisor caído al arrancar no deja la instancia inservible
      throw error
    })
    return servidor
  }

  // ── Transacción (sobrevive a la redirección, en sessionStorage) ──────────────

  function guardarTransaccion(tx: Transaccion) {
    try {
      entorno.almacen.setItem(claveTransaccion, JSON.stringify(tx))
    } catch (error) {
      throw new ErrorAutenticacion(
        'configuracion',
        'No se pudo guardar el inicio de sesión en sessionStorage, y sin él no se puede ' +
          'comprobar el retorno del emisor. ¿El navegador bloquea el almacenamiento del sitio?',
        { cause: causaSaneada(error) },
      )
    }
  }

  /** Lee y borra en el mismo paso: un código se canjea una vez. */
  function tomarTransaccion(): Transaccion | null {
    let crudo: string | null = null
    try {
      crudo = entorno.almacen.getItem(claveTransaccion)
      entorno.almacen.removeItem(claveTransaccion)
    } catch {
      return null
    }
    if (!crudo) return null
    try {
      const tx = JSON.parse(crudo) as Partial<Transaccion>
      const valida =
        typeof tx.estado === 'string' &&
        typeof tx.nonce === 'string' &&
        typeof tx.verificador === 'string' &&
        typeof tx.destino === 'string' &&
        typeof tx.creada === 'number'
      if (!valida) return null
      // El destino vuelve de un almacén que cualquier script del origen puede escribir:
      // se valida otra vez para que nunca termine en un replaceState hacia otro origen.
      return { ...(tx as Transaccion), destino: esDestinoValido(tx.destino) ? tx.destino : '/' }
    } catch {
      return null
    }
  }

  // ── Retorno del emisor ──────────────────────────────────────────────────────

  function esRetorno(url: URL): boolean {
    return (
      url.origin === config.redirectUri.origin &&
      url.pathname === config.redirectUri.pathname &&
      url.searchParams.has('state') &&
      (url.searchParams.has('code') || url.searchParams.has('error'))
    )
  }

  async function procesarRetorno(url: URL): Promise<void> {
    const parametros = new URLSearchParams(url.search)
    const tx = tomarTransaccion()
    // La URL se limpia antes del canje y no después: recargar a mitad no reenvía el
    // código, y un fallo no deja `code` en el historial ni en el Referer siguiente.
    entorno.reemplazarUrl(tx?.destino ?? sinParametrosDeRetorno(url))

    if (!tx || Date.now() - tx.creada > VIDA_TRANSACCION_MS) {
      throw new ErrorAutenticacion(
        'sin-transaccion',
        'Volvió un código del emisor pero en esta pestaña no hay un inicio de sesión en curso ' +
          '(o tiene más de 10 minutos). Se descarta: llama a entrar() de nuevo.',
      )
    }
    if (parametros.get('state') !== tx.estado) {
      throw new ErrorAutenticacion(
        'estado-invalido',
        'El `state` del retorno no es el que se envió. Se descarta el código: puede ser un ' +
          'intento de inyectar una sesión ajena (CSRF).',
      )
    }

    const as = await descubrir()
    let validados: URLSearchParams
    try {
      validados = oauth.validateAuthResponse(as, cliente, parametros, tx.estado)
    } catch (error) {
      if (error instanceof oauth.AuthorizationResponseError) {
        throw new ErrorAutenticacion(
          'respuesta-autorizacion',
          `El emisor devolvió ${error.error}${error.error_description ? `: ${error.error_description}` : ''}.`,
          { errorOAuth: error.error, cause: causaSaneada(error) },
        )
      }
      throw new ErrorAutenticacion('respuesta-invalida', `La respuesta del emisor no es válida: ${mensaje(error)}`, {
        cause: causaSaneada(error),
      })
    }

    let respuesta: Response
    try {
      respuesta = await oauth.authorizationCodeGrantRequest(
        as,
        cliente,
        sinSecreto,
        validados,
        config.redirectUri.href,
        tx.verificador,
        opcionesHttp(),
      )
    } catch (error) {
      throw new ErrorAutenticacion('intercambio', `No se pudo canjear el código: ${mensaje(error)}`, {
        cause: causaSaneada(error),
      })
    }

    let tokens: oauth.TokenEndpointResponse
    try {
      tokens = await oauth.processAuthorizationCodeResponse(as, cliente, respuesta, {
        expectedNonce: tx.nonce,
        requireIdToken: true,
      })
    } catch (error) {
      throw errorDeRespuestaDeToken(error, 'intercambio')
    }
    await verificarFirmaIdToken(as, respuesta)

    const claimsId = oauth.getValidatedIdTokenClaims(tokens)
    if (!claimsId || typeof tokens.id_token !== 'string') {
      throw new ErrorAutenticacion('token-invalido', 'El emisor no devolvió un ID token.')
    }
    instalar(
      {
        accessToken: tokens.access_token,
        idToken: tokens.id_token,
        refreshToken: tokens.refresh_token ?? null,
        expiraEn: null,
        claimsId: { ...claimsId },
        emisor: as.issuer,
      },
      tokens.expires_in,
      ++contador,
      true,
    )
  }

  async function verificarFirmaIdToken(as: oauth.AuthorizationServer, respuesta: Response) {
    if (!config.verificarFirma) return
    try {
      await oauth.validateApplicationLevelSignature(as, respuesta, {
        ...opcionesHttp(),
        [oauth.jwksCache]: cacheJwks,
      })
    } catch (error) {
      throw new ErrorAutenticacion(
        'token-invalido',
        `La firma del ID token no verifica contra el JWKS del emisor: ${mensaje(error)}`,
        { cause: causaSaneada(error) },
      )
    }
  }

  function errorDeRespuestaDeToken(error: unknown, siRechazo: 'intercambio' | 'sesion-expirada') {
    if (error instanceof oauth.ResponseBodyError) {
      return new ErrorAutenticacion(
        siRechazo,
        `El token endpoint respondió ${error.error}${error.error_description ? `: ${error.error_description}` : ''}.`,
        { errorOAuth: error.error, cause: causaSaneada(error) },
      )
    }
    return new ErrorAutenticacion('token-invalido', `El emisor devolvió un token que no es válido: ${mensaje(error)}`, {
      cause: causaSaneada(error),
    })
  }

  // ── Sesión ──────────────────────────────────────────────────────────────────

  /**
   * Valida el access token, lee la identidad y publica la sesión. Lanza sin tocar el
   * estado si algo no cuadra: una sesión a medias es peor que ninguna.
   */
  function instalar(tokens: Tokens, expiresIn: number | undefined, gen: number, exigirVigente: boolean) {
    const claimsAcceso = cargaJwtSinVerificar(tokens.accessToken)
    if (claimsAcceso !== null) {
      if (claimsAcceso['iss'] !== undefined && claimsAcceso['iss'] !== tokens.emisor) {
        throw new ErrorAutenticacion('token-invalido', 'El access token lo firmó otro emisor (`iss` distinto).')
      }
      const exp = claimsAcceso['exp']
      if (exigirVigente && typeof exp === 'number' && exp * 1000 + TOLERANCIA_RELOJ_MS < Date.now()) {
        throw new ErrorAutenticacion('token-invalido', 'El access token llegó vencido (`exp`).')
      }
    }
    if (config.audiencia !== null) {
      if (claimsAcceso === null) {
        throw new ErrorAutenticacion(
          'audiencia-invalida',
          `Se pidió la audiencia "${config.audiencia}" y el access token es opaco: no se puede comprobar. ` +
            'Quita `audiencia` si este emisor emite tokens opacos.',
        )
      }
      const aud = claimsAcceso['aud']
      const lista = Array.isArray(aud) ? aud : typeof aud === 'string' ? [aud] : []
      if (!lista.includes(config.audiencia)) {
        throw new ErrorAutenticacion(
          'audiencia-invalida',
          `El access token no trae la audiencia "${config.audiencia}": la API lo rechazaría con 401. ` +
            'Revisa el mapper de audiencia del cliente en el emisor.',
        )
      }
    }

    // Base: el ID token. Encima, el access token, porque es lo que ve la API: los roles
    // y la empresa que decide el backend salen de ahí, no del ID token.
    const claims = { ...tokens.claimsId, ...(claimsAcceso ?? {}) }
    let identidad: IdentidadAybar
    try {
      identidad = identidadDesdeClaims(claims, mapeo)
    } catch (error) {
      if (error instanceof ErrorClaims) {
        throw new ErrorAutenticacion(
          'claims-malformados',
          `El token trae claims corporativos malformados: ${error.message}. El backend lo rechazaría con 401.`,
        )
      }
      throw error
    }

    const expiraEn =
      typeof expiresIn === 'number'
        ? Date.now() + expiresIn * 1000
        : tokens.expiraEn ?? (typeof claimsAcceso?.['exp'] === 'number' ? claimsAcceso['exp'] * 1000 : null)
    const sub = typeof claims['sub'] === 'string' ? claims['sub'] : null

    estado = { ...tokens, expiraEn }
    generacion = gen
    vista = construirVista(identidad, sub, gen)
    persistir()
    notificar()
  }

  function construirVista(identidad: IdentidadAybar, sub: string | null, gen: number): SesionAutenticada {
    const roles = rolesEfectivos(identidad)
    return Object.freeze({
      // El core lee `usuarioId === null` como «sin sesión» (el cargador no monta un
      // remoto no público). Una sesión autenticada nunca puede decir eso: si el emisor no
      // trae el claim del mapeo, se usa el `sub`, que todo ID token trae.
      usuarioId: identidad.usuarioId ?? sub ?? '',
      // Como el backend: el nombre de usuario, y si no viene, el `sub`.
      nombre: identidad.nombreUsuario ?? sub,
      roles,
      empresaId: identidad.empresaId ?? undefined,
      rolesPorEmpresa: identidad.rolesPorEmpresa,
      atributos: identidad.atributos,
      sesionId: identidad.sesionId ?? undefined,
      tieneRol: (rol: string) => roles.includes(rol),
      // Atada a la sesión en que se creó: después de salir() no entrega el token de
      // quien inicie sesión a continuación.
      obtenerToken: () => obtenerToken(gen),
    })
  }

  async function obtenerToken(gen: number): Promise<string> {
    if (gen !== generacion || estado === null) {
      throw new ErrorAutenticacion('sin-sesion', 'No hay sesión abierta: inicia sesión con entrar().')
    }
    if (estado.expiraEn !== null && estado.expiraEn - Date.now() < MARGEN_RENOVACION_MS) {
      await renovar()
    }
    const actual = estado as Tokens | null
    if (gen !== generacion || actual === null) {
      throw new ErrorAutenticacion('sin-sesion', 'La sesión se cerró mientras se renovaba el token.')
    }
    return actual.accessToken
  }

  /** Una sola renovación en vuelo: diez peticiones a la vez no gastan diez refresh tokens. */
  function renovar(): Promise<void> {
    renovacion ??= ejecutarRenovacion().finally(() => {
      renovacion = null
    })
    return renovacion
  }

  async function ejecutarRenovacion(): Promise<void> {
    const actual = estado
    const gen = generacion
    if (actual === null) throw new ErrorAutenticacion('sin-sesion', 'No hay sesión que renovar.')
    if (actual.refreshToken === null) {
      cerrarLocal()
      throw new ErrorAutenticacion(
        'sesion-expirada',
        'El access token venció y el emisor no entregó refresh token: hay que volver a entrar().',
      )
    }

    let as: oauth.AuthorizationServer
    let respuesta: Response
    try {
      as = await descubrir()
      respuesta = await oauth.refreshTokenGrantRequest(as, cliente, sinSecreto, actual.refreshToken, opcionesHttp())
    } catch (error) {
      // La red, no el emisor: la sesión sigue y la próxima petición lo reintenta.
      throw new ErrorAutenticacion('renovacion', `No se pudo renovar el token: ${mensaje(error)}`, {
        cause: causaSaneada(error),
      })
    }
    if (respuesta.status >= 500) {
      // Un emisor caído un momento tampoco invalida la sesión: el refresh token sigue
      // siendo bueno y la próxima petición lo reintenta.
      await respuesta.body?.cancel()
      throw new ErrorAutenticacion('renovacion', `El emisor respondió ${respuesta.status} al renovar; se reintentará.`)
    }

    try {
      const tokens = await oauth.processRefreshTokenResponse(as, cliente, respuesta).catch((error: unknown) => {
        throw errorDeRespuestaDeToken(error, 'sesion-expirada')
      })
      if (gen !== generacion) {
        throw new ErrorAutenticacion('sin-sesion', 'La sesión se cerró mientras se renovaba el token.')
      }
      let claimsId = actual.claimsId
      let idToken = actual.idToken
      if (typeof tokens.id_token === 'string') {
        await verificarFirmaIdToken(as, respuesta)
        const nuevos = oauth.getValidatedIdTokenClaims(tokens)
        // OIDC Core §12.2: el ID token renovado es del mismo usuario o no es válido.
        if (!nuevos || nuevos.sub !== actual.claimsId['sub']) {
          throw new ErrorAutenticacion('token-invalido', 'El ID token renovado es de otro usuario (`sub` distinto).')
        }
        claimsId = { ...nuevos }
        idToken = tokens.id_token
      }
      instalar(
        {
          accessToken: tokens.access_token,
          idToken,
          // Si el emisor no rota el refresh token, el anterior sigue valiendo.
          refreshToken: tokens.refresh_token ?? actual.refreshToken,
          expiraEn: null,
          claimsId,
          emisor: actual.emisor,
        },
        tokens.expires_in,
        gen,
        true,
      )
    } catch (error) {
      // El emisor habló y dijo que no (o dio algo inválido): la sesión no se puede
      // sostener. Se cierra para que la aplicación lo vea, en vez de seguir entregando
      // un token vencido que la API va a rechazar.
      if (gen === generacion) cerrarLocal()
      throw error
    }
  }

  function cerrarLocal() {
    const habia = vista !== null
    estado = null
    vista = null
    generacion = ++contador
    inicio = null
    try {
      entorno.almacen.removeItem(claveSesion)
    } catch {
      // Sin almacén no hay nada guardado que borrar.
    }
    if (habia) notificar()
  }

  // ── Persistencia opcional (almacenamiento: 'sesion') ───────────────────────

  function persistir() {
    if (config.almacenamiento !== 'sesion' || estado === null) return
    try {
      entorno.almacen.setItem(claveSesion, JSON.stringify({ version: 1, ...estado }))
    } catch (error) {
      console.warn('[aybar/auth] No se pudo guardar la sesión en sessionStorage; seguirá solo en memoria.', mensaje(error))
    }
  }

  async function restaurar(): Promise<void> {
    let guardado: Tokens | null = null
    try {
      const crudo = entorno.almacen.getItem(claveSesion)
      guardado = crudo ? tokensGuardados(JSON.parse(crudo)) : null
    } catch {
      guardado = null
    }
    if (guardado === null || guardado.emisor !== config.emisor.href) {
      try {
        entorno.almacen.removeItem(claveSesion)
      } catch {
        // nada que borrar
      }
      return
    }
    try {
      // Vencido o no, se instala: si venció, se renueva justo debajo.
      instalar(guardado, undefined, ++contador, false)
    } catch {
      cerrarLocal()
      return
    }
    const vigente = estado as Tokens | null
    if (vigente?.expiraEn != null && vigente.expiraEn - Date.now() < MARGEN_RENOVACION_MS) {
      await renovar().catch(() => undefined)
    }
  }

  // ── Avisos ─────────────────────────────────────────────────────────────────

  function notificar() {
    for (const escucha of [...escuchas]) {
      try {
        escucha(vista)
      } catch (error) {
        // Un suscriptor que falla no impide que los demás se enteren.
        console.error('[aybar/auth] Una escucha de alCambiar lanzó un error', error)
      }
    }
  }

  /** Por defecto se vuelve a donde se estaba, sin los parámetros de un retorno anterior. */
  function destinoActual(): string {
    try {
      const url = new URL(entorno.url())
      if (esRetorno(url)) return sinParametrosDeRetorno(url)
      return `${url.pathname}${url.search}${url.hash}`
    } catch {
      return '/'
    }
  }

  // ── API pública ────────────────────────────────────────────────────────────

  async function iniciarUnaVez(): Promise<void> {
    if (estado !== null) return
    let actual: URL | null = null
    try {
      actual = new URL(entorno.url())
    } catch {
      actual = null
    }
    if (actual !== null && esRetorno(actual)) return procesarRetorno(actual)
    if (config.almacenamiento === 'sesion') return restaurar()
  }

  return {
    iniciar() {
      inicio ??= iniciarUnaVez().catch((error: unknown) => {
        inicio = null
        throw error
      })
      // Siempre la sesión vigente al resolver, no la de la primera llamada: entre una y
      // otra pudo renovarse o cerrarse.
      return inicio.then(() => vista)
    },

    async entrar(destino) {
      const vuelta = destino === undefined ? destinoActual() : validarDestino(destino)
      const as = await descubrir()
      const verificador = oauth.generateRandomCodeVerifier()
      const desafio = await oauth.calculatePKCECodeChallenge(verificador)
      const tx: Transaccion = {
        estado: oauth.generateRandomState(),
        nonce: oauth.generateRandomNonce(),
        verificador,
        destino: vuelta,
        creada: Date.now(),
      }
      guardarTransaccion(tx)

      const url = new URL(as.authorization_endpoint as string)
      for (const [clave, valor] of Object.entries(config.parametrosAutorizacion)) url.searchParams.set(clave, valor)
      url.searchParams.set('response_type', 'code')
      url.searchParams.set('client_id', config.clienteId)
      url.searchParams.set('redirect_uri', config.redirectUri.href)
      url.searchParams.set('scope', config.alcance)
      url.searchParams.set('state', tx.estado)
      url.searchParams.set('nonce', tx.nonce)
      url.searchParams.set('code_challenge', desafio)
      url.searchParams.set('code_challenge_method', 'S256')
      entorno.redirigir(url.href)
    },

    async salir() {
      const idToken = estado?.idToken ?? null
      cerrarLocal()
      let as: oauth.AuthorizationServer | null = null
      try {
        as = await descubrir()
      } catch {
        as = null // sin emisor la sesión local ya está cerrada; no hay más que hacer
      }
      if (as?.end_session_endpoint) {
        // RP-Initiated Logout 1.0. id_token_hint es lo que permite al emisor cerrar sin
        // pedir confirmación y aceptar post_logout_redirect_uri.
        const url = new URL(as.end_session_endpoint)
        url.searchParams.set('client_id', config.clienteId)
        if (idToken) url.searchParams.set('id_token_hint', idToken)
        if (config.postLogoutRedirectUri) url.searchParams.set('post_logout_redirect_uri', config.postLogoutRedirectUri)
        entorno.redirigir(url.href)
        return
      }
      if (config.postLogoutRedirectUri) entorno.redirigir(config.postLogoutRedirectUri)
    },

    sesion: () => vista,

    alCambiar(escucha) {
      escuchas.add(escucha)
      return () => {
        escuchas.delete(escucha)
      }
    },
  }

}

/**
 * Un destino es una ruta de este mismo origen. `//otro.example` o `/\otro.example` los
 * resuelven algunos navegadores como otro host: se rechazan (redirección abierta).
 */
function esDestinoValido(destino: unknown): destino is string {
  return typeof destino === 'string' && destino.startsWith('/') && !destino.startsWith('//') && !destino.startsWith('/\\')
}

function validarDestino(destino: string): string {
  if (!esDestinoValido(destino)) {
    throw new ErrorAutenticacion(
      'configuracion',
      `entrar() espera una ruta relativa de esta aplicación que empiece con "/", recibió "${String(destino)}".`,
    )
  }
  return destino
}

function sinParametrosDeRetorno(url: URL): string {
  const limpia = new URL(url.href)
  for (const parametro of PARAMETROS_DE_RETORNO) limpia.searchParams.delete(parametro)
  return `${limpia.pathname}${limpia.search}${limpia.hash}`
}

function tokensGuardados(valor: unknown): Tokens | null {
  if (typeof valor !== 'object' || valor === null) return null
  const v = valor as Record<string, unknown>
  const valido =
    v['version'] === 1 &&
    typeof v['accessToken'] === 'string' &&
    typeof v['idToken'] === 'string' &&
    (v['refreshToken'] === null || typeof v['refreshToken'] === 'string') &&
    (v['expiraEn'] === null || typeof v['expiraEn'] === 'number') &&
    typeof v['emisor'] === 'string' &&
    typeof v['claimsId'] === 'object' &&
    v['claimsId'] !== null
  if (!valido) return null
  return {
    accessToken: v['accessToken'] as string,
    idToken: v['idToken'] as string,
    refreshToken: v['refreshToken'] as string | null,
    expiraEn: v['expiraEn'] as number | null,
    claimsId: v['claimsId'] as Record<string, unknown>,
    emisor: v['emisor'] as string,
  }
}

function mensaje(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}

function esHostLocal(hostname: string): boolean {
  return (
    hostname === 'localhost' ||
    hostname.endsWith('.localhost') ||
    hostname === '127.0.0.1' ||
    hostname === '[::1]'
  )
}

function urlAbsoluta(valor: unknown, nombre: string): URL {
  let url: URL
  try {
    url = new URL(String(valor))
  } catch {
    throw new ErrorAutenticacion('configuracion', `${nombre} debe ser una URL absoluta, recibió "${String(valor)}".`)
  }
  if (url.protocol !== 'https:' && url.protocol !== 'http:') {
    throw new ErrorAutenticacion('configuracion', `${nombre} debe ser http o https, recibió "${url.protocol}".`)
  }
  return url
}

function validarOpciones(opciones: OpcionesAutenticacion): Configuracion {
  if (typeof opciones !== 'object' || opciones === null) {
    throw new ErrorAutenticacion('configuracion', 'crearAutenticacion necesita sus opciones.')
  }
  const emisor = urlAbsoluta(opciones.emisor, 'emisor')
  const inseguroLocal = emisor.protocol === 'http:'
  if (inseguroLocal && !esHostLocal(emisor.hostname)) {
    throw new ErrorAutenticacion(
      'configuracion',
      `emisor "${emisor.href}" usa http fuera de esta máquina. Solo se admite http contra ` +
        'localhost (el Keycloak de desarrollo); cualquier otro emisor va por https.',
    )
  }
  if (typeof opciones.clienteId !== 'string' || opciones.clienteId.trim() === '') {
    throw new ErrorAutenticacion('configuracion', 'clienteId no puede estar vacío.')
  }
  const redirectUri = urlAbsoluta(opciones.redirectUri, 'redirectUri')
  const postLogout =
    opciones.postLogoutRedirectUri === undefined
      ? null
      : urlAbsoluta(opciones.postLogoutRedirectUri, 'postLogoutRedirectUri').href

  const alcance = (opciones.alcance ?? 'openid profile').trim()
  if (!alcance.split(/\s+/).includes('openid')) {
    throw new ErrorAutenticacion(
      'configuracion',
      `alcance "${alcance}" no incluye openid: sin él el emisor no devuelve ID token y no hay sesión que validar.`,
    )
  }
  const almacenamiento = opciones.almacenamiento ?? 'memoria'
  if (almacenamiento !== 'memoria' && almacenamiento !== 'sesion') {
    throw new ErrorAutenticacion('configuracion', `almacenamiento debe ser "memoria" o "sesion", recibió "${String(almacenamiento)}".`)
  }
  const parametros = opciones.parametrosAutorizacion ?? {}
  for (const clave of Object.keys(parametros)) {
    if (PARAMETROS_RESERVADOS.has(clave)) {
      throw new ErrorAutenticacion('configuracion', `parametrosAutorizacion no puede fijar "${clave}": lo arma el flujo.`)
    }
  }
  const tiempoEsperaMs = opciones.tiempoEsperaMs ?? TIEMPO_ESPERA_POR_DEFECTO_MS
  if (!Number.isFinite(tiempoEsperaMs) || tiempoEsperaMs <= 0) {
    throw new ErrorAutenticacion('configuracion', 'tiempoEsperaMs debe ser un número de milisegundos mayor que 0.')
  }
  if (opciones.audiencia !== undefined && (typeof opciones.audiencia !== 'string' || opciones.audiencia === '')) {
    throw new ErrorAutenticacion('configuracion', 'audiencia, si se pasa, no puede estar vacía.')
  }

  return {
    emisor,
    clienteId: opciones.clienteId,
    redirectUri,
    postLogoutRedirectUri: postLogout,
    alcance,
    audiencia: opciones.audiencia ?? null,
    almacenamiento,
    parametrosAutorizacion: { ...parametros },
    verificarFirma: opciones.verificarFirma ?? true,
    tiempoEsperaMs,
    inseguroLocal,
  }
}

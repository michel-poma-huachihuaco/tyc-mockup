export { crearAutenticacion } from './autenticacion.js'
export { crearAutenticacionDemo } from './demo.js'
export type { AutenticacionDemo, OpcionesAutenticacionDemo, UsuarioDemo } from './demo.js'
export type {
  Almacenamiento,
  Autenticacion,
  OpcionesAutenticacion,
  SesionAutenticada,
} from './autenticacion.js'
export { ErrorAutenticacion } from './errores.js'
export type { CodigoErrorAutenticacion } from './errores.js'
export {
  ErrorClaims,
  MAPEO_CLAIMS_POR_DEFECTO,
  identidadDesdeClaims,
  leerClaim,
  resolverMapeo,
  rolesEfectivos,
} from './mapeo-claims.js'
export type { Claims, IdentidadAybar, MapeoClaims } from './mapeo-claims.js'
export { entornoNavegador } from './entorno.js'
export type { AlmacenClaveValor, EntornoNavegador } from './entorno.js'

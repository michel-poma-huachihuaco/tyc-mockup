/**
 * Lectura de la carga de un JWT SIN verificar la firma. Solo para el access token.
 *
 * El access token no es para el cliente: es para la API, que sí verifica su firma antes
 * de autorizar nada. Aquí se lee por una sola razón —los roles y la empresa que la API
 * va a ver están en él, no en el ID token— y lo que se lee solo decide la interfaz. Un
 * access token manipulado en el navegador enseñaría un botón que el backend rechaza con
 * 401: no abre nada.
 *
 * El ID token no pasa por aquí: lo valida oauth4webapi (iss, aud, exp, nonce) y su firma
 * se comprueba contra el JWKS del emisor.
 *
 * Devuelve `null` para un token opaco o ilegible; un emisor que emite access tokens
 * opacos es legítimo y la identidad sale entonces solo del ID token.
 */
export function cargaJwtSinVerificar(token: string): Record<string, unknown> | null {
  const partes = token.split('.')
  if (partes.length !== 3) return null
  try {
    const json = JSON.parse(decodificarBase64Url(partes[1] ?? '')) as unknown
    return typeof json === 'object' && json !== null && !Array.isArray(json)
      ? (json as Record<string, unknown>)
      : null
  } catch {
    return null
  }
}

function decodificarBase64Url(texto: string): string {
  const base64 = texto.replace(/-/g, '+').replace(/_/g, '/')
  const relleno = base64 + '='.repeat((4 - (base64.length % 4)) % 4)
  const binario = atob(relleno)
  const bytes = Uint8Array.from(binario, (c) => c.charCodeAt(0))
  return new TextDecoder().decode(bytes)
}

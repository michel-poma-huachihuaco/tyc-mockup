# @aybarcorp/core

El contrato entre el anfitrión y un remoto: tipos, bus de eventos y contexto
compartido. Sin dependencias de framework.

Forma parte del **framework Aybar**, un monorepo de paquetes `@aybarcorp/*` que se
publican juntos y comparten siempre la misma versión. La arquitectura y las decisiones de diseño
están documentadas en el [repositorio](https://github.com/AybarCorp/aybar-framework-desing-frontEnd).

> Se versionan en bloque, y se instalan con versión exacta. Mezclar versiones
> de `@aybarcorp/*` —o dejar una copia anidada bajo otra dependencia— pone dos módulos
> donde debía haber uno, y los contextos de React del anfitrión y del remoto dejan de
> coincidir: `useAnfitrion()` falla teniendo su Provider justo encima.
> `npx @aybarcorp/cli doctor` recorre `node_modules` en profundidad y lo detecta.

## Instalación

Requiere acceso a GitHub Packages: un `.npmrc` con `@aybarcorp:registry=https://npm.pkg.github.com` y un
token con permiso `read:packages`. No hay instalación anónima.

```bash
npm install @aybarcorp/core
```

La vía recomendada no es instalarlo a mano, sino dejar que el CLI cablee el proyecto:

```bash
npx @aybarcorp/cli init --papel remoto
```

## Uso

Es la única superficie que ambos lados comparten: un remoto no importa nada del
anfitrión salvo estos tipos. El anfitrión provee capacidades (ruta, sesión, tema, bus);
el remoto provee un ciclo de vida. Ninguno alcanza el estado interno del otro.

```ts
import { crearBus, acotarBus } from '@aybarcorp/core'
import type { ContextoAnfitrion, Remoto } from '@aybarcorp/core'

const bus = crearBus()
bus.suscribir('creditos:solicitud-creada', (carga) => { /* ... */ })

// La vista que recibe un remoto: escucha todo, emite solo en su espacio.
const delRemoto = acotarBus(bus, 'pagos')
delRemoto.emitir('pagos:pago-hecho', { id: 7 })         // bien
delRemoto.emitir('creditos:solicitud-creada', {})        // lanza
```

Los nombres de evento exigen el formato `<remoto>:<evento>`. No es cosmético: sin
espacio de nombres, dos remotos terminan escuchando el `submit` del otro. Y el
anfitrión entrega a cada remoto su bus ya acotado, así que un remoto no puede emitir
en el espacio de otro haciéndose pasar por él.

### Sesión

`Sesion` trae `usuarioId`, `nombre`, `roles`, `obtenerToken()` y `tieneRol()`, y tres
campos opcionales que llena la integración de identidad del anfitrión: `empresaId`,
`rolesPorEmpresa` y `atributos`. Son opcionales para que un anfitrión anterior siga
cumpliendo el contrato: un remoto que los use debe tolerar `undefined`.

`usuarioId === null` significa «sin sesión iniciada». `SESION_ANONIMA` es esa sesión
—sin usuario, sin roles, y con un `obtenerToken()` que rechaza— y `haySesion(s)` la
distingue de una real.

### Registro

Cada `EntradaRegistro` declara `nombre`, `url`, `version` exacta, `base` y,
opcionalmente, `roles` y `publico`. Un remoto sin `roles` **exige sesión igual**: lo
público se declara con `publico: true`, nunca por omisión.

### Tema

`ContextoAnfitrion.tema` es el tema efectivo, y `suscribirTema()` (opcional: un
anfitrión anterior no lo trae) avisa cuando cambia. Los enlaces de
`@aybarcorp/remote` ya lo usan, con el atributo `data-theme` de `<html>` como respaldo.

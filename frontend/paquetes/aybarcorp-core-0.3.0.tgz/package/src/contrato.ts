/**
 * El contrato entre el anfitrión y un remoto. Es la única superficie que ambos
 * lados comparten: un remoto no importa nada del anfitrión salvo estos tipos.
 *
 * Regla de frontera: el anfitrión provee capacidades (ruta, sesión, tema, bus);
 * el remoto provee un ciclo de vida. Ninguno alcanza el estado interno del otro.
 */

/**
 * Identidad y permisos del usuario. El remoto nunca guarda ni renueva el token.
 *
 * `usuarioId === null` significa que no hay sesión iniciada: así la trata el cargador
 * del anfitrión al decidir si monta un remoto que no es `publico`.
 *
 * Los tres campos opcionales los llena la integración de identidad del anfitrión
 * (`@aybarcorp/auth` los lee de los claims, con los mismos nombres por defecto que el
 * backend). Son opcionales para que un anfitrión anterior siga cumpliendo el contrato:
 * un remoto que los necesita debe tolerar `undefined`.
 */
export interface Sesion {
  readonly usuarioId: string | null
  readonly nombre: string | null
  readonly roles: readonly string[]
  /** Empresa en la que el usuario opera ahora, si la identidad la distingue. */
  readonly empresaId?: string
  /** Roles del usuario en cada empresa, por identificador de empresa. */
  readonly rolesPorEmpresa?: Readonly<Record<string, readonly string[]>>
  /** Claims adicionales que la integración de identidad decidió exponer. Solo lectura. */
  readonly atributos?: Readonly<Record<string, unknown>>
  /** Devuelve un access token válido. El anfitrión lo renueva si está por expirar. */
  obtenerToken(): Promise<string>
  tieneRol(rol: string): boolean
}

/** Ruteo delegado: el remoto navega dentro de su prefijo, nunca fuera. */
export interface Ruta {
  /** Prefijo que el anfitrión asignó a este remoto, p. ej. `/creditos`. */
  readonly base: string
  /** Ruta actual relativa a `base`, siempre con `/` inicial. */
  readonly relativa: string
  /** Navega dentro del remoto. Una ruta absoluta se rechaza. */
  navegar(destino: string, opciones?: { reemplazar?: boolean }): void
  /** Pide al anfitrión navegar fuera del remoto. */
  salir(destinoAbsoluto: string): void
  /** Notifica cambios de ruta. Devuelve la función para dejar de escuchar. */
  suscribir(escucha: (relativa: string) => void): () => void
}

export type Tema = 'light' | 'dark'

/** Eventos con nombre acotado: `<remoto>:<evento>`. Un remoto no emite en el espacio de otro. */
export interface Bus {
  emitir<T>(evento: string, carga: T): void
  suscribir<T>(evento: string, escucha: (carga: T) => void): () => void
}

/** Todo lo que el anfitrión entrega a un remoto en el momento de montarlo. */
export interface ContextoAnfitrion {
  readonly sesion: Sesion
  readonly ruta: Ruta
  /** Bus acotado: el remoto escucha cualquier evento, pero solo emite en `<remoto>:*`. */
  readonly bus: Bus
  /** Tema efectivo, o `undefined` si se sigue la preferencia del sistema. */
  readonly tema: Tema | undefined
  /**
   * Avisa cuando cambia el tema. Opcional: un anfitrión anterior no lo provee, y el
   * remoto debe caer entonces a observar el atributo `data-theme` de `<html>`, que es
   * donde lo escribe `setTheme()` de `@aybarcorp/tokens`.
   */
  suscribirTema?(escucha: (tema: Tema | undefined) => void): () => void
  readonly locale: string
  /** Nombre del remoto tal como lo declara el registro. */
  readonly remoto: string
  /** Registra un error para la observabilidad del anfitrión. */
  reportarError(error: unknown, contexto?: Record<string, unknown>): void
}

/** Lo que un remoto exporta por defecto desde su punto de entrada federado. */
export interface Remoto {
  /** Debe coincidir con el nombre del registro; el anfitrión lo verifica al cargar. */
  readonly nombre: string
  montar(nodo: HTMLElement, contexto: ContextoAnfitrion): void | Promise<void>
  desmontar(nodo: HTMLElement): void | Promise<void>
}

/** Una entrada del registro de remotos que el anfitrión resuelve en tiempo de ejecución. */
export interface EntradaRegistro {
  readonly nombre: string
  /**
   * URL del módulo ESM que exporta un `Remoto` por defecto: `https://`, `http://` solo en
   * desarrollo, o una ruta del mismo origen que empieza con `/`. Ningún otro esquema.
   */
  readonly url: string
  /** Versión exacta desplegada. El anfitrión declara qué versión carga: nunca `latest`. */
  readonly version: string
  /** Prefijo de ruta que el anfitrión le asigna. */
  readonly base: string
  /** Roles requeridos para montarlo. Vacío significa que basta estar autenticado. */
  readonly roles?: readonly string[]
  /**
   * `true` si se puede montar sin sesión iniciada (una página pública). Por omisión
   * es `false`: un remoto sin `roles` exige igualmente una sesión, nunca la omite.
   */
  readonly publico?: boolean
}

export interface Registro {
  readonly remotos: readonly EntradaRegistro[]
}

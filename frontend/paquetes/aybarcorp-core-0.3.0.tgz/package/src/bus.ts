import type { Bus } from './contrato.js'

const NOMBRE_EVENTO = /^[a-z][a-z0-9-]*:[a-z][a-z0-9-]*$/

/**
 * Bus en memoria con espacio de nombres obligatorio. El formato `<remoto>:<evento>`
 * no es cosmético: sin él, dos remotos terminan escuchando el `submit` del otro.
 */
export function crearBus(opciones: { onError?: (e: unknown) => void } = {}): Bus {
  const escuchas = new Map<string, Set<(carga: unknown) => void>>()

  const validar = (evento: string) => {
    if (!NOMBRE_EVENTO.test(evento)) {
      throw new Error(
        `Nombre de evento inválido: "${evento}". El formato es <remoto>:<evento> en minúsculas, p. ej. "creditos:solicitud-creada".`,
      )
    }
  }

  return {
    emitir(evento, carga) {
      validar(evento)
      const destinos = escuchas.get(evento)
      if (!destinos) return
      // Copia: una escucha que se da de baja durante el despacho no debe alterar la iteración.
      for (const escucha of [...destinos]) {
        try {
          escucha(carga)
        } catch (error) {
          // Un suscriptor que falla no impide que los demás reciban el evento.
          opciones.onError?.(error)
        }
      }
    },
    suscribir(evento, escucha) {
      validar(evento)
      let destinos = escuchas.get(evento)
      if (!destinos) {
        destinos = new Set()
        escuchas.set(evento, destinos)
      }
      const envuelta = escucha as (carga: unknown) => void
      destinos.add(envuelta)
      return () => {
        destinos.delete(envuelta)
        if (destinos.size === 0) escuchas.delete(evento)
      }
    },
  }
}

const NOMBRE_ESPACIO = /^[a-z][a-z0-9-]*$/

/**
 * Vista de un bus para un remoto concreto: escucha cualquier evento, pero solo emite en
 * su propio espacio de nombres. Es lo que el contrato promete —«un remoto no emite en el
 * espacio de otro»— y sin esta vista nada lo impedía: con el bus compartido, el remoto
 * `pagos` podía emitir `creditos:solicitud-aprobada` y el que escucha no tenía forma de
 * saber que no venía de `creditos`.
 *
 * Suscribirse a otro espacio sí se permite: escuchar a los demás es para lo que existe.
 */
export function acotarBus(bus: Bus, espacio: string): Bus {
  if (!NOMBRE_ESPACIO.test(espacio)) {
    throw new Error(
      `Espacio de nombres inválido: "${espacio}". Minúsculas, dígitos y guiones, empezando por letra.`,
    )
  }
  const prefijo = `${espacio}:`
  return {
    emitir(evento, carga) {
      if (!evento.startsWith(prefijo)) {
        throw new Error(
          `El remoto "${espacio}" no puede emitir "${evento}": solo emite en su propio espacio, "${prefijo}<evento>".`,
        )
      }
      bus.emitir(evento, carga)
    },
    suscribir(evento, escucha) {
      return bus.suscribir(evento, escucha)
    },
  }
}

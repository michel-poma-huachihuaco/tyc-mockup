import type { Sesion } from './contrato.js'

/**
 * La sesión de quien no ha iniciado sesión. El anfitrión la entrega a un remoto
 * `publico` cuando no hay usuario: el contrato exige siempre un objeto `Sesion`, y este
 * es el único que dice «nadie» sin que cada remoto tenga que comprobar `null`.
 *
 * `obtenerToken()` rechaza en vez de devolver una cadena vacía: un remoto público que
 * intenta llamar a una API protegida debe enterarse ahí, no con un 401 sin explicación.
 */
export const SESION_ANONIMA: Sesion = Object.freeze({
  usuarioId: null,
  nombre: null,
  roles: Object.freeze([]) as readonly string[],
  obtenerToken: () =>
    Promise.reject(new Error('No hay sesión iniciada: el remoto es público y no tiene token que pedir.')),
  tieneRol: () => false,
})

/** `true` si hay un usuario con sesión iniciada. `usuarioId === null` cuenta como anónimo. */
export function haySesion(sesion: Sesion | null | undefined): sesion is Sesion {
  return sesion != null && sesion.usuarioId !== null
}

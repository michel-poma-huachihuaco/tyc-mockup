# @aybarcorp/http

Cliente HTTP del framework: `fetch` con el token de la sesión, el `X-Correlation-Id` y
los errores RFC 7807 del backend convertidos en `ErrorAybar`. Sin dependencias de
framework: sirve igual en React, en Angular y en un remoto.

Forma parte del **framework Aybar**, un monorepo de diez paquetes que se publican
juntos y comparten siempre la misma versión. La arquitectura y las decisiones de diseño
están documentadas en el [repositorio](https://github.com/AybarCorp/aybar-framework-desing-frontEnd).

> Los diez se versionan en bloque, y se instalan con versión exacta. Mezclar versiones
> de `@aybarcorp/*` pone dos copias de `@aybarcorp/core` donde debía haber una.

## Instalación

Requiere acceso a GitHub Packages: un `.npmrc` con `@aybarcorp:registry=https://npm.pkg.github.com` y un
token con permiso `read:packages`. No hay instalación anónima.

```bash
npm install @aybarcorp/http
```

## Uso

```ts
import { crearClienteHttp, ErrorAybar } from '@aybarcorp/http'

const api = crearClienteHttp({
  baseUrl: '/api',                       // o https://api.example/v1
  sesion: () => autenticacion.sesion(),  // @aybarcorp/auth; o contexto.sesion en un remoto
  alNoAutenticado: () => autenticacion.entrar(),
})

const cliente = await api.get<Cliente>('/clientes/7')
await api.post('/clientes', { nombre: 'Cliente sintético' })

try {
  await api.put('/clientes/7', cambios)
} catch (e) {
  if (e instanceof ErrorAybar && e.esValidacion) mostrarCampos(e.campos)
  else throw e
}
```

`solicitar(metodo, ruta, opciones)` devuelve la respuesta completa —`status`, `datos`,
`cabeceras` y `correlationId`— cuando no basta con los datos.

### Lo que envía cada petición

| Cabecera | Valor |
|---|---|
| `Authorization` | `Bearer <token>` de `sesion.obtenerToken()`, que lo renueva si vence en menos de 30 s. No va sin sesión, con una sesión anónima del core (`usuarioId === null`, la que recibe un remoto público) ni con `anonima: true`. |
| `Accept` | `application/json, application/problem+json` |
| `X-Correlation-Id` | Un UUID v4 generado en el navegador, o el que pases en `correlationId`. |

El `X-Correlation-Id` cumple la regla del backend (`^[A-Za-z0-9._-]{1,64}$` y sin 8 o
más dígitos seguidos, la forma de un DNI). El backend no rechaza un valor que no la
cumple: lo descarta en silencio y genera otro, y la traza del navegador deja de
coincidir con la del servidor. Por eso el generador rompe esas rachas siempre, y un
`correlationId` propio que no la cumple se rechaza aquí con un `TypeError`.

Para leer el `X-Correlation-Id` de la respuesta desde otro origen, el backend tiene que
exponerlo por CORS (`aybar.security.cors.cabeceras-expuestas`, que por defecto lo
incluye). Si no lo expone, `correlationId` es el que se envió.

### ErrorAybar

| Campo | De dónde sale |
|---|---|
| `status` | Status HTTP; `0` si no hubo respuesta. |
| `fallo` | `respuesta`, `red`, `tiempo`, `cancelado` o `sin-sesion`. |
| `codigo` | `codigo` del problema (p. ej. `AYB-VAL-400`). Se lee `codigo`, no `code`: es lo que escribe el backend. |
| `titulo`, `detalle`, `instancia`, `tipo` | `title`, `detail`, `instance`, `type` de RFC 7807. |
| `correlationId` | El del cuerpo; si no, el de la cabecera; si no, el que se envió. Es el dato que hay que pedir a quien reporta un error. |
| `timestamp` | `timestamp` del problema. |
| `campos` | `[{ campo, mensaje }]` en una validación; vacío si no. |
| `esNoAutenticado`, `esSinPermiso`, `esValidacion` | 401; 403; 400 o 422. |

Un 401 llama a `alNoAutenticado` antes de lanzar; un 403 no, porque es falta de
permiso y no de sesión. Una sesión que no entrega token también cuenta como no
autenticado: la petición no sale y el error es `{ status: 401, fallo: 'sin-sesion' }`.

### Lo que no hace, a propósito

- **No habla con otro origen.** Una ruta absoluta (`https://otro.example/x`,
  `//otro.example`) se rechaza: el token de la sesión iría a quien la escriba. Para
  otra API, otro cliente.
- **No reintenta ni cachea.** Reintentar una escritura no es inocuo, y la caché es
  decisión de la pantalla.
- `timeoutMs` (15000 por defecto) cubre la petición y la lectura del cuerpo: un
  servidor que manda las cabeceras y se cuelga en el cuerpo también vence.

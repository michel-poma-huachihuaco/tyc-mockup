/**
 * El error que ve la aplicación, con la forma del cuerpo que manda el backend.
 *
 * El SDK de Aybar responde todo error como RFC 7807 (`application/problem+json`) con
 * tres propiedades propias —`codigo`, `correlationId`, `timestamp`— y, en validación,
 * `campos` (aybar-starter-web, `ProblemasAybar` y `ManejadorErroresAybar`). Se lee
 * `codigo` y no `code`: es el nombre que escribe el backend, y aceptar los dos sería
 * esconder el día en que alguien lo cambie de un lado y no del otro.
 *
 * Lo que no viene del servidor —la red cayó, venció el tiempo, la petición se canceló—
 * se reporta con `status` 0 y el motivo en `fallo`, para que la pantalla pueda decir
 * "sin conexión" en vez de "error 0".
 */

/** Un campo rechazado por la validación del backend. */
export interface CampoInvalido {
  readonly campo: string
  readonly mensaje: string
}

/**
 * Qué falló.
 *
 * - `respuesta`: el servidor contestó con un status de error.
 * - `red`: no hubo respuesta (servidor caído, DNS, CORS rechazado por el navegador).
 * - `tiempo`: se agotó `timeoutMs` antes de tener la respuesta completa.
 * - `cancelado`: la `senal` del llamador abortó la petición.
 * - `sin-sesion`: había sesión configurada pero no entregó token; la petición no salió.
 */
export type FalloHttp = 'respuesta' | 'red' | 'tiempo' | 'cancelado' | 'sin-sesion'

export interface DatosErrorAybar {
  readonly status: number
  readonly fallo: FalloHttp
  readonly codigo?: string | null
  readonly titulo?: string | null
  readonly detalle?: string | null
  readonly instancia?: string | null
  readonly tipo?: string | null
  readonly correlationId?: string | null
  readonly timestamp?: string | null
  readonly campos?: readonly CampoInvalido[]
  readonly cuerpo?: unknown
}

export class ErrorAybar extends Error {
  override readonly name = 'ErrorAybar'
  /** Status HTTP de la respuesta; 0 si no hubo respuesta. */
  readonly status: number
  readonly fallo: FalloHttp
  /** Código corporativo del backend, p. ej. `AYB-VAL-400`. `null` si no vino. */
  readonly codigo: string | null
  /** `title` del problema RFC 7807. */
  readonly titulo: string | null
  /** `detail` del problema RFC 7807. */
  readonly detalle: string | null
  /** `instance` del problema RFC 7807. */
  readonly instancia: string | null
  /** `type` del problema RFC 7807. */
  readonly tipo: string | null
  /**
   * El de la respuesta: el del cuerpo, si no el de la cabecera, si no el que se envió.
   * Es el dato que hay que pedir a quien reporta un error.
   */
  readonly correlationId: string | null
  readonly timestamp: string | null
  /** Campos rechazados en una validación; vacío en cualquier otro error. */
  readonly campos: readonly CampoInvalido[]
  /**
   * El cuerpo tal como llegó (objeto si era JSON, texto si no). Puede traer datos de la
   * petición: no se incluye en `message` para que un error que acaba en un log no lo
   * arrastre.
   */
  readonly cuerpo: unknown
  readonly esNoAutenticado: boolean
  readonly esSinPermiso: boolean
  readonly esValidacion: boolean

  constructor(datos: DatosErrorAybar, opciones?: { cause?: unknown }) {
    super(mensajeDe(datos), opciones)
    this.status = datos.status
    this.fallo = datos.fallo
    this.codigo = datos.codigo ?? null
    this.titulo = datos.titulo ?? null
    this.detalle = datos.detalle ?? null
    this.instancia = datos.instancia ?? null
    this.tipo = datos.tipo ?? null
    this.correlationId = datos.correlationId ?? null
    this.timestamp = datos.timestamp ?? null
    this.campos = Object.freeze([...(datos.campos ?? [])])
    this.cuerpo = datos.cuerpo
    this.esNoAutenticado = datos.status === 401
    this.esSinPermiso = datos.status === 403
    // El backend responde 400 con AYB-VAL-400 tanto a un @Valid que falla como a un
    // cuerpo ilegible; 422 queda para un servicio que lo use a propósito.
    this.esValidacion = datos.status === 400 || datos.status === 422
  }
}

function mensajeDe(datos: DatosErrorAybar): string {
  const partes = [datos.titulo, datos.detalle].filter((p): p is string => typeof p === 'string' && p !== '')
  const texto = partes.length ? partes.join(': ') : textoPorFallo(datos)
  const marca = [datos.codigo, datos.status ? String(datos.status) : null].filter(Boolean).join(', ')
  return marca ? `${texto} [${marca}]` : texto
}

function textoPorFallo(datos: DatosErrorAybar): string {
  switch (datos.fallo) {
    case 'red':
      return 'No hubo respuesta del servidor'
    case 'tiempo':
      return 'Se agotó el tiempo de espera'
    case 'cancelado':
      return 'La petición se canceló'
    case 'sin-sesion':
      return 'No hay sesión con la que firmar la petición'
    default:
      return 'Error HTTP'
  }
}

const TEXTO = (valor: unknown): string | null => (typeof valor === 'string' ? valor : null)

/**
 * Lee un cuerpo de error. Si es un problema RFC 7807 —un objeto JSON— extrae sus
 * propiedades; si no (un 502 en HTML de un proxy, un texto plano), deja los campos en
 * `null` y conserva el cuerpo crudo.
 */
export function errorDesdeRespuesta(
  status: number,
  textoStatus: string,
  cuerpo: unknown,
  correlationIdRespuesta: string | null,
): ErrorAybar {
  const problema = esObjeto(cuerpo) ? cuerpo : null
  return new ErrorAybar({
    status,
    fallo: 'respuesta',
    codigo: TEXTO(problema?.['codigo']),
    titulo: TEXTO(problema?.['title']) ?? (textoStatus || null),
    detalle: TEXTO(problema?.['detail']),
    instancia: TEXTO(problema?.['instance']),
    tipo: TEXTO(problema?.['type']),
    correlationId: TEXTO(problema?.['correlationId']) ?? correlationIdRespuesta,
    timestamp: TEXTO(problema?.['timestamp']),
    campos: camposDe(problema?.['campos']),
    cuerpo,
  })
}

function camposDe(valor: unknown): CampoInvalido[] {
  if (!Array.isArray(valor)) return []
  const campos: CampoInvalido[] = []
  for (const entrada of valor) {
    if (!esObjeto(entrada)) continue
    const campo = TEXTO(entrada['campo'])
    const mensaje = TEXTO(entrada['mensaje'])
    if (campo !== null && mensaje !== null) campos.push(Object.freeze({ campo, mensaje }))
  }
  return campos
}

function esObjeto(valor: unknown): valor is Record<string, unknown> {
  return typeof valor === 'object' && valor !== null && !Array.isArray(valor)
}

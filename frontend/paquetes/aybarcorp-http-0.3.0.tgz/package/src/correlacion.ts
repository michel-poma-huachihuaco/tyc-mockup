/**
 * El X-Correlation-Id que sale del navegador.
 *
 * El backend (aybar-starter-logging, `FiltroCorrelacion`) acepta el valor entrante solo
 * si cumple `^[A-Za-z0-9._-]{1,64}$` y NO trae 8 o más dígitos seguidos —la forma de un
 * DNI peruano—: el header es texto libre del cliente y termina en logs, respuestas y
 * auditoría. Un valor que no cumple no hace fallar la petición; el backend lo descarta en
 * silencio y genera otro, y ahí está el problema: la traza que el navegador anotó ya no
 * coincide con la del servidor y nadie lo nota hasta que hay que seguir un incidente.
 *
 * Por eso el generador no se conforma con "casi siempre". Un UUID v4 crudo trae 8 dígitos
 * seguidos en torno al 8 % de las veces (medido sobre 200 000 `crypto.randomUUID()`: el
 * primer grupo tiene 8 caracteres hex y el último 12), así que se rompe la racha de forma
 * determinista en vez de reintentar.
 */

/** Cabecera de correlación, con la grafía del backend (`CorrelacionIds.HEADER`). */
export const CABECERA_CORRELACION = 'X-Correlation-Id'

/** Lista blanca del backend: alfanumérico, punto, guion y guion bajo, máximo 64. */
export const FORMATO_CORRELATION_ID = /^[A-Za-z0-9._-]{1,64}$/

/** Forma de un DNI: el backend rechaza el valor entero si aparece. */
const SECUENCIA_TIPO_DNI = /\d{8,}/

/** Con qué se sustituye el dígito que completaría la racha: sigue siendo hexadecimal. */
const LETRAS_HEX = 'abcdef'

/** ¿El backend aceptaría este valor tal cual, sin reemplazarlo por uno suyo? */
export function esCorrelationIdValido(valor: string): boolean {
  return FORMATO_CORRELATION_ID.test(valor) && !SECUENCIA_TIPO_DNI.test(valor)
}

/**
 * Un UUID v4 que nunca trae 8 dígitos seguidos.
 *
 * Se arma con `crypto.getRandomValues` y no con `crypto.randomUUID`: el segundo solo
 * existe en contextos seguros, y una aplicación servida por http desde una IP de la red
 * local —un QA en una máquina de pruebas— no lo es.
 *
 * La racha se rompe sustituyendo el octavo dígito por una letra hexadecimal. Las rachas
 * de 8 solo caben en el primer grupo (8 caracteres) y en el último (12); el nibble de
 * versión y el de variante viven en los grupos de 4, así que el resultado sigue siendo
 * un UUID v4 bien formado y la pérdida de aleatoriedad es despreciable.
 */
export function generarCorrelationId(): string {
  const bytes = new Uint8Array(16)
  globalThis.crypto.getRandomValues(bytes)
  bytes[6] = ((bytes[6] ?? 0) & 0x0f) | 0x40 // versión 4
  bytes[8] = ((bytes[8] ?? 0) & 0x3f) | 0x80 // variante RFC 9562
  const hex = Array.from(bytes, (b) => b.toString(16).padStart(2, '0')).join('')
  const uuid = `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`
  return romperRachasDeDigitos(uuid)
}

function romperRachasDeDigitos(texto: string): string {
  let salida = ''
  let racha = 0
  for (const caracter of texto) {
    if (caracter >= '0' && caracter <= '9') {
      racha++
      if (racha === 8) {
        salida += LETRAS_HEX[Number(caracter) % LETRAS_HEX.length]
        racha = 0
        continue
      }
    } else {
      racha = 0
    }
    salida += caracter
  }
  return salida
}

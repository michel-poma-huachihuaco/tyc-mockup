import type { Sesion } from '@aybarcorp/core'
import { CABECERA_CORRELACION, esCorrelationIdValido, generarCorrelationId } from './correlacion.js'
import { ErrorAybar, errorDesdeRespuesta } from './error.js'

/**
 * Cliente HTTP del framework: `fetch` con las tres cosas que cada pantalla terminaba
 * escribiendo a mano —y cada una de una forma—: el token de la sesión, el
 * X-Correlation-Id y la lectura del error RFC 7807 del backend.
 *
 * Es neutral a propósito: no sabe de React ni de Angular, no reintenta y no cachea. Lo
 * que sí impone es que el token no salga del origen configurado: una ruta absoluta se
 * rechaza, porque `cliente.get('https://otro.example/x')` enviaría el Bearer de la
 * sesión a quien la escriba.
 */

export type MetodoHttp = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE' | 'HEAD' | 'OPTIONS'

export type ValorConsulta =
  | string
  | number
  | boolean
  | null
  | undefined
  | readonly (string | number | boolean)[]

/** Cómo se interpreta el cuerpo de una respuesta exitosa. */
export type ModoRespuesta = 'auto' | 'json' | 'texto' | 'blob' | 'ninguna'

export interface OpcionesSolicitud {
  /** Parámetros de consulta. `null` y `undefined` se omiten; un arreglo repite la clave. */
  readonly consulta?: Readonly<Record<string, ValorConsulta>>
  /**
   * Cuerpo. Un objeto o arreglo se serializa como JSON con `Content-Type:
   * application/json`; `FormData`, `Blob`, `URLSearchParams`, `ArrayBuffer` y texto se
   * envían tal cual.
   */
  readonly cuerpo?: unknown
  /** Cabeceras de esta petición; se suman a las del cliente y las pisan. */
  readonly cabeceras?: Readonly<Record<string, string>>
  /** Señal del llamador para cancelar. */
  readonly senal?: AbortSignal
  /** Tiempo máximo de esta petición, incluida la lectura del cuerpo. */
  readonly timeoutMs?: number
  /**
   * Correlation ID a propagar. Debe cumplir el formato del backend; uno que no cumple
   * es un error de programación y se rechaza aquí, antes de que el backend lo descarte
   * en silencio y la traza se parta en dos.
   */
  readonly correlationId?: string
  /** No envía `Authorization` aunque el cliente tenga sesión. */
  readonly anonima?: boolean
  /** `auto` (por defecto): JSON si el tipo es JSON, texto si es `text/*`, Blob si no. */
  readonly respuesta?: ModoRespuesta
}

export type OpcionesSinCuerpo = Omit<OpcionesSolicitud, 'cuerpo'>

export interface RespuestaHttp<T> {
  readonly status: number
  readonly datos: T
  readonly cabeceras: Headers
  /** El que devolvió el backend en X-Correlation-Id; si no lo expuso, el que se envió. */
  readonly correlationId: string
}

export interface OpcionesClienteHttp {
  /** Base de las rutas: absoluta (`https://api.example/v1`) o del mismo origen (`/api`). */
  readonly baseUrl: string
  /**
   * De dónde sale el token. Una función se consulta en cada petición: `() =>
   * autenticacion.sesion()` sigue al usuario aunque cierre e inicie sesión. Si devuelve
   * `null`, o una sesión anónima (`usuarioId === null`), la petición sale sin
   * `Authorization`.
   */
  readonly sesion?: Sesion | (() => Sesion | null)
  /** Por defecto 15000. */
  readonly timeoutMs?: number
  /**
   * Se llama ante un 401 del backend o cuando la sesión no entrega token. Es el lugar
   * para `autenticacion.entrar()`. El error se lanza igual después de llamarla.
   */
  readonly alNoAutenticado?: () => void
  /** Cabeceras que van en todas las peticiones (p. ej. `Accept-Language`). */
  readonly cabeceras?: Readonly<Record<string, string>>
  /** Implementación de fetch; por defecto la global. Útil en pruebas y en SSR. */
  readonly fetch?: typeof fetch
}

export interface ClienteHttp {
  /** La petición completa: status, cabeceras y correlation ID además de los datos. */
  solicitar<T = unknown>(metodo: MetodoHttp, ruta: string, opciones?: OpcionesSolicitud): Promise<RespuestaHttp<T>>
  get<T = unknown>(ruta: string, opciones?: OpcionesSinCuerpo): Promise<T>
  post<T = unknown>(ruta: string, cuerpo?: unknown, opciones?: OpcionesSinCuerpo): Promise<T>
  put<T = unknown>(ruta: string, cuerpo?: unknown, opciones?: OpcionesSinCuerpo): Promise<T>
  patch<T = unknown>(ruta: string, cuerpo?: unknown, opciones?: OpcionesSinCuerpo): Promise<T>
  delete<T = unknown>(ruta: string, opciones?: OpcionesSinCuerpo): Promise<T>
}

/** Lo que acepta un backend del SDK: el JSON del recurso y el problem+json del error. */
const ACEPTA = 'application/json, application/problem+json'

const TIMEOUT_POR_DEFECTO_MS = 15_000

export function crearClienteHttp(opciones: OpcionesClienteHttp): ClienteHttp {
  if (typeof opciones?.baseUrl !== 'string' || opciones.baseUrl.trim() === '') {
    throw new TypeError('crearClienteHttp necesita `baseUrl`: la base contra la que se resuelven las rutas.')
  }
  const base = opciones.baseUrl.replace(/\/+$/, '')
  const timeoutCliente = validarTimeout(opciones.timeoutMs ?? TIMEOUT_POR_DEFECTO_MS, 'timeoutMs')

  const avisarNoAutenticado = () => {
    try {
      opciones.alNoAutenticado?.()
    } catch (error) {
      // El aviso es un efecto secundario: si falla, el error que importa sigue siendo
      // el 401 que se va a lanzar, no el del callback.
      console.error('[aybar/http] alNoAutenticado lanzó un error', error)
    }
  }

  async function solicitar<T>(
    metodo: MetodoHttp,
    ruta: string,
    porPeticion: OpcionesSolicitud = {},
  ): Promise<RespuestaHttp<T>> {
    const url = construirUrl(base, ruta, porPeticion.consulta)
    const correlationId = correlacionDe(porPeticion.correlationId)
    const cabeceras = new Headers()
    cabeceras.set('Accept', ACEPTA)
    for (const [nombre, valor] of Object.entries(opciones.cabeceras ?? {})) cabeceras.set(nombre, valor)
    for (const [nombre, valor] of Object.entries(porPeticion.cabeceras ?? {})) cabeceras.set(nombre, valor)
    cabeceras.set(CABECERA_CORRELACION, correlationId)

    const cuerpo = prepararCuerpo(metodo, porPeticion.cuerpo, cabeceras)

    if (!porPeticion.anonima && !cabeceras.has('Authorization')) {
      const sesion = typeof opciones.sesion === 'function' ? opciones.sesion() : opciones.sesion
      // `usuarioId === null` es «nadie» en el contrato del core (SESION_ANONIMA, la que
      // recibe un remoto público): la petición sale sin token en vez de fallar, y la API
      // decide si la ruta es pública.
      if (sesion && sesion.usuarioId !== null) {
        let token: string
        try {
          token = await sesion.obtenerToken()
        } catch (causa) {
          avisarNoAutenticado()
          throw new ErrorAybar(
            { status: 401, fallo: 'sin-sesion', titulo: 'Sin sesión', correlationId },
            { cause: causa },
          )
        }
        cabeceras.set('Authorization', `Bearer ${token}`)
      }
    }

    // Un solo plazo para la petición y la lectura del cuerpo: un servidor que manda
    // las cabeceras y se queda colgado en el cuerpo también tiene que vencer.
    const plazo = validarTimeout(porPeticion.timeoutMs ?? timeoutCliente, 'timeoutMs')
    const controlador = new AbortController()
    let motivo: 'tiempo' | 'cancelado' | null = null
    const temporizador = setTimeout(() => {
      motivo ??= 'tiempo'
      controlador.abort()
    }, plazo)
    const senal = porPeticion.senal
    const alCancelar = () => {
      motivo ??= 'cancelado'
      controlador.abort()
    }
    if (senal?.aborted) alCancelar()
    else senal?.addEventListener('abort', alCancelar, { once: true })

    const fallaSinRespuesta = (causa: unknown) =>
      new ErrorAybar({ status: 0, fallo: motivo ?? 'red', correlationId }, { cause: causa })

    try {
      const ejecutar = opciones.fetch ?? globalThis.fetch.bind(globalThis)
      let respuesta: Response
      try {
        respuesta = await ejecutar(url, {
          method: metodo,
          headers: cabeceras,
          body: cuerpo,
          signal: controlador.signal,
        })
      } catch (causa) {
        throw fallaSinRespuesta(causa)
      }

      const correlationRespuesta = respuesta.headers.get(CABECERA_CORRELACION)

      if (!respuesta.ok) {
        let cuerpoError: unknown
        try {
          cuerpoError = await leerCuerpoError(respuesta)
        } catch (causa) {
          throw fallaSinRespuesta(causa)
        }
        const error = errorDesdeRespuesta(
          respuesta.status,
          respuesta.statusText,
          cuerpoError,
          correlationRespuesta ?? correlationId,
        )
        if (error.esNoAutenticado) avisarNoAutenticado()
        throw error
      }

      let datos: unknown
      try {
        datos = await leerCuerpo(respuesta, metodo, porPeticion.respuesta ?? 'auto')
      } catch (causa) {
        if (causa instanceof SyntaxError) {
          throw new ErrorAybar(
            {
              status: respuesta.status,
              fallo: 'respuesta',
              titulo: 'Respuesta ilegible',
              detalle: 'El servidor declaró JSON y el cuerpo no lo es',
              correlationId: correlationRespuesta ?? correlationId,
            },
            { cause: causa },
          )
        }
        throw fallaSinRespuesta(causa)
      }

      return {
        status: respuesta.status,
        datos: datos as T,
        cabeceras: respuesta.headers,
        correlationId: correlationRespuesta ?? correlationId,
      }
    } finally {
      clearTimeout(temporizador)
      senal?.removeEventListener('abort', alCancelar)
    }
  }

  const datosDe = <T>(promesa: Promise<RespuestaHttp<T>>) => promesa.then((r) => r.datos)

  return {
    solicitar,
    get: <T>(ruta: string, o?: OpcionesSinCuerpo) => datosDe(solicitar<T>('GET', ruta, o)),
    post: <T>(ruta: string, cuerpo?: unknown, o?: OpcionesSinCuerpo) =>
      datosDe(solicitar<T>('POST', ruta, { ...o, cuerpo })),
    put: <T>(ruta: string, cuerpo?: unknown, o?: OpcionesSinCuerpo) =>
      datosDe(solicitar<T>('PUT', ruta, { ...o, cuerpo })),
    patch: <T>(ruta: string, cuerpo?: unknown, o?: OpcionesSinCuerpo) =>
      datosDe(solicitar<T>('PATCH', ruta, { ...o, cuerpo })),
    delete: <T>(ruta: string, o?: OpcionesSinCuerpo) => datosDe(solicitar<T>('DELETE', ruta, o)),
  }
}

function validarTimeout(valor: number, nombre: string): number {
  if (!Number.isFinite(valor) || valor <= 0) {
    throw new TypeError(`${nombre} debe ser un número de milisegundos mayor que 0, recibió ${String(valor)}.`)
  }
  return valor
}

function correlacionDe(propuesto: string | undefined): string {
  if (propuesto === undefined) return generarCorrelationId()
  if (!esCorrelationIdValido(propuesto)) {
    throw new TypeError(
      `correlationId "${propuesto}" no lo aceptaría el backend: debe cumplir ^[A-Za-z0-9._-]{1,64}$ ` +
        'y no traer 8 o más dígitos seguidos. Lo descartaría en silencio y la traza quedaría partida.',
    )
  }
  return propuesto
}

/**
 * `base` + `ruta` + consulta. La ruta tiene que ser relativa: con una absoluta o
 * protocol-relative (`//otro.example`) el token de la sesión saldría hacia otro origen.
 */
function construirUrl(base: string, ruta: string, consulta?: Readonly<Record<string, ValorConsulta>>): string {
  if (typeof ruta !== 'string') throw new TypeError('La ruta debe ser texto.')
  if (/^[a-z][a-z0-9+.-]*:/i.test(ruta) || ruta.startsWith('//') || ruta.startsWith('\\')) {
    throw new TypeError(
      `La ruta "${ruta}" es absoluta. El cliente solo habla con su baseUrl: el token de la ` +
        'sesión no se envía a otro origen. Crea otro cliente para otra API.',
    )
  }
  const relativa = ruta.replace(/^\/+/, '')
  let url = relativa ? `${base}/${relativa}` : base
  const parametros = new URLSearchParams()
  for (const [clave, valor] of Object.entries(consulta ?? {})) {
    if (valor === null || valor === undefined) continue
    if (Array.isArray(valor)) for (const v of valor) parametros.append(clave, String(v))
    else parametros.append(clave, String(valor))
  }
  const texto = parametros.toString()
  if (texto) url += (url.includes('?') ? '&' : '?') + texto
  return url
}

function prepararCuerpo(metodo: MetodoHttp, cuerpo: unknown, cabeceras: Headers): BodyInit | undefined {
  if (cuerpo === undefined) return undefined
  if (metodo === 'GET' || metodo === 'HEAD') {
    throw new TypeError(`Una petición ${metodo} no lleva cuerpo.`)
  }
  if (
    typeof cuerpo === 'string' ||
    cuerpo instanceof URLSearchParams ||
    cuerpo instanceof ArrayBuffer ||
    ArrayBuffer.isView(cuerpo) ||
    (typeof Blob !== 'undefined' && cuerpo instanceof Blob) ||
    (typeof FormData !== 'undefined' && cuerpo instanceof FormData) ||
    (typeof ReadableStream !== 'undefined' && cuerpo instanceof ReadableStream)
  ) {
    return cuerpo as BodyInit
  }
  if (!cabeceras.has('Content-Type')) cabeceras.set('Content-Type', 'application/json')
  return JSON.stringify(cuerpo)
}

function esTipoJson(tipo: string | null): boolean {
  if (!tipo) return false
  const base = tipo.split(';')[0]?.trim().toLowerCase() ?? ''
  return base === 'application/json' || base.endsWith('+json')
}

async function leerCuerpo(respuesta: Response, metodo: MetodoHttp, modo: ModoRespuesta): Promise<unknown> {
  if (modo === 'ninguna' || metodo === 'HEAD' || respuesta.status === 204 || respuesta.status === 205) {
    await respuesta.body?.cancel()
    return undefined
  }
  if (modo === 'blob') return respuesta.blob()
  const tipo = respuesta.headers.get('Content-Type')
  if (modo === 'json' || (modo === 'auto' && esTipoJson(tipo))) {
    const texto = await respuesta.text()
    return texto === '' ? undefined : JSON.parse(texto)
  }
  if (modo === 'texto' || (tipo ?? '').toLowerCase().startsWith('text/')) return respuesta.text()
  return respuesta.blob()
}

/** El cuerpo de un error: objeto si es JSON legible, texto si no, `undefined` si vacío. */
async function leerCuerpoError(respuesta: Response): Promise<unknown> {
  const texto = await respuesta.text()
  if (texto === '') return undefined
  if (esTipoJson(respuesta.headers.get('Content-Type'))) {
    try {
      return JSON.parse(texto)
    } catch {
      return texto
    }
  }
  return texto
}

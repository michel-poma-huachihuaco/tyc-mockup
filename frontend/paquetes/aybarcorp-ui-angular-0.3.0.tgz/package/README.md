# @aybarcorp/ui-angular

Componentes Angular standalone del Aybar Design System V1: el camino del sistema de diseño
para un anfitrión o un remoto Angular. Selectores `ay-*`, signals (`input()`, `model()`,
`output()`) y la misma hoja `ui.css` —las mismas clases `ay-*`— que `@aybarcorp/ui`.

Forma parte del **framework Aybar**, un monorepo de diez paquetes que se publican juntos y
comparten siempre la misma versión. La arquitectura y las decisiones de diseño están
documentadas en el [repositorio](https://github.com/AybarCorp/aybar-framework-desing-frontEnd).

> Los diez se versionan en bloque, y se instalan con versión exacta. `ui-angular` y
> `tokens` en versiones distintas son una hoja de componentes que pide custom properties
> que la hoja de tokens no declara. `npx @aybarcorp/cli doctor` recorre `node_modules` en
> profundidad y lo detecta.

## Instalación

Requiere acceso a GitHub Packages: un `.npmrc` con `@aybarcorp:registry=https://npm.pkg.github.com` y un
token con permiso `read:packages`. No hay instalación anónima.

```bash
npm install @aybarcorp/ui-angular @aybarcorp/tokens
```

La vía recomendada no es instalarlo a mano, sino dejar que el CLI cablee el proyecto. En un
proyecto Angular, `init` instala `@aybarcorp/tokens` y `@aybarcorp/ui-angular` —no
`@aybarcorp/ui`, ni `@aybarcorp/ui-elements`, ni React— y escribe las hojas de estilo:

```bash
npx @aybarcorp/cli init --papel app
```

`@angular/core` y `@angular/common` `>=20.2.0` son `peerDependencies` obligatorias: el
paquete entero es Angular, no un subpath opcional. Se construye con Angular 22.2.1; contra
20.2.x no se ha compilado.

## Las hojas de estilo, en `angular.json`

En Angular los estilos globales se declaran en `architect.build.options.styles`, no se
importan desde el TypeScript: importarlos desde `main.ts` los mete en el bundle inicial y
rompe el presupuesto de tamaño que Angular verifica. Son tres y el orden es parte del
contrato, porque `ui.css` consume las custom properties que declara `aybar.css`:

```json
"styles": [
  "node_modules/@aybarcorp/tokens/dist/aybar.css",
  "node_modules/@aybarcorp/tokens/dist/fuentes.css",
  "node_modules/@aybarcorp/ui-angular/dist/ui.css"
]
```

`init` las agrega en ese orden. Si no puede editar `angular.json` sin adivinar —varias
aplicaciones y ninguna por defecto, JSON malformado— lo omite y escribe en pantalla las
tres líneas para pegarlas a mano.

La hoja es **la misma de `@aybarcorp/ui`**, unida por familia: el build de este paquete la
copia de `packages/ui/dist/ui.css` a `dist/ui.css` (`copiar-hoja.mjs`). Sale de aquí y no de
`@aybarcorp/ui` porque en un proyecto Angular `@aybarcorp/ui` no está instalado. Sin estas
hojas cada `var(--aybar-*)` cae a su valor inicial y los componentes salen sin color, que
parece un fallo de los componentes y es una instalación a medias.

## Uso

Cada componente es standalone: se importa en el componente que lo usa. No hay nada que
registrar en `main.ts` ni ningún `CUSTOM_ELEMENTS_SCHEMA` que declarar.

```ts
import { Component, signal } from '@angular/core'
import {
  AyButton,
  AyCard,
  AyCardBody,
  AyCardFooter,
  AyCardHeader,
  AyFormField,
  AyInput,
} from '@aybarcorp/ui-angular'

@Component({
  selector: 'app-reserva',
  imports: [AyButton, AyCard, AyCardBody, AyCardFooter, AyCardHeader, AyFormField, AyInput],
  template: `
    <ay-card>
      <ay-card-header titulo="Nueva reserva" subtitulo="Unidad 402 · Residencial Miraflores" />
      <ay-card-body>
        <ay-form-field
          etiqueta="Correo del comprador"
          ayuda="Se usará para enviar la minuta."
          [error]="error()"
          obligatorio
        >
          <ay-input tipo="email" placeholder="nombre@dominio.com" [(valor)]="correo" />
        </ay-form-field>
      </ay-card-body>
      <ay-card-footer>
        <ay-button variante="secondary" (click)="correo.set('')">Limpiar</ay-button>
        <ay-button variante="primary" [cargando]="enviando()" (click)="registrar()">
          Registrar reserva
        </ay-button>
      </ay-card-footer>
    </ay-card>
  `,
})
export class Reserva {
  protected readonly correo = signal('')
  protected readonly enviando = signal(false)
  protected readonly error = signal<string | undefined>(undefined)

  protected registrar(): void {
    if (!this.correo().includes('@')) {
      this.error.set('Escribe un correo con @, por ejemplo nombre@dominio.com.')
      return
    }
    this.error.set(undefined)
    this.enviando.set(true)
  }
}
```

Lo que ese ejemplo enseña:

- **Las entradas son las del uso Angular del diseño**, no las props de React. Casi todas
  en español —`variante`, `tono`, `titulo`, `etiqueta`, `cargando`, `bloque`, `abierto`—, y
  algunas que el diseño deja en inglés: `size` en la mayoría de familias (Heading, Input,
  Alert, Modal, Spinner…), mientras la familia Actions usa `tamano`. No se traducen por
  regla; se copian del diseño, así que ante la duda manda el tipo del componente.
- **Lo que cambia el componente es un `model()`**: `[(valor)]` en los controles de
  formulario, `[(abierto)]` en Modal, Dialog, Drawer, Bottom Sheet, Dropdown, Context
  Menu, Collapsible y Accordion Item (`abierto` y `abiertoChange`), `[(seleccionada)]` en
  una Card seleccionable.
- **Form Field cablea el control que envuelve**: busca el `<ay-input>`, `<ay-textarea>`,
  `<ay-select>` o `<input>` proyectado y le pone `id`, `required`, `aria-invalid` y
  `aria-describedby`. El error sustituye a la ayuda y se anuncia sin mover el foco.
- **`(click)` sobre `<ay-button>` es el del `<button>` interno**: el anfitrión no ocupa caja
  (`display: contents`), y un botón deshabilitado o con `cargando` no lo emite. Los iconos
  van como hijos con `ayIconoInicio` o `ayIconoFin`.

**Qué comprueba el compilador, y qué no.** Con `strictTemplates` —el valor de un proyecto
creado con `ng new`— Angular rechaza un valor que el tipo no admite
(`variante="secundario"`: `TS2322`) y un enlace a una entrada que no existe
(`[variant]="'secondary'"`: `NG8002`). Lo que **no** rechaza es un atributo estático con un
nombre que el componente no tiene: `variant="secondary"`, el nombre de la prop de React,
compila sin error y queda como atributo HTML suelto, con el botón en su variante por
omisión. Es el descuido más probable en un equipo que trabaja en los dos marcos.

Y una regla para el único sitio donde sigue haciendo falta `CUSTOM_ELEMENTS_SCHEMA`: la
página que aloja `<ay-punto-montaje>` de `@aybarcorp/shell`, que es un custom element. En
ese componente Angular deja pasar cualquier etiqueta con guion, así que un `<ay-button>`
que se olvidó importar compila igual y se pinta como un elemento vacío. Mantén esa página
pequeña y con sus `imports` completos.

## La vitrina: `<ay-vitrina />`

```ts
import { Component } from '@angular/core'
import { AyVitrina } from '@aybarcorp/ui-angular'

@Component({
  selector: 'app-vitrina',
  imports: [AyVitrina],
  template: `<ay-vitrina [nivel]="3" [(abiertas)]="abiertas" />`,
})
export class PaginaVitrina {
  protected abiertas = ['vitrina-actions']
}
```

Todas las familias del diseño en su orden, con los casos del catálogo de ejemplos
renderizados con los componentes de este paquete, el código «angular · standalone» de cada
caso (un `<details>` «Código» con su botón Copiar) y la tabla de entradas y salidas de cada
componente. Tiene dos modos:

- **`acordeon`** (por omisión): cada familia en una sección de acordeón y cada componente en
  un colapsable. Es perezosa en dos niveles: una familia se crea la primera vez que se abre y,
  dentro, cada componente la primera vez que se abre el suyo; cerrar solo oculta.
  `#vitrina-<familia>` en la URL abre esa familia.
- **`pagina`**: un componente a la vez, con su título, su descripción, sus grupos y sus casos.
  La navegación lateral la pone la aplicación con `CATALOGO_VITRINA`; sin componente, la
  vitrina muestra el índice de la familia o el de todas.

El buscador filtra familias, componentes, grupos y casos sin tildes ni mayúsculas. En el
acordeón deja solo lo que coincide y abre sus familias; en modo página lista los componentes
que coinciden.

| Entrada / salida | Tipo | Por omisión | Qué hace |
|---|---|---|---|
| `nivel` | `2 \| 3` | `2` | Nivel del título de la vitrina; el resto de títulos cuelga de él |
| `abiertas` | `model<string[]>` | `[]` | Familias abiertas en el acordeón, por su valor `vitrina-<familia>` |
| `modo` | `'acordeon' \| 'pagina'` | `'acordeon'` | Todas las familias plegadas, o un componente por página |
| `familia` | `string \| null` | `null` | Familia elegida, por su id (`form-controls`) o su nombre. La lleva la URL de la aplicación |
| `componente` | `string \| null` | `null` | Componente elegido, por su slug (`icon-button`) o su nombre; sin familia se busca en todas |
| `consulta` | `model<string>` | `''` | Lo que se busca; `[(consulta)]` la comparte con la aplicación |
| `sinonimos` | `(consulta) => string[]` | `null` | Alternativas de la consulta: se muestra lo que coincide con cualquiera |
| `buscador` | `boolean` | `true` | Pinta el buscador; sin él la consulta llega solo por `consulta` |
| `(navegar)` | `{ familia, componente }` | | El usuario eligió una familia (`componente: null`) o un componente: la aplicación lleva la URL |

```ts
import { Component, inject, input } from '@angular/core'
import { Router } from '@angular/router'
import { AyVitrina, CATALOGO_VITRINA } from '@aybarcorp/ui-angular'
import type { AyVitrinaNavegacion } from '@aybarcorp/ui-angular'

@Component({
  selector: 'app-pagina-vitrina',
  imports: [AyVitrina],
  template: `
    <ay-vitrina modo="pagina" [familia]="familia()" [componente]="componente()"
                [buscador]="false" (navegar)="ir($event)" />
  `,
})
export class PaginaVitrina {
  // Con withComponentInputBinding(), desde /vitrina/:familia/:componente.
  readonly familia = input<string>()
  readonly componente = input<string>()
  protected readonly familias = CATALOGO_VITRINA.familias // la barra lateral
  private readonly router = inject(Router)
  protected ir({ familia, componente }: AyVitrinaNavegacion): void {
    void this.router.navigate(['/vitrina', familia, ...(componente ? [componente] : [])])
  }
}
```

`CATALOGO_VITRINA` es el índice como datos —familias, componentes con su `slug`, grupos,
casos con su `codigo` y la `api` de cada clase— y `buscarEnCatalogo(catalogo, consulta)` su
búsqueda, una función pura: con un arreglo de alternativas (`['tabla', 'table', 'data
grid']`) devuelve lo que coincide con cualquiera, que es como se le suman sinónimos en una
búsqueda global o en una paleta de comandos.

**De dónde salen el código y la tabla de entradas.** Este paquete no depende de
`@aybarcorp/ui`, así que no puede leer su catálogo al ejecutarse. `generar-vitrina.mjs` corre
en `build` y en `typecheck` y escribe `src/vitrina/_catalogo.generado.ts` (no se versiona)
desde tres fuentes que ya existen: las vistas de la vitrina (familias, componentes, grupos y
etiquetas), `packages/ui/dist/ejemplos.json` (el `angularNativo` de cada caso y la nota de
cada grupo) y las clases standalone (`input()`, `input.required()`, `model()` y `output()`
con su tipo, su valor por omisión y su comentario, leídos con el parser de TypeScript). Una
etiqueta enlazada (`[etiqueta]="rol"`, los tokens de Foundations) no se puede leer ahí: la
vitrina la pinta y la filtra igual, pero no entra en el índice.

Es el equivalente Angular de `npx @aybarcorp/cli docs`, y en un proyecto Angular es el que
funciona: `docs` renderiza con `@aybarcorp/ui` y `react-dom`, que `init` ya no instala en
Angular, y sin ellos se detiene diciendo qué falta.

**Por qué no se desincroniza del catálogo.** Los casos no se inventan aquí: la prueba
`pruebas/vitrina.test.mjs` lee `packages/ui/dist/ejemplos.json` —el catálogo que arma y
verifica el build de `@aybarcorp/ui`— y exige, familia por familia, un componente de la
vitrina por cada componente del catálogo y un caso por cada caso, con la misma etiqueta y
ninguno de más. Fechas, archivos y datos de Perú viven en `familias/form-pickers`, pero el
diseño los pone en Form Controls y la vitrina los pinta ahí.

Los tokens de Foundations no tienen casos en el catálogo: la vitrina los muestra con las
variantes de su ficha. Tema y densidad cambian la raíz de toda la página (sección siguiente).

## Tema, densidad y apariencia

`AyThemeService` (`establecer('light' | 'dark' | 'system')`) y `AyDensityService`
(`establecer('comfortable' | 'compact')`) aplican el modo en la raíz del documento con
`data-theme` y `data-density`; los componentes no los consultan. Los dos delegan en
`AyAppearanceService`, que lleva todos los ejes como señales: `tema`, `temaResuelto`,
`densidad`, `paleta`, `acento`, `neutro`, `radio`, `fuente`, `estilo` y `profundidad`.
Tiene además `establecer(eje, valor)`, `restablecer()`, `ejes` y `presets`. `AyPaletteService`
es la fachada de paleta, acento y grises.

El estado no es de los servicios: es del núcleo de `@aybarcorp/tokens/apariencia`, uno por
documento, compartido con el anfitrión y los remotos (React o Angular) y recordado en el
navegador. Crear un servicio no escribe nada: arranca de lo que declara `<html>`. Para no
recordar, o para usar otra clave:

```ts
bootstrapApplication(App, { providers: [provideAyApariencia({ persistir: false })] })
```

Para que la persona elija, `<ay-appearance-panel>` (familia Specialized) pinta un grupo por
eje sobre `AyAppearanceService`, con el mismo marcado que el `AppearancePanel` de
`@aybarcorp/ui`: leyenda y descripción asociada, radios con muestra o
`ay-segmented-control`, las combinaciones de la marca y «Restablecer». Entradas: `titulo`,
`nivelTitulo` (2, 3 o 4), `ejes` (con los nombres en español de `AyEjeApariencia`, en el orden
en que se quieren; `AY_EJES_APARIENCIA` da el id del núcleo de cada uno) y `mostrarPresets`;
salida, `(cambio)` con la apariencia resultante.

```html
<ay-appearance-panel titulo="Pantalla" [nivelTitulo]="3" [ejes]="['tema', 'densidad']"
                     [mostrarPresets]="false" (cambio)="guardar($event)" />
```

### Profundidad 3D

Tres directivas de Foundations y una entrada de Card llevan la profundidad (`data-depth`) al
puntero, con el mismo marcado y las mismas clases que `Tilt`, `Parallax`, `ParallaxLayer` y
`Card surface="glass"` de `@aybarcorp/ui`:

```html
<div ayTilt>
  <ay-card variante="interactive" href="/unidades/402">…</ay-card>
</div>

<div ayParallax>
  <div ayParallaxCapa [profundidad]="-0.6" [decorativa]="true">…formas…</div>
  <div ayParallaxCapa [profundidad]="0.2">
    <ay-card superficie="glass">…</ay-card>
  </div>
</div>
```

- `ayTilt` inclina el anfitrión hacia el puntero hasta `depth.tilt-max` y lo acerca
  `depth.elevation`; no añade rol ni foco, y sus oyentes son pasivos.
- `ayParallax` es la escena; cada `ayParallaxCapa` se desplaza `profundidad` (de -1 a 1) veces
  `depth.parallax-shift`, y con `decorativa` va detrás, sin puntero y con `aria-hidden`.
- `<ay-card superficie="glass">` es el vidrio: la opacidad `depth.glass-opacity` está medida
  para que el texto por defecto y el atenuado cumplan AA con el fondo contrario detrás.

Escuchan el puntero desde el primer render en el navegador (`afterNextRender`: en el servidor
no hacen nada) y lo dejan al destruirse. Con `prefers-reduced-motion: reduce`, sin hover, con
colores forzados o con `data-depth="plano"` no piden ningún cuadro; el vidrio es opaco con
`data-depth="plano"`, `prefers-reduced-transparency: reduce`, colores forzados, al imprimir o
sin `backdrop-filter`.

## Relación con `@aybarcorp/ui`

| | `@aybarcorp/ui` | `@aybarcorp/ui-angular` |
|---|---|---|
| Para | React (Vite, Next.js) | Angular |
| API | La de la ficha de cada componente, en inglés (`variant`, `size`, `loading`, `fullWidth`) | La del uso Angular del diseño (`variante`, `tamano`, `cargando`, `bloque`) |
| Hoja | `@aybarcorp/ui/css` → `dist/ui.css` | `dist/ui.css`, copia de la misma |
| Marcado | Clases `ay-*` | Las mismas clases `ay-*` |
| Catálogo | `dist/ejemplos.json` y `dist/props.json` | `<ay-vitrina />`, probado contra ese mismo `ejemplos.json` |

Son dos implementaciones del mismo diseño, y la hoja es lo que las ata: un cambio visual
en `ui.css` llega a las dos en el mismo build. Lo que **no** las ata todavía es el
comportamiento: ninguna prueba compara el HTML que renderizan los dos paquetes para un
mismo caso, así que un cambio de marcado o de accesibilidad en un componente React hay que
llevarlo a mano a su par Angular.

El paquete no depende de `@aybarcorp/ui` en tiempo de ejecución —solo de
`@aybarcorp/tokens` y `tslib`— y no trae React. Su build sí necesita `@aybarcorp/ui`
construido antes (de ahí copia la hoja), por eso va detrás de `ui` en el orden de build y
de publicación.

## Cómo se construye y se publica

`ng-packagr` compila con `compilationMode: "partial"` y `strictTemplates`, y deja en
`dist/` el formato de paquete Angular (`fesm2022` y los tipos). El paquete se publica
**desde su raíz**, como los otros nueve, y sus `exports` apuntan a `dist/`; el subpath
`./ui.css` existe, pero Angular declara la hoja por su ruta en `angular.json`.

```bash
npm run build -w @aybarcorp/ui-angular       # ng-packagr + copiar-hoja.mjs
npm run typecheck -w @aybarcorp/ui-angular   # ngc --noEmit
npm test -w @aybarcorp/ui-angular            # la vitrina contra el catálogo
```

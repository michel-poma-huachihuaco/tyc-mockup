#!/usr/bin/env node
/**
 * Hace exigible la regla que sostiene el sistema de diseño: ningún componente
 * declara un color, un espacio o una tipografía literal. Todo pasa por var(--aybar-*).
 *
 * Sin esta verificación la regla es una intención; con ella, cambiar el manual de
 * marca sigue siendo un cambio de un solo archivo tres años después.
 */
import { existsSync, globSync, readFileSync } from 'node:fs'
import { dirname, join, relative } from 'node:path'
import { fileURLToPath } from 'node:url'

// Las rutas se resuelven contra la ubicación del script, no contra process.cwd():
// así `node packages/ui/verificar-tokens.mjs` da el mismo resultado desde la raíz
// del monorepo, desde el paquete o desde un hook de CI.
const raiz = dirname(fileURLToPath(import.meta.url))
const monorepo = join(raiz, '..', '..')
const mostrar = (ruta) => relative(monorepo, ruta)


const PROHIBIDO = [
  { nombre: 'color hexadecimal', re: /#[0-9a-fA-F]{3,8}\b/g },
  { nombre: 'color rgb()/hsl()', re: /\b(?:rgba?|hsla?)\s*\(/g },
  { nombre: 'medida literal en px', re: /(?<![\w-])\d*\.?\d+px\b/g },
  { nombre: 'medida literal en rem/em', re: /(?<![\w-])\d*\.?\d+r?em\b/g },
]

// `var(--aybar-*)` puede llevar un fallback legítimo; se ignora el interior de var().
const sinVar = (texto) => texto.replace(/var\([^)]*\)/g, 'var()')

/** Fuentes de un paquete que pueden emitir estilo: la hoja y todo su TS/TSX. */
const fuentesDe = (paquete, ...extras) => {
  const src = join(monorepo, 'packages', paquete, 'src')
  if (!existsSync(src)) return [] // @aybarcorp/ui publicado suelto: el hermano no viaja en el tarball
  return [
    ...extras.map((n) => join(src, n)).filter(existsSync),
    ...globSync('**/*.{ts,tsx}', { cwd: src }).map((n) => join(src, n)),
    // Cada familia trae su hoja en src/familias/<familia>/estilos.css.
    ...globSync('familias/**/*.css', { cwd: src }).map((n) => join(src, n)),
  ]
}

// También se revisa ui-elements: sus envoltorios tocan `style` en DOM claro, que es
// justo donde reaparecería un literal fuera del alcance de la hoja.
const archivos = [...fuentesDe('ui', 'ui.css'), ...fuentesDe('ui-elements')]

// Cero archivos no es un pase: es que el script no encontró nada que revisar. Pasaba
// al ejecutarlo desde el paquete instalado —los `src/` hermanos no viajan en el
// tarball— e imprimía «0 archivos sin valores literales» saliendo con éxito, que se
// lee exactamente igual que una verificación que sí midió. Una comprobación que no
// puede comprobar debe decirlo, no aprobar por defecto.
if (archivos.length === 0) {
  console.error(
    'No se encontró ningún archivo que revisar. Este verificador necesita los `src/`\n' +
      'del monorepo; desde un paquete instalado no tiene nada que medir.\n' +
      'Ejecútalo desde una copia del repositorio del framework.',
  )
  process.exit(1)
}

let fallos = 0
for (const archivo of archivos) {
  const lineas = sinVar(readFileSync(archivo, 'utf8')).split('\n')
  lineas.forEach((linea, i) => {
    if (linea.trimStart().startsWith('*') || linea.trimStart().startsWith('//')) return
    for (const { nombre, re } of PROHIBIDO) {
      for (const hallazgo of linea.matchAll(re)) {
        console.error(`${mostrar(archivo)}:${i + 1}  ${nombre} literal: ${hallazgo[0]}`)
        fallos++
      }
    }
  })
}

if (fallos) {
  console.error(
    `\n${fallos} valor(es) literal(es). Todo color, espacio y tipografía sale de var(--aybar-*).\n`,
  )
  process.exit(1)
}
console.log(`@aybarcorp/ui · ${archivos.length} archivos sin valores literales`)

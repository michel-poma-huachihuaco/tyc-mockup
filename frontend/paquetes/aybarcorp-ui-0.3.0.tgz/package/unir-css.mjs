#!/usr/bin/env node
/**
 * Une la hoja base (src/ui.css) con la de cada familia en dist/ui.css.
 *
 * El orden es el de las fichas del Aybar Design System V1: Foundations y Layout
 * primero, porque el resto se apoya en ellas, y Errors al final. Una familia sin
 * hoja no es un error: puede no tener estilos propios.
 */
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const raiz = dirname(fileURLToPath(import.meta.url))
const FAMILIAS = [
  'foundations', 'layout', 'actions', 'form-architecture', 'form-controls', 'form-pickers',
  'surfaces', 'data', 'feedback', 'overlays', 'navigation', 'media', 'specialized', 'errors',
]
const partes = [readFileSync(join(raiz, 'src', 'ui.css'), 'utf8')]
for (const familia of FAMILIAS) {
  const ruta = join(raiz, 'src', 'familias', familia, 'estilos.css')
  if (existsSync(ruta)) partes.push(readFileSync(ruta, 'utf8'))
}
mkdirSync(join(raiz, 'dist'), { recursive: true })
writeFileSync(join(raiz, 'dist', 'ui.css'), partes.join('\n'))
console.log(`@aybarcorp/ui · dist/ui.css: base + ${partes.length - 1} familias`)

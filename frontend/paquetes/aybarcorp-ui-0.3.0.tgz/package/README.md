# @aybarcorp/ui

Componentes React del **Aybar Design System V1**, el diseño aprobado que vive en
[`docs/diseno/`](../../docs/diseno/) del repositorio: el HTML exportado
(`aybar-design-system-v1.html`) y una ficha JSON por familia (`fichas/<familia>.json`). Ningún
valor literal de color, espacio o tipografía: todo sale de `var(--aybar-*)`, y el build lo
verifica.

Forma parte del **framework Aybar**, un monorepo de diez paquetes que se publican
juntos y comparten siempre la misma versión. La arquitectura y las decisiones de diseño
están documentadas en el [repositorio](https://github.com/AybarCorp/aybar-framework-desing-frontEnd).

> Los diez se versionan en bloque, y se instalan con versión exacta. Mezclar versiones
> de `@aybarcorp/*` —o dejar una copia anidada bajo otra dependencia— pone dos módulos
> donde debía haber uno, y los contextos de React del anfitrión y del remoto dejan de
> coincidir: `useAnfitrion()` falla teniendo su Provider justo encima.
> `npx @aybarcorp/cli doctor` recorre `node_modules` en profundidad y lo detecta.

Es el paquete de React (Vite y Next.js). En Angular el sistema de diseño es
[`@aybarcorp/ui-angular`](../ui-angular/README.md): componentes standalone nativos con la
misma hoja y las mismas clases.

## Instalación

Requiere acceso a GitHub Packages: un `.npmrc` con `@aybarcorp:registry=https://npm.pkg.github.com` y un
token con permiso `read:packages`. No hay instalación anónima.

```bash
npm install @aybarcorp/ui
```

La vía recomendada no es instalarlo a mano, sino dejar que el CLI cablee el proyecto:

```bash
npx @aybarcorp/cli init --papel app
```

## Uso

Requiere que `@aybarcorp/tokens/css` esté cargado **antes** que `@aybarcorp/ui/css`:
la hoja de los componentes consume las custom properties de los tokens.

```tsx
import '@aybarcorp/tokens/css'
import '@aybarcorp/ui/css'
import { useState } from 'react'
import { Button, Card, CardBody, CardHeader, FormField, Input, Stack } from '@aybarcorp/ui'

export function Reserva() {
  const [monto, setMonto] = useState('')
  return (
    <Card>
      <CardHeader title="Nueva reserva" />
      <CardBody>
        <Stack gap="4">
          <FormField label="Monto" helper="En soles, sin separador de miles." required>
            <Input type="number" value={monto} onChange={(e) => setMonto(e.target.value)} />
          </FormField>
          <Button variant="primary" fullWidth>Enviar</Button>
        </Stack>
      </CardBody>
    </Card>
  )
}
```

**La API es la de la ficha, en inglés y sin traducir.** Cada componente expone exactamente
las props de la tabla `api` de su ficha: `Button` lleva `variant`, `size`, `loading`,
`fullWidth`, `leadingIcon` y `trailingIcon`. En `0.1.x` las props estaban en español
(`variante`, `tamano`, `cargando`, `bloque`, `iconoInicio`); ya no existen, y el build falla
si un ejemplo las usa. Lo mismo con `Field`, que se reemplazó por `FormField` de la familia
Form Architecture: la etiqueta es `label`, la ayuda `helper`, la marca de obligatorio
`required`, y el control va como hijo —`Input`, `Textarea`, `Select`, `Combobox`, un
`DatePicker`…—, al que `FormField` le cablea `id`, `required`, `aria-invalid` y
`aria-describedby`.

## Las familias

Una carpeta por familia en `src/familias/<familia>/`, con sus componentes, su hoja
(`estilos.css`), sus ejemplos (`ejemplos.json`) y su `index.ts`. Son catorce carpetas para
las trece familias del diseño: fechas, archivos y datos de Perú están en `form-pickers`,
pero el diseño los pone en Form Controls y el catálogo los publica ahí.

| Familia | Componentes | Casos en el catálogo |
|---|---|---|
| Foundations | 5 (`Icon`, `PrintLayout`, `Tilt`, `Parallax`, `ParallaxLayer`; color, tipografía, espacio, radio y sombra son tokens y helpers) | 34 |
| Layout | 14 | 70 |
| Actions | 7 | 56 |
| Form Architecture | 8 | 35 |
| Form Controls (`form-controls` + `form-pickers`) | 25 | 130 |
| Surfaces | 16 | 72 |
| Data | 11 | 64 |
| Feedback | 10 | 43 |
| Overlays | 9 | 44 |
| Navigation | 14 | 49 |
| Media | 7 | 33 |
| Specialized | 13 | 79 |
| Errors | 9 | 36 |
| **Total** | **148** | **745** |

`Spinner` ya es público: es de Feedback, que tiene ficha. El índice re-exporta además
`setTheme` y el tipo `Theme` de `@aybarcorp/tokens`, para que un remoto no tenga que
importar los tokens solo para cambiar de tema. También re-exporta `APPEARANCE` y los tipos de
los ejes (`PaletteId`, `RadiusId`…).

La apariencia se elige con cuatro hooks de Foundations. Todos leen el núcleo de
`@aybarcorp/tokens/apariencia`: un estado por documento, compartido con el anfitrión y los
remotos y recordado al recargar.

| Hook | Devuelve |
|---|---|
| `useTheme()` | `{ theme, resolved, setTheme }`: `resolved` es el tema que se ve, con `system` resuelto |
| `useDensity()` | `{ density, setDensity }`: una para toda la página; arranca de `<html data-density>` y montarse no la escribe |
| `usePalette()` | `{ palette, accent, neutral, setPalette, setAccent, setNeutral, options }` |
| `useAppearance()` | `{ appearance, set(axis, value), reset(), axes, presets }` |

Lo elegido con un hook se recuerda (`setTheme` de `@aybarcorp/tokens` no). Para que no
parpadee al recargar, la página carga `@aybarcorp/tokens/apariencia/arranque` en el `<head>`.

Para que la persona elija, sin escribir el selector: `<AppearancePanel>` (familia
Specialized) recorre `APPEARANCE.axes` en su orden, un grupo por eje con su nombre como
leyenda y su descripción asociada. Los ejes con muestra (paleta, acento, grises, radio,
tipografía) son radios con la muestra como decoración y la etiqueta como nombre; los demás,
un Segmented Control. Encima, las combinaciones de la marca (aplicar una fija sus ejes uno por
uno) y «Restablecer», que vuelve a lo que declara `<html>`. Cada cambio se anuncia en una
región `status` sin mover el foco, y cabe en 320 px.

```tsx
<AppearancePanel />
<AppearancePanel title="Pantalla" headingLevel={3} axes={['theme', 'density']} showPresets={false}
  onChange={(apariencia) => guardar(apariencia)} />
```

### Profundidad 3D

Tres componentes de Foundations y una superficie llevan la profundidad (`data-depth`) al
puntero. Todo sale de los tokens `depth.*`: el componente solo escribe dónde está el puntero
(de -1 a 1) y la hoja pone el ángulo y el desplazamiento.

| Pieza | Qué hace |
|---|---|
| `<Tilt>` | Inclina su contenido hacia el puntero hasta `depth.tilt-max` y lo acerca `depth.elevation`; vuelve a plano al salir. Un `div` sin rol ni foco, con oyentes pasivos: los hijos reciben sus eventos como siempre. |
| `<Parallax>` | La escena: escucha el puntero, recorta lo que se sale y apila las capas decorativas detrás del contenido. |
| `<ParallaxLayer depth decorative>` | Una capa que se desplaza `depth` (de -1 a 1) veces `depth.parallax-shift`; `decorative` la manda detrás, sin puntero y con `aria-hidden`. |
| `<Card surface="glass">` | El vidrio: `bg-surface` con `depth.glass-opacity` y el fondo desenfocado. Esa opacidad es la medida para que el texto por defecto y el atenuado cumplan AA con `bg-inverse` detrás; dentro, el tenue sube a atenuado. Para marcado propio, la clase `.ay-glass`. |

Un cuadro de animación a la vez, como mucho, y nada si no hace falta: con
`prefers-reduced-motion: reduce`, sin hover (táctil), con colores forzados o con
`data-depth="plano"` no se pide ninguno y no se mueve nada. La transformación existe solo
mientras el puntero está encima. El vidrio vuelve a ser la superficie opaca con
`data-depth="plano"`, `prefers-reduced-transparency: reduce`, colores forzados, al imprimir o
en un navegador sin `backdrop-filter`. `.ay-perspective` da la perspectiva de los tokens a
una escena 3D propia.

La hoja `dist/ui.css` la arma `unir-css.mjs`: la base (`src/ui.css`) y después la de cada
familia, en el orden de las fichas —Foundations y Layout primero, porque el resto se apoya
en ellas; Errors al final—. Una familia sin hoja no es un error.

Un `Link` con `external` abre en pestaña nueva y lo dice dos veces: con la flecha `↗`, que
solo se ve, y con «abre en una pestaña nueva», que solo oye el lector de pantalla. Ese
texto usa `ay-visually-hidden`, la clase de texto oculto del diseño (familia Layout). Suma
`noopener noreferrer` al `rel` que traiga el enlace en vez de reemplazarlo: `rel="license"`
sale como `license noopener noreferrer`. *(La hoja base conserva todavía
`.ay-visualmente-oculto`, el nombre anterior, que hoy solo usan por dentro `Drawer` y
`SidePanel`; para marcado propio, `ay-visually-hidden`.)*

## Catálogo y props como datos

El paquete publica dos JSON que describen sus propios componentes. Los consume
`npx @aybarcorp/cli docs` para generar el catálogo visual —y `@aybarcorp/ui-angular` prueba
su vitrina contra el primero—, y sirven para cualquier otra cosa que necesite saber qué
existe sin leer los `.d.ts`.

| Subpath | Qué trae | De dónde sale |
|---|---|---|
| `@aybarcorp/ui/ejemplos` | Los ejemplos como datos, en el formato 2: `formato`, y `grupos[]` con `familia`, `componente`, `titulo`, `nota`, `capa`, `ancho` y `casos[]` (`etiqueta`, `props`, `hijos`, `marco`, `angular`, `jsx`) | `src/familias/<familia>/ejemplos.json`, escritos a mano, unidos por `verificar-ejemplos.mjs` con el campo `familia`, validados en cada build y con el `jsx` de cada caso ya calculado |
| `@aybarcorp/ui/props` | `componentes[]` con `nombre`, `descripcion` y `props[]` (`nombre`, `tipo`, `requerido`, `porOmision`, `descripcion`) | Extraído de `dist/*.d.ts` con la API del compilador de TypeScript |

Hoy son 149 componentes, 303 grupos, 751 casos y 1036 props propias.

Los dos viven aquí y no en el CLI a propósito: una lista de ejemplos o una tabla de props
escrita lejos de los componentes divergiría al primer cambio de una prop y nadie lo
notaría, porque un catálogo desincronizado se ve igual de bien que uno correcto. Por eso
tampoco es una convención escrita, sino dos comprobaciones del build:

- `generar-props.mjs` lee la API de los `.d.ts` que acaba de emitir `tsc`. No hay copia
  que mantener: `tipo` sale del tipo y `porOmision` de la desestructuración del `.tsx`.
  Solo se documentan las props **propias** —las declaradas en `PropsX`—; las que llegan
  por `extends Omit<HTMLAttributes<…>>` son la superficie nativa del elemento, están en
  MDN y son más de doscientas. Siguen funcionando y el catálogo las ejercita.
- `verificar-ejemplos.mjs` une los ejemplos de cada familia y los valida contra los
  componentes reales antes de escribir `dist/ejemplos.json`: falla el build si un caso
  nombra un componente que el índice no exporta, si usa una prop que el tipo no tiene, si
  un componente o una prop propia se queda sin ningún ejemplo, o si un fragmento `angular`
  usa una etiqueta, un atributo o un evento que `@aybarcorp/ui-elements` no registra. Un
  catálogo inválido no llega a `dist/`.

El formato 2 añade lo que un caso no podía decir con texto:

- `{"$elemento": nodo | [nodos]}` como valor de una prop que recibe un elemento —el
  `footer` de un Modal, los `providers` de un LoginForm—: el pie pasa a tener botones de
  verdad en vez de «Descartar · Guardar». Una lista se pinta como Fragment.
- `marco` en el caso: el contenedor que le da sentido —un List Item en su List, un
  Timeline Event en su `ol.ay-timeline`, una pestaña en su `tablist`, una celda en su
  `tr`—, con `"$caso"` exactamente una vez. Los elementos HTML se limitan a una lista
  blanca (`ul ol div section table tbody tr`): el marco da contexto, no maqueta.
- `capa: true` y `ancho: "completo"` en el grupo: quien pinta los casos —el catálogo del
  CLI, la vitrina del SDK— lo lee de aquí en lugar de llevar su propia lista.
- `jsx` en cada caso de `dist/ejemplos.json`, con su marco y sus `$elemento`, para
  «Copiar código». Lo calcula el verificador con `jsxDeCaso`, la misma función con que el
  CLI escribe el código del catálogo (`packages/cli/src/docs/formato-ejemplos.ts`), así que
  no se escribe en las fuentes.

Las props que solo se usan dentro de un `$elemento` o de un `marco` cuentan para la regla
de cobertura, y una fuente que declare un `formato` más nuevo que el que el verificador
entiende hace fallar el build.

El campo `angular` de un caso es el fragmento **Web Component** de `@aybarcorp/ui-elements`,
no el de `@aybarcorp/ui-angular`: solo aparece en los seis componentes que existen como
custom element (`ay-heading`, `ay-button`, `ay-link`, `ay-toggle-button`, `ay-field`,
`ay-alert`), 39 casos en total. El verificador también lee la sintaxis de Angular de esos
fragmentos: un `[attr.x]` tiene que nombrar un atributo observado y un `(ay-…)` un evento
que el envoltorio emita. El uso de los componentes Angular nativos está en
[`@aybarcorp/ui-angular`](../ui-angular/README.md) y en su `<ay-vitrina />`.

La mandarina de la marca no es un color de acción —`#FFA726` da 1.94:1 tanto con blanco
como con negro, ilegible en ambos casos—, así que `variant="accent"` pinta texto
petróleo sobre mandarina, que es el uso que le da el manual.

/**
 * Lee la API pública de los componentes desde los `.d.ts` que emite el propio build,
 * con la API del compilador de TypeScript.
 *
 * Por qué desde los tipos y no de una lista escrita a mano. Una tabla de props en el
 * CLI —o en un README— es una segunda fuente de verdad: sobrevive al primer cambio de
 * una prop y a partir de ahí documenta un componente que ya no existe, sin que nada
 * falle. Los `.d.ts` son lo que el consumidor realmente compila contra; si se leen de
 * ahí, la documentación no puede desincronizarse porque no es una copia.
 *
 * Por qué `dist/*.d.ts` y no `src/*.tsx`. El `.d.ts` es la superficie publicada: lo que
 * el tipo no expone no es API, y el `Omit<..., 'className'>` ya está aplicado. La única
 * cosa que se lee del `.tsx` es el valor por omisión, que vive en la desestructuración
 * de parámetros y que el tipo no puede expresar (`variante?: VarianteBoton` no dice
 * que sin ella se pinta `primary`).
 *
 * `typescript` es devDependency y se queda ahí: esto corre en el build del framework,
 * no en el navegador del consumidor. Un consumidor que solo quiere la tabla lee
 * `@aybarcorp/ui/props`, que son unos kilobytes de JSON.
 */
import { existsSync, readFileSync } from 'node:fs'
import { dirname, join, relative } from 'node:path'
import { fileURLToPath } from 'node:url'
import ts from 'typescript'

const raiz = dirname(fileURLToPath(import.meta.url))
const ENTRADA = join(raiz, 'dist', 'index.d.ts')

/**
 * Qué se considera «prop propia» y por qué se excluye el resto.
 *
 * Los seis componentes declaran su interfaz como
 * `interface PropsButton extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'className'>`.
 * El criterio es estructural: **propia es la que está declarada en el cuerpo de la
 * interfaz**; lo que llega por la cláusula `extends` es la superficie nativa del
 * elemento del DOM.
 *
 * Se excluye porque `HTMLAttributes` aporta más de doscientos miembros —cada `aria-*`,
 * cada `on*`, cada `data-*`— que no son decisiones de este sistema de diseño, que están
 * documentados en MDN mucho mejor que aquí, y que en una tabla sepultarían las cinco o
 * seis props que sí hay que leer. No se pierde nada: siguen funcionando y el catálogo
 * las ejercita (`disabled`, `placeholder`, `type`, `defaultValue` son heredadas), y la
 * validación de los ejemplos se hace contra el tipo **completo**, no contra esta lista.
 */
export function extraerComponentes() {
  if (!existsSync(ENTRADA)) {
    throw new Error(
      `No existe ${relative(raiz, ENTRADA)}. Esta extracción lee los .d.ts que emite el\n` +
        'build, así que `tsc -p tsconfig.json` tiene que haber corrido antes.',
    )
  }

  const programa = ts.createProgram([ENTRADA], {
    target: ts.ScriptTarget.ES2023,
    module: ts.ModuleKind.ESNext,
    moduleResolution: ts.ModuleResolutionKind.Bundler,
    jsx: ts.JsxEmit.ReactJSX,
    strict: true,
    skipLibCheck: true,
    noEmit: true,
  })
  const checker = programa.getTypeChecker()
  const indice = programa.getSourceFile(ENTRADA)
  if (!indice) throw new Error(`El programa de TypeScript no cargó ${ENTRADA}.`)

  const moduloSimbolo = checker.getSymbolAtLocation(indice)
  if (!moduloSimbolo) throw new Error('index.d.ts no se resolvió como módulo.')
  const exportados = new Map(checker.getExportsOfModule(moduloSimbolo).map((s) => [s.name, s]))

  const componentes = []
  for (const nombre of nombresEnOrdenDeIndice(indice, programa)) {
    // Un componente es un valor exportado en mayúscula que tiene su interfaz `Props*`
    // exportada al lado. Nada de listas: agregar un séptimo componente lo incorpora,
    // y quitarle su interfaz lo saca del catálogo con la misma naturalidad.
    if (!/^[A-Z]/.test(nombre)) continue
    const simbolo = resolver(checker, exportados.get(nombre))
    const simboloProps = resolver(checker, exportados.get(`Props${nombre}`))
    if (!simbolo || !simboloProps) continue
    const interfaz = simboloProps.declarations?.find(ts.isInterfaceDeclaration)
    if (!interfaz) continue

    const porOmision = valoresPorOmision(simbolo)
    const props = interfaz.members.filter(ts.isPropertySignature).map((miembro) => {
      const nombreProp = miembro.name.getText()
      const simboloProp = checker.getSymbolAtLocation(miembro.name)
      return {
        nombre: nombreProp,
        tipo: textoDeTipo(checker, miembro.type),
        requerido: !miembro.questionToken,
        porOmision: porOmision.get(nombreProp) ?? null,
        descripcion: simboloProp ? documentacion(checker, simboloProp) : '',
      }
    })

    componentes.push({
      nombre,
      // La descripción del componente sale de su JSDoc; si no lo tiene, de la de su
      // interfaz de props. Si ninguno lo tiene queda vacía a propósito: inventarla aquí
      // sería escribir documentación que el código no respalda, y además ocultaría la
      // deuda. `generar-props.mjs` la reporta.
      descripcion: documentacion(checker, simbolo) || documentacion(checker, simboloProps),
      props,
      // No va al JSON: es el tipo completo (propias + heredadas de HTMLAttributes) y lo
      // usa `verificar-ejemplos.mjs` para validar cada clave de `props` de un ejemplo.
      todasLasProps: new Set(
        checker.getPropertiesOfType(checker.getDeclaredTypeOfSymbol(simboloProps)).map((s) => s.name),
      ),
    })
  }

  if (componentes.length === 0) {
    throw new Error('No se identificó ningún componente en index.d.ts; la extracción no midió nada.')
  }
  return componentes
}

// ── Detalle ───────────────────────────────────────────────────────────────────

/** Los nombres tal como los exporta `src/index.ts`, para que el JSON no salga alfabético. */
function nombresEnOrdenDeIndice(indice, programa) {
  const nombres = []
  for (const sentencia of indice.statements) {
    if (!ts.isExportDeclaration(sentencia)) continue
    const enlaces = sentencia.exportClause
    // `export * from './familias/<familia>/index.js'`: se recorre el índice de la
    // familia en su orden, para que el catálogo siga el orden de las fichas.
    if (!enlaces && programa && sentencia.moduleSpecifier && ts.isStringLiteral(sentencia.moduleSpecifier)) {
      const ruta = join(dirname(indice.fileName), sentencia.moduleSpecifier.text.replace(/\.js$/, '.d.ts'))
      const hijo = programa.getSourceFile(ruta)
      if (hijo) for (const n of nombresEnOrdenDeIndice(hijo, programa)) if (!nombres.includes(n)) nombres.push(n)
      continue
    }
    if (!enlaces || !ts.isNamedExports(enlaces)) continue
    for (const elemento of enlaces.elements) {
      const nombre = elemento.name.text
      if (!nombres.includes(nombre)) nombres.push(nombre)
    }
  }
  return nombres
}

function resolver(checker, simbolo) {
  if (!simbolo) return undefined
  return simbolo.flags & ts.SymbolFlags.Alias ? checker.getAliasedSymbol(simbolo) : simbolo
}

function documentacion(checker, simbolo) {
  return ts
    .displayPartsToString(simbolo.getDocumentationComment(checker))
    .replace(/\s+/g, ' ')
    .trim()
}

/**
 * El texto del tipo. Se toma del nodo sintáctico y no de `typeToString`, para que
 * `CSSProperties['alignItems']` y `ReactNode` se lean como los escribió quien programó
 * el componente y no expandidos a doscientas constituyentes.
 *
 * La única expansión es la que sirve al lector: un alias local que resuelve a una unión
 * de puros literales (`VarianteBoton`, `TamanoBoton`, `TonoAlert`, `Espacio`) se
 * sustituye por la unión, porque «`variante?: VarianteBoton`» no dice qué valores
 * acepta y obligaría justamente a abrir el `.d.ts`.
 */
function textoDeTipo(checker, nodo) {
  if (!nodo) return ''
  if (ts.isTypeReferenceNode(nodo) && ts.isIdentifier(nodo.typeName)) {
    const alias = resolver(checker, checker.getSymbolAtLocation(nodo.typeName))
    const declaracion = alias?.declarations?.find(ts.isTypeAliasDeclaration)
    if (declaracion && esUnionDeLiterales(declaracion.type)) return normalizar(declaracion.type.getText())
  }
  return normalizar(nodo.getText())
}

const esUnionDeLiterales = (nodo) =>
  ts.isUnionTypeNode(nodo) && nodo.types.every((t) => ts.isLiteralTypeNode(t))

// Comillas simples y una sola línea: es texto para una tabla, no código para compilar.
const normalizar = (texto) => texto.replace(/"([^"]*)"/g, "'$1'").replace(/\s+/g, ' ').trim()

/**
 * Los valores por omisión reales, leídos de la desestructuración de parámetros del
 * `.tsx` (`{ variante = 'primary', ... }`). No se deducen del tipo porque el tipo no los
 * contiene, y no se escriben a mano porque entonces habría dos verdades. Lo que no sea
 * un literal simple queda en `null`: mejor un hueco honesto que un valor inventado.
 */
function valoresPorOmision(simbolo) {
  const declaracion = simbolo.declarations?.[0]
  if (!declaracion) return new Map()
  const dts = declaracion.getSourceFile().fileName
  const fuente = join(raiz, 'src', relative(join(raiz, 'dist'), dts)).replace(/\.d\.ts$/, '.tsx')
  if (!existsSync(fuente)) return new Map()

  const archivo = ts.createSourceFile(fuente, readFileSync(fuente, 'utf8'), ts.ScriptTarget.ES2023, true, ts.ScriptKind.TSX)
  const valores = new Map()
  const recorrer = (nodo) => {
    if (ts.isParameter(nodo) && ts.isObjectBindingPattern(nodo.name)) {
      for (const elemento of nodo.name.elements) {
        if (!elemento.initializer) continue
        const clave = (elemento.propertyName ?? elemento.name).getText()
        const valor = literal(elemento.initializer)
        if (valor !== null) valores.set(clave, valor)
      }
    }
    ts.forEachChild(nodo, recorrer)
  }
  recorrer(archivo)
  return valores
}

/**
 * Se serializa como cadena —`'false'`, `'4'`— y no con el tipo nativo: el destino es una
 * celda de una tabla, y un `porOmision` que a veces es booleano, a veces número y a
 * veces cadena obliga a quien lo consume a distinguir `false` de «no tiene».
 * Ese caso es `null`, y solo ese.
 */
function literal(nodo) {
  if (ts.isStringLiteralLike(nodo)) return nodo.text
  if (ts.isNumericLiteral(nodo)) return nodo.text
  if (nodo.kind === ts.SyntaxKind.TrueKeyword) return 'true'
  if (nodo.kind === ts.SyntaxKind.FalseKeyword) return 'false'
  return null
}

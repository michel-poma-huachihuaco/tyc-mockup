#!/usr/bin/env node
/**
 * Valida el catálogo de ejemplos contra los componentes reales y, si pasa, lo publica
 * en `dist/ejemplos.json` —el subpath `@aybarcorp/ui/ejemplos`, que consume `npx @aybarcorp/cli docs`—.
 *
 * Por qué el verificador es también el que copia. Un catálogo inválido no debe llegar a
 * `dist/` ni un segundo: `dist/` es lo que se empaqueta, y un `cp` antes de la
 * comprobación deja el archivo malo en el tarball si alguien empaqueta sin volver a
 * construir. Aquí la única forma de que `dist/ejemplos.json` exista es que las
 * comprobaciones hayan pasado.
 *
 * Qué se comprueba, y por qué cada cosa:
 *
 *   1. Que cada `componente` lo exporte de verdad `dist/index.js`. Un ejemplo que nombra
 *      un componente que ya no existe no da un catálogo incompleto: da un catálogo que
 *      revienta al renderizarse, en la máquina de quien lo abre.
 *   2. Que cada clave de `props` exista en el tipo del componente —el tipo **completo**,
 *      con las heredadas de `HTMLAttributes`, porque el catálogo ejercita a propósito
 *      `disabled`, `placeholder` o `defaultValue`—. Renombrar `tamano` a `size` sin
 *      tocar el catálogo tiene que romper el build, no producir un ejemplo silencioso
 *      con una prop que React ignora.
 *   3. Que ningún componente ni ninguna prop propia se quede sin ejemplo. Es la mitad
 *      que suele faltar: la prop nueva compila, se publica y nadie se enteró de que
 *      existe porque el catálogo no la muestra. Cuentan también las props que se usan
 *      dentro de un `$elemento` o de un `marco`: el botón del pie de un Modal ejercita
 *      el Button igual que un caso suelto.
 *   4. Que los fragmentos `angular` solo aparezcan en los componentes que
 *      `@aybarcorp/ui-elements` expone, con su etiqueta real y con atributos que estén
 *      en su mapa. Los nombres de atributo no son los de las props —`value` alimenta
 *      `defaultValue`— y esa traducción es exactamente lo que se desincroniza. Lo mismo
 *      con la sintaxis de Angular: un `[attr.x]` tiene que nombrar un atributo
 *      observado, y un `(ay-…)` un evento que el envoltorio emita de verdad —un
 *      `(ay-change)` donde el elemento emite `ay-cambio` compila y no se dispara nunca—.
 *   5. El formato 2 (`packages/cli/src/docs/formato-ejemplos.ts`): un `$elemento` es un
 *      componente o una lista de componentes; un `marco` usa componentes o elementos de
 *      la lista blanca y lleva `"$caso"` exactamente una vez; `capa` y `ancho` solo
 *      admiten `true` y `"completo"`; y ninguna fuente declara un formato más nuevo que
 *      el que este verificador entiende.
 *
 * Y una cosa que se calcula en vez de comprobarse: el `jsx` de cada caso, con su marco y
 * sus `$elemento`, que es lo que la vitrina copia con «Copiar código». Sale de
 * `jsxDeCaso`, la misma función con la que `aybar-front docs` escribe el código del
 * catálogo; el build de ui corre antes que el del CLI, así que se transpila desde su
 * fuente (`cargarFormato`), que por eso no importa nada.
 */
import { existsSync, globSync, readFileSync, writeFileSync } from 'node:fs'
import { dirname, join, relative } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import ts from 'typescript'

import { extraerComponentes } from './props-desde-tipos.mjs'

const raiz = dirname(fileURLToPath(import.meta.url))
const monorepo = join(raiz, '..', '..')
const FUENTE = join(raiz, 'src', 'ejemplos.json')
const SALIDA = join(raiz, 'dist', 'ejemplos.json')
const ELEMENTOS = join(monorepo, 'packages', 'ui-elements', 'src', 'index.ts')
const FORMATO = join(monorepo, 'packages', 'cli', 'src', 'docs', 'formato-ejemplos.ts')

// Orden de las familias: el de las fichas del Aybar Design System V1.
const FAMILIAS = [
  ['foundations', 'Foundations'], ['layout', 'Layout'], ['actions', 'Actions'],
  ['form-architecture', 'Form Architecture'], ['form-controls', 'Form Controls'],
  ['form-pickers', 'Form Controls'], ['surfaces', 'Surfaces'], ['data', 'Data'],
  ['feedback', 'Feedback'], ['overlays', 'Overlays'], ['navigation', 'Navigation'],
  ['media', 'Media'], ['specialized', 'Specialized'], ['errors', 'Errors'],
]

if (process.argv[1] && pathToFileURL(process.argv[1]).href === import.meta.url) await principal()

async function principal() {
  let formato
  try {
    formato = await cargarFormato()
  } catch (error) {
    salir([error.message])
  }
  const { catalogo, fallos: deLasFuentes } = unirCatalogo(formato)
  if (deLasFuentes.length) salir(deLasFuentes)

  // El índice compilado, no el tipo: que el componente esté exportado como valor es lo
  // que hace que el catálogo se pueda renderizar.
  const indice = await import(new URL('./dist/index.js', `file://${raiz}/`).href)
  const resultado = verificarCatalogo(catalogo, {
    componentes: extraerComponentes(),
    indice,
    envoltorios: leerEnvoltorios(),
    formato,
  })
  if (resultado.fallos.length) salir(resultado.fallos)

  writeFileSync(SALIDA, `${JSON.stringify(resultado.catalogo, null, 2)}\n`)
  const { componentes, grupos, casos, conAngular } = resultado.resumen
  console.log(
    `@aybarcorp/ui · ${relative(raiz, SALIDA)}: formato ${formato.FORMATO_EJEMPLOS}, ${componentes} componentes, ` +
      `${grupos} grupos, ${casos} casos con su jsx` +
      (conAngular === null ? '' : ` · ${conAngular} con fragmento Angular verificado`),
  )
}

// ── Formato ───────────────────────────────────────────────────────────────────

/**
 * El módulo del formato de ejemplos, transpilado desde la fuente del CLI con el
 * compilador de TypeScript. Se carga desde un `data:` URL, donde un `import` relativo no
 * resuelve: si el módulo dejara de ser puro, el fallo tiene que decir por qué y no salir
 * como un ERR_MODULE_NOT_FOUND sin contexto.
 */
export async function cargarFormato(ruta = FORMATO) {
  if (!existsSync(ruta)) {
    throw new Error(
      `No existe ${relative(monorepo, ruta)}: el formato de los ejemplos y su jsx los define el CLI, ` +
        'y este verificador los toma de su fuente. Sin él no hay contra qué validar ni con qué calcular el jsx.',
    )
  }
  const { outputText } = ts.transpileModule(readFileSync(ruta, 'utf8'), {
    fileName: ruta,
    compilerOptions: { module: ts.ModuleKind.ESNext, target: ts.ScriptTarget.ES2023 },
  })
  if (/^\s*import\s|^\s*export\s[^;]*\sfrom\s/m.test(outputText)) {
    throw new Error(
      `${relative(monorepo, ruta)} importa otro módulo. Tiene que bastarse solo: el build de ` +
        '@aybarcorp/ui lo transpila y lo carga sin poder resolver dependencias. Mueve lo que ' +
        'importa a ese mismo archivo o déjalo fuera de él.',
    )
  }
  return import(`data:text/javascript;base64,${Buffer.from(outputText).toString('base64')}`)
}

/**
 * Comprueba el `formato` que declara una fuente, si declara uno. Un formato más nuevo que
 * el del verificador no se valida a medias: lo que este no conoce pasaría sin comprobar.
 */
function revisarFormato(declarado, donde, formato, falla) {
  if (declarado === undefined) return
  if (!Number.isInteger(declarado) || declarado < 1) {
    falla(`${donde}: \`formato\` debe ser un entero positivo.`)
  } else if (declarado > formato.FORMATO_EJEMPLOS) {
    falla(
      `${donde}: declara el formato ${declarado} de ejemplos y este verificador entiende hasta el ` +
        `${formato.FORMATO_EJEMPLOS}. Actualiza packages/cli/src/docs/formato-ejemplos.ts —y con él el ` +
        'CLI que pinta el catálogo— antes de escribir ejemplos en el formato nuevo.',
    )
  }
}

/** Une `src/ejemplos.json` con los de cada familia, con el campo `familia` en cada grupo. */
function unirCatalogo(formato) {
  const fallos = []
  const falla = (mensaje) => fallos.push(mensaje)
  const catalogo = JSON.parse(readFileSync(FUENTE, 'utf8'))
  revisarFormato(catalogo.formato, relative(monorepo, FUENTE), formato, falla)
  for (const [carpeta, familia] of FAMILIAS) {
    const ruta = join(raiz, 'src', 'familias', carpeta, 'ejemplos.json')
    if (!existsSync(ruta)) continue
    const propio = JSON.parse(readFileSync(ruta, 'utf8'))
    revisarFormato(propio.formato, relative(monorepo, ruta), formato, falla)
    for (const grupo of propio.grupos ?? []) catalogo.grupos.push({ familia, ...grupo })
  }
  return { catalogo, fallos }
}

// ── Verificación ──────────────────────────────────────────────────────────────

/**
 * Valida un catálogo ya unido y, si pasa, lo devuelve con `formato` y el `jsx` de cada caso.
 *
 * `componentes` es la API extraída de los .d.ts (`extraerComponentes`), `indice` el módulo
 * compilado, `envoltorios` el mapa de @aybarcorp/ui-elements (o `null` si no está) y
 * `formato` el módulo de `cargarFormato`. Se reciben en vez de leerse aquí para poder
 * probar la verificación con un catálogo y una API pequeños.
 */
export function verificarCatalogo(catalogo, { componentes, indice, envoltorios = null, formato }) {
  const fallos = []
  const falla = (mensaje) => fallos.push(mensaje)
  const porNombre = new Map(componentes.map((c) => [c.nombre, c]))
  const propsUsadas = new Map(componentes.map((c) => [c.nombre, new Set()]))
  const componentesConAngular = new Set()
  let casos = 0

  revisarFormato(catalogo.formato, 'el catálogo', formato, falla)
  if (!Array.isArray(catalogo.grupos) || catalogo.grupos.length === 0) {
    falla('El catálogo no tiene un arreglo `grupos` con contenido.')
    return { fallos, catalogo: null, resumen: null }
  }

  // ── Un componente y sus props ──
  /** Comprueba el componente y sus props; `false` si no hay contra qué seguir mirando. */
  const revisarComponente = (nodo, donde) => {
    const componente = porNombre.get(nodo.componente)
    if (!componente) {
      falla(
        `${donde}: el componente "${nodo.componente}" no está en la API de @aybarcorp/ui. ` +
          `Exportados: ${componentes.map((c) => c.nombre).join(', ')}.`,
      )
      return false
    }
    if (typeof indice[nodo.componente] === 'undefined') {
      falla(`${donde}: "${nodo.componente}" tiene tipo pero dist/index.js no lo exporta como valor.`)
      return false
    }
    if (nodo.props === undefined || nodo.props === null || typeof nodo.props !== 'object' || Array.isArray(nodo.props)) {
      // En un nodo anidado `props` puede faltar; en un caso, no.
      if (nodo.props !== undefined || nodo.esCaso) {
        falla(`${donde}: \`props\` debe ser un objeto plano (usa {} si el caso no pasa ninguna).`)
      }
      return true
    }
    for (const [clave, valor] of Object.entries(nodo.props)) {
      if (!componente.todasLasProps.has(clave)) {
        falla(
          `${donde}: ${nodo.componente} no tiene la prop "${clave}". ` +
            `Propias: ${componente.props.map((p) => p.nombre).join(', ')}; el resto son las de HTMLAttributes.`,
        )
        continue
      }
      propsUsadas.get(nodo.componente).add(clave)
      revisarValor(valor, `${donde}.props.${clave}`)
    }
    return true
  }

  /** Un valor de prop: si es un `$elemento`, sus componentes se revisan como cualquier otro. */
  const revisarValor = (valor, donde) => {
    if (!formato.esValorElemento(valor)) {
      buscarElementoAnidado(valor, donde)
      return
    }
    const problemas = formato.problemasDeElemento(valor, donde)
    problemas.forEach(falla)
    if (problemas.length) return
    for (const [k, nodo] of formato.nodosDeElemento(valor).entries()) {
      revisarNodo(nodo, Array.isArray(valor.$elemento) ? `${donde}.$elemento[${k}]` : `${donde}.$elemento`)
    }
  }

  /**
   * `$elemento` vale solo como valor directo de una prop: dentro de un objeto o de una
   * lista —`items[0].icon`— ni el catálogo ni la vitrina lo resolverían, y llegaría al
   * componente como un objeto cualquiera.
   */
  const buscarElementoAnidado = (valor, donde) => {
    if (valor === null || typeof valor !== 'object') return
    for (const [clave, interno] of Object.entries(valor)) {
      const ruta = Array.isArray(valor) ? `${donde}[${clave}]` : `${donde}.${clave}`
      if (formato.esValorElemento(interno)) {
        falla(`${ruta}: \`$elemento\` solo vale como valor directo de una prop, no dentro de un objeto o una lista.`)
      } else {
        buscarElementoAnidado(interno, ruta)
      }
    }
  }

  /** Un componente y, recursivamente, sus `hijos` (Card > Stack > Heading). */
  const revisarNodo = (nodo, donde) => {
    if (typeof nodo !== 'object' || nodo === null || typeof nodo.componente !== 'string') {
      falla(`${donde}: un caso anidado necesita \`componente\`.`)
      return
    }
    if (!revisarComponente(nodo, donde)) return
    if (nodo.hijos === undefined || nodo.hijos === null || typeof nodo.hijos === 'string') return
    if (!Array.isArray(nodo.hijos)) {
      falla(`${donde}: \`hijos\` debe ser una cadena o un arreglo de casos anidados.`)
      return
    }
    for (const [k, hijo] of nodo.hijos.entries()) revisarNodo(hijo, `${donde}.hijos[${k}]`)
  }

  /**
   * El marco: primero su forma (lista blanca, `"$caso"` una vez), con la misma función que
   * usa el CLI; después, cada componente que use, contra la API como cualquier otro.
   */
  const revisarMarco = (marco, donde) => {
    const problemas = formato.problemasDeMarco(marco, donde)
    problemas.forEach(falla)
    if (problemas.length) return
    const recorrer = (nodo, ruta) => {
      if (nodo.componente !== undefined) {
        revisarComponente(nodo, ruta)
      } else {
        for (const [clave, valor] of Object.entries(nodo.props ?? {})) {
          // Un elemento HTML no tiene tipo contra el que comprobar sus props: lo mínimo es
          // que sean atributos escritos como los escribe React.
          if (clave === 'class' || clave === 'for') {
            falla(`${ruta}.props.${clave}: en React es \`${clave === 'class' ? 'className' : 'htmlFor'}\`.`)
          } else if (!['string', 'number', 'boolean'].includes(typeof valor)) {
            falla(`${ruta}.props.${clave}: un elemento del marco solo recibe textos, números o booleanos.`)
          }
        }
      }
      if (!Array.isArray(nodo.hijos)) return
      for (const [k, hijo] of nodo.hijos.entries()) {
        if (hijo !== formato.MARCADOR_CASO) recorrer(hijo, `${ruta}.hijos[${k}]`)
      }
    }
    recorrer(marco, donde)
  }

  const revisarAngular = (nombre, caso, donde) => {
    if (caso.angular === undefined) return
    if (typeof caso.angular !== 'string' || !caso.angular.startsWith('<')) {
      falla(`${donde}: \`angular\` debe ser el fragmento HTML del Web Component.`)
      return
    }
    if (!envoltorios) return // ui-elements no está en el árbol: no hay contra qué comprobar
    // De un componente que no existe ya habló `revisarComponente`; repetirlo aquí solo añade ruido.
    if (!porNombre.has(nombre)) return

    const envoltorio = envoltorios.get(nombre)
    if (!envoltorio) {
      falla(
        `${donde}: ${nombre} no se expone como Web Component y no puede traer \`angular\`. ` +
          'Card y Stack quedan fuera a propósito: la proyección de contenido la resuelve <ng-content>.',
      )
      return
    }
    // La etiqueta de apertura, tolerando un `>` dentro de un valor entre comillas.
    const apertura = /^<([a-z][a-z0-9-]*)((?:[^>"]|"[^"]*")*)>/.exec(caso.angular)
    if (!apertura) {
      falla(`${donde}: no se pudo leer la etiqueta de apertura de \`angular\`.`)
      return
    }
    if (apertura[1] !== envoltorio.etiqueta) {
      falla(`${donde}: la etiqueta es <${apertura[1]}> y ${nombre} se registra como <${envoltorio.etiqueta}>.`)
    }
    // Los valores se vacían antes de buscar nombres de atributo: si no, cada palabra de
    // `ayuda="Entre 6 y 60 meses."` se leería como un atributo inexistente.
    const atributos = apertura[2].replace(/="[^"]*"/g, '=')
    const observados = [
      ...[...atributos.matchAll(/(?:^|\s)([a-zA-Z][a-zA-Z0-9-]*)(?==|\s|$)/g)].map((m) => m[1]),
      // `[attr.presionado]="…"`: el enlace de Angular escribe exactamente ese atributo.
      ...[...atributos.matchAll(/\[attr\.([a-zA-Z][a-zA-Z0-9-]*)\]=/g)].map((m) => m[1]),
    ]
    for (const nombreAtributo of observados) {
      if (!envoltorio.atributos.has(nombreAtributo)) {
        falla(
          `${donde}: <${envoltorio.etiqueta}> no observa el atributo "${nombreAtributo}". ` +
            `Observa: ${[...envoltorio.atributos].join(', ')}.`,
        )
      }
    }
    // Solo los eventos propios (`ay-*`): los nativos —`(click)`, `(focusout)`— burbujean
    // desde el `<button>` o el `<input>` interno y no dependen del envoltorio.
    for (const [, evento] of atributos.matchAll(/\((ay-[a-z0-9-]+)\)=/g)) {
      if (!envoltorio.eventos.has(evento)) {
        falla(
          `${donde}: <${envoltorio.etiqueta}> no emite el evento "${evento}". ` +
            (envoltorio.eventos.size ? `Emite: ${[...envoltorio.eventos].join(', ')}.` : 'No emite eventos propios.'),
        )
      }
    }
    componentesConAngular.add(nombre)
  }

  // ── Los grupos ──
  for (const [i, grupo] of catalogo.grupos.entries()) {
    const donde = `grupos[${i}]`
    if (typeof grupo.componente !== 'string' || typeof grupo.titulo !== 'string') {
      falla(`${donde}: falta \`componente\` o \`titulo\` (cadenas).`)
      continue
    }
    if ('nota' in grupo && typeof grupo.nota !== 'string') falla(`${donde}: \`nota\` debe ser cadena.`)
    // `capa` y `ancho` existen para que quien pinta los casos no lleve su propia lista de
    // qué es una capa o una página; un `false` o un `"medio"` serían esa lista otra vez.
    if ('capa' in grupo && grupo.capa !== true) falla(`${donde} (${grupo.componente}): \`capa\` solo admite true; quítala si no es una capa.`)
    if ('ancho' in grupo && grupo.ancho !== 'completo') {
      falla(`${donde} (${grupo.componente}): \`ancho\` solo admite "completo"; quítalo si el caso cabe en una columna.`)
    }
    if (!Array.isArray(grupo.casos) || grupo.casos.length === 0) {
      falla(`${donde} (${grupo.componente}): \`casos\` debe ser un arreglo con contenido.`)
      continue
    }
    for (const [j, caso] of grupo.casos.entries()) {
      casos++
      const dondeCaso = `${donde}.casos[${j}]`
      if (typeof caso.etiqueta !== 'string' || !caso.etiqueta) falla(`${dondeCaso}: falta \`etiqueta\`.`)
      if ('jsx' in caso) {
        falla(`${dondeCaso} (${grupo.componente}): \`jsx\` no se escribe a mano: lo calcula este verificador desde el caso.`)
      }
      revisarNodo({ componente: grupo.componente, props: caso.props, hijos: caso.hijos, esCaso: true }, dondeCaso)
      if (caso.marco !== undefined) revisarMarco(caso.marco, `${dondeCaso}.marco`)
      revisarAngular(grupo.componente, caso, dondeCaso)
    }
  }

  // ── Cobertura ──
  const conGrupo = new Set(catalogo.grupos.map((g) => g.componente))
  for (const componente of componentes) {
    if (!conGrupo.has(componente.nombre)) {
      falla(
        `${componente.nombre} se exporta pero no tiene ningún grupo de ejemplos. ` +
          'Un componente sin ejemplo obliga a leer el .d.ts, que es justo lo que el catálogo evita.',
      )
      continue
    }
    const usadas = propsUsadas.get(componente.nombre)
    const huerfanas = componente.props.filter((p) => !usadas.has(p.nombre)).map((p) => p.nombre)
    if (huerfanas.length) {
      falla(
        `${componente.nombre}: sin ningún ejemplo que las use → ${huerfanas.join(', ')}. ` +
          'Las props propias son la API que este sistema añade; todas se muestran.',
      )
    }
  }
  if (envoltorios) {
    for (const [nombre, envoltorio] of envoltorios) {
      if (!componentesConAngular.has(nombre)) {
        falla(
          `${nombre} existe como <${envoltorio.etiqueta}> y ningún caso trae \`angular\`. ` +
            'Quien consume desde Angular necesita el fragmento; el nombre del atributo no siempre es el de la prop.',
        )
      }
    }
  }

  if (fallos.length) return { fallos, catalogo: null, resumen: null }

  // ── Salida: el formato que se publica y el jsx de cada caso ──
  const { formato: _declarado, grupos, ...resto } = catalogo
  return {
    fallos,
    catalogo: {
      formato: formato.FORMATO_EJEMPLOS,
      ...resto,
      grupos: grupos.map((grupo) => ({
        ...grupo,
        casos: grupo.casos.map((caso) => ({
          ...caso,
          jsx: formato.jsxDeCaso({
            componente: grupo.componente,
            props: caso.props,
            hijos: caso.hijos,
            marco: caso.marco,
          }),
        })),
      })),
    },
    resumen: {
      componentes: conGrupo.size,
      grupos: catalogo.grupos.length,
      casos,
      conAngular: envoltorios ? componentesConAngular.size : null,
    },
  }
}

// ── Web Components ────────────────────────────────────────────────────────────

/**
 * El mapa de atributos que registra `@aybarcorp/ui-elements`, leído de su fuente con el
 * parser de TypeScript en vez de a ojo: `envolver('ay-field', Field, { atributos: {…} })`.
 * Devuelve `null` si el paquete hermano no está —desde un tarball instalado no viaja—,
 * y entonces esta comprobación se omite en lugar de fallar por algo que no puede medir.
 */
function leerEnvoltorios() {
  if (!existsSync(ELEMENTOS)) return null
  const mapa = new Map()
  const fuentes = [ELEMENTOS, ...globSync('familias/*.ts', { cwd: dirname(ELEMENTOS) }).map((n) => join(dirname(ELEMENTOS), n))]
  for (const fuente of fuentes) leerEnvoltoriosDe(fuente, mapa)
  return mapa.size ? mapa : null
}

function leerEnvoltoriosDe(fuente, mapa) {
  const archivo = ts.createSourceFile(fuente, readFileSync(fuente, 'utf8'), ts.ScriptTarget.ES2023, true)
  const recorrer = (nodo) => {
    if (
      ts.isCallExpression(nodo) &&
      ts.isIdentifier(nodo.expression) &&
      nodo.expression.text === 'envolver' &&
      nodo.arguments.length >= 2 &&
      ts.isStringLiteralLike(nodo.arguments[0]) &&
      ts.isIdentifier(nodo.arguments[1])
    ) {
      const atributos = new Set()
      const eventos = new Set()
      const opciones = nodo.arguments[2]
      if (opciones && ts.isObjectLiteralExpression(opciones)) {
        for (const propiedad of opciones.properties) {
          if (!ts.isPropertyAssignment(propiedad)) continue
          if (!ts.isObjectLiteralExpression(propiedad.initializer)) continue
          const clave = propiedad.name.getText()
          if (clave === 'atributos') {
            for (const atributo of propiedad.initializer.properties) {
              if (atributo.name) atributos.add(atributo.name.getText().replace(/['"]/g, ''))
            }
          }
          // `eventos: { alCambiarPresionado: { evento: 'ay-cambio', detalle } }`: lo que
          // cuenta es el nombre del evento del DOM, no el de la prop de React.
          if (clave === 'eventos') {
            for (const callback of propiedad.initializer.properties) {
              if (!ts.isPropertyAssignment(callback) || !ts.isObjectLiteralExpression(callback.initializer)) continue
              for (const campo of callback.initializer.properties) {
                if (
                  ts.isPropertyAssignment(campo) &&
                  campo.name.getText() === 'evento' &&
                  ts.isStringLiteralLike(campo.initializer)
                ) {
                  eventos.add(campo.initializer.text)
                }
              }
            }
          }
        }
      }
      mapa.set(nodo.arguments[1].text, { etiqueta: nodo.arguments[0].text, atributos, eventos })
    }
    ts.forEachChild(nodo, recorrer)
  }
  recorrer(archivo)
}

function salir(mensajes) {
  console.error(`\n${mensajes.map((m) => `  ✗ ${m}`).join('\n')}`)
  console.error(
    `\n${mensajes.length} problema(s) en ${relative(monorepo, FUENTE)}. El catálogo describe la API real\n` +
      'de los componentes: si divergen, el que está mal es el catálogo. No se escribió dist/ejemplos.json.\n',
  )
  process.exit(1)
}

/** Une clases descartando falsy. Evita traer `clsx` a la superficie pública del paquete. */
export function cx(...partes: (string | false | null | undefined)[]): string {
  return partes.filter(Boolean).join(' ')
}

/**
 * Área útil de la ventana para colocar una superficie flotante: ancho y alto sin las
 * barras de scroll. `innerWidth` e `innerHeight` las incluyen, y una burbuja pegada al
 * borde derecho quedaba encima de la barra vertical y daba scroll horizontal a la página.
 * Si el documento aún no tiene caja (`clientWidth` 0: sin disposición, como en jsdom o
 * en un iframe oculto), se recurre a `innerWidth`/`innerHeight`.
 *
 * Interna: se comparte entre familias desde aquí, pero no se exporta en el índice.
 * Overlays lleva su propia copia en `_dom.ts`, que es copia literal de la de Angular.
 */
export function areaVisible(documento: Document = document): { ancho: number; alto: number } {
  const raiz = documento.documentElement
  const vista = documento.defaultView
  return {
    ancho: raiz.clientWidth || vista?.innerWidth || 0,
    alto: raiz.clientHeight || vista?.innerHeight || 0,
  }
}

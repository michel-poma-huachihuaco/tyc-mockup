import { forwardRef, useEffect, useState } from 'react'
import type { HTMLAttributes } from 'react'
import { ErrorPage } from './ErrorPage.js'
import type { ErrorScope } from './ErrorPage.js'
import { Anuncio, BotonAy, IncidentId, aFecha, conParametro, horaDelDia, recargar, useAccion } from './_internos.js'
import { IconServer } from './_iconos.js'

/** Qué pasó con lo que se estaba guardando cuando ocurrió el fallo. */
export type Error500DataState = 'unknown' | 'saved' | 'not-saved'

export interface PropsError500 extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'title'> {
  /** Identificador de la incidencia: seleccionable y copiable, con su nombre delante
   *  («Incidencia AY-7F3C-2291»). Si no se pudo generar, no se inventa: se omite. */
  incidentId?: string
  /** Hora del fallo, para que el soporte pueda cruzarla con los registros. */
  occurredAt?: Date
  /** Qué pasó con lo que se estaba guardando. Se dice siempre: dejarlo en el aire obliga
   *  al usuario a repetir el trabajo por si acaso. */
  dataState?: Error500DataState
  /** Reintentos disponibles antes de ofrecer soporte. Al agotarse, el reintento se retira
   *  —no se deshabilita— y la vía de soporte pasa a ser la acción primaria. */
  retriesLeft?: number
  /** Repite la petición que falló. Si devuelve una promesa, el botón entra en loading.
   *  Sin callback, «Reintentar» recarga la página. */
  onRetry?: () => void
  /** Vía de soporte. Al agotar los reintentos, el identificador viaja en el asunto. */
  supportHref?: string
  /** Página completa o panel que falló dentro de una página que sí se cargó. */
  scope?: ErrorScope
}

const COPY_DATA: Record<Error500DataState, string> = {
  unknown: 'No hemos podido completar la operación. Comprueba el registro antes de repetirla.',
  saved: 'Los cambios se guardaron antes del fallo. No hace falta repetirlos.',
  'not-saved': 'Los cambios no llegaron a guardarse. Tendrás que repetirlos.',
}

/**
 * 500: el fallo es nuestro. Reconoce el fallo sin disculpas en bucle y entrega un
 * identificador con el que pedir ayuda. No muestra trazas ni nombres de servicio.
 */
export const Error500 = forwardRef<HTMLDivElement, PropsError500>(function Error500(
  {
    incidentId,
    occurredAt,
    dataState = 'unknown',
    retriesLeft = 2,
    onRetry,
    supportHref = 'mailto:soporte@aybar.pe',
    scope = 'page',
    children,
    ...resto
  },
  ref,
) {
  const reintento = useAccion(typeof onRetry === 'function' ? onRetry : recargar)
  const agotado = reintento.intentos >= retriesLeft
  const [aviso, setAviso] = useState('')
  const enRegion = scope === 'region'
  const ocurrido = aFecha(occurredAt)

  useEffect(() => {
    if (agotado && reintento.intentos > 0) setAviso('Lo hemos intentado sin éxito. Escríbenos a soporte y lo miramos.')
  }, [agotado, reintento.intentos])

  const hrefSoporte = incidentId ? conParametro(supportHref, 'subject', `Incidencia ${incidentId}`) : supportHref

  return (
    <ErrorPage
      {...resto}
      ref={ref}
      status={500}
      title="Algo ha fallado por nuestra parte"
      description={COPY_DATA[dataState] ?? COPY_DATA.unknown}
      scope={scope}
      illustration={<IconServer />}
      actions={
        <>
          {/* Se retira, no se deshabilita: un botón apagado no explica que ya no va a funcionar. */}
          {!agotado && (
            <BotonAy variante={enRegion ? 'secondary' : 'primary'} cargando={reintento.cargando} onClick={reintento.ejecutar}>
              Reintentar
            </BotonAy>
          )}
          {agotado ? (
            <BotonAy variante={enRegion ? 'secondary' : 'primary'} href={hrefSoporte}>
              Escribir a soporte
            </BotonAy>
          ) : (
            !enRegion && (
              <BotonAy variante="secondary" href="/promociones">
                Volver a mis promociones
              </BotonAy>
            )
          )}
        </>
      }
    >
      {incidentId && <IncidentId value={incidentId} />}
      {ocurrido && (
        <p className="ay-error__meta">
          {incidentId
            ? `Ocurrió a las ${horaDelDia(ocurrido)}.`
            : `Ocurrió a las ${horaDelDia(ocurrido)}. Este fallo no generó identificador de incidencia.`}
        </p>
      )}
      {agotado && (
        <p className="ay-error__meta">
          {incidentId
            ? 'No hemos podido resolverlo reintentando. Escríbenos con este identificador y lo miramos.'
            : 'No hemos podido resolverlo reintentando. Escríbenos y lo miramos.'}
        </p>
      )}
      {children}
      <Anuncio texto={aviso} />
    </ErrorPage>
  )
})

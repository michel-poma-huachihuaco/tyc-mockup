/**
 * Iconos decorativos de las páginas de error, con el trazo del diseño aprobado. Van
 * siempre dentro de `.ay-error__art`, que lleva `aria-hidden`: no aportan nada que no
 * diga el texto. El tamaño es el del lienzo de 24 unidades escalado a 26; no hay
 * unidades CSS aquí, solo atributos de SVG.
 */
import type { ReactNode } from 'react'

function Lienzo({ children }: { children: ReactNode }) {
  return (
    <svg width="26" height="26" viewBox="0 0 24 24" fill="none" aria-hidden="true" focusable="false">
      {children}
    </svg>
  )
}

/** 400: la petición no se pudo leer. */
export const IconSlash = () => (
  <Lienzo>
    <circle cx="12" cy="12" r="8.5" stroke="currentColor" strokeWidth="1.5" />
    <path d="m6.5 6.5 11 11" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
  </Lienzo>
)

/** 401: falta identificarse. */
export const IconKey = () => (
  <Lienzo>
    <circle cx="8.5" cy="8.5" r="4.25" stroke="currentColor" strokeWidth="1.5" />
    <path d="m11.6 11.6 7.4 7.4m-2.6-2.6 2-2m-4.2.2 1.6 1.6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
  </Lienzo>
)

/** 403: falta permiso. */
export const IconLock = () => (
  <Lienzo>
    <rect x="4.75" y="10.75" width="14.5" height="9.5" rx="2" stroke="currentColor" strokeWidth="1.5" />
    <path d="M8.25 10.5V7.75a3.75 3.75 0 0 1 7.5 0v2.75" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
  </Lienzo>
)

/** 404: aquí no hay nada. */
export const IconCompass = () => (
  <Lienzo>
    <circle cx="12" cy="12" r="8.5" stroke="currentColor" strokeWidth="1.5" />
    <path d="m14.8 9.2-1.7 4.1-4.1 1.7 1.7-4.1 4.1-1.7Z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
  </Lienzo>
)

/** 500: el fallo es nuestro. */
export const IconServer = () => (
  <Lienzo>
    <rect x="3.75" y="4.75" width="16.5" height="6" rx="1.5" stroke="currentColor" strokeWidth="1.5" />
    <rect x="3.75" y="13.25" width="16.5" height="6" rx="1.5" stroke="currentColor" strokeWidth="1.5" />
    <path d="M7 7.75h.01M7 16.25h.01" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
  </Lienzo>
)

/** 503: parada planificada. */
export const IconWrench = () => (
  <Lienzo>
    <path
      d="M15.4 4.9a4.75 4.75 0 0 0-6.1 6.1l-5 5a1.75 1.75 0 1 0 2.5 2.5l5-5a4.75 4.75 0 0 0 6.1-6.1l-2.7 2.7-2.5-.4-.4-2.5 2.7-2.7Z"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinejoin="round"
    />
  </Lienzo>
)

/** 509: límite alcanzado. */
export const IconGauge = () => (
  <Lienzo>
    <path d="M4 16.5a8.5 8.5 0 1 1 16 0" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    <path d="m12 16 4.2-4.6" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
    <circle cx="12" cy="16.5" r="1.3" fill="currentColor" />
  </Lienzo>
)

/** Offline: conexión cortada. */
export const IconPlug = () => (
  <Lienzo>
    <path
      d="M3 12a9 9 0 0 1 3.2-6.9M21 12a9 9 0 0 0-3.2-6.9M7.5 12a4.5 4.5 0 0 1 1.7-3.5m5.6 0a4.5 4.5 0 0 1 1.7 3.5"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
    />
    <path d="m4 4 16 16" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
    <circle cx="12" cy="16" r="1.4" fill="currentColor" />
  </Lienzo>
)

/**
 * Indicador de reconexión: el marcado canónico del Spinner de Feedback. Es decorativo;
 * el estado lo dicen el título y la región polite, no el giro.
 */
export const IconReconectando = () => (
  <svg className="ay-spinner ay-spinner--sm" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
    <circle className="ay-spinner__track" cx="12" cy="12" r="9" />
    <circle className="ay-spinner__arc" cx="12" cy="12" r="9" />
  </svg>
)

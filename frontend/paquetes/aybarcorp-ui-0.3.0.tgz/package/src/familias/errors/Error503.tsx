import { forwardRef, useEffect, useRef, useState } from 'react'
import type { HTMLAttributes } from 'react'
import { ErrorPage } from './ErrorPage.js'
import type { ErrorScope } from './ErrorPage.js'
import {
  Anuncio,
  BotonAy,
  aFecha,
  horaAbsoluta,
  mmss,
  recargar,
  relativo,
  useAccion,
  useCuentaAtras,
} from './_internos.js'
import { IconWrench } from './_iconos.js'

/** Por qué está parado el servicio. */
export type Error503Reason = 'maintenance' | 'deploy' | 'dependency'

export interface PropsError503 extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'title'> {
  /** Hora estimada de vuelta. Se escribe absoluta y relativa —«a las 15:00, dentro de unos
   *  20 minutos»—. Sin ella se dice que no se puede estimar, en vez de inventar una hora. */
  until?: Date
  /** Muestra la cuenta atrás hasta la vuelta. La cifra va con `aria-live="off"` y no se
   *  anuncia nunca; una región polite aparte avisa solo al cruzar cada minuto. */
  countdown?: boolean
  /** Ajusta la explicación: mantenimiento planificado, despliegue o un servicio del que
   *  dependemos. Siempre en términos de producto, no de infraestructura. */
  reason?: Error503Reason
  /** Página de estado del servicio, como acción secundaria. */
  statusHref?: string
  /** Reintenta cuando la ventana ha pasado. El reintento aparece entonces —no se queda
   *  deshabilitado durante la espera—. Sin callback, recarga la página. */
  onRetry?: () => void
  /** Página completa o panel de un servicio secundario en mantenimiento. */
  scope?: ErrorScope
}

const COPY_503: Record<Error503Reason, string> = {
  maintenance: 'Estamos haciendo un mantenimiento planificado. Tu sesión seguirá activa al volver.',
  deploy: 'Estamos publicando una versión nueva; suele llevar pocos minutos. Tu sesión seguirá activa al volver.',
  dependency:
    'Un servicio del que depende esta parte está parado de forma temporal. Tu sesión seguirá activa al volver.',
}

/** «Quedan 19 minutos.» Solo se emite al cruzar el minuto, nunca segundo a segundo. */
const avisoDeMinutos = (minutos: number) =>
  minutos <= 1 ? 'Queda menos de un minuto.' : `Quedan ${minutos} minutos.`

/**
 * 503: la parada es nuestra y está prevista. Da la ventana cuando se conoce para que el
 * usuario decida si espera o vuelve luego. La respuesta HTTP real debe ser 503 con
 * Retry-After; el componente solo lo refleja.
 */
export const Error503 = forwardRef<HTMLDivElement, PropsError503>(function Error503(
  { until, countdown = false, reason = 'maintenance', statusHref, onRetry, scope = 'page', children, ...resto },
  ref,
) {
  const hasta = aFecha(until)
  const restante = useCuentaAtras(hasta)
  const vencida = restante !== null && restante <= 0
  const reintento = useAccion(typeof onRetry === 'function' ? onRetry : recargar)
  const [aviso, setAviso] = useState('')
  const minutoPrevio = useRef<number | null>(null)
  const enRegion = scope === 'region'

  // El aviso polite solo al cruzar el minuto: un lector leyendo números cada segundo
  // hace la página inutilizable.
  const minutos = restante !== null && restante > 0 ? Math.ceil(restante / 60_000) : null
  useEffect(() => {
    if (!countdown || minutos === null) return
    if (minutoPrevio.current !== null && minutoPrevio.current !== minutos) setAviso(avisoDeMinutos(minutos))
    minutoPrevio.current = minutos
  }, [countdown, minutos])

  useEffect(() => {
    if (vencida) setAviso('Está tardando más de lo previsto. Ya puedes reintentar.')
  }, [vencida])

  return (
    <ErrorPage
      {...resto}
      ref={ref}
      status={503}
      title="Estamos en mantenimiento"
      description={COPY_503[reason] ?? COPY_503.maintenance}
      scope={scope}
      illustration={<IconWrench />}
      actions={
        <>
          {/* Aparece al vencer la ventana; deshabilitado veinte minutos no comunica nada. */}
          {vencida && (
            <BotonAy variante={enRegion ? 'secondary' : 'primary'} cargando={reintento.cargando} onClick={reintento.ejecutar}>
              Reintentar
            </BotonAy>
          )}
          {/* Sin ventana, la página de estado es la única salida y pasa a primaria. */}
          {statusHref && (
            <BotonAy variante={!hasta && !enRegion ? 'primary' : 'secondary'} href={statusHref}>
              Ver el estado del servicio
            </BotonAy>
          )}
        </>
      }
    >
      {hasta && !vencida && restante !== null && (
        <div className="ay-error__window">
          <p>
            Volvemos <strong>a las {horaAbsoluta(hasta)}</strong>, {relativo(restante)}.
          </p>
          {countdown && (
            <p className="ay-error__countdown" aria-live="off" suppressHydrationWarning>
              {mmss(restante)}
            </p>
          )}
        </div>
      )}
      {hasta && vencida && (
        <p className="ay-error__meta">Está tardando más de lo previsto. Puedes reintentar ahora.</p>
      )}
      {!hasta && (
        <p className="ay-error__meta">
          {statusHref
            ? 'Aún no podemos estimar cuándo volveremos. Puedes seguir el avance en la página de estado.'
            : 'Aún no podemos estimar cuándo volveremos.'}
        </p>
      )}
      {children}
      <Anuncio texto={aviso} />
    </ErrorPage>
  )
})

import { forwardRef, useEffect, useId, useMemo, useRef, useState } from 'react'
import type { HTMLAttributes, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import {
  AvisoPolite,
  BotonAy,
  CORREO_SOPORTE,
  COPIA,
  ContextoErrorPage,
  IncidentId,
  MAX_REINTENTOS,
  RETARDO_AVISO_MS,
  conParametro,
  esNavegacionDeCliente,
  recargar,
  useAccion,
  useEsperaSegundos,
} from './_internos.js'

/** Caso de la página de error: fija el título, la explicación y el tono del borde. */
export type ErrorStatus = 400 | 401 | 403 | 404 | 500 | 503 | 509 | 'offline'

/** Página completa o panel que falló dentro de una página que funciona. */
export type ErrorScope = 'page' | 'region'

export interface PropsErrorPage extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'title'> {
  /** Caso que ha fallado. Fija el título y la explicación por omisión, el código que se
   *  muestra como metadato («Error 404») y el tono del borde en región. `offline` no
   *  muestra código: no hay respuesta del servidor que citar. */
  status: ErrorStatus
  /** Sobrescribe el título por omisión del caso. Dice el hecho desde el punto de vista
   *  del usuario —«Esta página ya no existe»—, nunca el número. */
  title?: string
  /** Sobrescribe la explicación: la causa probable y la salida, en dos frases como mucho. */
  description?: string
  /** `page` ocupa el área de contenido: el título es h1, recibe el foco en una navegación
   *  de cliente y cambia el title del documento. `region` es un panel que falló dentro de
   *  una página que funciona: h2, no roba el foco ni toca el title, y se anuncia en una
   *  región polite. */
  scope?: ErrorScope
  /** Acciones de salida, máximo dos; la primera es la más probable. Que sean enlaces
   *  reales cuando navegan: la página de error tiene que funcionar sin JavaScript. */
  actions?: ReactNode
  /** Identificador de la incidencia. Se muestra como texto seleccionable —se dicta por
   *  teléfono— y con un botón de copiar que confirma en una región polite. */
  incidentId?: string
  /** Segundos hasta poder reintentar. Mientras corren, el botón sigue visible y enfocable
   *  pero inerte, y su rótulo rota («Reintentar en 12 s») para explicar la espera. */
  retryAfter?: number
  /** Repite la petición que falló. Añade «Reintentar» como acción primaria; si devuelve
   *  una promesa, el botón entra en loading mientras dura. A partir del segundo intento
   *  fallido se retira y se ofrece la vía de soporte con la incidencia en el asunto. */
  onRetry?: () => void
  /** Icono decorativo. Solo se pinta en `page`, siempre con `aria-hidden`: no puede
   *  llevar información que no esté ya en el texto. */
  illustration?: ReactNode
  /** Título del documento en `page`. Por omisión, «<título> · Aybar». Se restaura al
   *  desmontar. */
  documentTitle?: string
}

/**
 * Página de error: el primitivo del que heredan 400, 401, 403, 404, 500, 503, 509 y
 * Offline. El código es metadato y el título dice el hecho; nunca termina sin salida.
 * Escape no hace nada aquí: no es un overlay, y capturarlo competiría con el del modal
 * o el menú que la contenga.
 */
export const ErrorPage = forwardRef<HTMLDivElement, PropsErrorPage>(function ErrorPage(
  {
    status,
    title,
    description,
    scope = 'page',
    actions,
    incidentId,
    retryAfter,
    onRetry,
    illustration,
    documentTitle,
    children,
    ...resto
  },
  ref,
) {
  const base = COPIA[status] ?? COPIA[500]
  const titulo = title ?? base.titulo
  const descripcion = description ?? base.descripcion
  const refTitulo = useRef<HTMLHeadingElement>(null)
  const idDescripcion = useId()
  const [aviso, setAviso] = useState('')
  const contexto = useMemo(() => ({ idDescripcion, scope, anunciar: setAviso }), [idDescripcion, scope])

  const conReintento = typeof onRetry === 'function' || (typeof retryAfter === 'number' && retryAfter > 0)
  const reintento = useAccion(typeof onRetry === 'function' ? onRetry : recargar)
  const espera = useEsperaSegundos(retryAfter)
  const agotado = conReintento && reintento.intentos >= MAX_REINTENTOS

  // Página completa: el usuario esperaba otra cosa y hay que reorientarle. Solo en una
  // navegación de cliente; en la carga del documento el foco ya está al inicio.
  useEffect(() => {
    if (scope === 'page' && esNavegacionDeCliente()) refTitulo.current?.focus()
  }, [scope])

  // El title refleja el error para que el historial y las pestañas no prometan un
  // contenido que no está. Se restaura al salir.
  useEffect(() => {
    if (scope !== 'page') return
    const previo = document.title
    document.title = documentTitle ?? `${titulo} · Aybar`
    return () => {
      document.title = previo
    }
  }, [scope, titulo, documentTitle])

  // Región: el foco no se mueve, así que el fallo se anuncia en el párrafo polite que ya
  // estaba vacío en el DOM.
  useEffect(() => {
    if (scope !== 'region') return
    const reloj = window.setTimeout(() => setAviso(titulo), RETARDO_AVISO_MS)
    return () => window.clearTimeout(reloj)
  }, [scope, titulo])

  useEffect(() => {
    if (agotado) setAviso('Lo hemos intentado dos veces sin éxito. Escríbenos a soporte y lo miramos.')
  }, [agotado])

  const variantePrincipal = scope === 'page' ? 'primary' : 'secondary'
  const hrefSoporte = incidentId
    ? conParametro(`mailto:${CORREO_SOPORTE}`, 'subject', `Incidencia ${incidentId}`)
    : `mailto:${CORREO_SOPORTE}`
  const Titulo = scope === 'page' ? 'h1' : 'h2'
  const hayAcciones = Boolean(actions) || conReintento

  return (
    <ContextoErrorPage.Provider value={contexto}>
      <div {...resto} ref={ref} className={cx('ay-error', `ay-error--${scope}`, `ay-error--${status}`)}>
        {scope === 'page' && illustration && (
          <span className="ay-error__art" aria-hidden="true">
            {illustration}
          </span>
        )}
        {typeof status === 'number' && <p className="ay-error__code">{`Error ${status}`}</p>}
        <Titulo className="ay-error__title" ref={refTitulo} tabIndex={-1}>
          {titulo}
        </Titulo>
        <p className="ay-error__desc" id={idDescripcion}>
          {descripcion}
        </p>
        {children}
        {incidentId && <IncidentId value={incidentId} />}
        {agotado && (
          <p className="ay-error__meta">
            Lo hemos intentado dos veces sin éxito. Escríbenos a soporte y lo miramos.
          </p>
        )}
        {hayAcciones && (
          <div className="ay-error__actions">
            {conReintento && !agotado && (
              <BotonAy
                variante={variantePrincipal}
                cargando={reintento.cargando}
                esperando={espera > 0}
                onClick={reintento.ejecutar}
              >
                {espera > 0 ? `Reintentar en ${espera} s` : 'Reintentar'}
              </BotonAy>
            )}
            {agotado && (
              <BotonAy variante={variantePrincipal} href={hrefSoporte}>
                Escribir a soporte
              </BotonAy>
            )}
            {actions}
          </div>
        )}
        <AvisoPolite>{aviso}</AvisoPolite>
      </div>
    </ContextoErrorPage.Provider>
  )
})

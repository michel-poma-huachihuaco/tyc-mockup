import { forwardRef, useContext, useId } from 'react'
import type { HTMLAttributes } from 'react'
import { ErrorPage } from './ErrorPage.js'
import type { ErrorScope } from './ErrorPage.js'
import { BotonAy, ContextoErrorPage } from './_internos.js'
import { IconSlash } from './_iconos.js'

/** Causa probable de la petición mal formada. */
export type Error400Cause = 'broken-link' | 'invalid-filters'

export interface PropsError400 extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'title'> {
  /** Ajusta la explicación y la acción primaria: `broken-link` es un enlace que se cortó
   *  al copiarlo; `invalid-filters`, unos filtros que no se pueden interpretar. */
  cause?: Error400Cause
  /** Parámetros que no se pudieron interpretar. Se nombran como texto, nunca la URL entera:
   *  un enlace de reserva lleva identificadores que no deben quedar a la vista. Con más de
   *  uno van en una lista real; con más de tres se nombran tres y se dice cuántos quedan. */
  invalidParams?: string[]
  /** Destino del listado sin filtros, que es la salida más probable. */
  listHref?: string
  /** Página completa o panel que pidió los datos con parámetros inválidos. */
  scope?: ErrorScope
}

const DESCRIPCION: Record<Error400Cause, string> = {
  'invalid-filters': 'Los filtros del enlace no son válidos. Puede que se haya cortado al copiarlo.',
  'broken-link': 'El enlace está incompleto. Puede que se haya cortado al copiarlo o al compartirlo.',
}

const TITULO = 'No hemos podido leer esta petición'

/**
 * En región, un panel que pidió sus datos con filtros ilegibles: el usuario no siguió
 * ningún enlace, así que se habla de los filtros del panel y no del enlace.
 */
const REGION_FILTROS = {
  titulo: 'No hemos podido aplicar estos filtros',
  descripcion: 'Vuelve a elegirlos en el panel de filtros.',
}

/** Cuántos parámetros se nombran antes de resumir el resto. */
const VISIBLES = 3

/**
 * Los parámetros ilegibles, como texto y no como color. Cada nombre se enlaza con la
 * explicación por `aria-describedby`, para que el lector lo reciba como parte del mensaje
 * y no como un fragmento de código suelto al final.
 */
function ParametrosInvalidos({ parametros }: { parametros: string[] }) {
  const contexto = useContext(ContextoErrorPage)
  const idRotulo = useId()
  const describe = contexto?.idDescripcion
  if (parametros.length === 1) {
    return (
      <p className="ay-error__meta">
        Filtro no reconocido: <code aria-describedby={describe}>{parametros[0]}</code>
      </p>
    )
  }
  const visibles = parametros.slice(0, VISIBLES)
  const quedan = parametros.length - visibles.length
  return (
    <div className="ay-error__meta">
      <span id={idRotulo}>Filtros no reconocidos:</span>
      <ul className="ay-error__params" aria-labelledby={idRotulo}>
        {visibles.map((parametro) => (
          <li key={parametro}>
            <code aria-describedby={describe}>{parametro}</code>
          </li>
        ))}
      </ul>
      {quedan > 0 && <span>{quedan === 1 ? 'y 1 más' : `y ${quedan} más`}</span>}
    </div>
  )
}

/**
 * 400: la petición llegó mal formada. El título no acusa —el usuario casi nunca es quien
 * construyó la URL— y la salida es el listado sin filtros.
 */
export const Error400 = forwardRef<HTMLDivElement, PropsError400>(function Error400(
  { cause = 'broken-link', invalidParams = [], listHref = '/unidades', scope = 'page', children, ...resto },
  ref,
) {
  const enRegion = scope === 'region'
  const filtrosDelPanel = enRegion && cause === 'invalid-filters'
  const acciones = enRegion ? (
    // En región la página funciona: la única salida es rehacer la consulta del panel.
    <BotonAy variante="secondary" href={listHref}>
      {cause === 'invalid-filters' ? 'Limpiar filtros' : 'Ver todas las unidades'}
    </BotonAy>
  ) : (
    <>
      <BotonAy variante="primary" href={listHref}>
        Ver todas las unidades
      </BotonAy>
      <BotonAy variante="secondary" href="/">
        Ir al inicio
      </BotonAy>
    </>
  )

  return (
    <ErrorPage
      {...resto}
      ref={ref}
      status={400}
      title={filtrosDelPanel ? REGION_FILTROS.titulo : TITULO}
      description={filtrosDelPanel ? REGION_FILTROS.descripcion : (DESCRIPCION[cause] ?? DESCRIPCION['broken-link'])}
      scope={scope}
      illustration={<IconSlash />}
      actions={acciones}
    >
      {invalidParams.length > 0 && <ParametrosInvalidos parametros={invalidParams} />}
      {children}
    </ErrorPage>
  )
})

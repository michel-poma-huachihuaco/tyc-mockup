import { forwardRef, useEffect, useRef, useState } from 'react'
import type { HTMLAttributes } from 'react'
import { ErrorPage } from './ErrorPage.js'
import type { ErrorScope } from './ErrorPage.js'
import { Anuncio, BotonAy, aFecha, fechaHora, recargar } from './_internos.js'
import { IconPlug, IconReconectando } from './_iconos.js'

/** Estado de la conexión. */
export type ErrorOfflineState = 'offline' | 'reconnecting'

export interface PropsErrorOffline extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'title'> {
  /** Fecha del último dato conocido que se está mostrando. Va en texto visible —«hoy a las
   *  14:10»—, no con un gris más claro: el matiz no dice «esto es antiguo». */
  cachedAt?: Date
  /** Hay cambios sin enviar guardados en local. Se dice que se enviarán solos al volver la
   *  red, para que el usuario no los copie a otro sitio por miedo a perderlos. */
  pendingDraft?: boolean
  /** `offline` mientras no hay red; `reconnecting` cuando ha vuelto y la petición se está
   *  repitiendo sola. */
  state?: ErrorOfflineState
  /** Repite la petición. El botón manual sigue aunque haya reintento automático: quien usa
   *  lector no ve el indicador girando. Sin callback, recarga la página. */
  onRetry?: () => void
  /** Reintenta solo al recuperar la conexión, espaciando los intentos si la red es
   *  intermitente, y lo anuncia una sola vez en una región polite. */
  autoRetry?: boolean
  /** Página completa o panel que necesita red dentro de una página ya cargada. */
  scope?: ErrorScope
}

/** Espera antes del enésimo reintento automático: 0, 2, 4, 8… hasta 30 segundos. */
const esperaDeReintento = (intento: number) => (intento === 0 ? 0 : Math.min(30_000, 1000 * 2 ** intento))

/**
 * Offline: distingue la red caída del servidor caído y dice qué se conserva mientras no
 * hay conexión. Un servidor que responde mal no es Offline: es 500 o 503.
 */
export const ErrorOffline = forwardRef<HTMLDivElement, PropsErrorOffline>(function ErrorOffline(
  { cachedAt, pendingDraft = false, state = 'offline', onRetry, autoRetry = true, scope = 'page', children, ...resto },
  ref,
) {
  const [aviso, setAviso] = useState('')
  const refReintentar = useRef(onRetry)
  refReintentar.current = onRetry
  const cacheado = aFecha(cachedAt)
  const reconectando = state === 'reconnecting'

  const reintentar = () => {
    const accion = refReintentar.current
    if (typeof accion === 'function') accion()
    else recargar()
  }

  // Se anuncia al volver, no en cada comprobación: repetirlo convierte la página en ruido.
  useEffect(() => {
    if (!autoRetry) return
    let intentos = 0
    let reloj: number | undefined
    const alVolver = () => {
      setAviso('Conexión restablecida')
      window.clearTimeout(reloj)
      reloj = window.setTimeout(() => {
        const accion = refReintentar.current
        if (typeof accion === 'function') accion()
        else recargar()
      }, esperaDeReintento(intentos))
      intentos += 1
    }
    window.addEventListener('online', alVolver)
    return () => {
      window.removeEventListener('online', alVolver)
      window.clearTimeout(reloj)
    }
  }, [autoRetry])

  return (
    <ErrorPage
      {...resto}
      ref={ref}
      status="offline"
      title={reconectando ? 'Volviendo a conectar…' : 'Parece que no hay conexión'}
      description={
        reconectando
          ? 'La conexión ha vuelto. Estamos recuperando los datos.'
          : 'No hemos podido contactar con el servidor. Comprueba tu conexión; reintentaremos solos en cuanto vuelva.'
      }
      scope={scope}
      illustration={reconectando ? <IconReconectando /> : <IconPlug />}
      actions={
        <BotonAy variante={reconectando || scope === 'region' ? 'secondary' : 'primary'} onClick={reintentar}>
          Reintentar
        </BotonAy>
      }
    >
      {cacheado && <p className="ay-error__note">Estás viendo el último dato conocido: {fechaHora(cacheado)}.</p>}
      {pendingDraft && (
        <p className="ay-error__note">Los cambios están guardados y se enviarán al volver la conexión.</p>
      )}
      {children}
      <Anuncio texto={aviso} />
    </ErrorPage>
  )
})

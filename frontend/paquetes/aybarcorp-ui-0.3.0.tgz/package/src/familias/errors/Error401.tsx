import { forwardRef, useState } from 'react'
import type { HTMLAttributes, MouseEvent } from 'react'
import { ErrorPage } from './ErrorPage.js'
import type { ErrorScope } from './ErrorPage.js'
import { BotonAy, conParametro, etiquetaDeDestino } from './_internos.js'
import { IconKey } from './_iconos.js'

/** Por qué falta la sesión. */
export type Error401Cause = 'expired' | 'no-session' | 'expired-invite'

export interface PropsError401 extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'title'> {
  /** Ajusta los textos: `expired` es una sesión que caducó, `no-session` alguien que nunca
   *  se identificó y `expired-invite` un enlace de invitación que ya no vale. No es un 403:
   *  aquí falta identificarse, no permiso. */
  cause?: Error401Cause
  /** Destino al que volver tras identificarse. Viaja en la URL de acceso (`?destino=`) y
   *  no en el historial del cliente, que se pierde si el acceso se abre en otra pestaña.
   *  El servidor lo valida contra rutas propias. */
  returnTo?: string
  /** Hubo cambios sin guardar y se conservaron como borrador. Se dice junto al título y no
   *  en un toast: es la primera pregunta de quien acaba de perder la sesión. */
  draftSaved?: boolean
  /** Destino del acceso. */
  signInHref?: string
  /** Página completa o panel que pidió datos con la sesión ya caducada. */
  scope?: ErrorScope
}

const COPY_401: Record<Error401Cause, { title: string; description: string }> = {
  expired: {
    title: 'Tu sesión ha caducado',
    description:
      'Por seguridad cerramos la sesión tras un rato sin actividad. Vuelve a acceder y seguirás donde estabas.',
  },
  'no-session': {
    title: 'Necesitas acceder para ver esto',
    description: 'Esta zona es del panel de gestión. Accede con tu cuenta de Aybar para continuar.',
  },
  'expired-invite': {
    title: 'Esta invitación ya no es válida',
    description: 'Los enlaces de invitación caducan a los siete días. Pide uno nuevo a quien te invitó.',
  },
}

/** Un clic que abre otra pestaña no deja esta página «redirigiendo». */
const abreEnOtraPestana = (evento: MouseEvent<HTMLElement>) =>
  evento.button !== 0 || evento.metaKey || evento.ctrlKey || evento.shiftKey || evento.altKey

/**
 * 401: lleva al acceso conservando el destino, para que el usuario acabe donde iba y no
 * en el inicio. El foco va al h1 y no al botón: primero se oye qué pasó y luego la salida.
 */
export const Error401 = forwardRef<HTMLDivElement, PropsError401>(function Error401(
  { cause = 'expired', returnTo, draftSaved = false, signInHref = '/acceso', scope = 'page', children, ...resto },
  ref,
) {
  const [redirigiendo, setRedirigiendo] = useState(false)
  const { title, description } = COPY_401[cause] ?? COPY_401.expired
  const href = returnTo ? conParametro(signInHref, 'destino', returnTo) : signInHref
  const etiqueta = returnTo ? etiquetaDeDestino(returnTo) : null
  const rotulo =
    cause === 'expired-invite'
      ? 'Pedir una invitación nueva'
      : etiqueta
        ? `Acceder y volver a ${etiqueta}`
        : 'Acceder'

  return (
    <ErrorPage
      {...resto}
      ref={ref}
      status={401}
      title={title}
      description={description}
      scope={scope}
      illustration={<IconKey />}
      actions={
        <BotonAy
          variante={scope === 'page' ? 'primary' : 'secondary'}
          href={href}
          cargando={redirigiendo}
          onClick={(evento) => {
            if (!abreEnOtraPestana(evento)) setRedirigiendo(true)
          }}
        >
          {rotulo}
        </BotonAy>
      }
    >
      {draftSaved && (
        // Con el nombre del registro cuando se sabe: «Los cambios de la unidad 402…».
        <p className="ay-error__note" role="status">
          {etiqueta
            ? `Los cambios de ${etiqueta} se han conservado como borrador.`
            : 'Los cambios sin guardar se han conservado como borrador.'}
        </p>
      )}
      {children}
    </ErrorPage>
  )
})

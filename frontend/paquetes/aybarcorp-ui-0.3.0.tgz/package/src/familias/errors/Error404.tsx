import { forwardRef, useId } from 'react'
import type { HTMLAttributes, KeyboardEvent } from 'react'
import { ErrorPage } from './ErrorPage.js'
import type { ErrorScope } from './ErrorPage.js'
import { BotonAy } from './_internos.js'
import { IconCompass } from './_iconos.js'

/** Por qué no está lo que se buscaba. */
export type Error404Cause = 'unknown-route' | 'removed-record'

export interface PropsError404 extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'title'> {
  /** Ajusta los textos: `unknown-route` es una URL que no corresponde a ninguna vista;
   *  `removed-record`, un registro que existió y se retiró. Se dice eso, no «no encontrado». */
  cause?: Error404Cause
  /** Nombre de lo que no está, cuando se conoce: «Esta unidad ya no está en el catálogo». */
  resourceName?: string
  /** Muestra el campo de búsqueda como primer control del orden de tabulación: buscar es
   *  la salida más probable de quien llega a un 404. En región se omite. */
  searchable?: boolean
  /** Término con el que se precarga la búsqueda. Se muestra escapado dentro del campo y
   *  nunca se inyecta en el título: una URL de terceros puede traer cualquier cosa. */
  query?: string
  /** Registros parecidos, hasta tres, como enlaces con texto descriptivo —nunca «ver más»—.
   *  Si no hay ninguno fiable, se omite el bloque en vez de rellenarlo al azar. */
  suggestions?: { label: string; href: string }[]
  /** Listado del que venía. Sin él, la salida degrada al inicio en lugar de encadenar un
   *  segundo 404. */
  backHref?: string
  /** Página completa o panel que pidió un registro que ya no está. */
  scope?: ErrorScope
}

/** Cuántas sugerencias se muestran como mucho. */
const MAX_SUGERENCIAS = 3

/**
 * 404: aquí no hay nada. Ofrece las dos salidas que sirven —buscar o volver al listado— y
 * pone «Página no encontrada» en el title del documento. Escape en el campo lo limpia sin
 * salir de la página.
 */
export const Error404 = forwardRef<HTMLDivElement, PropsError404>(function Error404(
  {
    cause = 'unknown-route',
    resourceName,
    searchable = true,
    query,
    suggestions = [],
    backHref,
    scope = 'page',
    children,
    ...resto
  },
  ref,
) {
  const idBuscar = useId()
  const enRegion = scope === 'region'
  const retirado = cause === 'removed-record'
  const title = retirado ? `${resourceName ?? 'Este registro'} ya no está en el catálogo` : 'Esta página no existe'
  const sugerencias = (suggestions ?? []).slice(0, MAX_SUGERENCIAS)

  // En página siempre hay una salida: el listado del que venía o, si no se conoce, el inicio.
  const salida = backHref
    ? { href: backHref, rotulo: backHref === '/' ? 'Ir al inicio' : 'Volver al listado' }
    : enRegion
      ? null
      : { href: '/', rotulo: 'Ir al inicio' }

  const limpiarConEscape = (evento: KeyboardEvent<HTMLInputElement>) => {
    if (evento.key !== 'Escape' || evento.currentTarget.value === '') return
    // Solo si había algo que limpiar: un Escape vacío sigue su camino hasta el overlay
    // o el menú que contenga la página, que es quien sí tiene algo que cerrar.
    evento.preventDefault()
    evento.stopPropagation()
    evento.currentTarget.value = ''
  }

  return (
    <ErrorPage
      {...resto}
      ref={ref}
      status={404}
      title={title}
      description={
        retirado
          ? 'Puede que se haya vendido o que el enlace sea antiguo. Busca por código o vuelve al listado de la promoción.'
          : 'Puede que el enlace esté incompleto o que la vista se haya movido.'
      }
      scope={scope}
      illustration={<IconCompass />}
      documentTitle="Página no encontrada · Aybar"
      actions={
        salida && (
          <BotonAy variante={enRegion ? 'secondary' : 'primary'} href={salida.href}>
            {salida.rotulo}
          </BotonAy>
        )
      }
    >
      {/* En región no hay sitio y la página sí funciona: se omite la búsqueda. */}
      {searchable && !enRegion && (
        <form className="ay-error__search" role="search" action="/buscar" method="get">
          <label className="ay-visually-hidden" htmlFor={idBuscar}>
            Buscar una unidad o promoción
          </label>
          <input
            id={idBuscar}
            type="search"
            name="q"
            defaultValue={query}
            placeholder="Buscar una unidad o promoción…"
            onKeyDown={limpiarConEscape}
          />
          <BotonAy variante="secondary" type="submit">
            Buscar
          </BotonAy>
        </form>
      )}
      {sugerencias.length > 0 && (
        <ul className="ay-error__suggestions">
          {sugerencias.map((sugerencia) => (
            <li key={sugerencia.href}>
              <a href={sugerencia.href}>{sugerencia.label}</a>
            </li>
          ))}
        </ul>
      )}
      {children}
    </ErrorPage>
  )
})

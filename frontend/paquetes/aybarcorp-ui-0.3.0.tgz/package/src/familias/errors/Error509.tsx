import { forwardRef } from 'react'
import type { HTMLAttributes } from 'react'
import { ErrorPage } from './ErrorPage.js'
import type { ErrorScope } from './ErrorPage.js'
import { BotonAy, aFecha, fechaAbsoluta, recargar, useEsperaSegundos } from './_internos.js'
import { IconGauge } from './_iconos.js'

/** Tipo de límite alcanzado. */
export type Error509Limit = 'quota' | 'rate' | 'resource'

export interface PropsError509 extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'title'> {
  /** `quota` es la cuota del periodo agotada; `rate`, una ráfaga de peticiones cortada que
   *  dura segundos; `resource`, un archivo que excede lo que el plan permite descargar. */
  limit?: Error509Limit
  /** Consumo del periodo, en cifras: una barra sin número no dice cuánto queda. */
  used?: number
  /** Límite del plan. */
  allowance?: number
  /** Qué se está contando, en plural: «descargas», «exportaciones». */
  unitLabel?: string
  /** Cuándo vuelve a cero el contador. Se escribe en fecha absoluta —«el 1 de octubre»—;
   *  si no se conoce, se omite en vez de estimarla. */
  renewsAt?: Date
  /** Segundos de espera en límite de tasa. La cifra se actualiza en silencio y el
   *  reintento aparece al terminar, no un botón apagado durante la cuenta. */
  retryAfter?: number
  /** El usuario administra el plan y puede ampliarlo. Si no, se nombra a quien sí, en vez
   *  de ofrecerle una acción que le devolvería un 403. */
  canUpgrade?: boolean
  /** Quién administra el plan. */
  planAdmin?: { name: string; email?: string }
  /** Página completa o panel que consume cuota. */
  scope?: ErrorScope
}

const TITULO_509: Record<Error509Limit, (unidad: string) => string> = {
  quota: (unidad) => `Has alcanzado el límite de ${unidad} del plan`,
  rate: () => 'Demasiadas peticiones seguidas',
  resource: (unidad) => `Este archivo supera el límite de ${unidad} del plan`,
}

// Lo primero es que el servicio no está caído: confundirlo lleva a esperar en vano.
const DESC_509: Record<Error509Limit, (unidad: string) => string> = {
  quota: (unidad) => `lo que se ha agotado es la cuota de ${unidad} de este mes`,
  rate: () => 'hemos cortado una ráfaga de peticiones para proteger la cuenta',
  resource: (unidad) => `lo que se ha superado es el tamaño de ${unidad} que el plan permite por archivo`,
}

const mayuscula = (texto: string) => texto.charAt(0).toUpperCase() + texto.slice(1)

/**
 * 509: un límite alcanzado, no un servicio caído. Dice qué límite es, cuánto se ha
 * consumido y cuándo se renueva. 509 es solo el nombre interno de esta pantalla: la
 * respuesta HTTP real del límite de tasa es 429 con Retry-After.
 */
export const Error509 = forwardRef<HTMLDivElement, PropsError509>(function Error509(
  {
    limit = 'quota',
    used,
    allowance,
    unitLabel = 'descargas',
    renewsAt,
    retryAfter,
    canUpgrade = false,
    planAdmin,
    scope = 'page',
    children,
    ...resto
  },
  ref,
) {
  const espera = useEsperaSegundos(limit === 'rate' ? retryAfter : undefined)
  const renovacion = aFecha(renewsAt)
  const enRegion = scope === 'region'
  const variante = enRegion ? 'secondary' : 'primary'
  const tipo = TITULO_509[limit] ? limit : 'quota'

  const principal =
    tipo === 'rate' ? (
      espera <= 0 && (
        <BotonAy variante={variante} onClick={recargar}>
          Reintentar
        </BotonAy>
      )
    ) : canUpgrade ? (
      <BotonAy variante={variante} href="/cuenta/plan">
        Ampliar el plan
      </BotonAy>
    ) : (
      // Sin permiso para ampliar, ofrecerlo devolvería un 403: se escribe a quien administra.
      planAdmin?.email && (
        <BotonAy variante={variante} href={`mailto:${planAdmin.email}`}>
          Escribir a {planAdmin.name}
        </BotonAy>
      )
    )

  return (
    <ErrorPage
      {...resto}
      ref={ref}
      status={509}
      title={TITULO_509[tipo](unitLabel)}
      description={`El servicio funciona con normalidad: ${DESC_509[tipo](unitLabel)}.`}
      scope={scope}
      illustration={<IconGauge />}
      actions={
        <>
          {principal}
          {!enRegion && (
            <BotonAy variante="secondary" href="/promociones">
              Volver a mis promociones
            </BotonAy>
          )}
        </>
      }
    >
      {tipo !== 'rate' && used != null && allowance != null && (
        <div className="ay-error__usage">
          {/* Cifra, no solo barra: una barra sin número no dice cuánto queda. */}
          <p>
            <strong>{used}</strong> de <strong>{allowance}</strong> {unitLabel} este mes
          </p>
          <progress max={allowance} value={Math.min(used, allowance)} aria-label={`${mayuscula(unitLabel)} consumidas del plan`} />
          {renovacion && <p className="ay-error__meta">El contador vuelve a cero el {fechaAbsoluta(renovacion)}.</p>}
        </div>
      )}
      {tipo !== 'rate' && !canUpgrade && planAdmin && (
        <p className="ay-error__meta">
          Puede ampliarlo <strong>{planAdmin.name}</strong>, que administra el plan.
        </p>
      )}
      {tipo === 'rate' && espera > 0 && (
        <p className="ay-error__meta" aria-live="off">
          Podrás reintentar en {espera} segundos.
        </p>
      )}
      {children}
    </ErrorPage>
  )
})

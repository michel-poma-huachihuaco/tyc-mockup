import { forwardRef, useState } from 'react'
import type { HTMLAttributes } from 'react'
import { ErrorPage } from './ErrorPage.js'
import type { ErrorScope } from './ErrorPage.js'
import { BotonAy, CORREO_SOPORTE, aFecha, conParametro, fechaAbsoluta, useAccion } from './_internos.js'
import { IconLock } from './_iconos.js'

export interface PropsError403 extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'title'> {
  /** Rol necesario, escrito como lo ve el usuario en el panel —«Gestor de promoción»—,
   *  nunca como identificador interno. */
  requiredRole?: string
  /** Nombre del recurso al que no se llega. Va en el título; nada más del recurso se revela,
   *  ni su contenido ni su tamaño. */
  resourceName?: string
  /** Quién puede conceder el acceso. Sin destinatario, un 403 es un muro: si no se conoce,
   *  se ofrece el soporte general en su lugar. */
  grantedBy?: { name: string; email?: string }
  /** Cuándo se pidió el acceso. Si existe, la fecha sustituye al botón de solicitar —no lo
   *  deshabilita, que no explicaría por qué— y no se deja pedir otra vez. */
  requestedAt?: Date
  /** Envía la solicitud. El botón entra en loading mientras dura la promesa y, si termina
   *  bien, se sustituye por la fecha. Sin este callback, «Solicitar acceso» es un enlace de
   *  correo a quien concede, o al soporte general. */
  onRequestAccess?: () => void
  /** Destino al que sí tiene acceso: «Volver a mis promociones». */
  backHref?: string
  /** Página completa o panel protegido dentro de una página que sí puede ver. */
  scope?: ErrorScope
}

/**
 * 403: la sesión es válida y el rol no alcanza. Dice qué permiso falta y, sobre todo,
 * quién puede darlo.
 */
export const Error403 = forwardRef<HTMLDivElement, PropsError403>(function Error403(
  {
    requiredRole,
    resourceName,
    grantedBy,
    requestedAt,
    onRequestAccess,
    backHref = '/promociones',
    scope = 'page',
    children,
    ...resto
  },
  ref,
) {
  const [solicitadoAqui, setSolicitadoAqui] = useState<Date | undefined>(undefined)
  const envio = useAccion(onRequestAccess, (exito) => {
    if (exito) setSolicitadoAqui(new Date())
  })
  const solicitado = aFecha(requestedAt) ?? solicitadoAqui
  const enRegion = scope === 'region'
  const variante = enRegion ? 'secondary' : 'primary'

  // Sin callback, la solicitud es un correo real: funciona sin JavaScript y llega a alguien.
  const destinatario = grantedBy?.email ?? CORREO_SOPORTE
  const hrefSolicitud = conParametro(
    `mailto:${destinatario}`,
    'subject',
    resourceName ? `Solicitud de acceso a ${resourceName}` : 'Solicitud de acceso',
  )

  const solicitar = solicitado ? (
    <p className="ay-error__meta">
      Solicitaste acceso el {fechaAbsoluta(solicitado)}. Te avisaremos cuando se resuelva.
    </p>
  ) : typeof onRequestAccess === 'function' ? (
    <BotonAy variante={variante} cargando={envio.cargando} onClick={envio.ejecutar}>
      Solicitar acceso
    </BotonAy>
  ) : (
    <BotonAy variante={variante} href={hrefSolicitud}>
      Solicitar acceso
    </BotonAy>
  )

  return (
    <ErrorPage
      {...resto}
      ref={ref}
      status={403}
      title={resourceName ? `No tienes permiso para ver ${resourceName}` : 'No tienes permiso para ver esto'}
      description={
        requiredRole
          ? `Hace falta el rol ${requiredRole} para abrir esta zona.`
          : 'Tu cuenta no incluye el permiso necesario para esta zona.'
      }
      scope={scope}
      illustration={<IconLock />}
      actions={
        <>
          {solicitar}
          {/* En región la página sí funciona: no hace falta salir de ella. */}
          {!enRegion && (
            <BotonAy variante="secondary" href={backHref}>
              Volver a mis promociones
            </BotonAy>
          )}
        </>
      }
    >
      <div className="ay-error__grantor">
        {grantedBy ? (
          <>
            <p>
              Puede darte acceso <strong>{grantedBy.name}</strong>, que administra este recurso.
            </p>
            {grantedBy.email && <a href={`mailto:${grantedBy.email}`}>{grantedBy.email}</a>}
          </>
        ) : (
          <p>
            Escribe a <a href={`mailto:${CORREO_SOPORTE}`}>{CORREO_SOPORTE}</a> para pedir el acceso.
          </p>
        )}
      </div>
      {children}
    </ErrorPage>
  )
})

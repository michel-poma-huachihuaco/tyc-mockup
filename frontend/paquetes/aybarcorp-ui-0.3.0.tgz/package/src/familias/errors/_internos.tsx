/**
 * Piezas internas de la familia Errors. No se exportan desde el índice: no son API.
 *
 * Aquí viven el texto por omisión de cada caso, los formatos de fecha en español de
 * Perú, el botón pintado con su marcado canónico (`ay-btn`, de la familia Actions, que
 * esta familia no importa), el identificador de incidencia copiable y los contadores.
 */
import { createContext, useCallback, useContext, useEffect, useId, useRef, useState } from 'react'
import type { MouseEvent, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import type { ErrorScope, ErrorStatus } from './ErrorPage.js'

// ── Texto por omisión ─────────────────────────────────────────────────────────

/** Título y explicación de cada caso cuando quien usa Error Page no los sobrescribe. */
export const COPIA: Record<ErrorStatus, { titulo: string; descripcion: string }> = {
  400: {
    titulo: 'No hemos podido leer esta petición',
    descripcion: 'El enlace está incompleto. Puede que se haya cortado al copiarlo o al compartirlo.',
  },
  401: {
    titulo: 'Tu sesión ha caducado',
    descripcion:
      'Por seguridad cerramos la sesión tras un rato sin actividad. Vuelve a acceder y seguirás donde estabas.',
  },
  403: {
    titulo: 'No tienes permiso para ver esto',
    descripcion: 'Tu cuenta no incluye el permiso necesario para esta zona.',
  },
  404: {
    titulo: 'Esta página no existe',
    descripcion: 'Puede que el enlace esté incompleto o que la vista se haya movido.',
  },
  500: {
    titulo: 'Algo ha fallado por nuestra parte',
    descripcion: 'No hemos podido completar la operación. El equipo ya tiene el aviso.',
  },
  503: {
    titulo: 'Estamos en mantenimiento',
    descripcion: 'Estamos haciendo un mantenimiento planificado. Tu sesión seguirá activa al volver.',
  },
  509: {
    titulo: 'Has alcanzado el límite de descargas del plan',
    descripcion:
      'El servicio funciona con normalidad: lo que se ha agotado es la cuota de descargas de este mes.',
  },
  offline: {
    titulo: 'Parece que no hay conexión',
    descripcion:
      'No hemos podido contactar con el servidor. Comprueba tu conexión; reintentaremos solos en cuanto vuelva.',
  },
}

/** La vía de soporte general: la que se ofrece cuando no hay a quién más pedir ayuda. */
export const CORREO_SOPORTE = 'soporte@aybar.pe'

/** A partir del segundo intento fallido no se ofrece un tercer reintento idéntico. */
export const MAX_REINTENTOS = 2

/** Cuánto dura la confirmación «Copiado» antes de volver al rótulo. */
const DURACION_COPIADO_MS = 1400

/**
 * Margen entre montar la región vacía y meterle el texto. Una live region que llega al
 * DOM con su contenido ya puesto no se anuncia de forma fiable: primero vacía, luego texto.
 */
export const RETARDO_AVISO_MS = 120

// ── Contexto de la página de error ───────────────────────────────────────────

/**
 * Lo que las piezas hijas necesitan de la Error Page que las contiene: el id de la
 * explicación (para enlazar con `aria-describedby`), el alcance y la única región polite
 * de la página, para que cada caso anuncie por ella en vez de sumar otra.
 */
export const ContextoErrorPage = createContext<{
  idDescripcion: string
  scope: ErrorScope
  anunciar: (texto: string) => void
} | null>(null)

/**
 * Anuncia `texto` en la región polite de la Error Page que lo contiene, cada vez que
 * cambia. No pinta nada: el párrafo polite ya estaba vacío en el DOM.
 */
export function Anuncio({ texto }: { texto: string }) {
  const contexto = useContext(ContextoErrorPage)
  const anunciar = contexto?.anunciar
  useEffect(() => {
    if (texto && anunciar) anunciar(texto)
  }, [texto, anunciar])
  return null
}

// ── Fechas (es-PE) ────────────────────────────────────────────────────────────

const LOCALE = 'es-PE'
const FORMATO_HORA = new Intl.DateTimeFormat(LOCALE, { hour: '2-digit', minute: '2-digit', hourCycle: 'h23' })
const FORMATO_DIA_MES = new Intl.DateTimeFormat(LOCALE, { day: 'numeric', month: 'long' })

/**
 * Normaliza una fecha que puede llegar como `Date`, como cadena ISO o como número. El
 * catálogo de ejemplos es JSON y no puede llevar un `Date`; una fecha inválida se trata
 * como ausente en lugar de reventar el formateo con un RangeError.
 */
export function aFecha(valor: unknown): Date | undefined {
  if (valor === undefined || valor === null || valor === '') return undefined
  const fecha = valor instanceof Date ? valor : new Date(valor as string | number)
  return Number.isNaN(fecha.getTime()) ? undefined : fecha
}

/** «15:00». */
export const horaAbsoluta = (fecha: Date): string => FORMATO_HORA.format(fecha)

/** «1 de octubre»: absoluta, porque quien vuelve días después leería mal un relativo. */
export const fechaAbsoluta = (fecha: Date): string => FORMATO_DIA_MES.format(fecha)

/** «14:32 del 15 de septiembre». */
export const horaDelDia = (fecha: Date): string => `${horaAbsoluta(fecha)} del ${fechaAbsoluta(fecha)}`

const mismoDia = (a: Date, b: Date) =>
  a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate()

/** «hoy a las 14:10», «ayer a las 18:02» o «15 de septiembre a las 14:10». */
export function fechaHora(fecha: Date, ahora: Date = new Date()): string {
  const ayer = new Date(ahora)
  ayer.setDate(ahora.getDate() - 1)
  const dia = mismoDia(fecha, ahora) ? 'hoy' : mismoDia(fecha, ayer) ? 'ayer' : `el ${fechaAbsoluta(fecha)}`
  return `${dia} a las ${horaAbsoluta(fecha)}`
}

/** «dentro de unos 20 minutos». Se acompaña siempre de la hora absoluta. */
export function relativo(milisegundos: number): string {
  const minutos = Math.round(milisegundos / 60_000)
  if (minutos < 1) return 'en menos de un minuto'
  if (minutos === 1) return 'dentro de un minuto'
  if (minutos < 60) return `dentro de unos ${minutos} minutos`
  const horas = Math.round(minutos / 60)
  if (horas < 24) return horas === 1 ? 'dentro de una hora' : `dentro de unas ${horas} horas`
  const dias = Math.round(horas / 24)
  return dias === 1 ? 'dentro de un día' : `dentro de ${dias} días`
}

/** «19:41», o «1:05:03» cuando pasa de una hora. */
export function mmss(milisegundos: number): string {
  const total = Math.max(0, Math.ceil(milisegundos / 1000))
  const horas = Math.floor(total / 3600)
  const minutos = Math.floor((total % 3600) / 60)
  const segundos = total % 60
  const dos = (n: number) => String(n).padStart(2, '0')
  return horas > 0 ? `${horas}:${dos(minutos)}:${dos(segundos)}` : `${dos(minutos)}:${dos(segundos)}`
}

// ── URLs ──────────────────────────────────────────────────────────────────────

/** Añade un parámetro respetando la consulta que el destino ya traiga. */
export function conParametro(href: string, clave: string, valor: string): string {
  const separador = href.includes('?') ? '&' : '?'
  return `${href}${separador}${clave}=${encodeURIComponent(valor)}`
}

const COLECCIONES: Record<string, string> = {
  unidades: 'la unidad',
  promociones: 'la promoción',
  reservas: 'la reserva',
  expedientes: 'el expediente',
  contratos: 'el contrato',
  clientes: 'la ficha del cliente',
}

/**
 * Cómo se nombra el destino en la acción de acceso: «/unidades/402» → «la unidad 402».
 * Una ruta que no se sabe nombrar devuelve `null` y la acción dice solo «Acceder»: mejor
 * eso que pintar la ruta cruda, que puede llevar identificadores.
 */
export function etiquetaDeDestino(ruta: string): string | null {
  const limpia = ruta.split(/[?#]/)[0] ?? ''
  const partes = limpia.split('/').filter(Boolean)
  const coleccion = partes[partes.length - 2]
  const id = partes[partes.length - 1]
  if (!coleccion || !id) return null
  const nombre = COLECCIONES[coleccion]
  return nombre ? `${nombre} ${decodeURIComponent(id)}` : null
}

// ── Navegador ─────────────────────────────────────────────────────────────────

/**
 * En una navegación de cliente el foco pasa al h1; en una carga completa del documento
 * no se toca, porque un focus() por programa puede cortar el anuncio de carga de página
 * del lector. Mientras el documento no termina de cargar, el render es parte de esa carga.
 */
export const esNavegacionDeCliente = (): boolean =>
  typeof document !== 'undefined' && document.readyState === 'complete'

/** El reintento por omisión cuando quien usa el componente no pasa `onRetry`. */
export function recargar(): void {
  if (typeof window !== 'undefined') window.location.reload()
}

// ── Hooks ─────────────────────────────────────────────────────────────────────

/**
 * Ejecuta una acción que puede devolver una promesa y expone `cargando` mientras dura.
 * `intentos` cuenta las ejecuciones que terminaron con el componente todavía montado:
 * si la petición hubiera ido bien, quien lo usa ya habría retirado la página de error.
 */
export function useAccion(
  accion: (() => unknown) | null | undefined,
  alTerminar?: (exito: boolean) => void,
) {
  const [cargando, setCargando] = useState(false)
  const [intentos, setIntentos] = useState(0)
  const montado = useRef(true)
  const refAlTerminar = useRef(alTerminar)
  refAlTerminar.current = alTerminar
  useEffect(() => {
    montado.current = true
    return () => {
      montado.current = false
    }
  }, [])

  const ejecutar = useCallback(() => {
    const terminar = (exito: boolean) => {
      if (!montado.current) return
      setCargando(false)
      setIntentos((n) => n + 1)
      refAlTerminar.current?.(exito)
    }
    let resultado: unknown
    try {
      resultado = typeof accion === 'function' ? accion() : undefined
    } catch {
      terminar(false)
      return
    }
    if (resultado && typeof (resultado as PromiseLike<unknown>).then === 'function') {
      setCargando(true)
      ;(resultado as PromiseLike<unknown>).then(
        () => terminar(true),
        () => terminar(false),
      )
      return
    }
    terminar(true)
  }, [accion])

  return { cargando, intentos, ejecutar }
}

/** Segundos que quedan de una espera, actualizados cada segundo en silencio. */
export function useEsperaSegundos(segundos: number | null | undefined): number {
  const inicial = typeof segundos === 'number' && segundos > 0 ? Math.ceil(segundos) : 0
  const [restante, setRestante] = useState(inicial)
  useEffect(() => {
    setRestante(inicial)
    if (inicial <= 0) return
    const fin = Date.now() + inicial * 1000
    const reloj = window.setInterval(() => {
      const quedan = Math.max(0, Math.ceil((fin - Date.now()) / 1000))
      setRestante(quedan)
      if (quedan <= 0) window.clearInterval(reloj)
    }, 1000)
    return () => window.clearInterval(reloj)
  }, [inicial])
  return restante
}

/** Milisegundos que faltan hasta `hasta`; `null` si no hay hora. Se actualiza cada segundo. */
export function useCuentaAtras(hasta: Date | undefined): number | null {
  const objetivo = hasta?.getTime()
  const [ahora, setAhora] = useState(() => Date.now())
  useEffect(() => {
    if (objetivo === undefined) return
    setAhora(Date.now())
    const reloj = window.setInterval(() => {
      const momento = Date.now()
      setAhora(momento)
      if (momento >= objetivo) window.clearInterval(reloj)
    }, 1000)
    return () => window.clearInterval(reloj)
  }, [objetivo])
  return objetivo === undefined ? null : objetivo - ahora
}

// ── Piezas ────────────────────────────────────────────────────────────────────

export type VarianteBotonAy = 'primary' | 'secondary'

type PropsBotonAy = {
  variante: VarianteBotonAy
  /** Con `href` se pinta un enlace real: la página de error funciona sin JavaScript. */
  href?: string
  cargando?: boolean
  /** Visible y enfocable pero inerte: el rótulo ya explica por qué hay que esperar. */
  esperando?: boolean
  type?: 'button' | 'submit'
  onClick?: (evento: MouseEvent<HTMLElement>) => void
  children: ReactNode
}

/**
 * Botón con el marcado canónico de la familia Actions (`ay-btn ay-btn--<variante>
 * ay-btn--md` y la etiqueta en `ay-btn__label`). Se pinta aquí y no se importa porque
 * una familia no depende de otra; la hoja de Actions es la que le da estilo.
 */
export function BotonAy({ variante, href, cargando = false, esperando = false, onClick, type, children }: PropsBotonAy) {
  const clases = cx('ay-btn', `ay-btn--${variante}`, 'ay-btn--md')
  const cuerpo = (
    <>
      {cargando && <span className="ay-btn__spinner" aria-hidden="true" />}
      <span className="ay-btn__label">{children}</span>
    </>
  )
  if (href !== undefined) {
    return (
      <a className={clases} href={href} aria-busy={cargando || undefined} onClick={onClick}>
        {cuerpo}
      </a>
    )
  }
  return (
    <button
      type={type ?? 'button'}
      className={clases}
      // `cargando` implica deshabilitado: un segundo clic repetiría la petición.
      disabled={cargando || undefined}
      aria-busy={cargando || undefined}
      aria-disabled={esperando || undefined}
      onClick={(evento) => {
        if (esperando) {
          evento.preventDefault()
          return
        }
        onClick?.(evento)
      }}
    >
      {cuerpo}
    </button>
  )
}

/** Párrafo polite que ya está vacío en el DOM; el texto se le mete después. */
export function AvisoPolite({ children }: { children?: ReactNode }) {
  return (
    <p className="ay-visually-hidden" role="status" aria-live="polite">
      {children}
    </p>
  )
}

/**
 * Identificador de incidencia: texto seleccionable además de copiable, porque mucha
 * gente lo dicta por teléfono o lo apunta a mano. La confirmación se anuncia en una
 * región polite y vuelve sola a su rótulo. Sin permiso de portapapeles, el botón avisa
 * de que hay que copiarlo a mano y deja el texto seleccionado.
 */
export function IncidentId({ value }: { value: string }) {
  const idCodigo = useId()
  const refCodigo = useRef<HTMLElement>(null)
  const [estado, setEstado] = useState<'inicial' | 'copiado' | 'manual'>('inicial')
  const reloj = useRef<number | undefined>(undefined)
  useEffect(() => () => window.clearTimeout(reloj.current), [])

  const volverLuego = () => {
    window.clearTimeout(reloj.current)
    reloj.current = window.setTimeout(() => setEstado('inicial'), DURACION_COPIADO_MS)
  }

  const seleccionar = () => {
    const nodo = refCodigo.current
    const seleccion = typeof window !== 'undefined' ? window.getSelection() : null
    if (!nodo || !seleccion) return
    const rango = document.createRange()
    rango.selectNodeContents(nodo)
    seleccion.removeAllRanges()
    seleccion.addRange(rango)
  }

  const copiar = async () => {
    try {
      if (!navigator.clipboard?.writeText) throw new Error('sin portapapeles')
      await navigator.clipboard.writeText(value)
      setEstado('copiado')
    } catch {
      seleccionar()
      setEstado('manual')
    }
    volverLuego()
  }

  const rotulo = estado === 'copiado' ? 'Copiado' : estado === 'manual' ? 'Cópialo a mano' : 'Copiar'
  const aviso =
    estado === 'copiado'
      ? `Incidencia ${value} copiada`
      : estado === 'manual'
        ? `No se pudo copiar. La incidencia ${value} está seleccionada para copiarla a mano.`
        : ''

  return (
    <p className="ay-error__incident">
      <span className="ay-error__incident-label">Incidencia</span>
      <code id={idCodigo} ref={refCodigo}>
        {value}
      </code>
      <button type="button" className="ay-error__copy" aria-describedby={idCodigo} onClick={() => void copiar()}>
        {rotulo}
      </button>
      <span className="ay-visually-hidden" role="status" aria-live="polite">
        {aviso}
      </span>
    </p>
  )
}

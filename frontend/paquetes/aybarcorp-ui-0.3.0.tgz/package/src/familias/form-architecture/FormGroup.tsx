import { forwardRef, useId } from 'react'
import type { FieldsetHTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import { ErrorMessage } from './ErrorMessage.js'
import { HelperText } from './HelperText.js'
import { unirIds } from './_internos.js'

export type VarianteFormGroup = 'simple' | 'card'

export interface PropsFormGroup
  extends Omit<FieldsetHTMLAttributes<HTMLFieldSetElement>, 'className' | 'disabled'> {
  /** Nombre del grupo; obligatorio. Va en un `<legend>`, la única forma nativa de nombrar
   *  un conjunto: sin ella el lector anuncia «Sí» y «No» sin decir a qué pregunta
   *  pertenecen. Nombra el concepto —«Datos del comprador»—, no se repite en cada
   *  etiqueta interna. */
  legend: string
  /** Aclaración del conjunto: por qué se piden esos datos, o por qué el grupo está
   *  deshabilitado. Se enlaza al `<fieldset>` con `aria-describedby`, para que la oiga
   *  también quien salta de control en control. */
  description?: string
  /** Error del conjunto, bajo el grupo y no bajo una opción: se anuncia una vez, no
   *  seis veces en un grupo de seis radios. */
  error?: string
  /** Presentación. `simple` no lleva borde, solo la legend y el espaciado; `card` monta
   *  el grupo sobre una superficie con borde, para formularios largos por secciones. */
  variant?: VarianteFormGroup
  /** Desactiva de golpe todos los controles del grupo con el `disabled` nativo del
   *  `<fieldset>`, para que ninguno se quede activo por olvido. */
  disabled?: boolean
}

/**
 * Agrupa controles relacionados bajo un nombre común —grupos de Radio o Checkbox, o
 * bloques como «Dirección del inmueble»—, para que el conjunto se anuncie como unidad.
 * No se anida dentro de otro Form Group: con dos niveles el lector recita las dos
 * legends antes de cada control. Un grupo de un solo control sobra: se deja el Form
 * Field suelto.
 */
export const FormGroup = forwardRef<HTMLFieldSetElement, PropsFormGroup>(function FormGroup(
  {
    legend,
    description,
    error,
    variant = 'simple',
    disabled = false,
    children,
    'aria-describedby': describedbyPropio,
    ...resto
  },
  ref,
) {
  const id = useId()
  const idDescripcion = `${id}-desc`
  const idError = `${id}-error`
  const hayError = Boolean(error)
  return (
    <fieldset
      {...resto}
      ref={ref}
      className={cx('ay-group', `ay-group--${variant}`)}
      disabled={disabled || undefined}
      aria-describedby={unirIds(description && idDescripcion, hayError && idError, describedbyPropio)}
    >
      <legend className="ay-legend">{legend}</legend>
      {description && <HelperText id={idDescripcion}>{description}</HelperText>}
      {children}
      {/* La región del error existe siempre, vacía mientras no haya error: una región
          viva insertada con el texto ya puesto no se anuncia de forma fiable. */}
      <ErrorMessage id={idError}>{hayError ? error : null}</ErrorMessage>
    </fieldset>
  )
})

import { forwardRef } from 'react'
import type { LabelHTMLAttributes } from 'react'
import { cx } from '../../utiles.js'

export interface PropsLabel extends Omit<LabelHTMLAttributes<HTMLLabelElement>, 'className' | 'htmlFor'> {
  /** Id del control asociado; obligatorio. La asociación va siempre por `for`/`id`:
   *  envolver el control dentro del `<label>` también funciona, pero en cuanto hay dos
   *  controles dentro el navegador asocia la etiqueta al primero y el segundo se queda
   *  sin nombre. */
  htmlFor: string
  /** Añade la marca «(obligatorio)» en texto, en peso regular junto al nombre del dato.
   *  Es texto y no un asterisco de color: el asterisco no tiene nombre accesible y quien
   *  no distingue el tono no ve diferencia entre un campo opcional y uno que bloquea. */
  required?: boolean
  /** Añade la marca «(opcional)», para formularios donde casi todo es obligatorio. Si
   *  llegan las dos marcas, gana la de obligatorio: un campo no puede ser ambas cosas. */
  optional?: boolean
  /** Oculta la etiqueta a la vista conservando el nombre accesible. Usa `clip-path`, no
   *  `display: none` ni `visibility: hidden`, que borrarían el nombre. Es una excepción
   *  que se documenta caso a caso, como la búsqueda con icono. */
  visuallyHidden?: boolean
}

/**
 * Nombra un control de formulario de forma visible y programática: el texto de la
 * etiqueta es el nombre accesible, así que cambiarlo cambia lo que anuncia el lector.
 * No es tabulable; un clic en ella mueve el foco al control asociado.
 */
export const Label = forwardRef<HTMLLabelElement, PropsLabel>(function Label(
  { htmlFor, required = false, optional = false, visuallyHidden = false, children, ...resto },
  ref,
) {
  return (
    <label
      {...resto}
      ref={ref}
      htmlFor={htmlFor}
      className={cx('ay-label', visuallyHidden && 'ay-label--hidden')}
    >
      {children}
      {/* El espacio separa la marca del nombre también en el nombre accesible: sin él,
          el lector recibe «Correo del comprador(obligatorio)» pegado. */}
      {required && ' '}
      {required && <span className="ay-label__req">(obligatorio)</span>}
      {!required && optional && ' '}
      {!required && optional && <span className="ay-label__opt">(opcional)</span>}
    </label>
  )
})

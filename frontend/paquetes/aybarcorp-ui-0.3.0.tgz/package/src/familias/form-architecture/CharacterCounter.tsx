import { forwardRef, useId } from 'react'
import type { HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import { contarCaracteres } from './_internos.js'

export type ModoCharacterCounter = 'used' | 'remaining'

export interface PropsCharacterCounter
  extends Omit<HTMLAttributes<HTMLParagraphElement>, 'className' | 'id'> {
  /** Texto actual del campo. Se cuenta lo que se ve —grafemas, no unidades de
   *  codificación—: un acento compuesto o un emoji cuentan uno, para que la cifra
   *  coincida con el texto y el aviso de exceso no llegue antes de tiempo. */
  value: string
  /** Límite de caracteres. Si el servidor lo cambia, el contador se recalcula sin
   *  perder el texto. El límite se declara además en la ayuda antes de escribir. */
  maxLength: number
  /** Forma de contar. `used` muestra «120 / 500»; `remaining` muestra «380 restantes»,
   *  que se lee mejor con límites bajos. Pasado el límite, `remaining` dice cuántos
   *  sobran, para que la cifra siga siendo informativa sin depender del color. */
  mode?: ModoCharacterCounter
  /** Fracción del límite desde la que avisa: el color pasa a advertencia y se anuncia una
   *  sola vez la entrada en el último tramo. */
  warnAt?: number
  /** Id que referencia el control con `aria-describedby`, junto a la ayuda. Si no se
   *  pasa, se genera; dentro de Form Field se enlaza solo. */
  id?: string
}

type Estado = 'normal' | 'near' | 'over'

/**
 * Cuánto texto se lleva frente al límite, para que el recorte no llegue por sorpresa.
 * La cifra cambia en cada pulsación pero no se anuncia: el anuncio vive en una región
 * viva aparte que ya está en el DOM y solo cambia de texto al cruzar un umbral —al
 * entrar en el último tramo y al pasarse—, porque oír «quedan 238, quedan 237» en cada
 * tecla haría el campo inservible con lector. Superar el límite bloquea el envío, no la
 * escritura: el contador no corta el texto.
 */
export const CharacterCounter = forwardRef<HTMLParagraphElement, PropsCharacterCounter>(
  function CharacterCounter({ value, maxLength, mode = 'used', warnAt = 0.9, id, ...resto }, ref) {
    const generado = useId()
    const usados = contarCaracteres(value ?? '')
    const limite = Math.max(0, maxLength)
    const proporcion = limite > 0 ? usados / limite : usados > 0 ? Number.POSITIVE_INFINITY : 0
    const estado: Estado = usados > limite ? 'over' : proporcion >= warnAt ? 'near' : 'normal'

    const texto =
      mode === 'remaining'
        ? estado === 'over'
          ? `${usados - limite} de más`
          : `${limite - usados} restantes`
        : `${usados} / ${limite}`

    // Texto por estado, no por cifra: mientras no se cruce un umbral no cambia, y una
    // región viva que no cambia no se vuelve a anunciar.
    const anuncio =
      estado === 'over'
        ? `Se superó el límite de ${limite} caracteres`
        : estado === 'near'
          ? `Cerca del límite de ${limite} caracteres`
          : ''

    return (
      <p
        {...resto}
        ref={ref}
        id={id ?? generado}
        className={cx('ay-counter', estado === 'near' && 'is-near', estado === 'over' && 'is-over')}
      >
        {texto}
        {/* Separa la cifra del aviso en la descripción que oye quien enfoca el campo. */}
        {anuncio && ' '}
        <span className="ay-counter__aviso" aria-live="polite">
          {anuncio}
        </span>
      </p>
    )
  },
)

import { forwardRef, useEffect, useMemo, useRef, useState } from 'react'
import type { FormEvent, FormHTMLAttributes, KeyboardEvent, MouseEvent } from 'react'
import { leerValores, unirRefs } from './_internos.js'

/** Los valores del formulario tal como los enviaría el navegador, por `name`. Un `name`
 *  repetido —un grupo de checkboxes— llega como arreglo. */
export type ValoresForm = Record<string, FormDataEntryValue | FormDataEntryValue[]>

export interface PropsForm extends Omit<FormHTMLAttributes<HTMLFormElement>, 'className' | 'onSubmit'> {
  /** Envío; recibe los valores del formulario por `name`. El envío nativo ya está
   *  cancelado: no recarga la página. Si devuelve una promesa, el formulario queda en
   *  estado de envío hasta que se resuelva. La validación es de quien llama: en blur por
   *  campo y, al enviar, `errors` con lo que falte. */
  onSubmit: (values: ValoresForm) => Promise<void> | void
  /** Estado de envío en curso. Marca `aria-busy` y deja los controles inertes —con el
   *  `disabled` nativo de un `<fieldset>`, que no borra sus valores—, así que el botón de
   *  envío no admite una segunda pulsación. Al terminar, el foco vuelve a un elemento
   *  real: el resumen de errores, el primer campo inválido o el que lo tenía. */
  submitting?: boolean
  /** Errores por campo, con el `id` del control como clave y el mensaje como valor.
   *  Alimentan el resumen: cada entrada es un enlace que lleva al campo. */
  errors?: Record<string, string>
  /** Muestra el resumen de errores al principio del formulario, una región con
   *  `role="alert"` y `tabindex="-1"` que recibe el foco tras un envío fallido y empieza
   *  por cuántos errores hay. Sin resumen, el foco va al primer campo inválido. */
  summary?: boolean
  /** Avisa al abandonar la página con cambios sin guardar. Solo si hubo edición real; un
   *  envío correcto o un `reset` lo desarman. Mientras haya cambios, el formulario lleva
   *  `data-sin-guardar`, para que el overlay que lo contenga pida confirmación al cerrar
   *  con Escape. */
  dirtyGuard?: boolean
}

/**
 * Organiza un conjunto de campos hasta su envío: estructura, orden de lectura, resumen
 * de errores y estados de la operación. Es un `<form>` real: Enter envía desde cualquier
 * campo de una línea —lo da el navegador— y Ctrl/Cmd+Enter envía desde un Textarea. No
 * valida por sí mismo ni deshabilita el botón mientras hay errores, que impediría
 * descubrir qué falta. El pie de acciones va en un `<div className="ay-form__actions">`:
 * a la derecha en escritorio y apilado a ancho completo, con la primaria arriba, en móvil.
 */
export const Form = forwardRef<HTMLFormElement, PropsForm>(function Form(
  {
    onSubmit,
    submitting = false,
    errors = {},
    summary = true,
    dirtyGuard = false,
    children,
    onInput,
    onReset,
    onKeyDown,
    ...resto
  },
  ref,
) {
  const formulario = useRef<HTMLFormElement | null>(null)
  const refs = useMemo(() => unirRefs(formulario, ref), [ref])
  const resumen = useRef<HTMLDivElement | null>(null)
  const focoPrevio = useRef<HTMLElement | null>(null)
  const pendiente = useRef(false)
  const [envios, setEnvios] = useState(0)
  const [enviandoPropio, setEnviandoPropio] = useState(false)
  const [conCambios, setConCambios] = useState(false)

  const enviando = submitting || enviandoPropio
  const lista = Object.entries(errors)
  const hayErrores = lista.length > 0

  // Tras un envío, cuando ya no está en curso: el foco va a un sitio real. Al resumen si
  // hay errores —o al primer campo inválido si no hay resumen—; si no, de vuelta al
  // elemento que lo tenía, que el `disabled` del envío había mandado al <body>.
  useEffect(() => {
    if (!pendiente.current || enviando) return
    pendiente.current = false
    const raiz = formulario.current
    if (hayErrores) {
      if (summary && resumen.current) {
        resumen.current.focus()
        return
      }
      const primero =
        lista
          .map(([idCampo]) => raiz?.ownerDocument.getElementById(idCampo))
          .find((elemento): elemento is HTMLElement => Boolean(elemento)) ??
        raiz?.querySelector<HTMLElement>('[aria-invalid="true"]')
      primero?.focus()
      return
    }
    setConCambios(false)
    const actual = raiz?.ownerDocument.activeElement
    const perdido = !actual || actual === raiz?.ownerDocument.body
    if (perdido && focoPrevio.current?.isConnected) focoPrevio.current.focus()
    // Sin `lista` en las dependencias: se deriva de `errors`, que puede llegar como objeto
    // nuevo en cada render, y `pendiente` ya impide que el foco se mueva dos veces.
  }, [envios, enviando, hayErrores, summary])

  useEffect(() => {
    if (!dirtyGuard || !conCambios) return
    const avisar = (evento: BeforeUnloadEvent) => {
      evento.preventDefault()
      // Navegadores anteriores a la norma solo avisan si `returnValue` no está vacío.
      evento.returnValue = true
    }
    window.addEventListener('beforeunload', avisar)
    return () => window.removeEventListener('beforeunload', avisar)
  }, [dirtyGuard, conCambios])

  const alEnviar = (evento: FormEvent<HTMLFormElement>) => {
    evento.preventDefault()
    if (enviando) return
    const raiz = evento.currentTarget
    const emisor = (evento.nativeEvent as SubmitEvent).submitter ?? null
    const activo = raiz.ownerDocument.activeElement as HTMLElement | null
    focoPrevio.current = activo && raiz.contains(activo) ? activo : emisor
    pendiente.current = true
    setEnvios((n) => n + 1)
    if (typeof onSubmit !== 'function') return
    const resultado = onSubmit(leerValores(raiz, emisor))
    if (resultado && typeof resultado.then === 'function') {
      setEnviandoPropio(true)
      // Si la promesa se rechaza, el rechazo sigue su curso: esconderlo aquí dejaría un
      // fallo de red sin rastro. El formulario solo sale del estado de envío.
      void resultado.finally(() => setEnviandoPropio(false))
    }
  }

  const alPulsar = (evento: KeyboardEvent<HTMLFormElement>) => {
    onKeyDown?.(evento)
    if (evento.defaultPrevented) return
    const objetivo = evento.target as HTMLElement
    if (evento.key === 'Enter' && (evento.ctrlKey || evento.metaKey) && objetivo.tagName === 'TEXTAREA') {
      evento.preventDefault()
      evento.currentTarget.requestSubmit()
    }
  }

  const saltarA = (idCampo: string) => (evento: MouseEvent<HTMLAnchorElement>) => {
    const destino = evento.currentTarget.ownerDocument.getElementById(idCampo)
    if (!destino) return
    // El ancla sola desplaza pero no siempre enfoca: corregir tiene que ser saltar.
    evento.preventDefault()
    destino.focus()
    destino.scrollIntoView?.({ block: 'center' })
  }

  return (
    <form
      {...resto}
      ref={refs}
      className="ay-form"
      noValidate
      aria-busy={enviando || undefined}
      data-sin-guardar={dirtyGuard && conCambios ? '' : undefined}
      onSubmit={alEnviar}
      onKeyDown={alPulsar}
      onInput={(evento) => {
        onInput?.(evento)
        if (!conCambios) setConCambios(true)
      }}
      onReset={(evento) => {
        onReset?.(evento)
        setConCambios(false)
      }}
    >
      {summary && hayErrores && (
        <div className="ay-form__summary" role="alert" tabIndex={-1} ref={resumen}>
          <p>{`Revisa ${lista.length} ${lista.length === 1 ? 'campo' : 'campos'} antes de continuar.`}</p>
          <ul>
            {lista.map(([idCampo, mensaje]) => (
              <li key={idCampo}>
                <a href={`#${idCampo}`} onClick={saltarA(idCampo)}>
                  {mensaje}
                </a>
              </li>
            ))}
          </ul>
        </div>
      )}
      {/* Inerte durante el envío sin perder valores: el `disabled` de un fieldset alcanza a
          todos los controles de golpe, incluido el botón de envío. `role="none"` y
          `display: contents` lo dejan sin semántica ni caja: no es un grupo con nombre. */}
      <fieldset className="ay-form__cuerpo" role="none" disabled={enviando || undefined}>
        {children}
      </fieldset>
    </form>
  )
})

import { forwardRef, useId } from 'react'
import type { HTMLAttributes } from 'react'
import { IconoAviso, IconoExito, IconoInfo } from './_iconos.js'
import { tieneContenido } from './_internos.js'

export type TonoValidationMessage = 'success' | 'warning' | 'info'

const ICONOS = { success: IconoExito, warning: IconoAviso, info: IconoInfo } as const

export interface PropsValidationMessage
  extends Omit<HTMLAttributes<HTMLParagraphElement>, 'className' | 'id'> {
  /** Tono del mensaje. `success` confirma una comprobación —«DNI verificado con el
   *  padrón»—; `warning` advierte de una consecuencia sin impedir continuar; `info` da un
   *  dato derivado del valor. El tono danger no existe aquí: un error que bloquea es
   *  Error Message. */
  tone?: TonoValidationMessage
  /** Id que referencia el control con `aria-describedby`. Si no se pasa, se genera; dentro
   *  de Form Field se enlaza solo, igual que la ayuda. */
  id?: string
  /** Muestra el icono del tono. Cada tono lleva el suyo para que un aviso no dependa de
   *  que el ámbar y el verde se vean distintos. */
  icon?: boolean
}

/**
 * Resultado de una validación que no es un error: confirmación, advertencia o contexto.
 * No marca `aria-invalid`, porque el valor no es inválido: hacerlo bloquearía el envío
 * por un aviso que solo pretendía informar. Es una región viva `polite`, para no cortar
 * al lector a media frase; cuando el mensaje se retira, la región queda vacía en el DOM
 * en lugar de desaparecer, porque quitar el nodo hace que el siguiente no se anuncie.
 */
export const ValidationMessage = forwardRef<HTMLParagraphElement, PropsValidationMessage>(
  function ValidationMessage({ tone = 'info', id, icon = true, children, ...resto }, ref) {
    const generado = useId()
    const hayMensaje = tieneContenido(children)
    const Icono = ICONOS[tone] ?? IconoInfo
    return (
      <p
        {...resto}
        ref={ref}
        id={id ?? generado}
        className={`ay-validation ay-validation--${tone}`}
        aria-live="polite"
      >
        {hayMensaje && icon && <Icono />}
        {hayMensaje ? children : null}
      </p>
    )
  },
)

/**
 * Iconos de los mensajes de la familia. Siempre `aria-hidden` y sin `focusable`: el texto
 * del mensaje es lo que se anuncia, y el icono solo refuerza el tono para quien ve. El
 * trazo es `currentColor`, así que el color lo pone el token del mensaje, nunca el SVG.
 * El tamaño, 14 unidades, es el de la definición canónica del diseño.
 */
const base = {
  'aria-hidden': true,
  focusable: false,
  width: 14,
  height: 14,
  viewBox: '0 0 24 24',
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 2,
  strokeLinecap: 'round',
  strokeLinejoin: 'round',
} as const

/** Círculo con exclamación: el error de un campo. */
export function IconoError() {
  return (
    <svg {...base}>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7.5v5" />
      <path d="M12 16.25v.01" />
    </svg>
  )
}

/** Círculo con marca: una comprobación que salió bien. */
export function IconoExito() {
  return (
    <svg {...base}>
      <circle cx="12" cy="12" r="9" />
      <path d="m8.25 12.25 2.5 2.5 5-5.25" />
    </svg>
  )
}

/** Triángulo con exclamación: una consecuencia que no bloquea. */
export function IconoAviso() {
  return (
    <svg {...base}>
      <path d="M10.3 4.2 2.9 17.1A2 2 0 0 0 4.6 20h14.8a2 2 0 0 0 1.7-2.9L13.7 4.2a2 2 0 0 0-3.4 0Z" />
      <path d="M12 9.5v4" />
      <path d="M12 16.75v.01" />
    </svg>
  )
}

/** Círculo con «i»: un dato derivado del valor. */
export function IconoInfo() {
  return (
    <svg {...base}>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 11v5" />
      <path d="M12 7.75v.01" />
    </svg>
  )
}

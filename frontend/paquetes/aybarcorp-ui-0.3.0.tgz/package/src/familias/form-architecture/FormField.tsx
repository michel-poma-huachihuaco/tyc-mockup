import { Children, Fragment, cloneElement, forwardRef, isValidElement, useId } from 'react'
import type { HTMLAttributes, ReactElement, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { CharacterCounter } from './CharacterCounter.js'
import { ErrorMessage } from './ErrorMessage.js'
import { HelperText } from './HelperText.js'
import { Label } from './Label.js'
import { ValidationMessage } from './ValidationMessage.js'
import { tieneContenido, unirIds } from './_internos.js'

export type DisposicionFormField = 'vertical' | 'horizontal'

export interface PropsFormField extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'id'> {
  /** Etiqueta visible; obligatoria. Nombra el dato, no la acción de rellenarlo. Un campo
   *  sin etiqueta visible es una excepción que se resuelve con `aria-label` en el
   *  control, nunca dejándolo mudo. */
  label: string
  /** Descripción persistente bajo el control: formato, origen o consecuencia del dato.
   *  Se enlaza por `aria-describedby` y se retira cuando hay error, para no anunciar
   *  seguidas la regla de formato y el fallo. Acepta un enlace a la documentación del
   *  dato además de texto. */
  helper?: ReactNode
  /** Mensaje de validación; su presencia activa el estado inválido: sustituye a la
   *  ayuda, marca `aria-invalid` en el control y se anuncia en una región viva `polite`
   *  que no mueve el foco. Dice qué corregir y cómo. */
  error?: string
  /** Marca «(obligatorio)» en la etiqueta, en texto, y `required` en el control. */
  required?: boolean
  /** Marca «(opcional)», cuando la mayoría de campos del formulario son obligatorios. */
  optional?: boolean
  /** Posición de la etiqueta. `vertical`, encima del control, es la de todo el sistema;
   *  `horizontal` la pone a la izquierda con un ancho fijo en `ch`, solo para
   *  formularios de escritorio muy densos. */
  layout?: DisposicionFormField
  /** Id del control. Se genera si no se pasa —o se toma el que ya traiga el control— y
   *  enlaza la etiqueta y las descripciones: ese cableado hecho a mano se olvida en el
   *  campo once de un formulario de quince y nadie lo nota. */
  id?: string
}

/** Lo que Form Field lee y escribe en el control que envuelve. */
interface PropsControl {
  id?: unknown
  disabled?: unknown
  required?: unknown
  'aria-describedby'?: unknown
  'aria-invalid'?: unknown
}

const esMensaje = (tipo: unknown) => tipo === ValidationMessage || tipo === CharacterCounter

/** El control es el primer elemento hijo que no es un mensaje ni un fragmento. */
function esControl(nodo: ReactNode): nodo is ReactElement<PropsControl> {
  return isValidElement(nodo) && nodo.type !== Fragment && !esMensaje(nodo.type)
}

const texto = (valor: unknown) => (typeof valor === 'string' && valor !== '' ? valor : undefined)

/**
 * Envuelve un control de entrada —Input, Textarea, Select, Combobox, Date Picker, File
 * Upload— con su etiqueta, su ayuda y su error, y resuelve solo el cableado de
 * accesibilidad entre las piezas: el control recibe `id`, `required`, `aria-invalid` y
 * `aria-describedby` (ayuda, mensajes de validación, error y contador, en ese orden, más
 * los que ya trajera). No impone la geometría del control: el tamaño lo fija el hijo.
 *
 * Un Validation Message o un Character Counter puestos como hijos se enlazan igual que la
 * ayuda; con error, el mensaje de validación se vacía —gana el error— y el contador
 * comparte fila (`ay-fieldfoot`) con la ayuda o el error. Para grupos de Radio o
 * Checkbox el contenedor correcto es Form Group, no este.
 */
export const FormField = forwardRef<HTMLDivElement, PropsFormField>(function FormField(
  { label, helper, error, required = false, optional = false, layout = 'vertical', id, children, ...resto },
  ref,
) {
  const generado = useId()
  const hijos = Children.toArray(children)
  const control = hijos.find(esControl)
  const propsControl: PropsControl = control?.props ?? {}

  const idCampo = id ?? texto(propsControl.id) ?? generado
  const idAyuda = `${idCampo}-ayuda`
  const idError = `${idCampo}-error`
  const hayError = typeof error === 'string' ? error !== '' : Boolean(error)
  const muestraAyuda = !hayError && tieneContenido(helper)
  const deshabilitado = Boolean(propsControl.disabled)

  // Primera pasada: los ids de los mensajes, que el control necesita antes de pintarse.
  const idsValidacion: string[] = []
  const idsContador: string[] = []
  const idDeHijo = new Map<ReactElement, string>()
  let validaciones = 0
  for (const hijo of hijos) {
    if (!isValidElement<{ id?: string; children?: ReactNode }>(hijo)) continue
    if (hijo.type === ValidationMessage) {
      validaciones += 1
      const idHijo = hijo.props.id ?? `${idCampo}-validacion${validaciones > 1 ? `-${validaciones}` : ''}`
      idDeHijo.set(hijo, idHijo)
      // Gana el error: el aviso se vacía y deja de describir el campo.
      if (!hayError && tieneContenido(hijo.props.children)) idsValidacion.push(idHijo)
    } else if (hijo.type === CharacterCounter) {
      const idHijo = hijo.props.id ?? `${idCampo}-contador${idsContador.length ? `-${idsContador.length + 1}` : ''}`
      idDeHijo.set(hijo, idHijo)
      idsContador.push(idHijo)
    }
  }

  const describedby = unirIds(
    muestraAyuda && idAyuda,
    ...idsValidacion,
    hayError && idError,
    ...idsContador,
    texto(propsControl['aria-describedby']),
  )

  // Segunda pasada: el control cableado y los mensajes con su id, en el orden del autor.
  // Los contadores van al final, en la fila de la ayuda o el error.
  const cuerpo: ReactNode[] = []
  const contadores: ReactNode[] = []
  for (const hijo of hijos) {
    if (hijo === control && control) {
      cuerpo.push(
        cloneElement(control, {
          id: idCampo,
          // Solo se añade: un `required` propio del control no se pisa con `undefined`.
          required: required || Boolean(propsControl.required) || undefined,
          'aria-invalid': hayError ? true : propsControl['aria-invalid'],
          'aria-describedby': describedby,
        }),
      )
    } else if (isValidElement<{ id?: string; children?: ReactNode }>(hijo) && idDeHijo.has(hijo)) {
      const idHijo = idDeHijo.get(hijo)
      if (hijo.type === CharacterCounter) contadores.push(cloneElement(hijo, { id: idHijo }))
      // Vaciar y no quitar: la región viva sigue en el DOM para el siguiente mensaje.
      else cuerpo.push(cloneElement(hijo, hayError ? { id: idHijo, children: null } : { id: idHijo }))
    } else {
      cuerpo.push(hijo)
    }
  }

  // Error y ayuda ocupan el mismo hueco: nunca se ven a la vez.
  const mensajes = (
    <>
      {/* Siempre en el DOM, vacía sin error: es la región viva donde entra el mensaje. */}
      <ErrorMessage id={idError}>{hayError ? error : null}</ErrorMessage>
      {muestraAyuda && (
        <HelperText id={idAyuda} disabled={deshabilitado}>
          {helper}
        </HelperText>
      )}
    </>
  )

  return (
    <div
      {...resto}
      ref={ref}
      className={cx(
        'ay-field',
        layout === 'horizontal' && 'ay-field--horizontal',
        hayError && 'is-invalid',
        deshabilitado && 'is-disabled',
      )}
    >
      <Label htmlFor={idCampo} required={required} optional={optional}>
        {label}
      </Label>
      {cuerpo}
      {/* Con contador, la ayuda —o el error— y la cifra comparten fila en el pie del
          campo: el mensaje al inicio y el contador al final, y si no caben, la cifra
          pasa debajo. Sin contador, el mensaje va suelto bajo el control. */}
      {contadores.length > 0 ? (
        <div className="ay-fieldfoot">
          {mensajes}
          {contadores}
        </div>
      ) : (
        mensajes
      )}
    </div>
  )
})

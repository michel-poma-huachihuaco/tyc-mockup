/**
 * Utilidades internas de la familia Form Architecture. No son API: el índice de la
 * familia no las exporta.
 */
import { Children } from 'react'
import type { ReactNode, Ref, RefCallback } from 'react'

/**
 * Une ids para `aria-describedby`: descarta los vacíos, separa los que ya traían varios
 * y quita repetidos. Devuelve `undefined` cuando no queda ninguno, para que React no
 * pinte un `aria-describedby=""` que algunos lectores anuncian como descripción vacía.
 */
export function unirIds(...ids: (string | false | null | undefined)[]): string | undefined {
  const vistos: string[] = []
  for (const grupo of ids) {
    if (!grupo) continue
    for (const id of grupo.split(/\s+/)) if (id && !vistos.includes(id)) vistos.push(id)
  }
  return vistos.length ? vistos.join(' ') : undefined
}

/**
 * Si un contenido pinta algo. `null`, `undefined`, booleanos y cadenas vacías no: es lo
 * que decide si una región viva lleva texto o se queda vacía esperando el siguiente.
 */
export function tieneContenido(contenido: ReactNode): boolean {
  return Children.toArray(contenido).some((parte) => parte !== '')
}

/**
 * Cuenta lo que se ve, no las unidades internas de codificación: «á» compuesta, una
 * bandera o un emoji con modificador cuentan uno. `Intl.Segmenter` agrupa por grafemas;
 * sin él se cae a puntos de código, que al menos no parte los pares sustitutos.
 */
const segmentador =
  typeof Intl !== 'undefined' && typeof Intl.Segmenter === 'function'
    ? new Intl.Segmenter(undefined, { granularity: 'grapheme' })
    : null

export function contarCaracteres(texto: string): number {
  if (!segmentador) return Array.from(texto).length
  return Array.from(segmentador.segment(texto)).length
}

/** Una sola ref de callback que alimenta la propia y la que llega por `forwardRef`. */
export function unirRefs<T>(...refs: (Ref<T> | undefined)[]): RefCallback<T> {
  return (valor) => {
    for (const ref of refs) {
      if (typeof ref === 'function') ref(valor)
      else if (ref) (ref as { current: T | null }).current = valor
    }
  }
}

/**
 * Los valores de un formulario tal como los enviaría el navegador, con el botón que lo
 * envió incluido. Un `name` repetido —un grupo de checkboxes— se devuelve como arreglo
 * en lugar de quedarse solo con el último.
 */
export function leerValores(
  formulario: HTMLFormElement,
  emisor: HTMLElement | null,
): Record<string, FormDataEntryValue | FormDataEntryValue[]> {
  // El `FormData` de la ventana del formulario y no el global: dentro de un iframe —o en un
  // entorno con otro DOM— el constructor global no acepta un formulario ajeno.
  const Datos = formulario.ownerDocument.defaultView?.FormData ?? FormData
  let datos: FormData
  try {
    datos = new Datos(formulario, emisor)
  } catch {
    // Un `submitter` que no es botón de envío lanza; los valores siguen siendo válidos.
    datos = new Datos(formulario)
  }
  const valores: Record<string, FormDataEntryValue | FormDataEntryValue[]> = {}
  // `forEach` y no `entries()`: el lib de este paquete es DOM sin DOM.Iterable.
  datos.forEach((valor, nombre) => {
    const previo = valores[nombre]
    if (previo === undefined) valores[nombre] = valor
    else valores[nombre] = Array.isArray(previo) ? [...previo, valor] : [previo, valor]
  })
  return valores
}

import { forwardRef, useId } from 'react'
import type { HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'

export interface PropsHelperText extends Omit<HTMLAttributes<HTMLParagraphElement>, 'className' | 'id'> {
  /** Id que referencia el control con `aria-describedby`. Si no se pasa, se genera: sin
   *  ese enlace el lector no anuncia nunca la ayuda. Dentro de Form Field no hace falta
   *  darlo, porque Form Field lo genera y lo enlaza solo. */
  id?: string
  /** Atenúa la ayuda junto al control deshabilitado. */
  disabled?: boolean
}

/**
 * Explica de forma persistente el formato, el origen o la consecuencia del dato antes de
 * que el usuario se equivoque. No es una región viva: si cambia según lo escrito, se
 * actualiza en silencio, porque reanunciarlo en cada tecla tapa lo que se está
 * escribiendo. No sirve para validar —eso es Error Message— ni como única forma de decir
 * que un campo es obligatorio.
 */
export const HelperText = forwardRef<HTMLParagraphElement, PropsHelperText>(function HelperText(
  { id, disabled = false, children, ...resto },
  ref,
) {
  const generado = useId()
  return (
    <p {...resto} ref={ref} id={id ?? generado} className={cx('ay-help', disabled && 'is-disabled')}>
      {children}
    </p>
  )
})

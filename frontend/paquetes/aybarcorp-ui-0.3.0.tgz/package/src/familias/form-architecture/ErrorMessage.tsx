import { forwardRef, useId } from 'react'
import type { HTMLAttributes } from 'react'
import { IconoError } from './_iconos.js'
import { tieneContenido } from './_internos.js'

export interface PropsErrorMessage extends Omit<HTMLAttributes<HTMLParagraphElement>, 'className' | 'id'> {
  /** Id que referencia el control con `aria-describedby`. Si no se pasa, se genera.
   *  Dentro de Form Field y Form Group no hace falta: lo generan y lo enlazan ellos. */
  id?: string
  /** Muestra el icono de error junto al texto. El color no puede ser la única pista: el
   *  rojo no distingue nada para quien no lo percibe, y el icono y el texto sí. */
  icon?: boolean
}

/**
 * Dice qué ha fallado en un campo y cómo corregirlo, en el momento en que se puede
 * actuar. Es una región viva `polite` que existe aunque no haya error: se monta vacía y
 * se le mete el texto al validar, porque una región insertada con su contenido ya puesto
 * no se anuncia de forma fiable y el primer error, que es el que importa, se perdería.
 * Al corregirse el campo se vacía y no vuelve a anunciar nada. No marca el control: el
 * `aria-invalid` lo pone Form Field, o quien cablee el control a mano.
 */
export const ErrorMessage = forwardRef<HTMLParagraphElement, PropsErrorMessage>(function ErrorMessage(
  { id, icon = true, children, ...resto },
  ref,
) {
  const generado = useId()
  const hayMensaje = tieneContenido(children)
  return (
    <p {...resto} ref={ref} id={id ?? generado} className="ay-error" aria-live="polite">
      {hayMensaje && icon && <IconoError />}
      {hayMensaje ? children : null}
    </p>
  )
})

/**
 * Foundations/Typography. La escala vive en CSS y en rem: con px el texto no crece al
 * cambiar el tamaño de fuente del navegador, que es el ajuste de accesibilidad más usado.
 * En TS se tipan los pasos para que el autocompletado impida un tamaño fuera de la escala.
 *
 * Supuesto declarado: Proxima Nova es licencia de escritorio. Hasta que exista licencia
 * web, los cuerpos se renderizan en Montserrat Regular, el segundo valor de la pila.
 */
import type { CSSProperties } from 'react'

/** Paso de la escala tipográfica, de xs a 5xl. */
export type FontSize = 'xs' | 'sm' | 'base' | 'lg' | 'xl' | '2xl' | '3xl' | '4xl' | '5xl'
/** Peso: regular, medium, semibold o bold, y display para las cifras y los titulares
 *  grandes (800; 700 en el estilo sobrio). El énfasis es semibold, nunca cursiva. */
export type FontWeight = 'regular' | 'medium' | 'semibold' | 'bold' | 'display'
/** Interlineado: al menos 1.5 en cuerpo y 1.7 en párrafos largos. */
export type Leading = 'tight' | 'snug' | 'normal' | 'relaxed'
/** Los cinco estilos publicados: title, subtitle, body, label y mono. */
type TextStyle = 'title' | 'subtitle' | 'body' | 'label' | 'mono'

export const TEXT_STYLES = {
  title: {
    fontFamily: 'var(--aybar-family-heading)',
    fontWeight: 'var(--aybar-font-weight-bold)',
    lineHeight: 'var(--aybar-font-leading-tight)',
    letterSpacing: 'var(--aybar-font-tracking-tight)',
    textWrap: 'pretty',
  },
  subtitle: {
    fontFamily: 'var(--aybar-family-heading)',
    fontWeight: 'var(--aybar-font-weight-regular)',
    lineHeight: 'var(--aybar-font-leading-normal)',
  },
  body: {
    fontFamily: 'var(--aybar-family-sans)',
    fontWeight: 'var(--aybar-font-weight-regular)',
    // Al menos 1.5 en cuerpo; 1.7 en párrafos largos.
    lineHeight: 'var(--aybar-font-leading-relaxed)',
    maxInlineSize: '70ch',
  },
  label: {
    fontFamily: 'var(--aybar-family-heading)',
    fontWeight: 'var(--aybar-font-weight-semibold)',
    // Mayúsculas solo en xs: en bloques se leen más despacio y pierden la forma de la palabra.
    fontSize: 'var(--aybar-font-size-xs)',
    textTransform: 'uppercase',
    letterSpacing: 'var(--aybar-font-tracking-wide)',
  },
  mono: {
    fontFamily: 'var(--aybar-family-mono)',
    fontVariantNumeric: 'tabular-nums',
  },
} as const satisfies Record<TextStyle, CSSProperties>

/** Paso de la escala como `var()`, en rem. */
export const fontSize = (s: FontSize): string => `var(--aybar-font-size-${s})`

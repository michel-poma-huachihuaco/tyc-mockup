import { forwardRef } from 'react'
import type { CSSProperties, HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'

export interface PropsParallaxLayer extends Omit<HTMLAttributes<HTMLDivElement>, 'className'> {
  /** Cuánto se desplaza con el puntero, de -1 a 1, como fracción de depth.parallax-shift. Las
   *  capas positivas siguen al puntero y las negativas van al revés: con el fondo en negativo
   *  y el frente en positivo, la escena se lee en profundidad. `0` no se mueve. */
  depth?: number
  /** Capa de decoración (formas, brillos, una textura): va detrás del contenido, ocupa toda
   *  la escena, no recibe el puntero y sale del árbol de accesibilidad (`aria-hidden`). Sin
   *  ella la capa es contenido, se lee y conserva su sitio en el flujo. Una capa decorativa
   *  no lleva nada que se pueda enfocar. */
  decorative?: boolean
}

const acotar = (n: number): number => (Number.isFinite(n) ? Math.max(-1, Math.min(1, n)) : 0)

/**
 * Una capa de Parallax. Su desplazamiento lo calcula la hoja con la posición del puntero que
 * escribe Parallax y su `depth`; la capa no escucha nada.
 */
export const ParallaxLayer = forwardRef<HTMLDivElement, PropsParallaxLayer>(function ParallaxLayer(
  { depth = 0, decorative = false, style, children, ...resto },
  ref,
) {
  const estilo = { ...style, '--ay-parallax-depth': String(acotar(depth)) } as CSSProperties
  return (
    <div
      {...resto}
      ref={ref}
      className={cx('ay-parallax__layer', decorative && 'ay-parallax__layer--decorative')}
      aria-hidden={decorative || undefined}
      style={estilo}
    >
      {children}
    </div>
  )
})

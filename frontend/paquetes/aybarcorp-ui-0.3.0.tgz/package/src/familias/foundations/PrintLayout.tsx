import { forwardRef, useCallback, useEffect, useRef } from 'react'
import type { HTMLAttributes, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { asignarRef, hayDocumento } from './_internos.js'

/** Tamaño y orientación de la hoja: A4 retrato es el formato por defecto en Perú. */
export type PaginaImpresion = 'a4' | 'a4-landscape' | 'letter'
/** Qué se imprime: un documento con saltos declarados, un listado o una ficha que no se parte. */
export type TipoImpresion = 'document' | 'list' | 'sheet'

/** Lo que no se imprime por omisión: la navegación y todo lo marcado como interfaz. */
const OCULTOS_POR_OMISION: string[] = ['nav', '[data-noprint]']
/** Marca que la hoja de impresión retira (`display: none`) durante la impresión. */
const MARCA_OCULTO = 'data-ay-print-hidden'
const FECHA = new Intl.DateTimeFormat('es-PE', { dateStyle: 'long' })

export interface PropsPrintLayout extends Omit<HTMLAttributes<HTMLElement>, 'className'> {
  /** Tamaño y orientación de la hoja. `a4-landscape` es para listados anchos: una tabla
   *  más ancha que la página se imprime apaisada en lugar de recortar columnas. */
  page?: PaginaImpresion
  /** Tipo de impresión. `document` es un contrato o expediente con saltos declarados;
   *  `list` una tabla larga con la cabecera repetida en cada hoja; `sheet` una sola
   *  unidad en una página, sin partir. */
  kind?: TipoImpresion
  /** Texto de la marca de agua: dice qué es, «Borrador · no válido para firma». Va
   *  detrás del texto y con opacidad baja para no reducirle el contraste. */
  watermark?: string
  /** Cabecera que se repite en cada hoja, con el documento y la referencia: «Contrato de
   *  reserva · unidad 402». En un listado filtrado, recoge también el filtro aplicado. */
  runningHead?: ReactNode
  /** Nota del pie, junto a la numeración y a la fecha de impresión. Si el usuario no
   *  tiene permiso sobre una parte, aquí se dice que el documento está incompleto. */
  footerNote?: string
  /** Selectores de lo que no se imprime. Se retira, no se imprime en gris: un botón en
   *  papel es tinta gastada y ruido. Se suman a lo que la hoja retira siempre. */
  hideSelectors?: string[]
  /** Escribe la URL entre paréntesis junto al texto de cada enlace: en papel, «ver el
   *  expediente» subrayado no lleva a ninguna parte. */
  expandLinks?: boolean
}

/**
 * Lo que el navegador imprime de lo que ya está en pantalla: un contrato o un expediente
 * que sale como documento y no como captura de la interfaz. Fuerza el tema claro, retira
 * la interfaz, repite la cabecera, no parte las firmas y despliega lo que está plegado por
 * comodidad (`<details data-print-open>`). No intercepta Ctrl/Cmd + P: el diálogo de
 * impresión es el del navegador, y guardar como PDF sigue las mismas reglas.
 */
export const PrintLayout = forwardRef<HTMLElement, PropsPrintLayout>(function PrintLayout(
  {
    page = 'a4',
    kind = 'document',
    watermark,
    runningHead,
    footerNote,
    hideSelectors = OCULTOS_POR_OMISION,
    expandLinks = true,
    children,
    ...resto
  },
  ref,
) {
  const raiz = useRef<HTMLElement | null>(null)
  const unirRef = useCallback(
    (nodo: HTMLElement | null) => {
      raiz.current = nodo
      asignarRef(ref, nodo)
    },
    [ref],
  )

  // Una cadena y no el arreglo: un `['nav']` escrito en línea es un arreglo nuevo en cada
  // render y volvería a suscribir los oyentes de impresión sin que nada cambiara.
  const selectores = hideSelectors.join('\n')

  useEffect(() => {
    if (!hayDocumento()) return
    const lista = selectores ? selectores.split('\n') : []
    const desplegados: HTMLDetailsElement[] = []
    const marcados: Element[] = []
    let pie: HTMLElement | null = null

    const antes = () => {
      const documento = raiz.current
      if (!documento) return
      // Lo plegado por comodidad sigue perteneciendo al documento; lo que es interfaz,
      // no. Solo se despliega lo marcado, y solo lo que está dentro del documento.
      documento.querySelectorAll<HTMLDetailsElement>('details[data-print-open]').forEach((detalle) => {
        if (detalle.open) return
        detalle.open = true
        desplegados.push(detalle)
      })
      for (const selector of lista) {
        let coincidencias: NodeListOf<Element>
        try {
          coincidencias = document.querySelectorAll(selector)
        } catch {
          continue // un selector inválido no puede impedir imprimir el resto
        }
        coincidencias.forEach((elemento) => {
          // Nunca el propio documento ni lo que lo contiene: retirarlo dejaría la hoja en blanco.
          if (elemento === documento || elemento.contains(documento)) return
          if (elemento.hasAttribute(MARCA_OCULTO)) return
          elemento.setAttribute(MARCA_OCULTO, '')
          marcados.push(elemento)
        })
      }
      // Un expediente suelto sin fecha no se puede fechar: va en el pie, junto a la nota.
      pie = documento.querySelector<HTMLElement>(':scope > .ay-doc-print__note')
      pie?.setAttribute('data-printed-at', `Impreso el ${FECHA.format(new Date())}`)
    }

    const despues = () => {
      for (const detalle of desplegados.splice(0)) detalle.open = false
      for (const elemento of marcados.splice(0)) elemento.removeAttribute(MARCA_OCULTO)
      pie?.removeAttribute('data-printed-at')
      pie = null
    }

    window.addEventListener('beforeprint', antes)
    window.addEventListener('afterprint', despues)
    return () => {
      window.removeEventListener('beforeprint', antes)
      window.removeEventListener('afterprint', despues)
      despues()
    }
  }, [selectores])

  return (
    <article
      {...resto}
      ref={unirRef}
      className={cx(
        'ay-doc-print',
        `ay-doc-print--${page}`,
        `ay-doc-print--${kind}`,
        expandLinks && 'expands-links',
      )}
      data-watermark={watermark || undefined}
    >
      {runningHead ? <header className="ay-doc-print__head">{runningHead}</header> : null}
      {children}
      {footerNote ? <footer className="ay-doc-print__note">{footerNote}</footer> : null}
    </article>
  )
})

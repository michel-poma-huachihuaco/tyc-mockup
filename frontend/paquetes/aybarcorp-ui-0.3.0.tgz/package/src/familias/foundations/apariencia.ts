/**
 * La apariencia de la aplicación: paleta, acento, grises, radio, tipografía, profundidad y
 * estilo, además del tema y la densidad. Como el tema, se aplica en la raíz (`data-palette`,
 * `data-radius`…) y los componentes no la consultan: cambian sus tokens.
 *
 * Los hooks son una vista del núcleo de apariencia de @aybarcorp/tokens: un estado por
 * documento, compartido con el anfitrión y los remotos, recordado al recargar y sincronizado
 * entre pestañas. Los ejes, sus valores con nombre visible y los presets son datos
 * (`APPEARANCE`): un panel de apariencia se pinta recorriéndolos, sin escribir un valor a mano.
 */
import { useCallback, useSyncExternalStore } from 'react'
import type { AccentId, AppearanceAxis, AppearanceValues, NeutralId, PaletteId } from '@aybarcorp/tokens'
import {
  APPEARANCE,
  readAppearance,
  resetAppearance,
  setPreference,
  subscribeAppearance,
} from '@aybarcorp/tokens/apariencia'

import { aparienciaDelServidor } from './_internos.js'

/** Los valores de los tres ejes de color de la paleta, con su nombre visible y su muestra. */
const OPCIONES_DE_PALETA = {
  palette: APPEARANCE.axes.palette.values,
  accent: APPEARANCE.axes.accent.values,
  neutral: APPEARANCE.axes.neutral.values,
} as const

const usarApariencia = (): AppearanceValues =>
  useSyncExternalStore(subscribeAppearance, readAppearance, aparienciaDelServidor)

/**
 * Paleta, acento y grises: los ejes que cambian color. Cada combinación está medida en el
 * build de @aybarcorp/tokens —las 96, en los dos temas— y todas cumplen AA, así que elegir
 * cualquiera no rompe ningún contraste. `options` trae los valores de cada eje con su nombre
 * visible y su muestra, para pintar el selector.
 */
export function usePalette() {
  const { palette, accent, neutral } = usarApariencia()
  const setPalette = useCallback((valor: PaletteId) => {
    setPreference('palette', valor)
  }, [])
  const setAccent = useCallback((valor: AccentId) => {
    setPreference('accent', valor)
  }, [])
  const setNeutral = useCallback((valor: NeutralId) => {
    setPreference('neutral', valor)
  }, [])
  return { palette, accent, neutral, setPalette, setAccent, setNeutral, options: OPCIONES_DE_PALETA }
}

/**
 * Toda la apariencia: el valor de cada eje, `set(eje, valor)` para cambiar uno, `reset()`
 * para olvidar lo elegido y volver a lo que declara la página, y los metadatos de los ejes y
 * de los presets. Un preset se aplica con un `set` por cada eje de sus `values`.
 */
export function useAppearance() {
  const appearance = usarApariencia()
  const set = useCallback(<A extends AppearanceAxis>(axis: A, value: AppearanceValues[A]) => {
    setPreference(axis, value)
  }, [])
  const reset = useCallback(() => {
    resetAppearance()
  }, [])
  return { appearance, set, reset, axes: APPEARANCE.axes, presets: APPEARANCE.presets }
}

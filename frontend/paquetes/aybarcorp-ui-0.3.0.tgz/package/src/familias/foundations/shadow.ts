/**
 * Foundations/Shadow. La sombra expresa elevación y nada más: no marca foco —el foco
 * tiene su anillo— ni estado —eso es color, borde y texto—, y no anima en hover. Por eso
 * no hay helper de sombra de foco ni de estado.
 */
import type { CSSProperties } from 'react'

/** Paso de la escala de sombras. */
export type Shadow = 'none' | 'sm' | 'md' | 'lg' | 'xl'
/** Nivel de elevación; cada uno concuerda con su capa de z-index. */
type Elevation = 'base' | 'raised' | 'floating' | 'modal'

/** Sombra como `var()`. En tema oscuro el token se refuerza solo. */
export const shadow = (s: Shadow): string => `var(--aybar-shadow-${s})`

/**
 * El nivel de sombra concuerda con la capa: un elemento con sombra de modal por debajo de
 * un menú es una contradicción visual.
 */
export const ELEVATION = {
  base: { shadow: 'none', z: 'base' },
  raised: { shadow: 'sm', z: 'raised' },
  floating: { shadow: 'lg', z: 'dropdown' },
  modal: { shadow: 'xl', z: 'modal' },
} as const satisfies Record<Elevation, { shadow: Shadow; z: string }>

/**
 * Estilo de una superficie que flota: sombra Y borde. Con forced-colors la sombra
 * desaparece, y sin el borde la superficie se funde con el contenido de debajo.
 */
export function floatingSurface(level: Elevation = 'floating'): CSSProperties {
  const { shadow: s, z } = ELEVATION[level]
  return {
    background: 'var(--aybar-color-bg-surface-raised)',
    border: 'var(--aybar-border-width-thin) solid var(--aybar-color-border-subtle)',
    boxShadow: shadow(s),
    zIndex: `var(--aybar-z-${z})`,
  }
}

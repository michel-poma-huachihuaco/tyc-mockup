/**
 * El set de iconos del Aybar Design System V1 (ficha Foundations/Icons), como datos.
 *
 * Malla de 24 unidades y trazo uniforme de 1.5: el grosor no se escala con el tamaño,
 * así que aquí solo hay geometría. El trazo, el relleno y el color los pone quien pinta
 * el `<svg>` —siempre `currentColor`—, de modo que el icono hereda el contraste del texto
 * que acompaña y funciona en los dos temas sin tocarlo.
 *
 * Los nombres son en inglés y descriptivos (chevron-down, trash, search), como pide la
 * ficha, y son los que usa el diseño aprobado (`icon: 'plus'`, `icon: 'more'`…). Cada
 * figura es un trazado: las circunferencias y los rectángulos se escriben como arcos para
 * que un solo elemento `<path>` pinte cualquier icono, en React y en Angular.
 *
 * ESTE ARCHIVO ES IDÉNTICO en packages/ui y en packages/ui-angular. Los dos paquetes no
 * dependen uno del otro —Angular no debe arrastrar React—, así que el set se copia y la
 * prueba de la familia (pruebas/foundations.test.js) falla si las dos copias divergen.
 */

/** Una figura del icono: un trazado en la malla de 24. */
export interface FormaIcono {
  /** Datos del trazado, en coordenadas de la malla de 24. */
  readonly d: string
  /** Se rellena siempre, con o sin la variante rellena: los puntos de «more». */
  readonly solida?: boolean
  /** Línea abierta: conserva el trazo en la variante rellena, donde si no desaparecería. */
  readonly abierta?: boolean
}

const linea = (d: string): FormaIcono => ({ d, abierta: true })
const figura = (d: string): FormaIcono => ({ d })
const punto = (d: string): FormaIcono => ({ d, solida: true })

// Figuras repetidas: una sola definición para que dos iconos no diverjan en un decimal.
const CIRCULO_9 = figura('M3 12a9 9 0 1 0 18 0a9 9 0 1 0-18 0Z')
const LUPA = figura('M4.5 11a6.5 6.5 0 1 0 13 0a6.5 6.5 0 1 0-13 0Z')
const TRIANGULO = figura('M12 4.5 21 19.5H3L12 4.5Z')

export const FORMAS_ICONO = {
  plus: [linea('M12 5v14M5 12h14')],
  minus: [linea('M5 12h14')],
  check: [linea('M5 12.5 10 17.5 19 7')],
  close: [linea('M6 6l12 12M18 6 6 18')],
  // `chevron` es el nombre corto del diseño (el «Acciones ⌄» del Dropdown y la malla de
  // la ficha): apunta en la dirección de lectura, como chevron-right.
  chevron: [linea('M9 6l6 6-6 6')],
  'chevron-right': [linea('M9 6l6 6-6 6')],
  'chevron-left': [linea('M15 6l-6 6 6 6')],
  'chevron-down': [linea('M6 9l6 6 6-6')],
  'chevron-up': [linea('M6 15l6-6 6 6')],
  'arrow-right': [linea('M5 12h14M13 6l6 6-6 6')],
  'arrow-left': [linea('M19 12H5M11 6l-6 6 6 6')],
  'arrow-up': [linea('M12 19V5M6 11l6-6 6 6')],
  'arrow-down': [linea('M12 5v14M6 13l6 6 6-6')],
  search: [LUPA, linea('M16 16l4 4')],
  'zoom-in': [LUPA, linea('M16 16l4 4M8.5 11h5M11 8.5v5')],
  'zoom-out': [LUPA, linea('M16 16l4 4M8.5 11h5')],
  trash: [linea('M5 7h14M10 11v6M14 11v6M6 7l1 12h10l1-12')],
  edit: [figura('M4 20h4L20 8l-4-4L4 16v4Z')],
  more: [
    punto('M4.4 12a1.6 1.6 0 1 0 3.2 0a1.6 1.6 0 1 0-3.2 0Z'),
    punto('M10.4 12a1.6 1.6 0 1 0 3.2 0a1.6 1.6 0 1 0-3.2 0Z'),
    punto('M16.4 12a1.6 1.6 0 1 0 3.2 0a1.6 1.6 0 1 0-3.2 0Z'),
  ],
  star: [figura('m12 4 2.5 5.2 5.5.8-4 3.9 1 5.6-5-2.9-5 2.9 1-5.6-4-3.9 5.5-.8L12 4Z')],
  download: [linea('M12 4v11m0 0 4-4m-4 4-4-4M5 20h14')],
  upload: [linea('M12 15V4m0 0 4 4m-4-4-4 4M5 20h14')],
  external: [linea('M14 5h5v5M19 5l-8 8M17 14v5H5V7h5')],
  copy: [
    figura('M10 8h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-8a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2Z'),
    linea('M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2'),
  ],
  // Los cuatro tonos de feedback, con el nombre del tono y con el descriptivo.
  info: [CIRCULO_9, linea('M12 11v5.5m0-8.5v.5')],
  success: [CIRCULO_9, linea('M8 12.5l2.5 2.5L16 9.5')],
  'check-circle': [CIRCULO_9, linea('M8 12.5l2.5 2.5L16 9.5')],
  warning: [TRIANGULO, linea('M12 10v4m0 2.5v.5')],
  alert: [TRIANGULO, linea('M12 10v4m0 2.5v.5')],
  danger: [CIRCULO_9, linea('M12 7.5v5m0 3v.5')],
  'alert-circle': [CIRCULO_9, linea('M12 7.5v5m0 3v.5')],
  'alert-octagon': [figura('M8.3 3h7.4L21 8.3v7.4L15.7 21H8.3L3 15.7V8.3Z'), linea('M12 8v5m0 3v.5')],
  clock: [CIRCULO_9, linea('M12 7.5V12l3 2')],
  calendar: [
    figura('M6 5.5h12a2 2 0 0 1 2 2v10.5a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V7.5a2 2 0 0 1 2-2Z'),
    linea('M4 10h16M8 3.5v4M16 3.5v4'),
  ],
  file: [figura('M14 3.5H7a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8.5Z'), linea('M14 3.5v5h5')],
  'file-warning': [
    figura('M14 3.5H7a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8.5Z'),
    linea('M14 3.5v5h5M12 11.5v3m0 2.5v.5'),
  ],
  image: [
    figura('M5.5 4.5h13a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2v-11a2 2 0 0 1 2-2Z'),
    figura('M7.25 10a1.75 1.75 0 1 0 3.5 0a1.75 1.75 0 1 0-3.5 0Z'),
    linea('M20.5 16l-5-5-8.5 8.5'),
  ],
  'image-off': [
    linea('M3 3l18 18'),
    linea('M8.5 4.5h10a2 2 0 0 1 2 2v10M18.5 19.5h-13a2 2 0 0 1-2-2v-11'),
    linea('M3.5 16.5 8 12l3 3'),
  ],
  grid: [
    figura('M5 4h4.5a1 1 0 0 1 1 1v4.5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1Z'),
    figura('M14.5 4H19a1 1 0 0 1 1 1v4.5a1 1 0 0 1-1 1h-4.5a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1Z'),
    figura('M5 13.5h4.5a1 1 0 0 1 1 1V19a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1v-4.5a1 1 0 0 1 1-1Z'),
    figura('M14.5 13.5H19a1 1 0 0 1 1 1V19a1 1 0 0 1-1 1h-4.5a1 1 0 0 1-1-1v-4.5a1 1 0 0 1 1-1Z'),
  ],
  list: [linea('M9 6h11M9 12h11M9 18h11M4.5 6h.01M4.5 12h.01M4.5 18h.01')],
  menu: [linea('M4 7h16M4 12h16M4 17h16')],
  filter: [figura('M4 5h16l-6 7.5V19l-4 1.5v-8Z')],
  sort: [linea('M8 10l4-4 4 4M8 14l4 4 4-4')],
  eye: [
    figura('M2.5 12S6 5.5 12 5.5 21.5 12 21.5 12 18 18.5 12 18.5 2.5 12 2.5 12Z'),
    figura('M9 12a3 3 0 1 0 6 0a3 3 0 1 0-6 0Z'),
  ],
  'eye-off': [
    linea('M3 3l18 18'),
    linea('M10.6 5.6c.5-.1.9-.1 1.4-.1 6 0 9.5 6.5 9.5 6.5a17 17 0 0 1-2.6 3.4'),
    linea('M6.6 6.6C3.9 8.4 2.5 12 2.5 12s3.5 6.5 9.5 6.5c1.6 0 3.1-.4 4.4-1.1'),
    linea('M9.9 9.9a3 3 0 0 0 4.2 4.2'),
  ],
  lock: [
    figura('M6.75 10.75h10.5a2 2 0 0 1 2 2v5.5a2 2 0 0 1-2 2H6.75a2 2 0 0 1-2-2v-5.5a2 2 0 0 1 2-2Z'),
    linea('M8.25 10.5V7.75a3.75 3.75 0 0 1 7.5 0v2.75'),
  ],
  bell: [figura('M6 16v-5a6 6 0 0 1 12 0v5l1.5 2h-15Z'), linea('M10 20.5a2 2 0 0 0 4 0')],
  user: [figura('M8.25 8a3.75 3.75 0 1 0 7.5 0a3.75 3.75 0 1 0-7.5 0Z'), linea('M4.5 20a7.5 7.5 0 0 1 15 0')],
  home: [linea('M4 11 12 4l8 7'), linea('M6 9.5V20h12V9.5')],
  building: [
    linea('M5 20.5v-16a1 1 0 0 1 1-1h8a1 1 0 0 1 1 1v16'),
    linea('M15 9.5h3a1 1 0 0 1 1 1v10M3 20.5h18M8.5 7.5h3M8.5 11h3M8.5 14.5h3'),
  ],
  tag: [
    figura('M3.5 12.6V4.5a1 1 0 0 1 1-1h8.1l8 8a1.5 1.5 0 0 1 0 2.1l-6 6a1.5 1.5 0 0 1-2.1 0Z'),
    figura('M7.25 8.5a1.25 1.25 0 1 0 2.5 0a1.25 1.25 0 1 0-2.5 0Z'),
  ],
  // El único que gira: lo marca el componente con `ay-icon--spin`, y deja de girar con
  // prefers-reduced-motion.
  spinner: [linea('M12 3.5a8.5 8.5 0 1 0 8.5 8.5')],
} as const satisfies Record<string, readonly FormaIcono[]>

/** Nombre de un icono del set. */
export type NombreIcono = keyof typeof FORMAS_ICONO

/** Los nombres del set, en el orden en que se declaran. */
export const NOMBRES_ICONO = Object.keys(FORMAS_ICONO) as NombreIcono[]

/** El único icono que gira; con prefers-reduced-motion deja de hacerlo. */
export const ICONO_DE_CARGA: NombreIcono = 'spinner'

/** Las figuras de un nombre, o `undefined` si el nombre no está en el set. */
export function formasDe(nombre: string | undefined): readonly FormaIcono[] | undefined {
  if (!nombre || !Object.prototype.hasOwnProperty.call(FORMAS_ICONO, nombre)) return undefined
  return FORMAS_ICONO[nombre as NombreIcono]
}

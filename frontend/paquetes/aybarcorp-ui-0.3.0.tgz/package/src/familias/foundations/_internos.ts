import type { ForwardedRef } from 'react'
import { DEFAULT_APPEARANCE } from '@aybarcorp/tokens/apariencia'
import type { AppearanceValues } from '@aybarcorp/tokens/apariencia'

/** Entrega el nodo a la ref que pasó el consumidor, sea de objeto o de función. */
export function asignarRef<T>(ref: ForwardedRef<T>, valor: T | null): void {
  if (typeof ref === 'function') ref(valor)
  else if (ref) ref.current = valor
}

/** Hay DOM: el componente puede escuchar `beforeprint` y consultar el documento. */
export const hayDocumento = (): boolean => typeof window !== 'undefined' && typeof document !== 'undefined'

/**
 * La apariencia que se pinta en el servidor y en la hidratación: la de por defecto. React
 * pide a `useSyncExternalStore` una instantánea de servidor que sea la misma en los dos lados;
 * la del navegador (con lo recordado) llega en el render siguiente.
 */
export const aparienciaDelServidor = (): AppearanceValues => DEFAULT_APPEARANCE

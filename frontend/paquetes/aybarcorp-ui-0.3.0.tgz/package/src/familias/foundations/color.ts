/**
 * Foundations/Color. Las tres capas —primitivas, semánticos y de componente— viven en CSS
 * (@aybarcorp/tokens). Aquí solo se tipan los roles, para que el autocompletado impida
 * escribir un primitivo donde va un semántico: un hexadecimal o un primitivo en un
 * componente rompe el tema oscuro de un golpe.
 */
import { useCallback, useSyncExternalStore } from 'react'
import type { ThemePreference as PreferenciaDeTema } from '@aybarcorp/tokens'
import { readAppearance, resolvedTheme, setPreference, subscribeAppearance } from '@aybarcorp/tokens/apariencia'
import type { ResolvedTheme } from '@aybarcorp/tokens/apariencia'

import { aparienciaDelServidor } from './_internos.js'

/** Fondo por intención. */
export type BgRole = 'canvas' | 'surface' | 'surface-raised' | 'surface-sunken' | 'brand' | 'accent-subtle'
/** Texto por intención. */
export type FgRole = 'default' | 'muted' | 'subtle' | 'on-brand' | 'on-accent' | 'inverse' | 'link' | 'accent'
/** Borde por intención. */
export type BorderRole = 'subtle' | 'default' | 'strong' | 'focus' | 'accent'
/** Tema que el usuario elige; `system` sigue a prefers-color-scheme. */
export type ThemePreference = PreferenciaDeTema

/** Fondo semántico como `var()`. */
export const bg = (role: BgRole): string => `var(--aybar-color-bg-${role})`
/** Texto semántico como `var()`. */
export const fg = (role: FgRole): string => `var(--aybar-color-fg-${role})`
/** Borde semántico como `var()`. */
export const border = (role: BorderRole): string => `var(--aybar-color-border-${role})`

/**
 * Cada texto va emparejado con su fondo, y el par está medido: un token de texto suelto
 * invita a ponerlo sobre cualquier superficie y a fallar el contraste sin darse cuenta.
 */
export const PARES = {
  surface: { bg: bg('surface'), fg: fg('default') },
  sunken: { bg: bg('surface-sunken'), fg: fg('default') },
  brand: { bg: bg('brand'), fg: fg('on-brand') },
  // Texto OSCURO sobre la mandarina: blanco sobre ella no llega a 4.5:1.
  accent: { bg: 'var(--aybar-color-action-accent-bg)', fg: 'var(--aybar-color-action-accent-fg)' },
} as const

/** En el servidor no hay sistema que consultar: el HTML sale en claro, como la hoja sin atributos. */
const temaDelServidor = (): ResolvedTheme => 'light'

/**
 * Tema de la aplicación. Se aplica en la raíz (`data-theme`); los componentes no lo
 * consultan. Con `system` sigue a prefers-color-scheme y reacciona a su cambio.
 *
 * La preferencia es del documento, no de cada componente ni de cada copia de este paquete:
 * vive en el núcleo de apariencia de @aybarcorp/tokens, que la comparte con el anfitrión y los
 * remotos, la recuerda al recargar y escucha al sistema una vez por página —una pantalla sin
 * `useTheme` sigue al sistema igual—. `resolved` es el tema que se ve, con `system` resuelto.
 */
export function useTheme() {
  const { theme } = useSyncExternalStore(subscribeAppearance, readAppearance, aparienciaDelServidor)
  const resolved = useSyncExternalStore(subscribeAppearance, resolvedTheme, temaDelServidor)
  const setTheme = useCallback((tema: ThemePreference) => {
    setPreference('theme', tema)
  }, [])
  return { theme, resolved, setTheme }
}

/**
 * Foundations/Radius. El radio comunica la naturaleza del elemento: md en controles, lg
 * en superficies, full en píldoras. No cambia en hover ni en foco a propósito: una forma
 * que se mueve al apuntar es ruido, y en foco compite con el anillo.
 */
import type { CSSProperties } from 'react'

/** Paso de la escala de radios. */
export type Radius = 'none' | 'sm' | 'md' | 'lg' | 'xl' | '2xl' | 'full'

/** Radio como `var()`. */
export const radius = (r: Radius): string => `var(--aybar-radius-${r})`

/**
 * Uso previsto por tipo de elemento: la mezcla de radios sin criterio es lo que hace que
 * una interfaz parezca hecha por varias manos.
 */
export const RADIUS_USE = {
  control: 'md',
  nested: 'sm',
  surface: 'lg',
  modal: 'xl',
  pill: 'full',
} as const satisfies Record<string, Radius>

const ORDEN: Radius[] = ['none', 'sm', 'md', 'lg', 'xl', '2xl']

/** El radio interior baja un paso: si iguala o supera al exterior, la esquina se ve rota. */
export function innerRadius(outer: Radius): Radius {
  if (outer === 'full') return 'full'
  const i = ORDEN.indexOf(outer)
  return ORDEN[Math.max(0, i - 1)] ?? 'none'
}

/**
 * El anillo de foco sigue el radio del elemento. Dentro de un contenedor con overflow
 * hidden se dibuja hacia dentro (`inset`), para que el recorte no se lo coma.
 */
export const focusRing = (r: Radius, inset = false): CSSProperties => ({
  outline: 'var(--aybar-focus-ring-width) solid var(--aybar-color-border-focus)',
  outlineOffset: inset ? 'calc(-1 * var(--aybar-focus-ring-width))' : 'var(--aybar-focus-ring-offset)',
  borderRadius: radius(r),
})

/**
 * El puntero sobre una escena con profundidad (Tilt y Parallax). Escribe en el elemento dónde
 * está el puntero, de -1 a 1 en cada eje (`--ay-tilt-x/y` o `--ay-parallax-x/y`), una vez por
 * cuadro. Cuánto se inclina o se desplaza eso lo decide la hoja con los tokens depth.*: el
 * componente no conoce ningún ángulo ni ninguna distancia, y por eso `data-depth="plano"` lo
 * apaga sin que el componente se entere.
 *
 * No escucha nada que no sea suyo ni roba eventos: oyentes pasivos de `pointermove` y
 * `pointerleave` en su propio elemento, sin `preventDefault` ni `stopPropagation`, así que los
 * hijos reciben sus eventos como siempre. Un `pointermove` del dedo no cuenta —en táctil el
 * dedo arrastra para desplazar la página, no para inclinar—, y con movimiento reducido, sin
 * hover, con colores forzados o con la profundidad plana no pide ningún cuadro.
 *
 * Interno: copia literal en @aybarcorp/ui-angular (familias/foundations/_profundidad.ts),
 * porque los dos paquetes no se importan entre sí.
 */

/** Dónde escribe cada efecto la posición del puntero. */
export type PrefijoProfundidad = '--ay-tilt' | '--ay-parallax'

/** Las preferencias del sistema con las que la profundidad no se mueve. */
export const CONSULTAS_SIN_PROFUNDIDAD = [
  '(prefers-reduced-motion: reduce)',
  '(hover: none)',
  '(forced-colors: active)',
] as const

const acotar = (n: number): number => Math.max(-1, Math.min(1, n))

/**
 * Sigue el puntero sobre `elemento` y devuelve la función que deja de seguirlo: quita los
 * oyentes, cancela el cuadro pendiente y borra las propiedades que escribió.
 */
export function seguirPuntero(elemento: HTMLElement, prefijo: PrefijoProfundidad): () => void {
  const documento = elemento.ownerDocument
  const ventana = documento.defaultView
  if (!ventana) return () => {}

  // Las listas de consulta son vivas: `matches` cambia si el sistema cambia la preferencia.
  const consultas = typeof ventana.matchMedia === 'function' ? CONSULTAS_SIN_PROFUNDIDAD.map((q) => ventana.matchMedia(q)) : []
  const apagada = (): boolean =>
    consultas.some((consulta) => consulta.matches) || documento.documentElement.getAttribute('data-depth') === 'plano'

  const propX = `${prefijo}-x`
  const propY = `${prefijo}-y`
  let cuadro = 0
  let x = 0
  let y = 0
  let movido = false

  const pintar = (): void => {
    cuadro = 0
    if (x === 0 && y === 0) {
      elemento.style.removeProperty(propX)
      elemento.style.removeProperty(propY)
      return
    }
    elemento.style.setProperty(propX, x.toFixed(3))
    elemento.style.setProperty(propY, y.toFixed(3))
  }
  // Un cuadro a la vez: veinte `pointermove` entre dos cuadros escriben una sola vez.
  const pedirCuadro = (): void => {
    if (!cuadro) cuadro = ventana.requestAnimationFrame(pintar)
  }

  // Al salir vuelve a cero; la hoja hace la transición.
  const alSalir = (): void => {
    if (!movido) return
    movido = false
    x = 0
    y = 0
    pedirCuadro()
  }
  const alMover = (evento: PointerEvent): void => {
    if (evento.pointerType === 'touch') return
    // Si la preferencia cambió con el puntero encima, lo que ya estaba inclinado vuelve a cero.
    if (apagada()) {
      alSalir()
      return
    }
    const caja = elemento.getBoundingClientRect()
    if (!caja.width || !caja.height) return
    x = acotar(((evento.clientX - caja.left) / caja.width) * 2 - 1)
    y = acotar(((evento.clientY - caja.top) / caja.height) * 2 - 1)
    movido = true
    pedirCuadro()
  }

  elemento.addEventListener('pointermove', alMover, { passive: true })
  elemento.addEventListener('pointerleave', alSalir, { passive: true })
  return () => {
    elemento.removeEventListener('pointermove', alMover)
    elemento.removeEventListener('pointerleave', alSalir)
    if (cuadro) ventana.cancelAnimationFrame(cuadro)
    cuadro = 0
    elemento.style.removeProperty(propX)
    elemento.style.removeProperty(propY)
  }
}

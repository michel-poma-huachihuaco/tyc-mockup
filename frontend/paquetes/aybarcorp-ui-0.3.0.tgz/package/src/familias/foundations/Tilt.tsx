import { forwardRef, useCallback, useEffect, useRef } from 'react'
import type { HTMLAttributes } from 'react'
import { asignarRef } from './_internos.js'
import { seguirPuntero } from './_profundidad.js'

export interface PropsTilt extends Omit<HTMLAttributes<HTMLDivElement>, 'className'> {}

/**
 * Envoltorio decorativo que inclina su contenido hacia el puntero: hasta depth.tilt-max en
 * cada eje con el puntero en una esquina, acercándolo depth.elevation, y vuelve a plano al
 * salir. Es un `div` sin rol ni foco propio: no añade nada al árbol de accesibilidad y sus
 * hijos —una Card interactiva, un enlace— reciben el puntero y el teclado como siempre.
 *
 * Solo se mueve con un puntero que pasa por encima y sin movimiento reducido; en táctil, con
 * colores forzados, al imprimir o con `data-depth="plano"` el contenido se queda quieto. La
 * transformación existe solo mientras el puntero está encima, así que en reposo no se vuelve
 * contenedor de lo que va fijo dentro; aun así, no envuelvas controles con capas fijas (el
 * tooltip de un Icon Button) en un Tilt: al inclinarse se moverían con él.
 */
export const Tilt = forwardRef<HTMLDivElement, PropsTilt>(function Tilt({ children, ...resto }, ref) {
  const nodo = useRef<HTMLDivElement | null>(null)
  const unirRef = useCallback(
    (elemento: HTMLDivElement | null) => {
      nodo.current = elemento
      asignarRef(ref, elemento)
    },
    [ref],
  )

  useEffect(() => {
    const elemento = nodo.current
    return elemento ? seguirPuntero(elemento, '--ay-tilt') : undefined
  }, [])

  return (
    <div {...resto} ref={unirRef} className="ay-tilt">
      {children}
    </div>
  )
})

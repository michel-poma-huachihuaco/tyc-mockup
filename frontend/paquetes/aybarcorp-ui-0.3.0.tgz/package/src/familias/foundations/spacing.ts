/**
 * Foundations/Spacing. La escala vive en CSS: múltiplos de 4 en rem, para que los huecos
 * crezcan con el texto cuando el usuario sube el tamaño de fuente del navegador. En TS se
 * tipan los pasos para que el autocompletado impida un valor arbitrario.
 */
import { useCallback, useSyncExternalStore } from 'react'
import type { DensityId } from '@aybarcorp/tokens'
import { readAppearance, setPreference, subscribeAppearance } from '@aybarcorp/tokens/apariencia'

import { aparienciaDelServidor } from './_internos.js'

/** Paso de la escala de espaciado. */
export type Space = '0' | 'px' | '1' | '2' | '3' | '4' | '5' | '6' | '8' | '10' | '12' | '16' | '20' | '24'
/** Tamaño de control: cada uno tiene su alto y su padding, sensibles a la densidad. */
type ControlSize = 'sm' | 'md' | 'lg'
/** Densidad de la interfaz; `comfortable` es la de por omisión. */
export type Density = DensityId

/** Paso de la escala como `var()`. */
export const space = (s: Space): string => `var(--aybar-space-${s})`

/** Tokens de control: los consumen los controles, no la escala base. */
export const control = {
  height: (s: ControlSize): string => `var(--aybar-control-height-${s})`,
  padding: (s: ControlSize): string => `var(--aybar-control-padding-${s})`,
  gap: 'var(--aybar-control-gap)',
} as const

/**
 * El ritmo vertical usa siempre el mismo valor para el mismo nivel de separación, de modo
 * que la estructura de la página se reconozca sin leerla.
 */
export const RHYTHM = {
  betweenFields: '4',
  betweenGroups: '6',
  betweenSections: '12',
  betweenPageBlocks: '20',
} as const satisfies Record<string, Space>

/**
 * Densidad de la aplicación, aplicada en la raíz (`data-density`). Cambia alturas,
 * padding y gap; nunca tamaños de fuente: reducir el texto para que quepa más es lo
 * contrario de una opción de densidad.
 *
 * Es una por documento y la comparten todos los componentes que la usan: vive en el núcleo
 * de apariencia de @aybarcorp/tokens, que la recuerda al recargar. Arranca de lo que declara
 * `<html data-density>` y montarse no escribe nada: antes cada `useDensity` empezaba en
 * `comfortable` y lo escribía al montarse, encima de un `compact` declarado por la página.
 */
export function useDensity() {
  const { density } = useSyncExternalStore(subscribeAppearance, readAppearance, aparienciaDelServidor)
  const setDensity = useCallback((densidad: Density) => {
    setPreference('density', densidad)
  }, [])
  return { density, setDensity }
}

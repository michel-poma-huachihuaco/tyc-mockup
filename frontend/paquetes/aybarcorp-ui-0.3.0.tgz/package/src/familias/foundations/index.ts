// Familia Foundations del Aybar Design System V1. Exporta solo lo de esta carpeta, en el
// orden de las fichas. Color, Typography, Spacing, Radius y Shadow no son componentes:
// viven en @aybarcorp/tokens y aquí solo se tipan sus pasos, como en los bloques
// «react · tsx» de sus fichas. Icons y Print Layout sí se instancian, y también la
// profundidad 3D —Tilt, Parallax y Parallax Layer—: son la elevación llevada al puntero, y
// sus medidas son tokens de foundations (depth.*), como las de Shadow.
export { bg, fg, border, PARES, useTheme } from './color.js'
export type { BgRole, FgRole, BorderRole, ThemePreference } from './color.js'
export { TEXT_STYLES, fontSize } from './typography.js'
export type { FontSize, FontWeight, Leading } from './typography.js'
export { space, control, RHYTHM, useDensity } from './spacing.js'
export type { Space, Density } from './spacing.js'
export { usePalette, useAppearance } from './apariencia.js'
export { radius, RADIUS_USE, innerRadius, focusRing } from './radius.js'
export type { Radius } from './radius.js'
export { shadow, ELEVATION, floatingSurface } from './shadow.js'
export type { Shadow } from './shadow.js'
export { Icon, createIcon, PlusIcon, TrashIcon, ChevronDownIcon } from './Icon.js'
export type { PropsIcon, TamanoIcono } from './Icon.js'
export { NOMBRES_ICONO } from './_iconos.js'
export type { NombreIcono } from './_iconos.js'
export { PrintLayout } from './PrintLayout.js'
export type { PropsPrintLayout, PaginaImpresion, TipoImpresion } from './PrintLayout.js'
export { Tilt } from './Tilt.js'
export type { PropsTilt } from './Tilt.js'
export { Parallax } from './Parallax.js'
export type { PropsParallax } from './Parallax.js'
export { ParallaxLayer } from './ParallaxLayer.js'
export type { PropsParallaxLayer } from './ParallaxLayer.js'

import { forwardRef, useCallback, useEffect, useRef } from 'react'
import type { HTMLAttributes } from 'react'
import { asignarRef } from './_internos.js'
import { seguirPuntero } from './_profundidad.js'

export interface PropsParallax extends Omit<HTMLAttributes<HTMLDivElement>, 'className'> {}

/**
 * Escena de capas que se desplazan con el puntero, cada una según su profundidad: las del
 * fondo, al revés que las del frente, y ninguna más de depth.parallax-shift. Las capas son
 * Parallax Layer; la escena recorta lo que se sale y apila las decorativas detrás del
 * contenido.
 *
 * Es un `div` sin rol: el contenido se lee en el orden del DOM y las capas decorativas no se
 * leen. Solo se mueve con un puntero que pasa por encima y sin movimiento reducido; en
 * táctil, con colores forzados, al imprimir o con `data-depth="plano"` las capas se quedan en
 * su sitio, que es su posición de diseño.
 */
export const Parallax = forwardRef<HTMLDivElement, PropsParallax>(function Parallax({ children, ...resto }, ref) {
  const nodo = useRef<HTMLDivElement | null>(null)
  const unirRef = useCallback(
    (elemento: HTMLDivElement | null) => {
      nodo.current = elemento
      asignarRef(ref, elemento)
    },
    [ref],
  )

  useEffect(() => {
    const elemento = nodo.current
    return elemento ? seguirPuntero(elemento, '--ay-parallax') : undefined
  }, [])

  return (
    <div {...resto} ref={unirRef} className="ay-parallax">
      {children}
    </div>
  )
})

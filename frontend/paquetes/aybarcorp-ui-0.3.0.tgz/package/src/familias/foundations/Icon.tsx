import { forwardRef } from 'react'
import type { ReactNode, SVGAttributes } from 'react'
import { cx } from '../../utiles.js'
import { ICONO_DE_CARGA, formasDe } from './_iconos.js'

/** Malla del icono: 16 en texto y controles sm, 20 en md, 24 en lg y navegación, 32 en Empty State. */
export type TamanoIcono = 16 | 20 | 24 | 32

export interface PropsIcon
  extends Omit<SVGAttributes<SVGSVGElement>, 'className' | 'name' | 'width' | 'height'> {
  /** Malla del icono: 16 acompaña a texto sm, 20 a base y 24 a lg. El trazo es 1.5 en
   *  todos los tamaños, sin escalar el grosor: uno de 16 con 1 se pierde y uno de 24 con
   *  2 pesa demasiado. El área de pulsación la aporta el control, no el icono. */
  size?: TamanoIcono
  /** Nombre del icono del set, en inglés y descriptivo: `plus`, `chevron-down`, `trash`,
   *  `search`. Si se pasan hijos (`<path>` propios), mandan los hijos y el nombre queda
   *  como `data-icon`, que es lo que refleja las flechas en un documento RTL. */
  name?: string
  /** Nombre accesible del icono. Si falta, el icono es decorativo (`aria-hidden`). Solo
   *  cuando el icono comunica algo que no está en el texto: si es el único contenido de
   *  un botón, el nombre va en el botón, que es lo que recibe el foco, no aquí. */
  label?: string
  /** Variante rellena, reservada a estados activos (una estrella valorada). Se acompaña
   *  del estado en texto: el relleno solo no lo comunica. */
  filled?: boolean
}

/**
 * Icono del set del Aybar Design System V1: SVG en línea, trazo `currentColor` de 1.5 en
 * una malla de 24. Decorativo por omisión (`aria-hidden`); con `label` pasa a ser una
 * imagen con nombre (`role="img"`). El color nunca es propio: se hereda del texto, así que
 * cumple el mismo contraste y funciona en los dos temas y en forced-colors sin tocarlo.
 */
export const Icon = forwardRef<SVGSVGElement, PropsIcon>(function Icon(
  { size = 20, name, label, filled = false, role, 'aria-hidden': ariaHidden, children, ...resto },
  ref,
) {
  const formas = formasDe(name)
  const propios = hayHijos(children)
  return (
    <svg
      {...resto}
      ref={ref}
      className={cx('ay-icon', name === ICONO_DE_CARGA && 'ay-icon--spin')}
      width={size}
      height={size}
      viewBox="0 0 24 24"
      // El color se hereda: el mismo contraste que el texto, y los dos temas sin tocarlo.
      fill={filled ? 'currentColor' : 'none'}
      // El trazo es 1.5 en todos los tamaños; en la variante rellena manda el relleno.
      stroke={filled ? undefined : 'currentColor'}
      strokeWidth={filled ? undefined : 1.5}
      strokeLinecap="round"
      strokeLinejoin="round"
      // Decorativo por omisión; `label` lo convierte en contenido con nombre propio.
      aria-hidden={label ? undefined : (ariaHidden ?? true)}
      role={label ? 'img' : role}
      aria-label={label}
      data-icon={name}
    >
      {propios
        ? children
        : formas?.map((forma, i) => (
            <path
              key={i}
              d={forma.d}
              // Un punto se rellena siempre; una línea abierta nunca, o el relleno
              // cerraría su trazado en una cuña (el check rellenado sería un triángulo).
              fill={forma.solida ? 'currentColor' : forma.abierta ? 'none' : undefined}
              // En la variante rellena, la línea conserva su trazo para no desaparecer.
              stroke={forma.solida ? 'none' : filled && forma.abierta ? 'currentColor' : undefined}
              strokeWidth={filled && forma.abierta ? 1.5 : undefined}
            />
          ))}
    </svg>
  )
})

function hayHijos(hijos: ReactNode): boolean {
  if (hijos === undefined || hijos === null || hijos === false || hijos === true) return false
  return !(Array.isArray(hijos) && hijos.length === 0)
}

/**
 * Crea un icono con nombre a partir de su trazado, como `PlusIcon` o `TrashIcon`, para un
 * set de producto que no esté en el del catálogo. Hereda la malla, el trazo y las reglas
 * de nombre accesible de `Icon`: el set nuevo no puede saltárselas.
 */
export function createIcon(name: string, paths: ReactNode) {
  const IconoConNombre = forwardRef<SVGSVGElement, Omit<PropsIcon, 'name'>>(function IconoConNombre(props, ref) {
    return (
      <Icon {...props} ref={ref} name={name}>
        {paths}
      </Icon>
    )
  })
  IconoConNombre.displayName = `Icon(${name})`
  return IconoConNombre
}

/** Más: crear, añadir. Decorativo cuando acompaña a «Nueva unidad». */
export const PlusIcon = createIcon('plus', <path d="M12 5v14M5 12h14" />)
/** Papelera. Solo, el nombre va en el control: «Eliminar el contrato», no «Papelera». */
export const TrashIcon = createIcon('trash', <path d="M5 7h14M10 11v6M14 11v6M6 7l1 12h10l1-12" />)
/** Desplegable: acompaña a un control que abre una lista. */
export const ChevronDownIcon = createIcon('chevron-down', <path d="M6 9l6 6 6-6" />)

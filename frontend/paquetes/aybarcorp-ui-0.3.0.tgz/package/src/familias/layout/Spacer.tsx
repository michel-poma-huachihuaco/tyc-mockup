import { forwardRef } from 'react'
import type { HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import { sinContenido } from './_internos.js'

/** Tamaño del hueco: `flex` ocupa el espacio libre; el resto es un valor fijo de la escala. */
export type TamanoSpacer = 'flex' | '1' | '2' | '3' | '4' | '6' | '8' | '12'
/** Eje en el que aplica el hueco. */
export type EjeSpacer = 'horizontal' | 'vertical' | 'both'
/** Breakpoint por debajo del cual el hueco desaparece. */
export type BreakpointSpacer = 'sm' | 'md' | 'lg'

export interface PropsSpacer extends Omit<HTMLAttributes<HTMLSpanElement>, 'className' | 'children'> {
  /** Tamaño del hueco. `flex` crece y empuja el resto al extremo, y solo funciona dentro
   *  de un contenedor flex; un valor de la escala es un hueco fijo, solo para cuando el
   *  contenedor no puede expresarlo con gap (los dos se suman). */
  size?: TamanoSpacer
  /** Eje en el que aplica. Con `both` el eje lo decide el contenedor. */
  axis?: EjeSpacer
  /** Desaparece por debajo del breakpoint, sin colapsar a un valor intermedio. */
  hideBelow?: BreakpointSpacer
}

/**
 * Hueco explícito para cuando el gap del contenedor no puede expresarlo. Siempre lleva
 * `aria-hidden` y nunca contiene nada —ni un espacio duro—: es una caja vacía. Si aparece
 * repetido entre cada par de elementos, el componente correcto es Stack con gap.
 */
export const Spacer = forwardRef<HTMLSpanElement, PropsSpacer>(function Spacer(
  { size = 'flex', axis = 'both', hideBelow, ...resto },
  ref,
) {
  return (
    <span
      {...sinContenido(resto)}
      ref={ref}
      className={cx(
        'ay-spacer',
        size !== 'flex' && `ay-spacer--${size}`,
        axis !== 'both' && `ay-spacer--${axis}`,
        hideBelow && `ay-spacer--hide-${hideBelow}`,
      )}
      // siempre: sin esto algunos lectores anuncian un elemento en blanco
      aria-hidden="true"
    />
  )
})

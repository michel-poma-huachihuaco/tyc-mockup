import { forwardRef } from 'react'
import type { HTMLAttributes } from 'react'
import { sinContenido } from './_internos.js'

export interface PropsRowSpacer extends Omit<HTMLAttributes<HTMLSpanElement>, 'className' | 'children'> {}

/**
 * Espaciador de una Row: empuja el resto al extremo con `flex: 1`, no con anchos fijos.
 * Lleva `aria-hidden` porque es un nodo vacío entre dos controles y no aporta nada al orden
 * de lectura. Si basta con empujar un hijo que ya existe, mejor margen automático sobre él.
 */
export const RowSpacer = forwardRef<HTMLSpanElement, PropsRowSpacer>(function RowSpacer(props, ref) {
  return <span {...sinContenido(props)} ref={ref} className="ay-row__spacer" aria-hidden="true" />
})

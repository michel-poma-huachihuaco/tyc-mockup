import { forwardRef } from 'react'
import type { CSSProperties, HTMLAttributes, ReactNode } from 'react'
import { cx } from '../../utiles.js'

/** Modo de ajuste del contenido dentro de la caja. */
export type AjusteAspectRatio = 'cover' | 'contain'
/** Radio de la caja. */
export type RadioAspectRatio = 'none' | 'md' | 'lg'

export interface PropsAspectRatio extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'placeholder'> {
  /** Proporción, como cadena (`'16 / 9'`, `'4 / 3'`, `'1 / 1'`, `'3 / 1'`) o número. Se
   *  reserva antes de que el contenido llegue, para que el layout no salte: un salto con
   *  el foco puesto desplaza lo que el usuario iba a pulsar. */
  ratio?: string | number
  /** Modo de ajuste del contenido. `cover` recorta los bordes: no se usa cuando el detalle
   *  de los bordes importa, como en un plano; ahí va `contain`, que deja franjas. */
  fit?: AjusteAspectRatio
  /** Radio de la caja; el contenido lo respeta. */
  rounded?: RadioAspectRatio
  /** Contenido de reserva mientras no hay contenido: dice qué va ahí («Plano de la
   *  unidad») en lugar de mostrar un rectángulo mudo. */
  placeholder?: ReactNode
}

/**
 * Caja de proporción fija para contenido visual —imagen, mapa, vídeo—. El alt va en la
 * imagen, no en la caja, que no aporta texto alternativo. No envuelve texto: un texto en
 * una caja de proporción fija se recorta al crecer con zoom.
 */
export const AspectRatio = forwardRef<HTMLDivElement, PropsAspectRatio>(function AspectRatio(
  { ratio = '16 / 9', fit = 'cover', rounded = 'md', placeholder, style, children, ...resto },
  ref,
) {
  return (
    <div
      {...resto}
      ref={ref}
      className={cx(
        'ay-aspect',
        fit === 'contain' && 'ay-aspect--contain',
        rounded !== 'md' && `ay-aspect--rounded-${rounded}`,
      )}
      // se reserva antes de que el contenido llegue
      style={{ '--aspect': String(ratio), ...style } as CSSProperties}
    >
      {children ?? (
        // dice qué va ahí, en lugar de un rectángulo mudo
        <div className="ay-aspect__placeholder">{placeholder}</div>
      )}
    </div>
  )
})

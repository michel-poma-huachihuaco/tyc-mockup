import { forwardRef } from 'react'
import type { HTMLAttributes, ReactNode } from 'react'
import { cx } from '../../utiles.js'

/** Nivel semántico del encabezado. Empieza en 2: el único h1 de la página lo aporta Header. */
export type NivelHeading = 2 | 3 | 4 | 5 | 6
/** Escala visual del título, independiente del nivel. */
export type TamanoHeading = 'sm' | 'md' | 'lg' | 'xl' | '2xl'

export interface PropsHeading extends Omit<HTMLAttributes<HTMLHeadingElement>, 'className'> {
  /** Nivel semántico; obligatorio de decidir, no de heredar. Responde a la jerarquía del
   *  documento y nunca al tamaño que se quiere ver: tras un h2 viene un h3, nunca un h4,
   *  porque el lector anuncia el nivel en cada parada y un salto hace pensar que se perdió
   *  una sección. Un valor fuera de 2–6 se pinta como h2. */
  level?: NivelHeading
  /** Escala visual, independiente del nivel: un h3 puede verse más grande que un h2. Son
   *  decisiones distintas —jerarquía y diseño— y por eso son dos props. */
  size?: TamanoHeading
  /** Rótulo superior: la categoría en mayúsculas sobre el título. Es un párrafo, no un
   *  encabezado, para no meter una entrada más en el índice del lector. */
  eyebrow?: string
  /** Frase descriptiva bajo el título. Va en un `<p>` y no en un encabezado: convertirlo en
   *  encabezado convierte el mapa de la página en una transcripción de ella. */
  subtitle?: string
  /** Acciones de la sección, alineadas al final de la fila. En pantallas estrechas bajan
   *  bajo el texto; si no caben, pasan a un Dropdown Menu. */
  actions?: ReactNode
  /** Borde inferior que separa la sección del contenido que sigue. */
  divider?: boolean
  /** Oculta el título visualmente sin sacarlo del árbol de accesibilidad: una sección sin
   *  título visible que necesita nombre lo oculta, no lo omite. */
  visuallyHidden?: boolean
  /** Va en el elemento de encabezado, para que otras regiones lo referencien con
   *  `aria-labelledby` y al entrar se anuncie su nombre y no un «región» anónimo. */
  id?: string
}

const NIVELES: readonly number[] = [2, 3, 4, 5, 6]

/**
 * Encabezado de sección. El nivel responde a la jerarquía del documento y el tamaño al
 * diseño; el rótulo y el subtítulo son párrafos y no encabezados. El texto no se trunca:
 * si no cabe, envuelve.
 */
export const Heading = forwardRef<HTMLHeadingElement, PropsHeading>(function Heading(
  {
    level = 2,
    size = 'lg',
    eyebrow,
    subtitle,
    actions,
    divider = false,
    visuallyHidden = false,
    id,
    children,
    ...resto
  },
  ref,
) {
  // Un nivel que llega de JavaScript sin tipos —un atributo de Web Component, un JSON—
  // no puede producir un h1 (lo aporta Header) ni un `hNaN`.
  const nivel = NIVELES.includes(level) ? level : 2
  const Etiqueta = `h${nivel}` as 'h2' | 'h3' | 'h4' | 'h5' | 'h6'

  // Necesario pero no visible: se oculta, no se omite.
  if (visuallyHidden) {
    return (
      <Etiqueta {...resto} ref={ref} id={id} className="ay-visually-hidden">
        {children}
      </Etiqueta>
    )
  }

  return (
    <div className={cx('ay-heading', `ay-heading--${size}`, divider && 'ay-heading--divider')}>
      <div className="ay-heading__text">
        {/* p, no un encabezado de nivel menor */}
        {eyebrow && <p className="ay-heading__eyebrow">{eyebrow}</p>}
        <Etiqueta {...resto} ref={ref} id={id} className="ay-heading__title">
          {children}
        </Etiqueta>
        {subtitle && <p className="ay-heading__subtitle">{subtitle}</p>}
      </div>
      {actions && <div className="ay-heading__actions">{actions}</div>}
    </div>
  )
})

import { forwardRef } from 'react'
import type { ElementType, HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'

/** Dirección del eje principal. No hay variante `reverse` a propósito. */
export type DireccionFlex = 'row' | 'column'
/** Separación entre hijos: space.2, space.4 o space.6. */
export type GapFlex = 'sm' | 'md' | 'lg'
/** Distribución en el eje principal. */
export type JustificacionFlex = 'start' | 'center' | 'between' | 'end'
/** Alineación en el eje cruzado. */
export type AlineacionFlex = 'start' | 'center' | 'baseline' | 'stretch'

export interface PropsFlex extends Omit<HTMLAttributes<HTMLElement>, 'className'> {
  /** Dirección. No existe `row-reverse` ni `column-reverse`: invertirían lo que se ve pero
   *  no el DOM, y el foco saltaría de derecha a izquierda. Si el orden cambia, se cambia el
   *  orden de los hijos. */
  direction?: DireccionFlex
  /** Permite el ajuste de línea. Se activa en cualquier grupo que pueda desbordar: sin él,
   *  el contenido se recorta con zoom o en pantallas estrechas. */
  wrap?: boolean
  /** Separación entre hijos, desde la escala. Siempre gap y no margen: el gap sobrevive a
   *  añadir, quitar y reordenar elementos. */
  gap?: GapFlex
  /** Distribución en el eje principal; `between` lleva el contenido a los dos extremos. */
  justify?: JustificacionFlex
  /** Alineación en el eje cruzado; `baseline` alinea texto de tamaños distintos sin tocar
   *  márgenes. */
  align?: AlineacionFlex
  /** Elemento que se renderiza. */
  as?: ElementType
}

const JUSTIFY: Record<JustificacionFlex, string> = {
  start: 'flex-start',
  center: 'center',
  between: 'space-between',
  end: 'flex-end',
}

const ALIGN: Record<AlineacionFlex, string> = {
  start: 'flex-start',
  center: 'center',
  baseline: 'baseline',
  stretch: 'stretch',
}

/**
 * Dispone elementos en una línea con control de dirección, ajuste, alineación y
 * crecimiento. Los hijos no llevan margen y pueden encogerse (`min-inline-size: 0`); el que
 * crece lo declara con `flex: 1`. No maqueta la página completa: para eso está Grid.
 */
export const Flex = forwardRef<HTMLElement, PropsFlex>(function Flex(
  {
    direction = 'row',
    wrap = false,
    gap = 'md',
    justify = 'start',
    align = 'stretch',
    as: Etiqueta = 'div',
    style,
    children,
    ...resto
  },
  ref,
) {
  return (
    <Etiqueta
      {...resto}
      ref={ref}
      className={cx('ay-flex', `ay-flex--gap-${gap}`, wrap && 'ay-flex--wrap')}
      style={{
        // Un valor que llega de JavaScript sin tipos —`row-reverse`— no invierte nada.
        flexDirection: direction === 'column' ? 'column' : 'row',
        justifyContent: JUSTIFY[justify] ?? JUSTIFY.start,
        alignItems: ALIGN[align] ?? ALIGN.stretch,
        ...style,
      }}
    >
      {children}
    </Etiqueta>
  )
})

import { forwardRef } from 'react'
import type { HTMLAttributes } from 'react'

export interface PropsContainerBleed extends Omit<HTMLAttributes<HTMLDivElement>, 'className'> {}

/**
 * Hijo de un Container que debe llegar al borde —una tabla ancha—: un margen negativo
 * igual al padding del Container, en lugar de sacarlo del árbol. Fuera de un Container no
 * hay padding que compensar y no desplaza nada.
 */
export const ContainerBleed = forwardRef<HTMLDivElement, PropsContainerBleed>(function ContainerBleed(
  { children, ...resto },
  ref,
) {
  return (
    <div {...resto} ref={ref} className="ay-container__bleed">
      {children}
    </div>
  )
})

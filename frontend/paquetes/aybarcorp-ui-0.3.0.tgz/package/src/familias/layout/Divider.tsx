import { forwardRef } from 'react'
import type { ElementType, HTMLAttributes, Ref } from 'react'
import { cx } from '../../utiles.js'
import { sinContenido } from './_internos.js'

/** Orientación de la línea. */
export type OrientacionDivider = 'horizontal' | 'vertical'
/** Margen a los dos lados de la línea: nada, space.2, space.4 o space.6. */
export type EspaciadoDivider = 'none' | 'sm' | 'md' | 'lg'

export interface PropsDivider extends Omit<HTMLAttributes<HTMLElement>, 'className' | 'children'> {
  /** Orientación. El vertical necesita un alto declarado o un contenedor con alto: sin
   *  él no se ve. */
  orientation?: OrientacionDivider
  /** Si es decorativo se oculta al lector con `aria-hidden`: anunciar «separador» veinte
   *  veces en una página es ruido puro. Solo un cambio real de sección —o la agrupación de
   *  un menú— se anuncia, con `hr` o `role="separator"`. */
  decorative?: boolean
  /** Texto centrado en la línea, muy corto y sin puntuación final («o», «Más opciones»). Es
   *  texto, no un encabezado; la línea es decoración. */
  label?: string
  /** Margen a los dos lados, declarado en el divisor y no en los vecinos. */
  spacing?: EspaciadoDivider
  /** Se sale del padding del contenedor con un margen negativo igual a ese padding, para
   *  llegar al borde. */
  bleed?: boolean
  /** Elemento que se renderiza. `hr` por defecto; con otro elemento, el divisor semántico
   *  lleva `role="separator"` —en un menú, la agrupación de comandos es información—. */
  as?: ElementType
}

/**
 * Separa visualmente dos bloques e indica si la separación es decorativa —la mayoría— o un
 * cambio real de sección. Se dibuja con un borde, que se mantiene nítido en cualquier
 * densidad de pantalla, y se imprime porque marca la estructura. No sustituye al espacio:
 * si basta con separar, el gap del Stack lo hace sin añadir una línea.
 */
export const Divider = forwardRef<HTMLElement, PropsDivider>(function Divider(
  {
    orientation = 'horizontal',
    decorative = true,
    label,
    spacing = 'md',
    bleed = false,
    as: Etiqueta = 'hr',
    ...resto
  },
  ref,
) {
  // Un divisor no contiene nada, y un `hr` con hijos hace lanzar a React.
  const atributos = sinContenido(resto)

  // Con etiqueta: la línea es decoración y la etiqueta es texto, no un encabezado. No lleva
  // `role="separator"`, cuyos hijos son presentacionales: la etiqueta dejaría de leerse.
  if (label) {
    return (
      <div
        {...atributos}
        ref={ref as Ref<HTMLDivElement>}
        className={cx('ay-divider__labelled', `ay-divider--${spacing}`, bleed && 'ay-divider--bleed')}
      >
        <span className="ay-divider__line" aria-hidden="true" />
        <span className="ay-divider__label">{label}</span>
        <span className="ay-divider__line" aria-hidden="true" />
      </div>
    )
  }

  const vertical = orientation === 'vertical'
  // Decorativo: oculto al lector. Semántico: el `hr` ya es un separador; cualquier otro
  // elemento necesita el rol para anunciarse.
  const semantica = decorative
    ? { 'aria-hidden': true }
    : {
        role: Etiqueta === 'hr' ? undefined : 'separator',
        'aria-orientation': vertical ? 'vertical' : undefined,
      }

  return (
    <Etiqueta
      {...atributos}
      {...semantica}
      ref={ref}
      className={cx(
        'ay-divider',
        `ay-divider--${spacing}`,
        vertical && 'ay-divider--vertical',
        bleed && 'ay-divider--bleed',
      )}
    />
  )
})

import { forwardRef } from 'react'
import type { ElementType, HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'

/** Ancho máximo del Container: estrecho, de lectura, de página o sin límite. */
export type TamanoContainer = 'narrow' | 'reading' | 'page' | 'full'

export interface PropsContainer extends Omit<HTMLAttributes<HTMLElement>, 'className'> {
  /** Ancho máximo. `page` envuelve el contenido de una página; `reading` (cerca de 75
   *  caracteres) el texto largo, porque las líneas muy largas hacen perder el renglón;
   *  `narrow` un formulario de una columna; `full` no limita. */
  size?: TamanoContainer
  /** Padding lateral del sistema: space.6 en escritorio y space.4 en móvil, nunca menos.
   *  Se quita solo cuando el hijo necesita llegar al borde, o en un Container anidado,
   *  donde el padding se duplicaría. */
  padding?: boolean
  /** Elemento que se renderiza: `main`, `section` o `article` según el caso, para que el
   *  elemento semántico no acabe siendo un div envuelto en otro div. */
  as?: ElementType
}

/**
 * Limita el ancho del contenido y le da el padding lateral del sistema. No aporta
 * semántica propia —la da `as`— ni se anida: el padding se duplicaría. Una franja de color
 * envuelve al Container (`ay-band`), de modo que el color llega al borde y el contenido no.
 */
export const Container = forwardRef<HTMLElement, PropsContainer>(function Container(
  { size = 'page', padding = true, as: Etiqueta = 'div', children, ...resto },
  ref,
) {
  return (
    <Etiqueta
      {...resto}
      ref={ref}
      className={cx('ay-container', `ay-container--${size}`, !padding && 'ay-container--flush')}
    >
      {children}
    </Etiqueta>
  )
})

import { forwardRef } from 'react'
import type { CSSProperties, ElementType, HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import { plantillaDeColumnas } from './_internos.js'

/** Separación entre celdas: space.2, space.4 o space.6. */
export type GapGrid = 'sm' | 'md' | 'lg'
/** Alineación vertical de las celdas dentro de su fila. */
export type AlineacionGrid = 'start' | 'center' | 'stretch'

export interface PropsGrid extends Omit<HTMLAttributes<HTMLElement>, 'className'> {
  /** Número de columnas, o una plantilla completa (contenido y barra lateral, por ejemplo).
   *  Las columnas fijas usan `minmax(0, 1fr)`, para que una celda larga no desborde, y 2, 3
   *  y 4 columnas pasan a menos en pantallas estrechas. */
  columns?: number | string
  /** Ancho mínimo de celda para el ajuste automático, `repeat(auto-fill, minmax(…, 1fr))`:
   *  cubre casi todos los casos sin declarar un breakpoint y, con zoom alto, colapsa a una
   *  columna sin media queries. Tiene prioridad sobre `columns`. */
  minItemWidth?: string
  /** Separación entre celdas, desde la escala. El gap es el único mecanismo de
   *  separación: los hijos no llevan margen. */
  gap?: GapGrid
  /** Separación vertical distinta de la horizontal. */
  rowGap?: GapGrid
  /** Alineación vertical de las celdas: con `stretch` se igualan en alto; con `start`
   *  conservan el suyo. */
  align?: AlineacionGrid
  /** Elemento que se renderiza. Si el contenido es una lista, `ul` con hijos `li`: la
   *  rejilla no aporta semántica. */
  as?: ElementType
}

/**
 * Distribuye contenido en columnas con separación tokenizada. No aporta semántica ni
 * reordena: el orden del DOM es el de lectura y el de tabulación, y si el orden visual debe
 * cambiar se cambia el DOM. Nunca se usa para datos tabulares, que son una Table.
 */
export const Grid = forwardRef<HTMLElement, PropsGrid>(function Grid(
  {
    columns,
    minItemWidth,
    gap = 'md',
    rowGap,
    align = 'stretch',
    as: Etiqueta = 'div',
    style,
    children,
    ...resto
  },
  ref,
) {
  // El ancho mínimo manda sobre las columnas, como en la ficha.
  const { clase, plantilla } = minItemWidth ? {} : plantillaDeColumnas(columns)
  const estilo: CSSProperties & Record<`--${string}`, string> = {}
  if (minItemWidth) estilo['--grid-min'] = minItemWidth
  if (plantilla) estilo.gridTemplateColumns = plantilla
  if (align !== 'stretch') estilo.alignItems = align

  return (
    <Etiqueta
      {...resto}
      ref={ref}
      className={cx('ay-grid', clase, `ay-grid--gap-${gap}`, rowGap && `ay-grid--rowgap-${rowGap}`)}
      style={{ ...estilo, ...style }}
    >
      {children}
    </Etiqueta>
  )
})

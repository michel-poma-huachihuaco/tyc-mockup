import { forwardRef } from 'react'
import type { HTMLAttributes } from 'react'

export interface PropsColumnFooter extends Omit<HTMLAttributes<HTMLDivElement>, 'className'> {}

/**
 * Pie de una Column: queda abajo con `margin-block-start: auto` y no con una altura fija
 * sobre él, que dejaría de valer en cuanto el usuario amplía el texto. Solo se nota si la
 * Column tiene alto (`fullHeight` dentro de un padre con alto, o una celda de rejilla).
 */
export const ColumnFooter = forwardRef<HTMLDivElement, PropsColumnFooter>(function ColumnFooter(
  { children, ...resto },
  ref,
) {
  return (
    <div {...resto} ref={ref} className="ay-column__footer">
      {children}
    </div>
  )
})

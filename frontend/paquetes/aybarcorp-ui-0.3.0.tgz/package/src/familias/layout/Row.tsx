import { forwardRef } from 'react'
import type { ElementType, HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'

/** Separación de la fila: space.1 … space.6. */
export type GapRow = '1' | '2' | '3' | '4' | '6'
/** Distribución en el eje principal. */
export type JustificacionRow = 'start' | 'between' | 'end'
/** Alineación en el eje cruzado. */
export type AlineacionRow = 'center' | 'baseline' | 'start'

export interface PropsRow extends Omit<HTMLAttributes<HTMLElement>, 'className'> {
  /** Separación, desde la escala. Va en el gap y no en márgenes: un hijo que no se
   *  renderiza —una acción sin permiso— no deja un hueco que parezca un fallo de carga. */
  gap?: GapRow
  /** Permite el ajuste. Se activa cuando el grupo puede desbordar: una fila sin ajuste
   *  recorta contenido al ampliar el texto. */
  wrap?: boolean
  /** Distribución en el eje principal; `between` lleva el contenido a los dos lados. */
  justify?: JustificacionRow
  /** Alineación en el eje cruzado. `center` por defecto, que es el caso real más frecuente
   *  —un icono junto a un texto—; `baseline` cuando se mezclan tamaños de texto. */
  align?: AlineacionRow
  /** Elemento que se renderiza. Si los hijos son un conjunto de etiquetas, `ul` con `li`,
   *  para que el lector diga que forman un grupo y cuántos son. */
  as?: ElementType
}

/**
 * Dispone elementos en horizontal con separación tokenizada y centrado vertical por
 * defecto. Es un atajo de Flex; si hace falta alineación distinta por hijo, el componente
 * es Flex.
 */
export const Row = forwardRef<HTMLElement, PropsRow>(function Row(
  { gap = '2', wrap = false, justify = 'start', align = 'center', as: Etiqueta = 'div', children, ...resto },
  ref,
) {
  return (
    <Etiqueta
      {...resto}
      ref={ref}
      className={cx(
        'ay-row',
        `ay-row--${gap}`,
        wrap && 'ay-row--wrap',
        justify !== 'start' && `ay-row--${justify}`,
        align !== 'center' && `ay-row--${align}`,
      )}
    >
      {children}
    </Etiqueta>
  )
})

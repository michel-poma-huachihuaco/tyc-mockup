import { forwardRef } from 'react'
import type { ElementType, HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'

/** Separación de la columna: space.1 … space.8. */
export type GapColumn = '1' | '2' | '3' | '4' | '6' | '8'
/** Alineación horizontal de los hijos. */
export type AlineacionColumn = 'stretch' | 'start' | 'center'
/** Distribución en el eje vertical. */
export type JustificacionColumn = 'start' | 'between' | 'end'

export interface PropsColumn extends Omit<HTMLAttributes<HTMLElement>, 'className'> {
  /** Separación, desde la escala. Los hijos no llevan margen propio: repartir la
   *  separación entre contenedor e hijos obliga a revisarlos todos para cambiar el ritmo. */
  gap?: GapColumn
  /** Eje horizontal, declarado en el contenedor y no hijo a hijo. `stretch` por defecto,
   *  para que las cards y los campos ocupen el ancho. */
  align?: AlineacionColumn
  /** Eje vertical. `between` empuja el último hijo al pie sin alturas fijas. */
  justify?: JustificacionColumn
  /** Ocupa el alto del contenedor. Solo tiene efecto si el padre define alto; si no, no
   *  hace nada. */
  fullHeight?: boolean
  /** Elemento que se renderiza. Si el contenido es una lista, `ul` con hijos `li`. */
  as?: ElementType
}

/**
 * Apila elementos en vertical con separación tokenizada y alineación horizontal declarada.
 * Un hijo condicional que no se renderiza no deja hueco, porque el gap solo actúa entre los
 * hijos presentes. Es el complemento vertical de Row.
 */
export const Column = forwardRef<HTMLElement, PropsColumn>(function Column(
  {
    gap = '4',
    align = 'stretch',
    justify = 'start',
    fullHeight = false,
    as: Etiqueta = 'div',
    children,
    ...resto
  },
  ref,
) {
  return (
    <Etiqueta
      {...resto}
      ref={ref}
      className={cx(
        'ay-column',
        `ay-column--${gap}`,
        align !== 'stretch' && `ay-column--${align}`,
        justify !== 'start' && `ay-column--${justify}`,
        // solo tiene efecto si el padre define alto; si no, confunde
        fullHeight && 'ay-column--full',
      )}
    >
      {children}
    </Etiqueta>
  )
})

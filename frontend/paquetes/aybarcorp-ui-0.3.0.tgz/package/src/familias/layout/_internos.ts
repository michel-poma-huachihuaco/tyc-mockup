/**
 * Ayudas internas de la familia Layout. No se exportan en el índice: no son API.
 */

/**
 * Quita `children` de unas props que no lo admiten por tipo pero pueden traerlo desde
 * JavaScript sin tipos —un JSON del catálogo, un atributo de Web Component—. Un divisor o
 * un espaciador no contienen nada: un espacio duro dentro se leería como contenido, y un
 * `hr` con hijos hace lanzar a React.
 */
export function sinContenido<T extends object>(props: T): Omit<T, 'children'> {
  const { children: _descartado, ...resto } = props as T & { children?: unknown }
  return resto
}

/** Columnas fijas que tienen clase propia en la hoja y, con ella, su colapso en móvil. */
export const COLUMNAS_CON_CLASE: readonly number[] = [2, 3, 4, 12]

/**
 * Normaliza `columns`: un número, o una cadena que solo contiene dígitos —lo que llega de
 * un atributo HTML o de un JSON—, es un número de columnas; cualquier otra cadena es una
 * plantilla completa. Sin esto, `columns="3"` acabaría como `grid-template-columns: 3`,
 * que el navegador descarta en silencio.
 */
export function normalizarColumnas(columnas: number | string | undefined): number | string | undefined {
  if (typeof columnas === 'string' && /^\d+$/.test(columnas.trim())) return Number(columnas)
  return columnas
}

/**
 * Plantilla de columnas para una rejilla. `minmax(0, 1fr)` y no `1fr`: sin el 0, una celda
 * con contenido largo desborda la rejilla. Devuelve la clase cuando la hoja la tiene, para
 * que las columnas fijas colapsen en pantallas estrechas igual que en el marcado canónico.
 */
export function plantillaDeColumnas(
  columnas: number | string | undefined,
): { clase?: string; plantilla?: string } {
  const normalizadas = normalizarColumnas(columnas)
  if (typeof normalizadas === 'number') {
    if (COLUMNAS_CON_CLASE.includes(normalizadas)) return { clase: `ay-grid--${normalizadas}` }
    return { plantilla: `repeat(${normalizadas}, minmax(0, 1fr))` }
  }
  return normalizadas ? { plantilla: normalizadas } : {}
}

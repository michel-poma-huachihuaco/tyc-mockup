/**
 * Mecánica del tirador que reparte el espacio entre dos paneles, sin React ni Angular: el
 * cálculo del tamaño, las teclas del patrón APG «window splitter», el arrastre con pointer
 * events y la memoria en `localStorage`. La usan Splitter y el tirador de Side Panel.
 *
 * Es interna: no se exporta en el índice. `@aybarcorp/ui-angular` lleva una copia literal
 * del mismo archivo, porque los dos paquetes no dependen el uno del otro y la conducta
 * tiene que ser la misma en los dos; una prueba de @aybarcorp/ui exige que sean idénticos.
 *
 * El tamaño es siempre el del panel de inicio, en porcentaje del contenedor (0–100): es lo
 * que anuncia `aria-valuenow` y lo que sobrevive a que cambie el ancho de la ventana. Un
 * tamaño en píxeles quedaría desproporcionado en cuanto la ventana cambiara.
 */

/** Eje en el que se reparten los paneles: lado a lado (`horizontal`) o apilados. */
export type EjeTirador = 'horizontal' | 'vertical'

/** Límites del panel de inicio, en porcentaje. Plegable admite además el 0: plegado. */
export interface LimitesTirador {
  min: number
  max: number
  plegable: boolean
}

/**
 * El tamaño del panel de inicio y el último tamaño abierto que tuvo. `previo` es el destino
 * de Enter al restaurar un panel plegado: sin él, restaurar no sabría adónde volver.
 */
export interface EstadoTirador {
  tamano: number
  previo: number
}

/** Paso de una flecha y de una flecha con Shift, en puntos porcentuales. */
export const PASO_TIRADOR = 2
export const PASO_LARGO_TIRADOR = 10

/** Un porcentaje dentro de 0–100; lo que no es un número finito cuenta como `respaldo`. */
function porcentaje(valor: number, respaldo: number): number {
  return Number.isFinite(valor) ? Math.min(Math.max(valor, 0), 100) : respaldo
}

/**
 * Mínimo y máximo dentro de 0–100 y en orden. Llegan sin tipos desde un atributo de
 * plantilla o un JSON del catálogo: un `min` mayor que el `max` no debe dejar el tirador
 * sin ninguna posición válida, así que el mínimo manda.
 */
export function normalizarLimites(min: number, max: number, plegable: boolean): LimitesTirador {
  const minimo = porcentaje(min, 0)
  return { min: minimo, max: Math.max(porcentaje(max, 100), minimo), plegable }
}

/**
 * El tamaño que se puede pintar: entre el mínimo y el máximo, o 0 si el panel es plegable
 * y se pide 0 o menos. Plegar es un estado explícito (Enter, o arrastrar más allá de la
 * mitad del mínimo), nunca el resultado de quedarse corto con una flecha.
 */
export function limitarTamano(valor: number, limites: LimitesTirador): number {
  if (limites.plegable && valor <= 0) return 0
  const numero = Number.isFinite(valor) ? valor : limites.min
  return redondear(Math.min(Math.max(numero, limites.min), limites.max))
}

/** Dos decimales: suficiente para un arrastre fino y estable al guardarlo y releerlo. */
function redondear(valor: number): number {
  return Math.round(valor * 100) / 100
}

/** El estado siguiente: `previo` recuerda el último tamaño abierto. */
function siguiente(estado: EstadoTirador, tamano: number): EstadoTirador {
  if (tamano > 0) return { tamano, previo: tamano }
  return { tamano: 0, previo: estado.tamano > 0 ? estado.tamano : estado.previo }
}

export interface TeclaTirador {
  /** `KeyboardEvent.key`. */
  tecla: string
  /** Shift pulsado: paso largo. */
  shift: boolean
  eje: EjeTirador
  /** Dirección derecha a izquierda: en horizontal, la flecha izquierda agranda el inicio. */
  rtl: boolean
}

/**
 * El estado tras una tecla, o `null` si la tecla no es del tirador y debe seguir su
 * camino. Las flechas son solo las del eje: en un reparto lado a lado, arriba y abajo
 * siguen desplazando la página.
 *
 * - Flechas: el paso; con Shift, el paso largo.
 * - Home y End: el mínimo y el máximo del panel de inicio.
 * - Enter (si es plegable): pliega el panel de inicio o lo restaura donde estaba.
 */
export function estadoPorTecla(
  estado: EstadoTirador,
  { tecla, shift, eje, rtl }: TeclaTirador,
  limites: LimitesTirador,
): EstadoTirador | null {
  const paso = shift ? PASO_LARGO_TIRADOR : PASO_TIRADOR
  const crece = eje === 'horizontal' ? (rtl ? 'ArrowLeft' : 'ArrowRight') : 'ArrowDown'
  const mengua = eje === 'horizontal' ? (rtl ? 'ArrowRight' : 'ArrowLeft') : 'ArrowUp'
  // Desde plegado, una flecha que agranda abre el panel en su mínimo.
  if (tecla === crece) return siguiente(estado, limitarTamano(Math.max(estado.tamano + paso, limites.min), limites))
  // Menguar se detiene en el mínimo: plegar es Enter. Un panel plegado sigue plegado.
  if (tecla === mengua) {
    return estado.tamano === 0 ? estado : siguiente(estado, limitarTamano(Math.max(estado.tamano - paso, limites.min), limites))
  }
  if (tecla === 'Home') return siguiente(estado, limitarTamano(limites.min, limites))
  if (tecla === 'End') return siguiente(estado, limitarTamano(limites.max, limites))
  if (tecla === 'Enter' && limites.plegable) {
    if (estado.tamano > 0) return siguiente(estado, 0)
    return siguiente(estado, limitarTamano(estado.previo > 0 ? estado.previo : limites.min, limites))
  }
  return null
}

export interface ArrastreTirador {
  /** Desplazamiento del puntero desde que empezó el arrastre, en píxeles, en el eje. */
  delta: number
  /** Tamaño del contenedor en el eje, en píxeles. */
  total: number
  eje: EjeTirador
  rtl: boolean
}

/**
 * El estado durante un arrastre, a partir del estado con que empezó: el porcentaje que el
 * puntero recorrió del contenedor. Si el panel es plegable, soltarlo por debajo de la mitad
 * de su mínimo lo pliega; entre esa mitad y el mínimo se queda en el mínimo.
 */
export function estadoPorArrastre(
  inicio: EstadoTirador,
  { delta, total, eje, rtl }: ArrastreTirador,
  limites: LimitesTirador,
): EstadoTirador {
  if (!(total > 0)) return inicio
  const sentido = eje === 'horizontal' && rtl ? -1 : 1
  const deseado = inicio.tamano + ((delta * sentido) / total) * 100
  if (limites.plegable && deseado < limites.min / 2) return siguiente(inicio, 0)
  return siguiente(inicio, limitarTamano(Math.max(deseado, limites.min), limites))
}

/** Lo que anuncia el lector de pantalla junto al valor: el porcentaje, o que está plegado. */
export function textoTamano(tamano: number): string {
  return tamano === 0 ? 'Panel plegado' : `${Math.round(tamano)} %`
}

/**
 * Derecha a izquierda. Manda la dirección calculada del elemento; si el entorno no la
 * calcula (un DOM sin hoja, como el de las pruebas), el `dir` del ancestro más cercano.
 */
export function esRtl(elemento: Element): boolean {
  const calculada = typeof getComputedStyle === 'function' ? getComputedStyle(elemento).direction : ''
  if (calculada === 'rtl' || calculada === 'ltr') return calculada === 'rtl'
  return elemento.closest('[dir]')?.getAttribute('dir')?.toLowerCase() === 'rtl'
}

// ── Arrastre ─────────────────────────────────────────────────────────────────

/**
 * Sigue un arrastre desde el `pointerdown` del tirador. Captura el puntero —el arrastre
 * sigue aunque el cursor salga del tirador o de la ventana— y marca el tirador con
 * `data-activo` mientras dura, que es lo que la hoja usa para dejarlo resaltado.
 */
export function seguirArrastre(
  tirador: HTMLElement,
  evento: PointerEvent,
  alMover: (evento: PointerEvent) => void,
  alSoltar?: () => void,
): void {
  tirador.setPointerCapture?.(evento.pointerId)
  tirador.dataset['activo'] = ''
  const soltar = (): void => {
    delete tirador.dataset['activo']
    tirador.removeEventListener('pointermove', alMover)
    tirador.removeEventListener('pointerup', soltar)
    tirador.removeEventListener('pointercancel', soltar)
    alSoltar?.()
  }
  tirador.addEventListener('pointermove', alMover)
  tirador.addEventListener('pointerup', soltar)
  tirador.addEventListener('pointercancel', soltar)
}

// ── Desborde ─────────────────────────────────────────────────────────────────

/**
 * Un panel estrecho desborda y se desplaza, y lo que se desplaza tiene que alcanzarse con
 * el teclado (WCAG 2.1.1): mientras desborda, el panel entra en el orden de Tab; cuando
 * deja de desbordar, sale, para no sumar paradas vacías. Se vuelve a medir cuando cambia el
 * tamaño del panel o de sus hijos, y cuando cambian los hijos. Devuelve con qué dejar de
 * vigilar. Sin ResizeObserver (un DOM de pruebas, el servidor) no hace nada.
 */
export function vigilarDesborde(panel: HTMLElement): () => void {
  if (typeof ResizeObserver === 'undefined') return () => {}
  const medir = (): void => {
    // El píxel de margen absorbe el redondeo de un ancho fraccionario.
    const desborda = panel.scrollWidth > panel.clientWidth + 1 || panel.scrollHeight > panel.clientHeight + 1
    if (desborda) panel.setAttribute('tabindex', '0')
    else panel.removeAttribute('tabindex')
  }
  const tamano = new ResizeObserver(medir)
  const observarHijos = (): void => {
    tamano.disconnect()
    tamano.observe(panel)
    for (const hijo of Array.from(panel.children)) tamano.observe(hijo)
  }
  const hijos = typeof MutationObserver === 'undefined' ? null : new MutationObserver(() => {
    observarHijos()
    medir()
  })
  hijos?.observe(panel, { childList: true })
  observarHijos()
  medir()
  return () => {
    tamano.disconnect()
    hijos?.disconnect()
  }
}

// ── Memoria ──────────────────────────────────────────────────────────────────

/** Almacenamiento del navegador; puede no existir o lanzar (modo privado, sin permiso). */
export function leerAlmacenado(clave: string): string | null {
  try {
    return window.localStorage.getItem(clave)
  } catch {
    return null
  }
}

export function guardarAlmacenado(clave: string, valor: string): void {
  try {
    window.localStorage.setItem(clave, valor)
  } catch {
    // Sin almacenamiento el valor vale para esta sesión: no es motivo para fallar.
  }
}

/** La clave de un Splitter en `localStorage`, con el prefijo que lo distingue de otros. */
export function claveSplitter(clave: string): string {
  return `ay-splitter:${clave}`
}

/**
 * El estado guardado de un Splitter: `"40"`, o `"0/40"` si quedó plegado —el segundo número
 * es adónde vuelve al restaurarlo—. Lo que no se entiende, o no cabe en los límites
 * actuales, se descarta: los límites pueden haber cambiado desde que se guardó.
 */
export function leerEstado(clave: string, limites: LimitesTirador): EstadoTirador | null {
  const texto = leerAlmacenado(clave)
  if (texto === null) return null
  const [tamano, previo] = texto.split('/').map(Number)
  if (tamano === undefined || !Number.isFinite(tamano)) return null
  if (tamano === 0 && limites.plegable) {
    const destino = previo !== undefined && Number.isFinite(previo) && previo > 0 ? limitarTamano(previo, limites) : limites.min
    return { tamano: 0, previo: destino }
  }
  const limitado = limitarTamano(tamano, limites)
  return limitado > 0 ? { tamano: limitado, previo: limitado } : null
}

export function guardarEstado(clave: string, estado: EstadoTirador): void {
  guardarAlmacenado(clave, estado.tamano === 0 ? `0/${estado.previo}` : String(estado.tamano))
}

import { forwardRef } from 'react'
import type { ElementType, HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'

/** Separación del Stack: una sola medida de la escala de espaciado (space.1 … space.12). */
export type GapStack = '1' | '2' | '3' | '4' | '6' | '8' | '12'
/** Eje en el que se apilan los hijos. */
export type DireccionStack = 'vertical' | 'horizontal'
/** Alineación de los hijos en el eje cruzado. */
export type AlineacionStack = 'start' | 'center' | 'stretch'

export interface PropsStack extends Omit<HTMLAttributes<HTMLElement>, 'className'> {
  /** Separación, desde la escala: una sola medida por Stack, que es lo que mantiene el
   *  ritmo reconocible. Entre secciones de página se usan los valores mayores (8 y 12), que
   *  se reducen un paso en pantallas estrechas. */
  gap?: GapStack
  /** Eje. El horizontal no activa el ajuste de línea: si el grupo puede desbordar, el
   *  componente adecuado es Flex con `wrap`. */
  direction?: DireccionStack
  /** Línea entre cada par de hijos, dibujada como borde de cada hijo menos el primero —no
   *  con elementos hr— y calculada sobre los hijos presentes, no sobre el índice. */
  dividers?: boolean
  /** Alineación en el eje cruzado. Con `stretch` los hijos ocupan el ancho del contenedor. */
  align?: AlineacionStack
  /** Elemento que se renderiza. Si el contenido es una lista, `ul` con hijos `li`: el Stack
   *  no aporta semántica. */
  as?: ElementType
}

/**
 * Separa elementos en un eje con una única medida de la escala. La separación es el gap del
 * contenedor y nunca un margen en los hijos ni un selector «todos menos el último»: así un
 * hijo condicional que no se renderiza no deja hueco.
 */
export const Stack = forwardRef<HTMLElement, PropsStack>(function Stack(
  {
    gap = '4',
    direction = 'vertical',
    dividers = false,
    align = 'stretch',
    as: Etiqueta = 'div',
    children,
    ...resto
  },
  ref,
) {
  return (
    <Etiqueta
      {...resto}
      ref={ref}
      className={cx(
        'ay-stack',
        `ay-stack--${gap}`,
        direction === 'horizontal' && 'ay-stack--horizontal',
        dividers && 'ay-stack--dividers',
        align !== 'stretch' && `ay-stack--align-${align}`,
      )}
    >
      {children}
    </Etiqueta>
  )
})

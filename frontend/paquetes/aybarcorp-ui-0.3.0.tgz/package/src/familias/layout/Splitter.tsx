import { Children, forwardRef, useCallback, useEffect, useId, useRef, useState } from 'react'
import type { CSSProperties, HTMLAttributes, KeyboardEvent, PointerEvent } from 'react'
import { cx } from '../../utiles.js'
import {
  claveSplitter,
  esRtl,
  estadoPorArrastre,
  estadoPorTecla,
  guardarEstado,
  leerEstado,
  limitarTamano,
  normalizarLimites,
  seguirArrastre,
  textoTamano,
  vigilarDesborde,
} from './_tirador.js'
import type { EjeTirador, EstadoTirador } from './_tirador.js'

/** Reparto de los dos paneles: lado a lado o apilados. */
export type OrientacionSplitter = 'horizontal' | 'vertical'

export interface PropsSplitter
  extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'defaultValue' | 'onChange'> {
  /** `horizontal`: los paneles lado a lado y el separador vertical entre ellos.
   *  `vertical`: apilados; el contenedor necesita un alto, que por omisión da la hoja. */
  orientation?: OrientacionSplitter
  /** Tamaño inicial del primer panel, en porcentaje del contenedor (0–100), sin controlar. */
  defaultSize?: number
  /** Tamaño controlado del primer panel, en porcentaje. Con él, el reparto es de quien lo
   *  pasa: cada tecla y cada arrastre llegan a `onSizeChange` y no cambian nada solos. */
  size?: number
  /** Cada cambio de tamaño, en porcentaje; 0 si el primer panel quedó plegado. */
  onSizeChange?: (size: number) => void
  /** Tamaño mínimo del primer panel, en porcentaje. Home lo lleva aquí. */
  min?: number
  /** Tamaño máximo del primer panel, en porcentaje. End lo lleva aquí. */
  max?: number
  /** Enter pliega el primer panel y lo restaura donde estaba; arrastrarlo por debajo de la
   *  mitad del mínimo también lo pliega. Plegado sale del orden de foco y del lector. */
  collapsible?: boolean
  /** Recuerda el reparto entre sesiones en `localStorage`, bajo `ay-splitter:<clave>`. Sin
   *  almacenamiento (modo privado, sin permiso) vale para la sesión y no falla. */
  persistKey?: string
  /** Nombre accesible del separador: qué reparte. «Ajustar el ancho de la lista». */
  label?: string
}

/**
 * Dos paneles con un separador que reparte el espacio entre ellos: lista y detalle, editor
 * y vista previa. Sigue el patrón «window splitter» de las APG: el separador es un control
 * enfocable (`role="separator"`) que anuncia el tamaño del primer panel y lo controla con
 * el teclado —flechas, Shift para el paso largo, Home y End, Enter para plegar— y con el
 * puntero, también táctil. Los dos primeros hijos son los paneles; el primero manda.
 *
 * No sustituye a Side Panel: un detalle que se abre y se cierra junto a una lista es Side
 * Panel; dos áreas que conviven y cuyo reparto decide quien trabaja, Splitter.
 */
export const Splitter = forwardRef<HTMLDivElement, PropsSplitter>(function Splitter(
  {
    orientation = 'horizontal',
    defaultSize = 50,
    size,
    onSizeChange,
    min = 10,
    max = 90,
    collapsible = false,
    persistKey,
    label = 'Ajustar el reparto entre los paneles',
    children,
    style,
    ...resto
  },
  ref,
) {
  const id = useId()
  const idInicio = `${id}-inicio`
  // Lo que llega sin tipos —un JSON del catálogo, un atributo— no puede romper el eje.
  const eje: EjeTirador = orientation === 'vertical' ? 'vertical' : 'horizontal'
  const limites = normalizarLimites(Number(min), Number(max), collapsible)
  const controlado = size !== undefined
  const [interno, setInterno] = useState(() => limitarTamano(Number(defaultSize), limites))
  const tamano = limitarTamano(Number(controlado ? size : interno), limites)
  const [inicio, fin] = Children.toArray(children)

  // El último tamaño abierto: adónde vuelve Enter al restaurar un panel plegado.
  const previo = useRef(tamano > 0 ? tamano : limites.min)
  useEffect(() => {
    if (tamano > 0) previo.current = tamano
  }, [tamano])

  // Un arrastre dura muchos renders: lee siempre los valores del último, no los del inicio.
  const vivo = useRef({ tamano, controlado, onSizeChange })
  vivo.current = { tamano, controlado, onSizeChange }
  const cambiar = useCallback((estado: EstadoTirador): void => {
    previo.current = estado.previo
    if (estado.tamano === vivo.current.tamano) return
    if (!vivo.current.controlado) setInterno(estado.tamano)
    vivo.current.onSizeChange?.(estado.tamano)
  }, [])

  // Memoria entre sesiones. Se lee al montar —no en el render, que en el servidor no tiene
  // almacenamiento— y se guarda en cada cambio, pero solo después de haber leído la clave
  // vigente: si no, el primer render guardaría el tamaño por omisión encima del recordado.
  // Por eso el efecto que guarda va antes que el que lee.
  const clave = persistKey ? claveSplitter(persistKey) : null
  const leida = useRef<string | null>(null)
  const limitesVivos = useRef(limites)
  limitesVivos.current = limites
  useEffect(() => {
    if (clave && leida.current === clave) guardarEstado(clave, { tamano, previo: previo.current })
  }, [clave, tamano])
  useEffect(() => {
    if (!clave) return
    const guardado = leerEstado(clave, limitesVivos.current)
    if (guardado) cambiar(guardado)
    leida.current = clave
  }, [clave, cambiar])

  // Un panel que desborda entra en el orden de Tab mientras desborde: _tirador.ts.
  const panelInicio = useRef<HTMLDivElement | null>(null)
  const panelFin = useRef<HTMLDivElement | null>(null)
  useEffect(() => {
    const paneles = [panelInicio.current, panelFin.current].filter((p): p is HTMLDivElement => p !== null)
    const dejar = paneles.map(vigilarDesborde)
    return () => dejar.forEach((d) => d())
  }, [])

  const alTecla = (evento: KeyboardEvent<HTMLDivElement>): void => {
    const nuevo = estadoPorTecla(
      { tamano, previo: previo.current },
      { tecla: evento.key, shift: evento.shiftKey, eje, rtl: esRtl(evento.currentTarget) },
      limites,
    )
    if (!nuevo) return
    evento.preventDefault()
    cambiar(nuevo)
  }

  const alPulsar = (evento: PointerEvent<HTMLDivElement>): void => {
    // Solo el botón principal: el secundario abre el menú contextual, no arrastra.
    if (evento.button !== 0) return
    const tirador = evento.currentTarget
    const contenedor = tirador.parentElement
    if (!contenedor) return
    const caja = contenedor.getBoundingClientRect()
    const total = eje === 'horizontal' ? caja.width : caja.height
    const origen = eje === 'horizontal' ? evento.clientX : evento.clientY
    const desde = { tamano, previo: previo.current }
    const rtl = esRtl(contenedor)
    // Sin esto, arrastrar con el ratón selecciona el texto de los paneles. El foco se da a
    // mano: tras arrastrar, las flechas siguen afinando desde el mismo separador.
    evento.preventDefault()
    tirador.focus({ preventScroll: true })
    contenedor.dataset['arrastrando'] = ''
    seguirArrastre(
      tirador,
      evento.nativeEvent,
      (movimiento) => {
        const delta = (eje === 'horizontal' ? movimiento.clientX : movimiento.clientY) - origen
        cambiar(estadoPorArrastre(desde, { delta, total, eje, rtl }, limites))
      },
      () => delete contenedor.dataset['arrastrando'],
    )
  }

  const plegado = tamano === 0
  return (
    <div
      {...resto}
      ref={ref}
      className={cx('ay-splitter', `ay-splitter--${eje}`)}
      data-plegado={plegado ? '' : undefined}
      style={{ ...style, '--_tamano': tamano } as CSSProperties}
    >
      <div ref={panelInicio} className="ay-splitter__panel ay-splitter__panel--inicio" id={idInicio} hidden={plegado || undefined}>
        {inicio}
      </div>
      <div
        className="ay-splitter__tirador"
        role="separator"
        tabIndex={0}
        aria-label={label}
        aria-controls={idInicio}
        // El separador de dos paneles lado a lado es una línea vertical, y al revés.
        aria-orientation={eje === 'horizontal' ? 'vertical' : 'horizontal'}
        aria-valuenow={Math.round(tamano)}
        aria-valuemin={collapsible ? 0 : Math.round(limites.min)}
        aria-valuemax={Math.round(limites.max)}
        aria-valuetext={textoTamano(tamano)}
        onKeyDown={alTecla}
        onPointerDown={alPulsar}
      />
      <div ref={panelFin} className="ay-splitter__panel ay-splitter__panel--fin">
        {fin}
      </div>
    </div>
  )
})

import { forwardRef } from 'react'
import type { HTMLAttributes } from 'react'

export interface PropsGridItem extends Omit<HTMLAttributes<HTMLDivElement>, 'className'> {
  /** Columnas que ocupa la celda, con `span` y no con coordenadas absolutas: el orden del
   *  DOM sigue siendo el de lectura. */
  span?: number
  /** Filas que ocupa la celda. */
  rowSpan?: number
}

/**
 * Celda de un Grid que expande varias columnas o filas. Va como hijo directo del Grid;
 * fuera de una rejilla no tiene efecto.
 */
export const GridItem = forwardRef<HTMLDivElement, PropsGridItem>(function GridItem(
  { span, rowSpan, style, children, ...resto },
  ref,
) {
  return (
    <div
      {...resto}
      ref={ref}
      style={{
        gridColumn: span ? `span ${span}` : undefined,
        gridRow: rowSpan ? `span ${rowSpan}` : undefined,
        ...style,
      }}
    >
      {children}
    </div>
  )
})

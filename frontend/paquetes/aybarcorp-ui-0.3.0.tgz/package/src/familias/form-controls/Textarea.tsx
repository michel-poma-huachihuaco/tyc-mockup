import { forwardRef, useEffect, useId, useRef, useState } from 'react'
import type { ChangeEvent, TextareaHTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import { combinarRefs, unirIds, useEfectoDeDiseno } from './_internos.js'

export interface PropsTextarea
  extends Omit<TextareaHTMLAttributes<HTMLTextAreaElement>, 'className' | 'value' | 'onChange'> {
  /** Valor controlado. Para el modo no controlado está `defaultValue`, el nativo. */
  value?: string
  /** Cambio de valor; recibe el evento nativo del campo. */
  onChange?: (evento: ChangeEvent<HTMLTextAreaElement>) => void
  /** Altura mínima en líneas. Tres es el mínimo del sistema: menos se lee como un Input. */
  rows?: number
  /** Con `autoResize`, número de líneas a partir del cual el campo deja de crecer y pasa
   *  a scroll interno. */
  maxRows?: number
  /** El campo crece con el contenido hasta `maxRows`. El scroll interno sigue existiendo:
   *  el tirador nunca es el único acceso al texto. */
  autoResize?: boolean
  /** Límite de caracteres. Sin contador es el límite duro del control nativo. Con
   *  contador es un límite blando: el texto pegado que lo excede se acepta y se marca, y
   *  lo que se bloquea es el envío —validez del formulario—, no la escritura. */
  maxLength?: number
  /** Muestra el contador «120 / 500». Cambia a advertencia al 90 % y a error al pasar el
   *  límite, y solo anuncia al cruzar esos umbrales, no en cada tecla. */
  showCounter?: boolean
  /** Aplica `aria-invalid` y el borde de error. */
  invalid?: boolean
  /** Desactiva el campo: atenuado y fuera del orden de tabulación. */
  disabled?: boolean
}

type Umbral = 'normal' | 'cerca' | 'excedido'

/**
 * Texto libre de varias líneas: observaciones de una visita, condiciones particulares
 * de un contrato. Enter inserta salto de línea y no envía. Se redimensiona solo en
 * vertical, porque el horizontal rompe la rejilla del formulario.
 */
export const Textarea = forwardRef<HTMLTextAreaElement, PropsTextarea>(function Textarea(
  {
    value,
    onChange,
    rows = 3,
    maxRows = 12,
    autoResize = false,
    maxLength,
    showCounter = false,
    invalid = false,
    disabled = false,
    defaultValue,
    ...resto
  },
  ref,
) {
  const id = useId()
  const idContador = `${id}-contador`
  const interna = useRef<HTMLTextAreaElement | null>(null)
  const [largoNoControlado, setLargoNoControlado] = useState(String(defaultValue ?? '').length)
  const largo = value !== undefined ? value.length : largoNoControlado
  const limite = showCounter ? maxLength : undefined
  const contador = limite !== undefined
  const umbral: Umbral =
    limite === undefined ? 'normal' : largo > limite ? 'excedido' : largo >= limite * 0.9 ? 'cerca' : 'normal'
  const [anuncio, setAnuncio] = useState('')
  const umbralPrevio = useRef<Umbral>(umbral)

  // Solo se anuncia al cruzar un umbral: recitar «quedan 411» tecla a tecla tapa el
  // propio texto que se está dictando.
  useEffect(() => {
    if (limite === undefined || umbral === umbralPrevio.current) return
    umbralPrevio.current = umbral
    if (umbral === 'cerca') setAnuncio(`Quedan ${limite - largo} caracteres de ${limite}.`)
    else if (umbral === 'excedido') setAnuncio(`Has superado el límite de ${limite} caracteres.`)
    else setAnuncio('')
  }, [umbral, limite, largo])

  // Con contador el límite es blando: el exceso bloquea el envío por validez nativa.
  useEffect(() => {
    const campo = interna.current
    if (!campo || limite === undefined) return
    campo.setCustomValidity(umbral === 'excedido' ? `El texto supera el límite de ${limite} caracteres.` : '')
  }, [umbral, limite])

  // Autoajuste: crece hasta maxRows y luego hace scroll.
  useEfectoDeDiseno(() => {
    const campo = interna.current
    if (!campo || !autoResize) return
    const estilo = getComputedStyle(campo)
    const linea = parseFloat(estilo.lineHeight) || parseFloat(estilo.fontSize) * 1.55
    const extra =
      parseFloat(estilo.paddingBlockStart) +
      parseFloat(estilo.paddingBlockEnd) +
      parseFloat(estilo.borderBlockStartWidth) +
      parseFloat(estilo.borderBlockEndWidth)
    campo.style.blockSize = 'auto'
    const alto = Math.min(campo.scrollHeight + (extra || 0), linea * maxRows + (extra || 0))
    campo.style.blockSize = `${alto}px`
  }, [value, largo, autoResize, maxRows])

  return (
    <>
      <textarea
        {...resto}
        ref={combinarRefs(ref, interna)}
        rows={rows}
        value={value}
        defaultValue={defaultValue}
        disabled={disabled}
        // Sin contador, el límite es el duro del control nativo.
        maxLength={contador ? undefined : maxLength}
        aria-invalid={invalid || umbral === 'excedido' || resto['aria-invalid'] === true || undefined}
        aria-describedby={unirIds(resto['aria-describedby'], contador && idContador)}
        onChange={(evento) => {
          if (value === undefined) setLargoNoControlado(evento.target.value.length)
          onChange?.(evento)
        }}
        className={cx('ay-textarea', autoResize && 'ay-textarea--auto')}
      />
      {contador && (
        <p
          className={cx('ay-counter', umbral === 'cerca' && 'is-near', umbral === 'excedido' && 'is-over')}
          id={idContador}
        >
          {largo} / {limite}
        </p>
      )}
      {contador && (
        <span className="ay-visually-hidden" aria-live="polite">
          {anuncio}
        </span>
      )}
    </>
  )
})

import { forwardRef, useEffect, useId, useRef, useState } from 'react'
import type { InputHTMLAttributes, KeyboardEvent, ReactNode } from 'react'
import { areaVisible, cx } from '../../utiles.js'
import { anclarEnCapaSuperior } from '../surfaces/_capa.js'
import { IconoCerrar, IconoChevron, SpinnerCanonico } from './_iconos.js'
import {
  combinarRefs,
  normalizarTexto,
  unirIds,
  useAnuncioDiferido,
  useControlable,
  useEfectoDeDiseno,
} from './_internos.js'

export type TamanoCombobox = 'sm' | 'md' | 'lg'

/** Una opción de la lista. `description` es la segunda línea que desambigua. */
export interface OpcionCombobox {
  value: string
  label: string
  description?: string
  group?: string
  disabled?: boolean
}

export interface PropsCombobox
  extends Omit<
    InputHTMLAttributes<HTMLInputElement>,
    'className' | 'type' | 'value' | 'defaultValue' | 'onChange' | 'size' | 'placeholder' | 'multiple'
  > {
  /** Etiqueta visible; obligatoria. Nombra el dato: «Promoción». */
  label: string
  /** Opciones. `group` las agrupa bajo una cabecera dentro de la lista. */
  options?: OpcionCombobox[]
  /** Valor elegido: una cadena, o un arreglo con `multiple`. Si se omite, el control
   *  lleva su propio estado. Un valor que ya no está en la lista se muestra con aviso. */
  value?: string | string[]
  /** Cambio de valor: la cadena elegida (o `undefined` al limpiar) o el arreglo completo. */
  onValueChange?: (value: string | string[] | undefined) => void
  /** Permite varios valores, que se muestran como Chips sobre el campo. Retroceso con el
   *  campo vacío quita el último. */
  multiple?: boolean
  /** Lo escrito, para filtrar en servidor. Con él, el filtro local se desactiva. */
  onInputChange?: (q: string) => void
  /** Opciones cargando: el indicador va dentro de la lista, no en el campo. */
  loading?: boolean
  /** Mensaje sin resultados. Vive dentro de la lista: no es un error de validación. */
  emptyMessage?: string
  /** Permite crear un valor que no está en la lista; la opción de crear aparece al final
   *  y dice qué creará. */
  allowCreate?: boolean
  /** Altura del campo. */
  size?: TamanoCombobox
  /** Mensaje de validación, asociado por `aria-describedby`. */
  error?: string
  /** Invitación a escribir: «Escribe para buscar». */
  placeholder?: string
}

type Item = { opcion: OpcionCombobox; crear?: boolean }

/**
 * Lista cerrada de más de diez opciones que se filtra escribiendo. Patrón APG combobox:
 * el foco no sale nunca del input y la opción activa se señala con
 * `aria-activedescendant`; la lista no se abre por recibir el foco, sino al escribir o
 * con la flecha abajo. Si el valor no tiene que estar en la lista, es Autocomplete.
 */
export const Combobox = forwardRef<HTMLInputElement, PropsCombobox>(function Combobox(
  {
    label,
    options = [],
    value,
    onValueChange,
    multiple = false,
    onInputChange,
    loading = false,
    emptyMessage = 'Sin coincidencias',
    allowCreate = false,
    size = 'md',
    error,
    placeholder = 'Escribe para buscar',
    id: idPropio,
    disabled,
    onBlur,
    onKeyDown,
    ...resto
  },
  ref,
) {
  const automatico = useId()
  const id = idPropio ?? automatico
  const idLista = `${id}-list`
  const idError = `${id}-error`
  const idAviso = `${id}-aviso`
  const idElegidos = `${id}-elegidos`
  const campo = useRef<HTMLInputElement | null>(null)
  const caja = useRef<HTMLDivElement | null>(null)
  const lista = useRef<HTMLUListElement | null>(null)

  const [valor, cambiarValor] = useControlable<string | string[] | undefined>(
    value,
    multiple ? [] : undefined,
    onValueChange,
  )
  const elegidos = Array.isArray(valor) ? valor : valor ? [valor] : []
  const etiquetaDe = (v: string) => options.find((o) => o.value === v)?.label ?? v
  const textoDelValor = !multiple && elegidos[0] !== undefined ? etiquetaDe(elegidos[0]) : ''

  const [abierto, setAbierto] = useState(false)
  const [consulta, setConsulta] = useState(textoDelValor)
  // Solo se filtra lo que la persona ha escrito desde que abrió: al abrir con la flecha,
  // la lista sale entera aunque el campo muestre el valor elegido.
  const [filtrando, setFiltrando] = useState(false)
  const [activa, setActiva] = useState(-1)
  const [volteada, setVolteada] = useState(false)

  // Cerrada, el campo muestra el valor elegido: lo escrito sin elegir no se queda a medias.
  useEffect(() => {
    if (!multiple && !abierto) setConsulta(textoDelValor)
  }, [multiple, abierto, textoDelValor])

  const q = consulta.trim()
  const filtradas =
    onInputChange || !filtrando || !q
      ? options
      : options.filter((o) => normalizarTexto(o.label).includes(normalizarTexto(q)))
  const exacta = q ? options.find((o) => normalizarTexto(o.label) === normalizarTexto(q)) : undefined

  // Orden de pintado: sin grupo primero y luego cada grupo en el orden en que aparece.
  const secciones: { grupo?: string; items: Item[] }[] = [{ items: [] }]
  for (const opcion of filtradas) {
    const grupo = opcion.group
    let seccion = secciones.find((s) => s.grupo === grupo)
    if (!seccion) {
      seccion = { grupo, items: [] }
      secciones.push(seccion)
    }
    seccion.items.push({ opcion })
  }
  if (allowCreate && filtrando && q && !exacta) {
    secciones.push({ items: [{ opcion: { value: q, label: `Crear «${q}»` }, crear: true }] })
  }
  const items = secciones.flatMap((s) => s.items)
  const habilitado = (i: number) => {
    const item = items[i]
    return item !== undefined && !item.opcion.disabled
  }
  const primera = () => items.findIndex((_, i) => habilitado(i))
  const ultima = () => {
    for (let i = items.length - 1; i >= 0; i--) if (habilitado(i)) return i
    return -1
  }
  const siguiente = (desde: number, paso: 1 | -1) => {
    for (let i = desde + paso; i >= 0 && i < items.length; i += paso) if (habilitado(i)) return i
    return desde
  }

  const abrir = (indice: number) => {
    setAbierto(true)
    setActiva(indice)
  }
  const cerrar = () => {
    setAbierto(false)
    setActiva(-1)
    setFiltrando(false)
  }

  const elegir = (item: Item) => {
    if (item.opcion.disabled) return
    const v = item.opcion.value
    if (multiple) {
      cambiarValor(elegidos.includes(v) ? elegidos.filter((x) => x !== v) : [...elegidos, v])
      // En múltiple la lista sigue abierta y la consulta se limpia: encadenar elecciones es
      // el caso normal y volver a borrar el filtro a mano cansa.
      setConsulta('')
      setFiltrando(false)
      onInputChange?.('')
    } else {
      cambiarValor(v)
      setConsulta(item.crear ? v : item.opcion.label)
      cerrar()
    }
  }
  const quitar = (v: string) => cambiarValor(elegidos.filter((x) => x !== v))

  // La opción activa siempre visible dentro de la lista con scroll.
  useEffect(() => {
    if (!abierto || activa < 0) return
    document.getElementById(`${id}-opt-${activa}`)?.scrollIntoView?.({ block: 'nearest' })
  }, [abierto, activa, id])

  // Abierta, la lista sube a la capa superior junto al campo, con su mismo ancho: allí no
  // la tapa una Navbar o un Banner pegajoso, ni la recorta el overflow de una tarjeta o de
  // un Modal. Antes del volteo, que la mide. Sin la API sigue anclada con la hoja.
  useEfectoDeDiseno(() => {
    if (!abierto || !lista.current || !caja.current) return
    return anclarEnCapaSuperior(lista.current, caja.current, { separacion: '--aybar-space-1', ancho: 'igual' })
  }, [abierto])

  // Voltea la lista hacia arriba si no cabe debajo del campo.
  useEfectoDeDiseno(() => {
    if (!abierto || !caja.current || !lista.current) return
    const r = caja.current.getBoundingClientRect()
    const alto = lista.current.offsetHeight
    // El alto útil, sin la barra de scroll horizontal si la hay.
    setVolteada(areaVisible().alto - r.bottom < alto && r.top > alto)
  }, [abierto, items.length])

  const teclas = (evento: KeyboardEvent<HTMLInputElement>) => {
    onKeyDown?.(evento)
    if (evento.defaultPrevented) return
    const actual = items[activa]
    switch (evento.key) {
      case 'ArrowDown':
        evento.preventDefault()
        if (!abierto) abrir(primera())
        else setActiva(activa < 0 ? primera() : siguiente(activa, 1))
        break
      case 'ArrowUp':
        evento.preventDefault()
        if (!abierto) abrir(ultima())
        // En la primera, vuelve al campo: sin opción activa.
        else setActiva(activa <= primera() ? -1 : siguiente(activa, -1))
        break
      case 'Home':
        if (!abierto) return
        evento.preventDefault()
        setActiva(primera())
        break
      case 'End':
        if (!abierto) return
        evento.preventDefault()
        setActiva(ultima())
        break
      case 'Enter':
        if (!abierto) return
        evento.preventDefault()
        if (actual) elegir(actual)
        else if (exacta && !multiple) elegir({ opcion: exacta })
        break
      case 'Tab':
        // Tab elige la activa y sigue: no deja el campo a medias.
        if (abierto && actual) elegir(actual)
        cerrar()
        break
      case 'Escape':
        if (abierto) {
          evento.preventDefault()
          evento.stopPropagation()
          cerrar()
        } else if (consulta || elegidos.length) {
          evento.preventDefault()
          setConsulta('')
          cambiarValor(multiple ? [] : undefined)
          onInputChange?.('')
        }
        break
      case 'Backspace':
        if (multiple && consulta === '' && elegidos.length) {
          evento.preventDefault()
          quitar(elegidos[elegidos.length - 1] as string)
        }
        break
    }
  }

  const textoAnuncio = !abierto
    ? ''
    : loading
      ? 'Cargando opciones'
      : items.length === 0
        ? emptyMessage
        : `${items.length} ${items.length === 1 ? 'opción' : 'opciones'}`
  const anuncio = useAnuncioDiferido(textoAnuncio, 500)

  const huerfano =
    !multiple && !allowCreate && !loading && elegidos[0] !== undefined && !options.some((o) => o.value === elegidos[0])
      ? elegidos[0]
      : null
  const invalido = Boolean(error) || resto['aria-invalid'] === true || resto['aria-invalid'] === 'true'

  let indice = -1
  const pintarItem = (item: Item): ReactNode => {
    indice += 1
    const i = indice
    const elegida = !item.crear && elegidos.includes(item.opcion.value)
    return (
      <li
        key={`${item.crear ? 'crear' : 'opt'}-${item.opcion.value}`}
        id={`${id}-opt-${i}`}
        role="option"
        aria-selected={elegida}
        aria-disabled={item.opcion.disabled || undefined}
        data-active={i === activa || undefined}
        className={cx('ay-combo__option', item.crear && 'ay-combo__option--crear')}
        onMouseDown={(evento) => {
          // El foco se queda en el input: el clic no debe disparar su blur.
          evento.preventDefault()
          elegir(item)
        }}
        onMouseMove={() => {
          if (i !== activa && !item.opcion.disabled) setActiva(i)
        }}
      >
        {item.opcion.label}
        {item.opcion.description && <span className="ay-combo__desc">{item.opcion.description}</span>}
      </li>
    )
  }

  return (
    <div className="ay-field">
      <label className="ay-label" htmlFor={id}>
        {label}
      </label>
      <div
        ref={caja}
        className={cx('ay-combo', `ay-combo--${size}`, invalido && 'is-invalid', disabled && 'is-disabled')}
      >
        {multiple &&
          elegidos.map((v) => (
            <span className="ay-chip ay-chip--removable" key={v}>
              <span className="ay-chip__text">{etiquetaDe(v)}</span>
              <button
                type="button"
                className="ay-chip__remove"
                aria-label={`Quitar ${etiquetaDe(v)}`}
                disabled={disabled}
                onClick={() => {
                  quitar(v)
                  campo.current?.focus()
                }}
              >
                <IconoCerrar lado={14} />
              </button>
            </span>
          ))}
        <input
          {...resto}
          ref={combinarRefs(ref, campo)}
          className="ay-combo__field"
          id={id}
          type="text"
          role="combobox"
          autoComplete="off"
          disabled={disabled}
          aria-expanded={abierto}
          aria-controls={idLista}
          aria-autocomplete="list"
          // La opción activa es foco virtual: el foco real nunca sale del input.
          aria-activedescendant={abierto && activa >= 0 && items[activa] ? `${id}-opt-${activa}` : undefined}
          aria-invalid={invalido || undefined}
          aria-describedby={unirIds(
            resto['aria-describedby'],
            multiple && elegidos.length > 0 && idElegidos,
            huerfano !== null && idAviso,
            error && idError,
          )}
          placeholder={placeholder}
          value={consulta}
          onChange={(evento) => {
            const texto = evento.target.value
            setConsulta(texto)
            setFiltrando(true)
            setAbierto(true)
            setActiva(texto.trim() ? 0 : -1)
            onInputChange?.(texto)
          }}
          onKeyDown={teclas}
          onBlur={(evento) => {
            onBlur?.(evento)
            // Pegar o escribir el valor completo elige la coincidencia exacta.
            if (!multiple && exacta && !exacta.disabled && exacta.value !== elegidos[0]) {
              cambiarValor(exacta.value)
            }
            cerrar()
          }}
        />
        <button
          type="button"
          className="ay-combo__trigger"
          tabIndex={-1}
          aria-label={`Mostrar ${label.toLowerCase()}`}
          aria-expanded={abierto}
          aria-controls={idLista}
          disabled={disabled}
          onMouseDown={(evento) => evento.preventDefault()}
          onClick={() => {
            if (abierto) cerrar()
            else abrir(-1)
            campo.current?.focus()
          }}
        >
          <IconoChevron />
        </button>
        <ul
          ref={lista}
          className="ay-combo__list"
          id={idLista}
          role="listbox"
          aria-label={label}
          aria-multiselectable={multiple || undefined}
          hidden={!abierto}
          data-volteada={volteada || undefined}
        >
          {loading ? (
            <li className="ay-combo__status" role="presentation">
              <SpinnerCanonico lado={16} />
              Cargando…
            </li>
          ) : items.length === 0 ? (
            // Dentro de la lista: sacarlo al campo lo convierte en un error que no lo es.
            <li className="ay-combo__status" role="presentation">
              {emptyMessage}
            </li>
          ) : (
            secciones.map((s, k) =>
              s.items.length === 0 ? null : s.grupo ? (
                <li key={`g-${s.grupo}`} role="presentation">
                  <span className="ay-combo__group" id={`${id}-grupo-${k}`} aria-hidden="true">
                    {s.grupo}
                  </span>
                  <ul role="group" aria-labelledby={`${id}-grupo-${k}`} className="ay-combo__grouplist">
                    {s.items.map(pintarItem)}
                  </ul>
                </li>
              ) : (
                s.items.map(pintarItem)
              ),
            )
          )}
        </ul>
      </div>
      {multiple && elegidos.length > 0 && (
        <span className="ay-visually-hidden" id={idElegidos}>
          {`${elegidos.length} ${elegidos.length === 1 ? 'elegido' : 'elegidos'}`}
        </span>
      )}
      {huerfano !== null && (
        <p className="ay-help ay-combo__aviso" id={idAviso}>
          {`«${huerfano}» ya no está en la lista; se conserva hasta que elijas otro valor.`}
        </p>
      )}
      <p className="ay-visually-hidden" aria-live="polite">
        {anuncio}
      </p>
      {error && (
        <p className="ay-error" id={idError}>
          {error}
        </p>
      )}
    </div>
  )
})

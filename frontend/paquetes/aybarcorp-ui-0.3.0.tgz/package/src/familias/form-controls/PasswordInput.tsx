import { forwardRef, useEffect, useId, useState } from 'react'
import type { InputHTMLAttributes, KeyboardEvent } from 'react'
import { cx } from '../../utiles.js'
import { IconoOjo, IconoOjoTachado } from './_iconos.js'
import { unirIds, useControlable } from './_internos.js'

export type AutocompletadoPassword = 'current-password' | 'new-password'

/** Una condición de la contraseña y si ya se cumple. */
export interface RequisitoPassword {
  label: string
  met: boolean
}

/** Fortaleza estimada, siempre con etiqueta textual: una barra de color no dice nada a un lector. */
export interface FortalezaPassword {
  score: 0 | 1 | 2 | 3 | 4
  label: string
}

export interface PropsPasswordInput
  extends Omit<
    InputHTMLAttributes<HTMLInputElement>,
    'className' | 'type' | 'value' | 'defaultValue' | 'onChange' | 'autoComplete'
  > {
  /** Etiqueta visible; obligatoria. «Contraseña» o «Contraseña nueva», sin instrucciones. */
  label: string
  /** Valor. Si se omite, el campo lleva su propio estado. El pegado nunca se bloquea. */
  value?: string
  /** Cambio de valor. */
  onValueChange?: (v: string) => void
  /** `new-password` en creación y `current-password` en acceso: sin ellos, el gestor de
   *  contraseñas no propone, no genera y no guarda. */
  autoComplete?: AutocompletadoPassword
  /** Condiciones y su cumplimiento, visibles antes de escribir y asociadas al campo. Cada
   *  una dice su estado con texto, no solo con color. Solo en creación: en el acceso estorban. */
  requirements?: RequisitoPassword[]
  /** Fortaleza con etiqueta textual: «Fortaleza: media». */
  strength?: FortalezaPassword
  /** Nombre del botón de revelar cuando la contraseña está oculta. Al revelarla pasa a
   *  «Ocultar…», y `aria-pressed` refleja el estado. */
  revealLabel?: string
  /** Mensaje de error. En el acceso no revela qué parte falló: «Las credenciales no son
   *  correctas». */
  error?: string
}

/** «Mostrar la contraseña» → «Ocultar la contraseña»; cualquier otro texto, el genérico. */
const nombreOcultar = (mostrar: string) =>
  /^mostrar\b/i.test(mostrar) ? mostrar.replace(/^mostrar/i, 'Ocultar') : 'Ocultar la contraseña'

/**
 * Contraseña con la opción de revelarla para comprobar lo escrito. El botón de revelar es
 * un toggle con `aria-pressed` y el foco se queda en él. Al abandonar la vista, la
 * contraseña vuelve a ocultarse; con Bloq Mayús activo se avisa sin bloquear.
 */
export const PasswordInput = forwardRef<HTMLInputElement, PropsPasswordInput>(function PasswordInput(
  {
    label,
    value,
    onValueChange,
    autoComplete = 'current-password',
    requirements,
    strength,
    revealLabel = 'Mostrar la contraseña',
    error,
    id: idPropio,
    disabled,
    onKeyDown,
    onKeyUp,
    onBlur,
    ...resto
  },
  ref,
) {
  const automatico = useId()
  const id = idPropio ?? automatico
  const idRequisitos = `${id}-req`
  const idFortaleza = `${id}-fuerza`
  const idError = `${id}-error`
  const idMayusculas = `${id}-mayus`
  const [actual, cambiar] = useControlable(value, '', onValueChange)
  const [revelada, setRevelada] = useState(false)
  const [mayusculas, setMayusculas] = useState(false)

  // Contraseña revelada y la persona deja la vista: al volver, está otra vez oculta.
  useEffect(() => {
    const alCambiarVisibilidad = () => {
      if (document.visibilityState === 'hidden') setRevelada(false)
    }
    document.addEventListener('visibilitychange', alCambiarVisibilidad)
    return () => document.removeEventListener('visibilitychange', alCambiarVisibilidad)
  }, [])

  const leerMayusculas = (evento: KeyboardEvent<HTMLInputElement>) =>
    setMayusculas(evento.getModifierState?.('CapsLock') ?? false)

  const hayRequisitos = Boolean(requirements && requirements.length > 0)
  const invalido = Boolean(error) || resto['aria-invalid'] === true || resto['aria-invalid'] === 'true'

  return (
    <div className="ay-field">
      <label className="ay-label" htmlFor={id}>
        {label}
      </label>
      <div className={cx('ay-password', invalido && 'is-invalid', disabled && 'is-disabled')}>
        <input
          {...resto}
          ref={ref}
          className="ay-password__field"
          id={id}
          type={revelada ? 'text' : 'password'}
          value={actual}
          disabled={disabled}
          autoComplete={autoComplete}
          spellCheck={false}
          autoCapitalize="off"
          aria-invalid={invalido || undefined}
          // Requisitos, fortaleza y error en ese orden: primero la regla, luego el estado.
          aria-describedby={unirIds(
            resto['aria-describedby'],
            hayRequisitos && idRequisitos,
            strength && idFortaleza,
            error && idError,
            mayusculas && idMayusculas,
          )}
          onChange={(evento) => cambiar(evento.target.value)}
          onKeyDown={(evento) => {
            onKeyDown?.(evento)
            leerMayusculas(evento)
          }}
          onKeyUp={(evento) => {
            onKeyUp?.(evento)
            leerMayusculas(evento)
          }}
          onBlur={(evento) => {
            onBlur?.(evento)
            setMayusculas(false)
          }}
        />
        <button
          type="button"
          className="ay-password__reveal"
          aria-pressed={revelada}
          aria-label={revelada ? nombreOcultar(revealLabel) : revealLabel}
          aria-controls={id}
          disabled={disabled}
          // El foco se queda en el botón: llevarlo al campo interrumpe a quien escribe.
          onClick={() => setRevelada((r) => !r)}
        >
          {revelada ? <IconoOjoTachado /> : <IconoOjo />}
        </button>
      </div>
      {mayusculas && (
        <p className="ay-help ay-password__caps" id={idMayusculas} role="status">
          Bloq Mayús está activado.
        </p>
      )}
      {strength && (
        <div className="ay-password__strength" data-score={strength.score}>
          <span className="ay-password__bar" aria-hidden="true" />
          <span className="ay-password__strength-label" id={idFortaleza}>
            Fortaleza: {strength.label}
          </span>
        </div>
      )}
      {hayRequisitos && (
        <ul className="ay-password__req" id={idRequisitos}>
          {requirements?.map((r) => (
            <li key={r.label} data-met={r.met}>
              <span aria-hidden="true">{r.met ? '✓' : '·'}</span>{' '}
              <span className="ay-visually-hidden">{r.met ? 'Cumplido: ' : 'Pendiente: '}</span>
              {r.label}
            </li>
          ))}
        </ul>
      )}
      {error && (
        <p className="ay-error" id={idError}>
          {error}
        </p>
      )}
    </div>
  )
})

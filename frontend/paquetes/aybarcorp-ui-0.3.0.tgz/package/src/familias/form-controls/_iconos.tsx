/**
 * Glifos de la familia Form Controls. Todos son decorativos y van `aria-hidden`: el
 * nombre accesible lo da siempre el control o el botón que los contiene. Viven aquí
 * y no en otra familia porque una familia no importa componentes de otra; el
 * indicador de carga se pinta con el marcado canónico de Spinner (`.ay-spinner`).
 */
import type { SVGAttributes } from 'react'

type PropsGlifo = Omit<SVGAttributes<SVGSVGElement>, 'children'> & { lado?: number }

const base = (lado: number) =>
  ({
    width: lado,
    height: lado,
    viewBox: '0 0 24 24',
    fill: 'none',
    stroke: 'currentColor',
    strokeWidth: 2,
    strokeLinecap: 'round',
    strokeLinejoin: 'round',
    'aria-hidden': true,
    focusable: false,
  }) as const

export function IconoChevron({ lado = 16, ...resto }: PropsGlifo) {
  return (
    <svg {...base(lado)} {...resto}>
      <path d="m6 9 6 6 6-6" />
    </svg>
  )
}

export function IconoLupa({ lado = 16, ...resto }: PropsGlifo) {
  return (
    <svg {...base(lado)} {...resto}>
      <circle cx="11" cy="11" r="7" />
      <path d="m20 20-3.5-3.5" />
    </svg>
  )
}

export function IconoCerrar({ lado = 16, ...resto }: PropsGlifo) {
  return (
    <svg {...base(lado)} {...resto}>
      <path d="M18 6 6 18M6 6l12 12" />
    </svg>
  )
}

export function IconoOjo({ lado = 18, ...resto }: PropsGlifo) {
  return (
    <svg {...base(lado)} {...resto}>
      <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z" />
      <circle cx="12" cy="12" r="3" />
    </svg>
  )
}

export function IconoOjoTachado({ lado = 18, ...resto }: PropsGlifo) {
  return (
    <svg {...base(lado)} {...resto}>
      <path d="M10.6 5.1A10.4 10.4 0 0 1 12 5c6.5 0 10 7 10 7a17.6 17.6 0 0 1-2.7 3.6" />
      <path d="M6.6 6.6C3.7 8.5 2 12 2 12s3.5 7 10 7a9.9 9.9 0 0 0 5.4-1.6" />
      <path d="M9.9 9.9a3 3 0 0 0 4.2 4.2" />
      <path d="m2 2 20 20" />
    </svg>
  )
}

/** Marcado canónico de Spinner (familia Feedback): la animación sale de `.ay-spinner`. */
export function SpinnerCanonico({ lado = 16, ...resto }: PropsGlifo) {
  return (
    <svg
      {...resto}
      className={['ay-spinner', resto.className].filter(Boolean).join(' ')}
      width={lado}
      height={lado}
      viewBox="0 0 24 24"
      fill="none"
      aria-hidden="true"
      focusable="false"
    >
      <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3" strokeOpacity="0.25" />
      <path d="M22 12a10 10 0 0 0-10-10" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
    </svg>
  )
}

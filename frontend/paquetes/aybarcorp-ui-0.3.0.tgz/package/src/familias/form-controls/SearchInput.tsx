import { forwardRef, useEffect, useId, useRef, useState } from 'react'
import type { InputHTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import { IconoCerrar, IconoLupa, SpinnerCanonico } from './_iconos.js'
import { combinarRefs, pegarEnUnaLinea } from './_internos.js'

export type TamanoSearchInput = 'sm' | 'md' | 'lg'

export interface PropsSearchInput
  extends Omit<
    InputHTMLAttributes<HTMLInputElement>,
    'className' | 'type' | 'value' | 'defaultValue' | 'onChange' | 'size' | 'placeholder'
  > {
  /** Nombre accesible; obligatorio aunque no sea visible. Dice el alcance: «Buscar unidades». */
  label: string
  /** Término de búsqueda. Lo escrito se ve al instante; al padre llega por `onValueChange`. */
  value?: string
  /** Cambio del término. En el filtrado inmediato llega con `debounce` de retardo; con
   *  `onSearch`, en cada cambio. Limpiar lo notifica al momento. */
  onValueChange?: (v: string) => void
  /** Envío explícito con Enter. Si se omite, el filtrado es inmediato al escribir. */
  onSearch?: (v: string) => void
  /** Por qué campos busca: «Número, comprador o referencia». No sustituye a `label`. */
  placeholder?: string
  /** Muestra el spinner en lugar de la lupa y marca `aria-busy` en el contenedor. */
  loading?: boolean
  /** Recuento que se anuncia en la live region tras la búsqueda: «12 unidades encontradas». */
  resultCount?: number
  /** Retardo del filtrado inmediato, en milisegundos. */
  debounce?: number
  /** Altura: `sm` dentro de Table Toolbar, `lg` en pantallas de búsqueda dedicadas. */
  size?: TamanoSearchInput
  /** Entidad que se cuenta en el anuncio del recuento: «unidades», «promociones». */
  itemLabel?: string
}

/** «encontradas» para las entidades femeninas más habituales; si no, «encontrados». */
const participio = (entidad: string) =>
  /(as|dades|ciones|siones)$/i.test(entidad.trim()) ? 'encontradas' : 'encontrados'

/**
 * Filtrar o buscar dentro de un conjunto de datos, con el término siempre visible y una
 * forma clara de limpiarlo. Escape limpia, como en un `input type="search"` nativo; el
 * recuento se anuncia agrupado en una live region y no en cada pulsación.
 */
export const SearchInput = forwardRef<HTMLInputElement, PropsSearchInput>(function SearchInput(
  {
    label,
    value = '',
    onValueChange,
    onSearch,
    placeholder,
    loading = false,
    resultCount,
    debounce = 300,
    size = 'md',
    itemLabel = 'resultados',
    id: idPropio,
    onKeyDown,
    onPaste,
    ...resto
  },
  ref,
) {
  const automatico = useId()
  const id = idPropio ?? automatico
  const campo = useRef<HTMLInputElement | null>(null)
  const [texto, setTexto] = useState(value)
  const emitido = useRef(value)
  const temporizador = useRef<ReturnType<typeof setTimeout> | undefined>(undefined)

  // Solo un cambio externo pisa lo escrito; el eco del propio valor emitido no.
  useEffect(() => {
    if (value !== emitido.current) {
      emitido.current = value
      setTexto(value)
    }
  }, [value])
  useEffect(() => () => clearTimeout(temporizador.current), [])

  const emitir = (v: string) => {
    clearTimeout(temporizador.current)
    emitido.current = v
    onValueChange?.(v)
  }
  const escribir = (v: string) => {
    setTexto(v)
    if (onSearch) {
      emitir(v)
      return
    }
    // Filtrado inmediato con retardo: anunciar en cada pulsación lo hace inservible con lector.
    clearTimeout(temporizador.current)
    temporizador.current = setTimeout(() => emitir(v), debounce)
  }
  const limpiar = () => {
    setTexto('')
    emitir('')
    campo.current?.focus()
  }

  const anuncio =
    resultCount === undefined ? '' : `${resultCount} ${itemLabel} ${participio(itemLabel)}`

  return (
    <>
      <div className={cx('ay-search', `ay-search--${size}`)} aria-busy={loading || undefined}>
        <label className="ay-visually-hidden" htmlFor={id}>
          {label}
        </label>
        {loading ? (
          <SpinnerCanonico className="ay-search__icon" lado={16} />
        ) : (
          <IconoLupa className="ay-search__icon" />
        )}
        <input
          {...resto}
          ref={combinarRefs(ref, campo)}
          className="ay-search__field"
          id={id}
          type="search"
          value={texto}
          placeholder={placeholder}
          onChange={(evento) => escribir(evento.target.value)}
          onPaste={(evento) => {
            onPaste?.(evento)
            if (!evento.defaultPrevented) pegarEnUnaLinea(evento)
          }}
          onKeyDown={(evento) => {
            onKeyDown?.(evento)
            if (evento.defaultPrevented) return
            if (evento.key === 'Enter' && onSearch) {
              evento.preventDefault()
              onSearch(texto)
            }
            if (evento.key === 'Escape' && texto) {
              // Con texto, Escape limpia y no sube: un diálogo alrededor no debe cerrarse.
              evento.preventDefault()
              evento.stopPropagation()
              limpiar()
            }
          }}
        />
        {texto && (
          <button
            type="button"
            className="ay-iconbtn ay-iconbtn--ghost ay-iconbtn--sm ay-search__clear"
            aria-label="Limpiar la búsqueda"
            disabled={resto.disabled}
            onClick={limpiar}
          >
            <IconoCerrar />
          </button>
        )}
      </div>
      <p className="ay-visually-hidden" aria-live="polite">
        {anuncio}
      </p>
    </>
  )
})

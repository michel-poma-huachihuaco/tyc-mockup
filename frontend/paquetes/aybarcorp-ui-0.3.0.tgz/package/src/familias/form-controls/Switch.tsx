import { forwardRef, useId } from 'react'
import type { InputHTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import { SpinnerCanonico } from './_iconos.js'
import { unirIds, useControlable } from './_internos.js'

export type PosicionEtiquetaSwitch = 'right' | 'left'

export interface PropsSwitch
  extends Omit<
    InputHTMLAttributes<HTMLInputElement>,
    'className' | 'type' | 'role' | 'checked' | 'defaultChecked' | 'children'
  > {
  /** Estado controlado. Si se omite, el conmutador lleva su propio estado. */
  checked?: boolean
  /** Cambio de estado, con el valor nuevo. El efecto es inmediato: no hay botón Guardar. */
  onCheckedChange?: (checked: boolean) => void
  /** Nombre del ajuste; obligatorio. No cambia con el estado: nunca «Activar avisos» /
   *  «Desactivar avisos», porque el lector acabaría diciendo «Desactivar avisos, activado». */
  label: string
  /** Consecuencia del cambio, en una segunda línea alineada con la etiqueta. */
  description?: string
  /** Lado de la etiqueta. `left` alinea el conmutador al final, para filas de ajustes. */
  labelPosition?: PosicionEtiquetaSwitch
  /** Cambio en curso: el control queda inerte, muestra un indicador y lleva `aria-busy`. */
  pending?: boolean
  /** Desactiva el control conservando la posición del pulgar. */
  disabled?: boolean
}

/**
 * Preferencia que se aplica al instante y se lee como encendido o apagado. Es un
 * checkbox con `role="switch"`: el lector dice «activado» y no «marcada». Dentro de un
 * formulario que se confirma con un botón no es esto, es Checkbox.
 */
export const Switch = forwardRef<HTMLInputElement, PropsSwitch>(function Switch(
  {
    checked,
    onCheckedChange,
    label,
    description,
    labelPosition = 'right',
    pending = false,
    disabled = false,
    onChange,
    ...resto
  },
  ref,
) {
  const id = useId()
  const idTexto = `${id}-texto`
  const idDescripcion = `${id}-desc`
  const [activo, cambiar] = useControlable(checked, false, onCheckedChange)

  return (
    <label className={cx('ay-switch', `ay-switch--${labelPosition}`, pending && 'is-pending')}>
      <input
        {...resto}
        ref={ref}
        type="checkbox"
        role="switch"
        checked={activo}
        // Inerte mientras el cambio está en curso: aria-busy solo difiere los anuncios,
        // no impide una segunda pulsación.
        disabled={disabled || pending}
        aria-busy={pending || undefined}
        aria-labelledby={description ? idTexto : resto['aria-labelledby']}
        aria-describedby={unirIds(resto['aria-describedby'], description && idDescripcion)}
        onChange={(evento) => {
          onChange?.(evento)
          cambiar(evento.target.checked)
        }}
      />
      <span className="ay-switch__track" aria-hidden="true">
        <span className="ay-switch__thumb">{pending && <SpinnerCanonico lado={12} />}</span>
      </span>
      <span className="ay-switch__text">
        <span id={idTexto}>{label}</span>
        {description && (
          <span className="ay-switch__desc" id={idDescripcion}>
            {description}
          </span>
        )}
      </span>
    </label>
  )
})

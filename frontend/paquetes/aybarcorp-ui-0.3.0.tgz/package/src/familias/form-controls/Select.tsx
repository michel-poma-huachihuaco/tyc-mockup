import { forwardRef, useState } from 'react'
import type { ChangeEvent, SelectHTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import { IconoChevron } from './_iconos.js'

export type TamanoSelect = 'sm' | 'md' | 'lg'

/** Una opción de la lista. */
export interface OpcionSelect {
  value: string
  label: string
  disabled?: boolean
}

/** Un grupo de opciones relacionadas, pintado como `optgroup`. */
export interface GrupoSelect {
  label: string
  options: OpcionSelect[]
  disabled?: boolean
}

export interface PropsSelect
  extends Omit<SelectHTMLAttributes<HTMLSelectElement>, 'className' | 'size' | 'value' | 'onChange'> {
  /** Valor seleccionado, controlado. Un valor que ya no está en la lista no se borra en
   *  silencio: se conserva como opción marcada «(no disponible)». */
  value?: string
  /** Cambio de selección; recibe el evento nativo del `select`. */
  onChange?: (evento: ChangeEvent<HTMLSelectElement>) => void
  /** Opciones. Admite grupos anidados (`{ label, options }`), que salen como `optgroup`. */
  options?: (OpcionSelect | GrupoSelect)[]
  /** Texto de la opción vacía —«Selecciona el estado», no «—»—. Es una opción
   *  deshabilitada y no un valor enviable. Úsalo cuando no hay un valor por defecto
   *  legítimo: preseleccionar sesga la respuesta. */
  placeholder?: string
  /** Altura y padding, igual que Input para alinear en una fila de formulario. */
  size?: TamanoSelect
  /** Aplica `aria-invalid` y el borde de error. */
  invalid?: boolean
  /** Desactiva el control. Mientras las opciones cargan, deshabilitado y con «Cargando…»
   *  dentro: un select gris y vacío se lee como una avería. */
  disabled?: boolean
}

const esGrupo = (o: OpcionSelect | GrupoSelect): o is GrupoSelect => 'options' in o

/**
 * Lista cerrada de cuatro a quince opciones con el `select` nativo: el sistema operativo
 * dibuja la lista, resuelve el teclado y abre su rueda en móvil. No se reconstruye con
 * divs para poder estilizarla.
 */
export const Select = forwardRef<HTMLSelectElement, PropsSelect>(function Select(
  {
    value,
    onChange,
    options = [],
    placeholder,
    size = 'md',
    invalid = false,
    disabled = false,
    defaultValue,
    ...resto
  },
  ref,
) {
  const planas = options.flatMap((o) => (esGrupo(o) ? o.options : [o]))
  const [noControlado, setNoControlado] = useState(
    String(defaultValue ?? (placeholder !== undefined ? '' : (planas[0]?.value ?? ''))),
  )
  const actual = value ?? noControlado
  const vacio = actual === ''
  const invalido = invalid || resto['aria-invalid'] === true || resto['aria-invalid'] === 'true'

  // Con una sola opción posible no hay nada que elegir: se muestra como texto estático.
  // `output` y no `span` porque es etiquetable: el `for` de Form Field sigue apuntando a él.
  const unica = planas.length === 1 && options.length === 1 && placeholder === undefined && !disabled
  if (unica && planas[0]) {
    return (
      <span className="ay-selectwrap">
        <output className={cx('ay-select', `ay-select--${size}`, 'ay-select--estatico')} id={resto.id}>
          {planas[0].label}
        </output>
        {resto.name && <input type="hidden" name={resto.name} value={planas[0].value} />}
      </span>
    )
  }

  // El valor recibido que ya no existe se conserva como opción extra para no perder el dato.
  const huerfano =
    value !== undefined && value !== '' && !planas.some((o) => o.value === value) ? value : null

  const opcion = (o: OpcionSelect) => (
    <option key={o.value} value={o.value} disabled={o.disabled}>
      {o.label}
    </option>
  )

  return (
    <span className="ay-selectwrap">
      <select
        {...resto}
        ref={ref}
        value={value}
        defaultValue={value === undefined ? noControlado : undefined}
        disabled={disabled}
        aria-invalid={invalido || undefined}
        data-vacio={vacio || undefined}
        onChange={(evento) => {
          if (value === undefined) setNoControlado(evento.target.value)
          onChange?.(evento)
        }}
        className={cx('ay-select', `ay-select--${size}`)}
      >
        {placeholder !== undefined && (
          <option value="" disabled>
            {placeholder}
          </option>
        )}
        {options.map((o) =>
          esGrupo(o) ? (
            <optgroup key={`grupo-${o.label}`} label={o.label} disabled={o.disabled}>
              {o.options.map(opcion)}
            </optgroup>
          ) : (
            opcion(o)
          ),
        )}
        {huerfano !== null && (
          <option value={huerfano} disabled>
            {`${huerfano} (no disponible)`}
          </option>
        )}
      </select>
      <IconoChevron className="ay-select__chevron" />
    </span>
  )
})

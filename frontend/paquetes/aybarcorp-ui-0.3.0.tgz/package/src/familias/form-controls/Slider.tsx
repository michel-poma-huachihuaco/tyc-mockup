import { forwardRef, useEffect, useId } from 'react'
import type { CSSProperties, InputHTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import { limitar, porcentaje, useControlable } from './_internos.js'

export interface PropsSlider
  extends Omit<
    InputHTMLAttributes<HTMLInputElement>,
    'className' | 'type' | 'value' | 'defaultValue' | 'onChange' | 'min' | 'max' | 'step' | 'size'
  > {
  /** Valor actual, controlado. Si se omite, el control lleva su propio estado desde `min`.
   *  Un valor fuera de rango se ajusta al extremo más cercano y se notifica. */
  value?: number
  /** Cambio de valor, ya convertido a número. */
  onValueChange?: (value: number) => void
  /** Extremo inferior del rango. */
  min?: number
  /** Extremo superior del rango. */
  max?: number
  /** Incremento. Con `ticks`, las marcas caen sobre estos pasos. */
  step?: number
  /** Etiqueta visible; obligatoria. Nombra el dato con su unidad: «Superficie mínima (m²)». */
  label: string
  /** Formato del valor mostrado y anunciado: con él, `aria-valuetext` dice «85 m²» y no
   *  un número desnudo que no se sabe si es superficie, precio o dormitorios. */
  formatValue?: (v: number) => string
  /** Valores con marca visible bajo el raíl. Son decorativos: el valor ya está escrito
   *  junto a la etiqueta. */
  ticks?: number[]
  /** Desactiva el control: raíl y pulgar atenuados, el valor sigue legible. */
  disabled?: boolean
}

/**
 * Valor dentro de un rango continuo o por pasos, cuando importa la posición relativa más
 * que la cifra exacta. `input type="range"` nativo: rol slider, teclado y arrastre vienen
 * dados. El valor es siempre texto visible junto a la etiqueta, no un tooltip al arrastrar.
 */
export const Slider = forwardRef<HTMLInputElement, PropsSlider>(function Slider(
  {
    value,
    onValueChange,
    min = 0,
    max = 100,
    step = 1,
    label,
    formatValue,
    ticks,
    disabled = false,
    id: idPropio,
    ...resto
  },
  ref,
) {
  const automatico = useId()
  const id = idPropio ?? automatico
  const [crudo, cambiar] = useControlable(value, min, onValueChange)
  const actual = limitar(crudo, min, max)
  const formatear = (v: number) => (formatValue ? formatValue(v) : String(v))
  const texto = formatear(actual)

  // Un valor fuera de rango por un cambio de datos se ajusta al extremo y se notifica.
  useEffect(() => {
    if (crudo !== actual) cambiar(actual)
  }, [crudo, actual, cambiar])

  return (
    <div className={cx('ay-field', disabled && 'is-disabled')}>
      <div className="ay-slider__head">
        <label className="ay-label" htmlFor={id}>
          {label}
        </label>
        <output className="ay-slider__value" htmlFor={id}>
          {texto}
        </output>
      </div>
      <input
        {...resto}
        ref={ref}
        className="ay-slider"
        type="range"
        id={id}
        min={min}
        max={max}
        step={step}
        value={actual}
        disabled={disabled}
        aria-valuetext={formatValue ? texto : resto['aria-valuetext']}
        onChange={(evento) => cambiar(Number(evento.target.value))}
        style={{ ...resto.style, '--ay-fill': `${porcentaje(actual, min, max)}%` } as CSSProperties}
      />
      {ticks && ticks.length > 0 && (
        <div className="ay-slider__ticks" aria-hidden="true">
          {ticks.map((t) => {
            const pos = porcentaje(t, min, max)
            return (
              <span
                key={t}
                className={cx(pos === 0 && 'is-start', pos === 100 && 'is-end') || undefined}
                style={{ '--ay-pos': `${pos}%` } as CSSProperties}
              >
                {formatear(t)}
              </span>
            )
          })}
        </div>
      )}
    </div>
  )
})

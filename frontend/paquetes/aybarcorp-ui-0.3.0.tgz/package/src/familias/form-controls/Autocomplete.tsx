import { forwardRef, useEffect, useId, useRef, useState } from 'react'
import type { InputHTMLAttributes, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { anclarEnCapaSuperior } from '../surfaces/_capa.js'
import { SpinnerCanonico } from './_iconos.js'
import {
  combinarRefs,
  partirCoincidencia,
  unirIds,
  useControlable,
  useEfectoDeDiseno,
  useUltimo,
} from './_internos.js'

export type TamanoAutocomplete = 'md' | 'lg'

/** Una sugerencia. `data` viaja intacta hasta `onSelect`, para rellenar otros campos. */
export interface SugerenciaAutocomplete {
  id: string
  label: string
  data?: unknown
}

export interface PropsAutocomplete
  extends Omit<
    InputHTMLAttributes<HTMLInputElement>,
    'className' | 'type' | 'value' | 'defaultValue' | 'onChange' | 'onSelect' | 'size'
  > {
  /** Etiqueta visible; obligatoria. Nombra el dato: «Dirección». */
  label: string
  /** Texto del campo. Es válido por sí mismo aunque no coincida con ninguna sugerencia:
   *  no se restaura ni se descarta al salir. Si se omite, el campo lleva su propio estado. */
  value?: string
  /** Cambio de texto. */
  onValueChange?: (v: string) => void
  /** Consulta de sugerencias. Una respuesta que llega tarde se descarta: solo cuenta la
   *  de la última consulta. Si falla, el campo sigue funcionando como texto libre. */
  onQuery?: (q: string) => Promise<SugerenciaAutocomplete[]>
  /** Sugerencia elegida; permite rellenar otros campos con su `data`. */
  onSelect?: (s: SugerenciaAutocomplete) => void
  /** Caracteres mínimos para consultar. Se dice en `help` desde el principio, no como
   *  error al escribir menos. */
  minChars?: number
  /** Retardo de la consulta, en milisegundos. */
  debounce?: number
  /** Resalta con `mark` la parte escrita dentro de cada sugerencia. No cambia el texto. */
  highlight?: boolean
  /** Atribución de la fuente de las sugerencias, fija al pie de la lista. */
  attribution?: ReactNode
  /** Ayuda bajo la etiqueta; aquí va el mínimo: «Escribe al menos tres caracteres». */
  help?: string
  /** Altura del campo. */
  size?: TamanoAutocomplete
}

type Estado = 'reposo' | 'consultando' | 'listo' | 'error'

/**
 * Texto libre con sugerencias que llegan mientras se escribe, sin obligar a elegir una.
 * Mismo patrón que Combobox —foco siempre en el input, `aria-activedescendant`—, pero lo
 * escrito es el valor. No tener sugerencias no es un error: ni `aria-invalid` ni borde.
 */
export const Autocomplete = forwardRef<HTMLInputElement, PropsAutocomplete>(function Autocomplete(
  {
    label,
    value,
    onValueChange,
    onQuery,
    onSelect,
    minChars = 3,
    debounce = 300,
    highlight = true,
    attribution,
    help,
    size = 'md',
    id: idPropio,
    onKeyDown,
    onBlur,
    onFocus,
    ...resto
  },
  ref,
) {
  const automatico = useId()
  const id = idPropio ?? automatico
  const idLista = `${id}-list`
  const idAyuda = `${id}-help`
  const campo = useRef<HTMLInputElement | null>(null)
  const caja = useRef<HTMLDivElement | null>(null)
  const lista = useRef<HTMLUListElement | null>(null)
  const [texto, cambiar] = useControlable(value, '', onValueChange)
  const [sugerencias, setSugerencias] = useState<SugerenciaAutocomplete[]>([])
  const [abierto, setAbierto] = useState(false)
  const [activa, setActiva] = useState(-1)
  const [estado, setEstado] = useState<Estado>('reposo')
  const [enfocado, setEnfocado] = useState(false)
  const [reintento, setReintento] = useState(0)
  const [anuncio, setAnuncio] = useState('')
  // Solo lo que la persona escribe consulta; el texto que pone una sugerencia elegida no.
  const pedirConsulta = useRef(false)
  const turno = useRef(0)
  const consultar = useUltimo(onQuery)

  // Abierta, la lista sube a la capa superior junto al campo, con su mismo ancho: allí no
  // la tapa una Navbar o un Banner pegajoso, ni la recorta el overflow de una tarjeta o de
  // un Modal. Sin la API sigue anclada con la hoja.
  useEfectoDeDiseno(() => {
    if (!abierto || !lista.current || !caja.current) return
    return anclarEnCapaSuperior(lista.current, caja.current, { separacion: '--aybar-space-1', ancho: 'igual' })
  }, [abierto])

  useEffect(() => {
    if (!pedirConsulta.current) return
    if (texto.length < minChars || !consultar.current) {
      turno.current += 1
      setSugerencias([])
      setAbierto(false)
      setEstado('reposo')
      return
    }
    const mio = ++turno.current
    const temporizador = setTimeout(async () => {
      setEstado('consultando')
      try {
        const respuesta = (await consultar.current?.(texto)) ?? []
        // Una respuesta de una consulta anterior llega tarde y desordenada: se descarta.
        if (mio !== turno.current) return
        // Una sugerencia idéntica a lo escrito no aporta nada.
        const utiles = respuesta.filter((s) => s.label !== texto)
        setSugerencias(utiles)
        setActiva(-1)
        setEstado('listo')
        setAbierto(respuesta.length === 0 || utiles.length > 0)
        setAnuncio(
          respuesta.length === 0
            ? 'Sin sugerencias'
            : utiles.length > 0
              ? `${utiles.length} ${utiles.length === 1 ? 'sugerencia' : 'sugerencias'}`
              : '',
        )
      } catch {
        // El texto escrito no se toca: la sugerencia era una ayuda, no el dato.
        if (mio !== turno.current) return
        setEstado('error')
        setAbierto(false)
        setAnuncio('')
      }
    }, debounce)
    return () => clearTimeout(temporizador)
  }, [texto, minChars, debounce, reintento, consultar])

  const elegir = (s: SugerenciaAutocomplete) => {
    pedirConsulta.current = false
    turno.current += 1
    cambiar(s.label)
    onSelect?.(s)
    setAbierto(false)
    setActiva(-1)
    setAnuncio(`Elegida: ${s.label}`)
  }

  const marcar = (etiqueta: string): ReactNode => {
    if (!highlight) return etiqueta
    const partes = partirCoincidencia(etiqueta, texto)
    if (!partes) return etiqueta
    return (
      <>
        {partes[0]}
        <mark>{partes[1]}</mark>
        {partes[2]}
      </>
    )
  }

  const faltan = minChars - texto.length
  const bajoMinimo = enfocado && texto.length > 0 && faltan > 0 && Boolean(onQuery)

  return (
    <div className="ay-field">
      <label className="ay-label" htmlFor={id}>
        {label}
      </label>
      {help && (
        <p className="ay-help" id={idAyuda}>
          {help}
        </p>
      )}
      <div ref={caja} className={cx('ay-autocomplete', `ay-autocomplete--${size}`)}>
        <input
          {...resto}
          ref={combinarRefs(ref, campo)}
          className="ay-autocomplete__field"
          id={id}
          type="text"
          role="combobox"
          autoComplete={resto.autoComplete ?? 'off'}
          aria-expanded={abierto}
          aria-controls={idLista}
          aria-autocomplete="list"
          aria-activedescendant={abierto && activa >= 0 ? `${id}-opt-${activa}` : undefined}
          // Sin aria-invalid: no tener sugerencias no es un error de validación.
          aria-describedby={unirIds(help && idAyuda, resto['aria-describedby'])}
          aria-busy={estado === 'consultando' || undefined}
          value={texto}
          onChange={(evento) => {
            pedirConsulta.current = true
            cambiar(evento.target.value)
          }}
          onFocus={(evento) => {
            onFocus?.(evento)
            setEnfocado(true)
          }}
          onBlur={(evento) => {
            onBlur?.(evento)
            setEnfocado(false)
            setAbierto(false)
            setActiva(-1)
          }}
          onKeyDown={(evento) => {
            onKeyDown?.(evento)
            if (evento.defaultPrevented) return
            const ultimo = sugerencias.length - 1
            switch (evento.key) {
              case 'ArrowDown':
                if (ultimo < 0) return
                evento.preventDefault()
                setAbierto(true)
                setActiva((i) => Math.min(ultimo, i + 1))
                break
              case 'ArrowUp':
                if (ultimo < 0) return
                evento.preventDefault()
                setAbierto(true)
                setActiva((i) => Math.max(-1, i - 1))
                break
              case 'Enter': {
                // Sin sugerencia activa, Enter envía el formulario con lo escrito.
                const s = abierto && activa >= 0 ? sugerencias[activa] : undefined
                if (!s) return
                evento.preventDefault()
                elegir(s)
                break
              }
              case 'Escape':
                // Cierra y conserva lo escrito.
                if (!abierto) return
                evento.preventDefault()
                evento.stopPropagation()
                setAbierto(false)
                setActiva(-1)
                break
              case 'Tab':
                // Sale conservando el texto, sin elegir sugerencia.
                setAbierto(false)
                setActiva(-1)
                break
            }
          }}
        />
        {estado === 'consultando' && <SpinnerCanonico className="ay-autocomplete__spinner" lado={16} />}
        <ul
          ref={lista}
          className="ay-autocomplete__list"
          id={idLista}
          role="listbox"
          aria-label={`Sugerencias de ${label.toLowerCase()}`}
          hidden={!abierto}
        >
          {sugerencias.length === 0 && estado === 'listo' && (
            <li className="ay-autocomplete__status" role="presentation">
              {`Sin sugerencias; puedes escribir la ${label.toLowerCase()} completa.`}
            </li>
          )}
          {sugerencias.map((s, i) => (
            <li
              key={s.id}
              id={`${id}-opt-${i}`}
              role="option"
              aria-selected={false}
              data-active={i === activa || undefined}
              className="ay-autocomplete__option"
              onMouseDown={(evento) => {
                evento.preventDefault()
                elegir(s)
              }}
              onMouseMove={() => {
                if (i !== activa) setActiva(i)
              }}
            >
              {marcar(s.label)}
            </li>
          ))}
          {attribution && (
            <li className="ay-autocomplete__attr" role="presentation">
              {attribution}
            </li>
          )}
        </ul>
      </div>
      {bajoMinimo && (
        <p className="ay-help ay-autocomplete__min">
          {`Escribe ${faltan} ${faltan === 1 ? 'carácter' : 'caracteres'} más para ver sugerencias.`}
        </p>
      )}
      {estado === 'error' && (
        <p className="ay-autocomplete__error" role="status">
          {`No se pudieron cargar las sugerencias. Puedes escribir la ${label.toLowerCase()} completa.`}{' '}
          <button
            type="button"
            className="ay-btn ay-btn--ghost ay-btn--sm"
            onClick={() => {
              pedirConsulta.current = true
              setReintento((n) => n + 1)
              campo.current?.focus()
            }}
          >
            Reintentar
          </button>
        </p>
      )}
      <p className="ay-visually-hidden" aria-live="polite">
        {anuncio}
      </p>
    </div>
  )
})

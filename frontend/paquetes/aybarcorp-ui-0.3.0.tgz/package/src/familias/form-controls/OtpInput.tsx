import { forwardRef, useEffect, useId, useRef } from 'react'
import type { FieldsetHTMLAttributes, KeyboardEvent } from 'react'
import { cx } from '../../utiles.js'
import { useControlable } from './_internos.js'

export type TipoOtp = 'numeric' | 'alphanumeric'

export interface PropsOtpInput
  extends Omit<FieldsetHTMLAttributes<HTMLFieldSetElement>, 'className' | 'onChange' | 'disabled'> {
  /** Número de caracteres, una celda por cada uno. */
  length?: number
  /** Código introducido. Si se omite, el grupo lleva su propio estado. */
  value?: string
  /** Cambio del código, ya limpio de espacios y guiones y en mayúsculas. */
  onValueChange?: (v: string) => void
  /** Se dispara al completar la última celda, también cuando el sistema rellena el
   *  código de una vez o se pega entero. */
  onComplete?: (v: string) => void
  /** Etiqueta del grupo; obligatoria. Nombra el origen del código: «Código enviado a tu
   *  teléfono». Cada celda lleva además «Dígito 1 de 6». */
  label: string
  /** Caracteres admitidos. `numeric` saca el teclado de cifras en móvil. */
  type?: TipoOtp
  /** Mensaje de error del grupo. Se anuncia una sola vez, no una por celda, y marca
   *  `aria-invalid` en todas las celdas. */
  error?: string
  /** Desactiva todas las celdas, por ejemplo mientras se verifica. */
  disabled?: boolean
}

/**
 * Código de un solo uso repartido en celdas. Pegar reparte el código completo desde
 * cualquier celda; `autocomplete="one-time-code"` deja que el sistema ofrezca el código
 * recibido por SMS. No es para contraseñas: esas no tienen longitud fija.
 */
export const OtpInput = forwardRef<HTMLFieldSetElement, PropsOtpInput>(function OtpInput(
  {
    length = 6,
    value,
    onValueChange,
    onComplete,
    label,
    type = 'numeric',
    error,
    disabled = false,
    ...resto
  },
  ref,
) {
  const id = useId()
  const idError = `${id}-error`
  const celdas = useRef<(HTMLInputElement | null)[]>([])
  const [codigo, cambiar] = useControlable(value, '', onValueChange)
  const actual = codigo.slice(0, length)
  const previo = useRef(actual)
  // Código vigente sin esperar al render: escribir y mover el foco ocurren en el mismo
  // evento, y el onFocus de la celda destino todavía ve el código de antes del cambio.
  const vigente = useRef(actual)
  vigente.current = actual
  const patron = type === 'numeric' ? /[^0-9]/g : /[^0-9a-z]/gi
  const nombreCelda = type === 'numeric' ? 'Dígito' : 'Carácter'

  const enfocar = (i: number) => {
    const celda = celdas.current[Math.max(0, Math.min(i, length - 1))]
    celda?.focus()
    celda?.select()
  }

  // Código caducado: si el valor se vacía desde fuera, el foco vuelve a la primera celda.
  useEffect(() => {
    if (previo.current && !actual && celdas.current.some((c) => c === document.activeElement)) enfocar(0)
    previo.current = actual
  })

  const escribir = (i: number, crudo: string) => {
    // Celda vaciada sin pasar por keydown —teclados virtuales que no envían Backspace—.
    if (crudo === '') {
      if (actual[i]) {
        vigente.current = actual.slice(0, i) + actual.slice(i + 1)
        cambiar(vigente.current)
      }
      return
    }
    const anterior = actual[i] ?? ''
    let entrada = crudo
    // La celda ya tenía carácter y el cursor no lo seleccionaba: se toma solo lo nuevo.
    if (anterior && crudo.length > 1) {
      if (crudo.startsWith(anterior)) entrada = crudo.slice(anterior.length)
      else if (crudo.endsWith(anterior)) entrada = crudo.slice(0, -anterior.length)
    }
    const limpio = entrada.replace(patron, '').toUpperCase()
    if (!limpio) return
    const siguiente = (actual.slice(0, i) + limpio + actual.slice(i + limpio.length)).slice(0, length)
    vigente.current = siguiente
    cambiar(siguiente)
    enfocar(Math.min(i + limpio.length, length - 1))
    if (siguiente.length === length) onComplete?.(siguiente)
  }

  const borrar = (j: number) => {
    vigente.current = actual.slice(0, j) + actual.slice(j + 1)
    cambiar(vigente.current)
  }

  const teclas = (i: number) => (evento: KeyboardEvent<HTMLInputElement>) => {
    switch (evento.key) {
      case 'Backspace': {
        evento.preventDefault()
        // Con la celda vacía, el retroceso borra la anterior y salta a ella.
        const j = actual[i] ? i : Math.max(0, i - 1)
        if (actual[j]) borrar(j)
        enfocar(j)
        break
      }
      case 'Delete':
        evento.preventDefault()
        if (actual[i]) borrar(i)
        break
      case 'ArrowLeft':
        evento.preventDefault()
        enfocar(i - 1)
        break
      case 'ArrowRight':
        evento.preventDefault()
        enfocar(Math.min(i + 1, actual.length))
        break
      case 'Home':
        evento.preventDefault()
        enfocar(0)
        break
      case 'End':
        evento.preventDefault()
        enfocar(actual.length)
        break
    }
  }

  return (
    <fieldset
      {...resto}
      ref={ref}
      className={cx('ay-otp', error && 'is-invalid')}
      disabled={disabled}
      aria-describedby={error ? idError : resto['aria-describedby']}
    >
      <legend className="ay-label">{label}</legend>
      <div className="ay-otp__cells">
        {Array.from({ length }, (_, i) => (
          <input
            key={i}
            ref={(nodo) => {
              celdas.current[i] = nodo
            }}
            className="ay-otp__cell"
            type="text"
            inputMode={type === 'numeric' ? 'numeric' : 'text'}
            // maxLength es la longitud del código, no 1: así se puede pegar entero en una celda.
            maxLength={length}
            autoComplete={i === 0 ? 'one-time-code' : 'off'}
            autoCapitalize={type === 'alphanumeric' ? 'characters' : 'off'}
            spellCheck={false}
            aria-label={`${nombreCelda} ${i + 1} de ${length}`}
            aria-invalid={error ? true : undefined}
            value={actual[i] ?? ''}
            disabled={disabled}
            onFocus={(evento) => {
              // El código no admite huecos: una celda más allá de la primera vacía no se rellena.
              const largo = vigente.current.length
              if (i > largo) enfocar(largo)
              else evento.target.select()
            }}
            onChange={(evento) => escribir(i, evento.target.value)}
            onKeyDown={teclas(i)}
          />
        ))}
      </div>
      {error && (
        <p className="ay-error" id={idError} role="alert">
          {error}
        </p>
      )}
    </fieldset>
  )
})

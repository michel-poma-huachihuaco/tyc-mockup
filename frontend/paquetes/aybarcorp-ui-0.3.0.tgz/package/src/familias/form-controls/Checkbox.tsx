import { forwardRef, useId, useRef } from 'react'
import type { ChangeEvent, InputHTMLAttributes, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { combinarRefs, unirIds, useControlable, useEfectoDeDiseno } from './_internos.js'

export interface PropsCheckbox
  extends Omit<InputHTMLAttributes<HTMLInputElement>, 'className' | 'type' | 'checked' | 'defaultChecked' | 'onChange'> {
  /** Estado controlado. */
  checked?: boolean
  /** Estado inicial en modo no controlado. */
  defaultChecked?: boolean
  /** Tercer estado visual, para la cabecera de una selección parcial. Se aplica por
   *  propiedad DOM —el atributo no existe— y así el navegador expone
   *  `aria-checked="mixed"` él solo. */
  indeterminate?: boolean
  /** Cambio de estado; recibe el evento nativo del input. */
  onChange?: (evento: ChangeEvent<HTMLInputElement>) => void
  /** Etiqueta visible, a la derecha de la caja y clicable en toda su extensión. En
   *  positivo: «Recibir avisos», nunca «No recibir avisos». */
  label?: ReactNode
  /** Aclaración bajo la etiqueta, alineada con el texto y no con la caja. Se asocia como
   *  descripción, no como parte del nombre. */
  helper?: string
  /** Aplica `aria-invalid` y el borde de error: aceptación obligatoria que falta. */
  invalid?: boolean
  /** Desactiva el control conservando su estado marcado: el dato sigue siendo información. */
  disabled?: boolean
}

/**
 * Casilla para marcar ninguna, una o varias opciones independientes, o una condición que
 * aceptar. `input type="checkbox"` nativo: el rol, el estado y el anuncio los aporta el
 * navegador. Varias casillas van en un fieldset con legend (Radio Group o Form Group).
 */
export const Checkbox = forwardRef<HTMLInputElement, PropsCheckbox>(function Checkbox(
  {
    checked,
    defaultChecked = false,
    indeterminate = false,
    onChange,
    label,
    helper,
    invalid = false,
    disabled = false,
    ...resto
  },
  ref,
) {
  const id = useId()
  const interna = useRef<HTMLInputElement | null>(null)
  const idTexto = `${id}-texto`
  const idAyuda = `${id}-ayuda`
  const [marcado, marcar] = useControlable(checked, defaultChecked)

  useEfectoDeDiseno(() => {
    if (interna.current) interna.current.indeterminate = indeterminate
  }, [indeterminate, marcado])

  const invalido = invalid || resto['aria-invalid'] === true || resto['aria-invalid'] === 'true'

  return (
    <label className={cx('ay-check', invalido && 'is-invalid')}>
      <input
        {...resto}
        ref={combinarRefs(ref, interna)}
        type="checkbox"
        checked={marcado}
        disabled={disabled}
        onChange={(evento) => {
          marcar(evento.target.checked)
          onChange?.(evento)
        }}
        aria-invalid={invalido || undefined}
        // Con helper, el nombre es solo la etiqueta y la aclaración va como descripción:
        // si no, el lector la leería pegada al nombre en cada visita.
        aria-labelledby={helper && label ? idTexto : resto['aria-labelledby']}
        aria-describedby={unirIds(resto['aria-describedby'], helper && idAyuda)}
      />
      {(label || helper) && (
        <span className="ay-check__text">
          {label && <span id={idTexto}>{label}</span>}
          {helper && (
            <span className="ay-check__helper" id={idAyuda}>
              {helper}
            </span>
          )}
        </span>
      )}
    </label>
  )
})

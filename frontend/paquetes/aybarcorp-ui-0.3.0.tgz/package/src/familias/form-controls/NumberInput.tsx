import { forwardRef, useId, useState } from 'react'
import type { InputHTMLAttributes, KeyboardEvent } from 'react'
import { cx } from '../../utiles.js'
import { interpretarNumero, limitar, redondearAlPaso, unirIds, useControlable } from './_internos.js'

export type TamanoNumberInput = 'sm' | 'md' | 'lg'

export interface PropsNumberInput
  extends Omit<
    InputHTMLAttributes<HTMLInputElement>,
    'className' | 'type' | 'value' | 'defaultValue' | 'onChange' | 'min' | 'max' | 'step' | 'size' | 'prefix'
  > {
  /** Etiqueta visible; obligatoria. Nombra el dato con su unidad: «Superficie útil (m²)».
   *  También da nombre a los botones del stepper: «Aumentar dormitorios». */
  label: string
  /** Valor; `null` cuando el campo está vacío. Vaciar el campo no escribe 0: un campo
   *  vacío y un cero son datos distintos. Si se omite, el control lleva su propio estado. */
  value?: number | null
  /** Cambio de valor. Se notifica al salir del campo y con cada paso del stepper o de las
   *  flechas, no en cada pulsación. */
  onValueChange?: (v: number | null) => void
  /** Mínimo permitido. En el mínimo, el botón de reducir queda deshabilitado. */
  min?: number
  /** Máximo permitido. Lo que lo excede no se recorta al escribir: se avisa al salir. */
  max?: number
  /** Incremento del stepper y de las flechas; Re Pág / Av Pág saltan diez pasos. */
  step?: number
  /** Unidad pospuesta dentro del campo: m², %. Decorativa si la etiqueta ya la nombra; si
   *  no, entra en la descripción del campo. */
  unit?: string
  /** Símbolo antepuesto: S/ en importes, como se escribe el sol. */
  prefix?: string
  /** Configuración regional de los separadores. Se aceptan coma y punto al escribir y se
   *  normaliza al guardar. */
  locale?: string
  /** Muestra los botones de aumentar y reducir. En importes grandes se quita: incrementar
   *  de uno en uno no sirve. */
  stepper?: boolean
  /** Altura del control. */
  size?: TamanoNumberInput
  /** Mensaje de error; dice el rango válido: «Introduce un valor entre 0 y 8». */
  error?: string
}

/**
 * Cantidad exacta con teclado: importes, plazos, superficies. `type="text"` con
 * `inputMode="numeric"` y `role="spinbutton"`, no `type="number"`: el nativo admite
 * caracteres inesperados, redondea a su manera y la rueda del ratón le cambia el valor.
 */
export const NumberInput = forwardRef<HTMLInputElement, PropsNumberInput>(function NumberInput(
  {
    label,
    value,
    onValueChange,
    min,
    max,
    step = 1,
    unit,
    prefix,
    locale = 'es-PE',
    stepper = true,
    size = 'md',
    error,
    id: idPropio,
    disabled,
    onBlur,
    onKeyDown,
    ...resto
  },
  ref,
) {
  const automatico = useId()
  const id = idPropio ?? automatico
  const idError = `${id}-error`
  const idUnidad = `${id}-unidad`
  const [valor, cambiar] = useControlable<number | null>(value, null, onValueChange)
  // Lo que se está escribiendo, sin interpretar todavía: se interpreta al salir.
  const [bruto, setBruto] = useState<string | null>(null)

  const formatear = (v: number) => {
    try {
      return new Intl.NumberFormat(locale, { maximumFractionDigits: 10 }).format(v)
    } catch {
      return String(v)
    }
  }
  const texto = bruto ?? (valor === null ? '' : formatear(valor))
  const fueraDeRango =
    valor !== null && ((min !== undefined && valor < min) || (max !== undefined && valor > max))
  const invalido =
    Boolean(error) || fueraDeRango || resto['aria-invalid'] === true || resto['aria-invalid'] === 'true'

  // La unidad es decorativa si la etiqueta ya la dice; si no, va a la descripción.
  const sinNombrar = [prefix, unit].filter((s): s is string => Boolean(s) && !label.includes(s as string))

  const ajustar = (delta: number) => {
    const base = (bruto !== null ? interpretarNumero(bruto, locale) : valor) ?? min ?? 0
    setBruto(null)
    cambiar(redondearAlPaso(limitar(base + delta, min, max), step))
  }

  const teclas = (evento: KeyboardEvent<HTMLInputElement>) => {
    onKeyDown?.(evento)
    if (evento.defaultPrevented) return
    const ir = (destino: number) => {
      setBruto(null)
      cambiar(destino)
    }
    const acciones: Record<string, (() => void) | undefined> = {
      ArrowUp: () => ajustar(step),
      ArrowDown: () => ajustar(-step),
      PageUp: () => ajustar(step * 10),
      PageDown: () => ajustar(-step * 10),
      // Inicio y Fin llevan a los extremos solo si existen; si no, mueven el cursor.
      Home: min !== undefined ? () => ir(min) : undefined,
      End: max !== undefined ? () => ir(max) : undefined,
    }
    const accion = acciones[evento.key]
    if (!accion) return
    evento.preventDefault()
    accion()
  }

  const valorTexto =
    valor === null ? undefined : [prefix, formatear(valor), unit].filter(Boolean).join(' ')

  return (
    <div className="ay-field">
      <label className="ay-label" htmlFor={id}>
        {label}
      </label>
      <div
        className={cx(
          'ay-numinput',
          `ay-numinput--${size}`,
          invalido && 'is-invalid',
          disabled && 'is-disabled',
        )}
      >
        {prefix && (
          <span className="ay-numinput__prefix" aria-hidden="true">
            {prefix}
          </span>
        )}
        <input
          {...resto}
          ref={ref}
          className="ay-numinput__field"
          id={id}
          type="text"
          // Teclado de cifras en móvil; con pasos decimales o negativos hace falta el
          // teclado decimal, que trae el separador y el signo.
          inputMode={step % 1 === 0 && (min === undefined || min >= 0) ? 'numeric' : 'decimal'}
          role="spinbutton"
          autoComplete={resto.autoComplete ?? 'off'}
          value={texto}
          disabled={disabled}
          aria-valuenow={valor ?? undefined}
          aria-valuemin={min}
          aria-valuemax={max}
          aria-valuetext={valorTexto}
          aria-invalid={invalido || undefined}
          aria-describedby={unirIds(
            resto['aria-describedby'],
            sinNombrar.length > 0 && idUnidad,
            error && idError,
          )}
          onChange={(evento) => setBruto(evento.target.value)}
          onBlur={(evento) => {
            onBlur?.(evento)
            if (bruto === null) return
            const n = interpretarNumero(bruto, locale)
            setBruto(null)
            if (n !== valor) cambiar(n)
          }}
          onKeyDown={teclas}
        />
        {unit && (
          <span className="ay-numinput__unit" aria-hidden="true">
            {unit}
          </span>
        )}
        {sinNombrar.length > 0 && (
          <span className="ay-visually-hidden" id={idUnidad}>
            {`Expresado en ${sinNombrar.join(' ')}`}
          </span>
        )}
        {/* «− +» en fila: reducir primero, que es el orden del foco y el de la lectura. */}
        {stepper && (
          <div className="ay-numinput__stepper">
            <button
              type="button"
              aria-label={`Reducir ${label.toLowerCase()}`}
              disabled={disabled || (min !== undefined && valor !== null && valor <= min)}
              onClick={() => ajustar(-step)}
            >
              <span aria-hidden="true">−</span>
            </button>
            <button
              type="button"
              aria-label={`Aumentar ${label.toLowerCase()}`}
              disabled={disabled || (max !== undefined && valor !== null && valor >= max)}
              onClick={() => ajustar(step)}
            >
              <span aria-hidden="true">+</span>
            </button>
          </div>
        )}
      </div>
      {error && (
        <p className="ay-error" id={idError}>
          {error}
        </p>
      )}
    </div>
  )
})

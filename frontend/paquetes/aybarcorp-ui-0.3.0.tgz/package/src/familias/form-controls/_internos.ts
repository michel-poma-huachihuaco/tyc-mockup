/**
 * Piezas internas de la familia Form Controls. No se exportan en el índice: son el
 * detalle que comparten varios controles —estado controlado o no, anuncios diferidos,
 * normalización de texto y de cifras— y no forman parte de la API pública.
 */
import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react'
import type { ClipboardEvent, MutableRefObject, Ref, RefCallback } from 'react'

/** `useLayoutEffect` en el navegador y `useEffect` en el servidor, donde no hay layout. */
export const useEfectoDeDiseno = typeof window === 'undefined' ? useEffect : useLayoutEffect

/** Une la ref que llega por `forwardRef` con la ref interna del componente. */
export function combinarRefs<T>(...refs: (Ref<T> | undefined)[]): RefCallback<T> {
  return (nodo: T | null) => {
    for (const ref of refs) {
      if (typeof ref === 'function') ref(nodo)
      else if (ref) (ref as MutableRefObject<T | null>).current = nodo
    }
  }
}

/**
 * Estado controlado o no controlado con una sola regla: si `valor` llega por props
 * manda él; si no, el componente lleva el suyo a partir de `porDefecto`. El aviso al
 * padre ocurre en los dos modos.
 */
export function useControlable<T>(
  valor: T | undefined,
  porDefecto: T,
  alCambiar?: ((siguiente: T) => void) | null,
): [T, (siguiente: T) => void] {
  const [interno, setInterno] = useState(porDefecto)
  const controlado = valor !== undefined
  const actual = controlado ? valor : interno
  const cambiar = useCallback(
    (siguiente: T) => {
      if (!controlado) setInterno(siguiente)
      alCambiar?.(siguiente)
    },
    [controlado, alCambiar],
  )
  return [actual, cambiar]
}

/**
 * Devuelve `texto` solo cuando lleva `ms` sin cambiar. Es lo que alimenta las regiones
 * en vivo de los recuentos: anunciar en cada pulsación pisa lo que la persona escribe.
 */
export function useAnuncioDiferido(texto: string, ms: number): string {
  const [anuncio, setAnuncio] = useState('')
  useEffect(() => {
    const temporizador = setTimeout(() => setAnuncio(texto), ms)
    return () => clearTimeout(temporizador)
  }, [texto, ms])
  return anuncio
}

/** Guarda el último valor de una prop o estado sin provocar renders. */
export function useUltimo<T>(valor: T): MutableRefObject<T> {
  const ref = useRef(valor)
  ref.current = valor
  return ref
}

/** Une ids para `aria-describedby` descartando los vacíos; `undefined` si no queda ninguno. */
export function unirIds(...ids: (string | false | null | undefined)[]): string | undefined {
  const texto = ids.filter(Boolean).join(' ').trim()
  return texto || undefined
}

/** Encaja un número entre dos extremos opcionales. */
export function limitar(n: number, min?: number, max?: number): number {
  let r = n
  if (min !== undefined && r < min) r = min
  if (max !== undefined && r > max) r = max
  return r
}

/** Posición de un valor dentro del rango, en porcentaje y acotada a 0–100. */
export function porcentaje(v: number, min: number, max: number): number {
  if (max === min) return 0
  return limitar(((v - min) / (max - min)) * 100, 0, 100)
}

/** Redondea al número de decimales del paso: 0.1 + 0.2 no debe dar 0.30000000000000004. */
export function redondearAlPaso(n: number, paso: number): number {
  const decimales = (String(paso).split('.')[1] ?? '').length
  return Number(n.toFixed(decimales))
}

/** Minúsculas y sin tildes: «Perú» coincide con «peru» al filtrar. */
export function normalizarTexto(texto: string): string {
  return texto.normalize('NFD').replace(/\p{M}/gu, '').toLocaleLowerCase('es')
}

/**
 * Parte `texto` alrededor de la primera coincidencia de `consulta`, sin distinguir
 * mayúsculas ni tildes. Se compara carácter a carácter para que los índices sigan
 * siendo los del texto original y la marca caiga sobre las letras tal como se ven.
 */
export function partirCoincidencia(texto: string, consulta: string): [string, string, string] | null {
  if (!consulta) return null
  const letras = Array.from(texto)
  const plano = letras.map((c) => normalizarTexto(c))
  const buscado = Array.from(normalizarTexto(consulta))
  if (plano.some((c) => Array.from(c).length !== 1)) {
    // Un carácter que se expande al normalizar desalinea los índices: mejor sin marca.
    const i = texto.toLocaleLowerCase('es').indexOf(consulta.toLocaleLowerCase('es'))
    if (i < 0) return null
    return [texto.slice(0, i), texto.slice(i, i + consulta.length), texto.slice(i + consulta.length)]
  }
  const i = plano.join('').indexOf(buscado.join(''))
  if (i < 0) return null
  return [
    letras.slice(0, i).join(''),
    letras.slice(i, i + buscado.length).join(''),
    letras.slice(i + buscado.length).join(''),
  ]
}

/**
 * Pegar en un campo de una línea: los saltos de línea se normalizan a un espacio en
 * lugar de desaparecer pegados a la palabra siguiente, que es lo que hace el navegador.
 * Se escribe con `setRangeText` y un evento `input`, de modo que React recibe su
 * `onChange` como si se hubiera tecleado.
 */
export function pegarEnUnaLinea(evento: ClipboardEvent<HTMLInputElement>): void {
  const texto = evento.clipboardData?.getData('text') ?? ''
  if (!/[\r\n]/.test(texto)) return
  evento.preventDefault()
  const campo = evento.currentTarget
  const limpio = texto.replace(/\s*[\r\n]+\s*/g, ' ').trim()
  const inicio = campo.selectionStart ?? campo.value.length
  const fin = campo.selectionEnd ?? campo.value.length
  campo.setRangeText(limpio, inicio, fin, 'end')
  campo.dispatchEvent(new Event('input', { bubbles: true }))
}

/** Separadores de grupo y de decimales de una configuración regional. */
function separadores(locale: string): { grupo: string; decimal: string } {
  try {
    const partes = new Intl.NumberFormat(locale).formatToParts(12345.6)
    return {
      grupo: partes.find((p) => p.type === 'group')?.value ?? ',',
      decimal: partes.find((p) => p.type === 'decimal')?.value ?? '.',
    }
  } catch {
    return { grupo: ',', decimal: '.' }
  }
}

/**
 * Interpreta lo escrito en un campo numérico. Se descartan los caracteres que no son
 * cifra, signo o separador; se aceptan coma y punto como decimal; un separador repetido
 * o el de grupos de la configuración seguido de tres cifras se lee como separador de
 * miles. Vacío devuelve `null`, nunca 0: un campo vacío y un cero son datos distintos.
 */
export function interpretarNumero(texto: string, locale: string): number | null {
  const negativo = /^\s*[-−]/.test(texto)
  let limpio = texto.replace(/[^\d.,]/g, '')
  if (!/\d/.test(limpio)) return null
  const { grupo } = separadores(locale)
  const comas = (limpio.match(/,/g) ?? []).length
  const puntos = (limpio.match(/\./g) ?? []).length
  if (comas && puntos) {
    // Con los dos, el último que aparece es el decimal y el otro agrupa miles.
    const decimal = limpio.lastIndexOf(',') > limpio.lastIndexOf('.') ? ',' : '.'
    const otro = decimal === ',' ? '.' : ','
    limpio = limpio.split(otro).join('').replace(decimal, '.')
  } else if (comas || puntos) {
    const sep = comas ? ',' : '.'
    const veces = comas || puntos
    const tras = limpio.split(sep).pop() ?? ''
    if (veces > 1 || (sep === grupo && tras.length === 3)) limpio = limpio.split(sep).join('')
    else limpio = limpio.replace(sep, '.')
  }
  const n = Number(limpio)
  if (!Number.isFinite(n)) return null
  return negativo ? -n : n
}

import { forwardRef } from 'react'
import type { ChangeEvent, InputHTMLAttributes, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { pegarEnUnaLinea } from './_internos.js'

export type TamanoInput = 'sm' | 'md' | 'lg'
export type TipoInput = 'text' | 'email' | 'tel' | 'url' | 'number'

export interface PropsInput
  extends Omit<InputHTMLAttributes<HTMLInputElement>, 'className' | 'size' | 'type' | 'prefix'> {
  /** Valor controlado. Para el modo no controlado está `defaultValue`, el nativo. */
  value?: string
  /** Cambio de valor; recibe el evento nativo del campo. */
  onChange?: (evento: ChangeEvent<HTMLInputElement>) => void
  /** Tipo nativo. Decide el teclado en móvil: `email` trae la arroba y `tel` las cifras. */
  type?: TipoInput
  /** Altura y padding del control: `sm` en toolbars y tablas, `md` en formularios y `lg`
   *  en móvil o en formularios de una sola pregunta. */
  size?: TamanoInput
  /** Aplica `aria-invalid` y el borde de error. El mensaje lo pone Form Field y se
   *  enlaza por `describedBy`. */
  invalid?: boolean
  /** Desactiva el campo y lo saca del orden de tabulación. */
  disabled?: boolean
  /** No editable pero enfocable y copiable: un importe que no se puede tocar se tiene
   *  que poder seleccionar, cosa que `disabled` impide. */
  readOnly?: boolean
  /** Affix inicial no interactivo —«S/», «@» o un icono—. Es decorativo (`aria-hidden`):
   *  si el dato importa, lo dice la etiqueta. */
  prefix?: ReactNode
  /** Affix final. Si es una acción (limpiar, revelar) tiene que ser un Icon Button real,
   *  con nombre accesible; si es una validación asíncrona, un spinner. */
  suffix?: ReactNode
  /** Ids del helper y del error, separados por espacio. Lo gestiona Form Field. */
  describedBy?: string
}

/**
 * Campo de texto de una línea: nombre, correo, número de unidad, importe. Es la base de
 * Search, Password, Number y OTP. Va siempre dentro de Form Field, que pone la etiqueta
 * visible y el cableado de ayuda y error: el placeholder no sustituye a la etiqueta.
 */
export const Input = forwardRef<HTMLInputElement, PropsInput>(function Input(
  {
    value,
    onChange,
    type = 'text',
    size = 'md',
    invalid = false,
    disabled = false,
    readOnly = false,
    prefix,
    suffix,
    describedBy,
    onPaste,
    ...resto
  },
  ref,
) {
  // Form Field inyecta aria-invalid y aria-describedby al clonar el control: se respetan.
  const invalido = invalid || resto['aria-invalid'] === true || resto['aria-invalid'] === 'true'
  const campo = (
    <input
      {...resto}
      ref={ref}
      type={type}
      value={value}
      onChange={(evento) => onChange?.(evento)}
      disabled={disabled}
      readOnly={readOnly}
      aria-invalid={invalido || undefined}
      aria-describedby={describedBy ?? resto['aria-describedby']}
      onPaste={(evento) => {
        onPaste?.(evento)
        if (!evento.defaultPrevented) pegarEnUnaLinea(evento)
      }}
      className={cx('ay-input', `ay-input--${size}`)}
    />
  )
  if (!prefix && !suffix) return campo

  // Con affix, la caja es el envoltorio y el input queda desnudo dentro de ella.
  return (
    <span
      className={cx(
        'ay-inputwrap',
        `ay-inputwrap--${size}`,
        invalido && 'is-invalid',
        disabled && 'is-disabled',
        readOnly && 'is-readonly',
      )}
    >
      {prefix && (
        <span className="ay-input__affix" aria-hidden="true">
          {prefix}
        </span>
      )}
      {campo}
      {suffix && <span className="ay-input__affix ay-input__affix--end">{suffix}</span>}
    </span>
  )
})

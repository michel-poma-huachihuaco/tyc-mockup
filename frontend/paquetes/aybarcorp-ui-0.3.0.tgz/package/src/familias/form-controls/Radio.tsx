import { forwardRef, useId } from 'react'
import type { ChangeEvent, FieldsetHTMLAttributes, InputHTMLAttributes, ReactNode } from 'react'
import { unirIds } from './_internos.js'

export interface PropsRadio
  extends Omit<InputHTMLAttributes<HTMLInputElement>, 'className' | 'type' | 'name' | 'value' | 'checked' | 'onChange'> {
  /** Agrupa las opciones; obligatorio. Con el mismo `name`, el navegador aporta el
   *  tabindex itinerante y la navegación con flechas. */
  name: string
  /** Valor de la opción, el que se envía con el formulario. */
  value?: string
  /** Selección controlada. Para el modo no controlado está `defaultChecked`, el nativo. */
  checked?: boolean
  /** Cambio de selección; recibe el evento nativo del input. */
  onChange?: (evento: ChangeEvent<HTMLInputElement>) => void
  /** Etiqueta visible y clicable: amplía el objetivo hasta el ancho del texto. */
  label: ReactNode
  /** Aclaración de la opción, indentada bajo la etiqueta. Se asocia como descripción. */
  helper?: string
  /** Desactiva solo esta opción; el resto del grupo sigue operativo y las flechas la saltan. */
  disabled?: boolean
}

/**
 * Una opción de un conjunto excluyente de dos a cinco, todas visibles. Va siempre dentro
 * de un Radio Group (fieldset con legend). No se preselecciona salvo que exista un valor
 * por defecto legítimo.
 */
export const Radio = forwardRef<HTMLInputElement, PropsRadio>(function Radio(
  { name, value, checked, onChange, label, helper, disabled = false, ...resto },
  ref,
) {
  const id = useId()
  const idTexto = `${id}-texto`
  const idAyuda = `${id}-ayuda`
  return (
    <label className="ay-radio">
      <input
        {...resto}
        ref={ref}
        type="radio"
        name={name}
        value={value}
        checked={checked}
        onChange={(evento) => onChange?.(evento)}
        disabled={disabled}
        aria-labelledby={helper ? idTexto : resto['aria-labelledby']}
        aria-describedby={unirIds(resto['aria-describedby'], helper && idAyuda)}
      />
      <span className="ay-radio__text">
        <span id={idTexto}>{label}</span>
        {helper && (
          <span className="ay-radio__helper" id={idAyuda}>
            {helper}
          </span>
        )}
      </span>
    </label>
  )
})

export interface PropsRadioGroup extends Omit<FieldsetHTMLAttributes<HTMLFieldSetElement>, 'className'> {
  /** Enunciado del conjunto. Obligatorio: sin legend, el lector anuncia las opciones sin
   *  decir nunca cuál era la pregunta. */
  legend: string
}

/**
 * Fieldset con legend que da nombre a un conjunto de Radio. El error del grupo se enlaza
 * al grupo y no a una opción suelta: lo que falta es la decisión entera.
 */
export function RadioGroup({ legend, children, ...resto }: PropsRadioGroup) {
  return (
    <fieldset {...resto} className="ay-group">
      <legend className="ay-legend">{legend}</legend>
      {children}
    </fieldset>
  )
}

import { forwardRef, useEffect, useId } from 'react'
import type { CSSProperties, HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import { limitar, porcentaje, useControlable } from './_internos.js'

export interface PropsRangeSlider
  extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'defaultValue' | 'defaultChecked'> {
  /** Nombre del intervalo con su unidad; obligatorio: «Precio (S/)». Cada pulgar lleva
   *  además su propia etiqueta, «… mínimo» y «… máximo». */
  label: string
  /** Extremos actuales `[desde, hasta]`. Si se omite, el control lleva su propio estado
   *  desde el rango completo. Valores fuera de rango se ajustan al extremo y se notifican. */
  value?: [number, number]
  /** Cambio de intervalo. */
  onValueChange?: (v: [number, number]) => void
  /** Extremo inferior del rango. */
  min?: number
  /** Extremo superior del rango. */
  max?: number
  /** Incremento de los dos pulgares. */
  step?: number
  /** Separación mínima entre extremos. El pulgar se detiene al llegar a ella, igual con
   *  teclado que con ratón. */
  minDistance?: number
  /** Formato de los valores mostrados y anunciados: «284,000 soles», no «284000». */
  formatValue?: (v: number) => string
  /** Desactiva los dos pulgares; el intervalo sigue legible. */
  disabled?: boolean
}

/**
 * Intervalo con un mínimo y un máximo dentro de un rango conocido. Son dos
 * `input type="range"` superpuestos, cada uno con su etiqueta: un control con dos pulgares
 * no existe en HTML. Cada pulgar declara como límites reales el otro pulgar, no el
 * extremo del rango, y el intervalo completo es texto visible.
 */
export const RangeSlider = forwardRef<HTMLDivElement, PropsRangeSlider>(function RangeSlider(
  {
    label,
    value,
    onValueChange,
    min = 0,
    max = 100,
    step = 1,
    minDistance = 0,
    formatValue,
    disabled = false,
    ...resto
  },
  ref,
) {
  const id = useId()
  const idEtiqueta = `${id}-label`
  const [crudo, cambiar] = useControlable<[number, number]>(value, [min, max], onValueChange)
  const desde = limitar(Math.min(crudo[0], crudo[1]), min, max)
  const hasta = limitar(Math.max(crudo[0], crudo[1]), min, max)
  const f = (v: number) => (formatValue ? formatValue(v) : String(v))

  // Valores fuera de rango al cargar: se ajustan al extremo y se notifica el ajuste.
  useEffect(() => {
    if (crudo[0] !== desde || crudo[1] !== hasta) cambiar([desde, hasta])
  }, [crudo, desde, hasta, cambiar])

  const cambiarDesde = (v: number) => cambiar([limitar(Math.min(v, hasta - minDistance), min, max), hasta])
  const cambiarHasta = (v: number) => cambiar([desde, limitar(Math.max(v, desde + minDistance), min, max)])

  const sinFiltro = desde === min && hasta === max
  // Con los pulgares juntos en la mitad alta, el inferior va delante para poder moverse.
  const desdeDelante = desde > min + (max - min) / 2

  return (
    <div {...resto} ref={ref} className={cx('ay-field', disabled && 'is-disabled')}>
      <div className="ay-rangeslider__head">
        <span className="ay-label" id={idEtiqueta}>
          {label}
        </span>
        {/* El intervalo completo, visible: no solo al arrastrar. */}
        <output className="ay-rangeslider__value" htmlFor={`${id}-min ${id}-max`}>
          {sinFiltro ? `Todo el rango (sin filtro): de ${f(min)} a ${f(max)}` : `De ${f(desde)} a ${f(hasta)}`}
        </output>
      </div>
      <div
        className="ay-rangeslider"
        role="group"
        aria-labelledby={idEtiqueta}
        style={
          { '--ay-from': `${porcentaje(desde, min, max)}%`, '--ay-to': `${porcentaje(hasta, min, max)}%` } as CSSProperties
        }
      >
        <label className="ay-visually-hidden" htmlFor={`${id}-min`}>
          {label} mínimo
        </label>
        <input
          className={cx('ay-rangeslider__thumb', desdeDelante && 'is-delante')}
          id={`${id}-min`}
          type="range"
          min={min}
          max={max}
          step={step}
          value={desde}
          disabled={disabled}
          // Los límites reales son el otro pulgar, no el extremo del rango.
          aria-valuemin={min}
          aria-valuemax={hasta - minDistance}
          aria-valuetext={f(desde)}
          onChange={(evento) => cambiarDesde(Number(evento.target.value))}
        />
        <label className="ay-visually-hidden" htmlFor={`${id}-max`}>
          {label} máximo
        </label>
        <input
          className="ay-rangeslider__thumb"
          id={`${id}-max`}
          type="range"
          min={min}
          max={max}
          step={step}
          value={hasta}
          disabled={disabled}
          aria-valuemin={desde + minDistance}
          aria-valuemax={max}
          aria-valuetext={f(hasta)}
          onChange={(evento) => cambiarHasta(Number(evento.target.value))}
        />
      </div>
      <div className="ay-rangeslider__ticks" aria-hidden="true">
        <span>{f(min)}</span>
        <span>{f(max)}</span>
      </div>
    </div>
  )
})

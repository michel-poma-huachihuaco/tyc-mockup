import { forwardRef, useEffect, useId, useLayoutEffect, useRef, useState } from 'react'
import type { LiHTMLAttributes, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { anclarEnCapaSuperior } from '../surfaces/_capa.js'
import { IconoPuntos } from './_iconos.js'
import { aFecha, enfocables, fechaCompleta, textoRelativo } from './_internos.js'

export type ToneNotification = 'default' | 'critical'
export type SizeNotification = 'md' | 'sm'

export interface PropsNotification extends Omit<LiHTMLAttributes<HTMLLIElement>, 'className' | 'title'> {
  /** Qué ha pasado, con el hecho y el objeto: «Reserva nueva en la unidad 402». Es el
   *  enlace del aviso: la fila no se convierte en botón. */
  title: string
  /** Detalle en una línea —quién y cuánto: «María Rojas · S/ 284,000»—; se recorta y el
   *  detalle completo está en el registro. */
  description?: string
  /** Momento del aviso. Relativo dentro de las últimas 24 horas, con la fecha completa
   *  en el `title` del `time`. */
  date: Date
  /** Estado de lectura, `false` por omisión. «Sin leer» va escrito en el nombre
   *  accesible, no solo en el punto. Sin `read`, el aviso lleva su propio estado. */
  read?: boolean
  /** Marca como leída o no leída: al abrir el enlace y desde el menú. No reordena la
   *  lista bajo el foco. */
  onReadChange?: (read: boolean) => void
  /** Destino del aviso: el registro afectado. */
  href?: string
  /** `critical` para avisos que bloquean una operación; el tono va acompañado de la
   *  palabra «Crítico» en el nombre accesible. */
  tone?: ToneNotification
  /** Avisos del mismo tipo agrupados en la fila: «3 reservas nuevas en Miraflores». */
  groupCount?: number
  /** Acción rápida, bajo la descripción y no junto a la fecha. */
  action?: ReactNode
  /** Origen del aviso (Avatar o icono). */
  avatar?: ReactNode
  /** Quita el aviso (menú o Supr). El foco pasa al aviso siguiente; ofrecer deshacer
   *  durante unos segundos es cosa de la bandeja (Toast). */
  onDismiss?: () => void
  /** El registro ya no existe: el enlace se desactiva y este motivo lo explica. */
  hrefDisabledReason?: string
  /** Locale de la fecha. */
  locale?: string
  /** `sm` en el panel desplegable del Navbar: fila más baja y descripción en una línea. */
  size?: SizeNotification
}

/**
 * Un aviso persistente de la bandeja, dentro de una lista real (`ul.ay-notifications`).
 * El enlace vive en el título, de modo que la acción rápida y el menú del aviso siguen
 * siendo alcanzables con Tab. Para una confirmación efímera es Toast; para un aviso en el
 * flujo de la página, Alert.
 */
export const Notification = forwardRef<HTMLLIElement, PropsNotification>(function Notification(
  {
    title,
    description,
    date,
    read,
    onReadChange,
    href,
    tone = 'default',
    groupCount,
    action,
    avatar,
    onDismiss,
    hrefDisabledReason,
    locale = 'es-PE',
    size = 'md',
    onKeyDown,
    ...resto
  },
  ref,
) {
  const fila = useRef<HTMLLIElement | null>(null)
  const [interno, setInterno] = useState(false)
  const leida = read ?? interno
  const fecha = aFecha(date)
  const texto = groupCount ? `${groupCount} ${title}` : title

  const marcar = (valor: boolean) => {
    if (read === undefined) setInterno(valor)
    onReadChange?.(valor)
  }

  // Quitar devuelve el foco al aviso siguiente (o al anterior si era el último): si se
  // queda en la fila retirada, cae al documento.
  const quitar = () => {
    if (!onDismiss) return
    const actual = fila.current
    const vecina = (actual?.nextElementSibling ?? actual?.previousElementSibling) as HTMLElement | null
    const destino = vecina ? enfocables(vecina)[0] : undefined
    destino?.focus()
    onDismiss()
  }

  const prefijos = (
    <>
      {/* el estado va escrito, no solo en el punto de color */}
      {!leida && <span className="ay-visually-hidden">Sin leer. </span>}
      {tone === 'critical' && <span className="ay-visually-hidden">Crítico. </span>}
    </>
  )

  return (
    <li
      {...resto}
      ref={(el) => {
        fila.current = el
        if (typeof ref === 'function') ref(el)
        else if (ref) ref.current = el
      }}
      className={cx(
        'ay-notification',
        !leida && 'ay-notification--unread',
        tone === 'critical' && 'ay-notification--critical',
        size === 'sm' && 'ay-notification--sm',
      )}
      onKeyDown={(e) => {
        onKeyDown?.(e)
        if (e.key === 'Delete' && onDismiss && !e.defaultPrevented) {
          e.preventDefault()
          quitar()
        }
      }}
    >
      {/* siempre presente: una fila leída conserva la alineación con las no leídas */}
      <span className="ay-notification__dot" aria-hidden="true" />
      {avatar}

      <div className="ay-notification__body">
        <p className="ay-notification__title">
          {href && !hrefDisabledReason ? (
            // el enlace vive en el título: una fila-botón atraparía el menú y la acción
            <a href={href} onClick={() => !leida && marcar(true)}>
              {prefijos}
              {texto}
            </a>
          ) : (
            <span>
              {prefijos}
              {texto}
              {hrefDisabledReason && <span className="ay-notification__gone"> · {hrefDisabledReason}</span>}
            </span>
          )}
        </p>

        {description && <p className="ay-notification__desc">{description}</p>}

        <time
          className="ay-notification__time"
          dateTime={fecha.toISOString()}
          title={fechaCompleta(fecha, locale)}
          suppressHydrationWarning
        >
          {textoRelativo(fecha, locale)}
        </time>

        {/* bajo la descripción, no junto a la fecha */}
        {action && <div className="ay-notification__action">{action}</div>}
      </div>

      <MenuDelAviso
        label={`Acciones del aviso: ${texto}`}
        opciones={[
          // no reordena la lista bajo el foco
          { id: 'read', label: leida ? 'Marcar como no leída' : 'Marcar como leída', alElegir: () => marcar(!leida) },
          ...(onDismiss ? [{ id: 'dismiss', label: 'Quitar el aviso', peligro: true, alElegir: quitar }] : []),
        ]}
      />
    </li>
  )
})

type Opcion = { id: string; label: string; peligro?: boolean; alElegir: () => void }

/**
 * Menú del aviso con el marcado canónico de Dropdown Menu (Overlays): disparador con
 * `aria-haspopup="menu"` y `aria-expanded`, `role="menu"` con foco móvil, flechas, Inicio,
 * Fin y Escape, que lo cierra y devuelve el foco al disparador.
 */
function MenuDelAviso({ label, opciones }: { label: string; opciones: Opcion[] }) {
  const id = useId()
  const [abierto, setAbierto] = useState(false)
  const [activo, setActivo] = useState(0)
  const disparador = useRef<HTMLButtonElement>(null)
  const contenedor = useRef<HTMLDivElement>(null)
  const menu = useRef<HTMLDivElement>(null)
  const items = useRef<(HTMLButtonElement | null)[]>([])

  // Abierto, el menú sube a la capa superior bajo el botón, alineado a su borde final: allí
  // no lo recorta el overflow de la lista de avisos ni lo tapa nada pegajoso. Antes de que el
  // foco entre en una acción. Sin la API sigue anclado con la hoja.
  useLayoutEffect(() => {
    if (!abierto || !menu.current || !contenedor.current) return
    return anclarEnCapaSuperior(menu.current, contenedor.current, { alineacion: 'fin' })
  }, [abierto])

  useEffect(() => {
    if (abierto) items.current[activo]?.focus()
  }, [abierto, activo])

  useEffect(() => {
    if (!abierto) return
    const fuera = (e: PointerEvent) => {
      if (!contenedor.current?.contains(e.target as Node)) setAbierto(false)
    }
    document.addEventListener('pointerdown', fuera)
    return () => document.removeEventListener('pointerdown', fuera)
  }, [abierto])

  const cerrar = (devolverFoco: boolean) => {
    setAbierto(false)
    if (devolverFoco) disparador.current?.focus()
  }

  return (
    <div className="ay-notification__menu" ref={contenedor}>
      <button
        ref={disparador}
        type="button"
        id={`${id}-disparador`}
        className="ay-iconbtn ay-iconbtn--ghost ay-iconbtn--sm"
        aria-haspopup="menu"
        aria-expanded={abierto}
        aria-controls={abierto ? `${id}-menu` : undefined}
        aria-label={label}
        onClick={() => {
          setActivo(0)
          setAbierto((a) => !a)
        }}
        onKeyDown={(e) => {
          if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
            e.preventDefault()
            setActivo(e.key === 'ArrowDown' ? 0 : opciones.length - 1)
            setAbierto(true)
          }
        }}
      >
        <IconoPuntos className="ay-iconbtn__glyph" />
      </button>
      {abierto && (
        <div
          ref={menu}
          className="ay-menu"
          id={`${id}-menu`}
          role="menu"
          aria-labelledby={`${id}-disparador`}
          onKeyDown={(e) => {
            // las teclas del menú no llegan a la fila: Supr no debe quitar el aviso desde aquí
            e.stopPropagation()
            const n = opciones.length
            if (e.key === 'ArrowDown') {
              e.preventDefault()
              setActivo((i) => (i + 1) % n)
            } else if (e.key === 'ArrowUp') {
              e.preventDefault()
              setActivo((i) => (i - 1 + n) % n)
            } else if (e.key === 'Home') {
              e.preventDefault()
              setActivo(0)
            } else if (e.key === 'End') {
              e.preventDefault()
              setActivo(n - 1)
            } else if (e.key === 'Escape') {
              e.preventDefault()
              cerrar(true)
            } else if (e.key === 'Tab') {
              cerrar(false)
            }
          }}
        >
          {opciones.map((o, i) => (
            <button
              key={o.id}
              ref={(el) => {
                items.current[i] = el
              }}
              type="button"
              role="menuitem"
              tabIndex={i === activo ? 0 : -1}
              className={cx('ay-menu__item', o.peligro && 'ay-menu__item--danger')}
              onClick={() => {
                cerrar(o.id !== 'dismiss')
                o.alElegir()
              }}
            >
              {o.label}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

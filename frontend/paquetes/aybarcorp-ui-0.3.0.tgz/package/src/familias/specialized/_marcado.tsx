/**
 * Marcado canónico de componentes de OTRAS familias que Specialized compone: Button,
 * Alert, Spinner, Skeleton, Badge, Empty State, Progress Bar y Confirmation Dialog.
 *
 * Por qué se pinta aquí y no se importa. Cada familia se construye y se versiona por su
 * lado; importar el `Button` de Actions ataría esta familia a su API de React en vez de a
 * su contrato, que es el marcado y las clases `ay-*` del diseño aprobado. Pintar ese
 * marcado tal como lo define su ficha deja a Specialized dependiendo solo de `ui.css`,
 * que es lo que de verdad comparten las tres implementaciones (React, Angular, Web
 * Components). No se exporta desde el índice: no es API.
 */
import { forwardRef, useEffect, useId, useRef, useState } from 'react'
import type { ButtonHTMLAttributes, HTMLAttributes, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { IconoAlerta, IconoCorrecto, IconoInfo } from './_iconos.js'
import { atraparTab } from './_internos.js'

// ── Button (Actions) ──────────────────────────────────────────────────────────

type PropsBoton = Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'className'> & {
  variant?: 'primary' | 'secondary' | 'accent' | 'ghost' | 'danger'
  size?: 'sm' | 'md' | 'lg'
  full?: boolean
  loading?: boolean
}

export const Boton = forwardRef<HTMLButtonElement, PropsBoton>(function Boton(
  { variant = 'primary', size = 'md', full = false, loading = false, disabled, type = 'button', children, ...resto },
  ref,
) {
  return (
    <button
      {...resto}
      ref={ref}
      type={type}
      // ocupado implica deshabilitado: un segundo clic enviaría la operación dos veces
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      className={cx('ay-btn', `ay-btn--${variant}`, `ay-btn--${size}`, full && 'ay-btn--full')}
    >
      {loading && <Spinner size="sm" />}
      <span className="ay-btn__label">{children}</span>
    </button>
  )
})

// ── Spinner (Feedback) ────────────────────────────────────────────────────────

/** Arco decorativo. Con `label` añade el texto oculto que dice qué se está esperando. */
export function Spinner({ size = 'md', label }: { size?: 'sm' | 'md' | 'lg'; label?: string }) {
  return (
    <>
      <svg className={cx('ay-spinner', `ay-spinner--${size}`)} viewBox="0 0 24 24" aria-hidden="true" focusable="false">
        <circle className="ay-spinner__track" cx="12" cy="12" r="9" />
        <circle className="ay-spinner__arc" cx="12" cy="12" r="9" />
      </svg>
      {label && <span className="ay-visually-hidden">{label}</span>}
    </>
  )
}

/** Fila de espera con su texto visible, anunciada como estado. */
export function FilaSpinner({ label, className }: { label: string; className?: string }) {
  return (
    <div className={cx('ay-spinner-row', className)} role="status" aria-live="polite">
      <Spinner size="sm" />
      <span className="ay-spinner__text">{label}…</span>
    </div>
  )
}

// ── Skeleton (Feedback) ───────────────────────────────────────────────────────

/** Una línea de esqueleto. El ancho lo pone la clase que se pasa, con tokens. */
export function Esqueleto({ className }: { className?: string }) {
  return <span className={cx('ay-skel', 'ay-skel--text', className)} aria-hidden="true" />
}

// ── Badge (Surfaces) ──────────────────────────────────────────────────────────

export function Insignia({
  tone = 'neutral',
  children,
  ...resto
}: { tone?: 'neutral' | 'success' | 'warning' | 'danger' | 'info'; children: ReactNode } & Omit<
  HTMLAttributes<HTMLSpanElement>,
  'className'
>) {
  return (
    <span {...resto} className={cx('ay-badge', `ay-badge--${tone}`, 'ay-badge--md')}>
      {children}
    </span>
  )
}

// ── Alert (Feedback) ──────────────────────────────────────────────────────────

type PropsAlerta = Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'title'> & {
  tone: 'info' | 'success' | 'warning' | 'danger'
  title?: string
  actions?: ReactNode
}

/**
 * `warning` y `danger` usan `role="alert"` e interrumpen; `info` y `success` esperan su
 * turno con `role="status"`, igual que en la ficha de Alert.
 */
export const Alerta = forwardRef<HTMLDivElement, PropsAlerta>(function Alerta(
  { tone, title, actions, children, ...resto },
  ref,
) {
  const Icono = tone === 'success' ? IconoCorrecto : tone === 'info' ? IconoInfo : IconoAlerta
  return (
    <div
      {...resto}
      ref={ref}
      className={cx('ay-alert', `ay-alert--${tone}`, 'ay-alert--md')}
      role={tone === 'warning' || tone === 'danger' ? 'alert' : 'status'}
    >
      <Icono className="ay-alert__icon" width={20} height={20} />
      <div className="ay-alert__content">
        {title && <p className="ay-alert__title">{title}</p>}
        {children && <p className="ay-alert__desc">{children}</p>}
        {actions && <div className="ay-alert__actions">{actions}</div>}
      </div>
    </div>
  )
})

// ── Empty State (Data) ────────────────────────────────────────────────────────

export function Vacio({ title, description, action }: { title: string; description?: string; action?: ReactNode }) {
  return (
    <div className="ay-empty ay-empty--empty ay-empty--compact" role="status">
      <h3 className="ay-empty__title">{title}</h3>
      {description && <p className="ay-empty__desc">{description}</p>}
      {action && <div className="ay-empty__actions">{action}</div>}
    </div>
  )
}

// ── Progress Bar (Feedback) ───────────────────────────────────────────────────

export function Progreso({ value, label }: { value: number; label: string }) {
  const id = useId()
  const pct = Math.min(100, Math.max(0, Math.round(value)))
  return (
    <div className="ay-progress ay-progress--sm">
      <div className="ay-progress__head">
        <span className="ay-progress__label" id={id}>
          {label}
        </span>
        {/* el porcentaje es texto: el ancho de la barra no se puede leer */}
        <span className="ay-progress__value">{pct}%</span>
      </div>
      <div
        className="ay-progress__track ay-progress__track--brand"
        role="progressbar"
        aria-labelledby={id}
        aria-valuenow={pct}
        aria-valuemin={0}
        aria-valuemax={100}
      >
        <div className="ay-progress__fill" style={{ ['--ay-value' as string]: `${pct}%` }} />
      </div>
    </div>
  )
}

// ── Confirmation Dialog (Overlays) ────────────────────────────────────────────

type PropsConfirmacion = {
  title: string
  description: string
  confirmLabel: string
  cancelLabel?: string
  /** Texto que hay que escribir para habilitar la confirmación (borrados masivos). */
  phrase?: string
  onConfirm: () => void | Promise<void>
  onCancel: () => void
}

/**
 * `alertdialog` modal con trampa de foco. El foco inicial va a la salida segura: un Enter
 * por reflejo no destruye nada. Escape cancela.
 */
export function Confirmacion({
  title,
  description,
  confirmLabel,
  cancelLabel = 'Cancelar',
  phrase,
  onConfirm,
  onCancel,
}: PropsConfirmacion) {
  const id = useId()
  const dialogo = useRef<HTMLDivElement>(null)
  const cancelar = useRef<HTMLButtonElement>(null)
  const [escrito, setEscrito] = useState('')
  const [ocupado, setOcupado] = useState(false)
  const bloqueado = phrase !== undefined && escrito.trim() !== phrase

  useEffect(() => {
    cancelar.current?.focus()
  }, [])

  const confirmar = async () => {
    setOcupado(true)
    try {
      await onConfirm()
    } finally {
      setOcupado(false)
    }
  }

  return (
    <>
      <div className="ay-scrim" data-open="true" onClick={() => !ocupado && onCancel()} />
      <div
        ref={dialogo}
        className="ay-confirm"
        role="alertdialog"
        aria-modal="true"
        aria-labelledby={`${id}-titulo`}
        aria-describedby={`${id}-desc`}
        onKeyDown={(e) => {
          if (e.key === 'Escape' && !ocupado) {
            e.preventDefault()
            e.stopPropagation()
            onCancel()
          }
          atraparTab(e, dialogo.current)
        }}
      >
        <div className="ay-confirm__head">
          <IconoAlerta className="ay-confirm__icon" width={24} height={24} />
          <h2 className="ay-confirm__title" id={`${id}-titulo`}>
            {title}
          </h2>
        </div>
        <p className="ay-confirm__desc" id={`${id}-desc`}>
          {description}
        </p>
        {phrase !== undefined && (
          <div className="ay-field">
            <label className="ay-label" htmlFor={`${id}-frase`}>
              Escribe «{phrase}» para confirmar
            </label>
            <input
              className="ay-input ay-input--md"
              id={`${id}-frase`}
              type="text"
              autoComplete="off"
              value={escrito}
              onChange={(e) => setEscrito(e.target.value)}
            />
          </div>
        )}
        <div className="ay-confirm__actions">
          <Boton ref={cancelar} variant="secondary" disabled={ocupado} onClick={onCancel}>
            {cancelLabel}
          </Boton>
          <Boton variant="danger" loading={ocupado} disabled={bloqueado} onClick={() => void confirmar()}>
            {confirmLabel}
          </Boton>
        </div>
      </div>
    </>
  )
}

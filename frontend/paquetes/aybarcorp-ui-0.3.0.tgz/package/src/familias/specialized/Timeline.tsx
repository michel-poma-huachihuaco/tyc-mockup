import { Fragment, forwardRef, useEffect, useRef, useState } from 'react'
import type { OlHTMLAttributes, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { Boton, Esqueleto, FilaSpinner, Vacio } from './_marcado.js'
import { aFecha, diaCompleto, horaMinutos, mismoDia, textoRelativo, useMasEstrechoQue } from './_internos.js'
import { Hito } from './TimelineEvent.js'
import type { TimelineEvent } from './TimelineEvent.js'

export type LayoutTimeline = 'vertical' | 'alternating'

export interface PropsTimeline extends Omit<OlHTMLAttributes<HTMLOListElement>, 'className'> {
  /** Hitos, del más reciente al más antiguo. Dos hitos con la misma hora conservan su
   *  orden de llegada y muestran la hora con minutos. */
  events?: TimelineEvent[]
  /** Añade una cabecera por día. Son encabezados reales (`h3`): el único atajo para
   *  recorrer con el lector un historial de meses. Bajo la cabecera, cada hito muestra
   *  solo la hora, sin repetir la fecha. */
  groupByDay?: boolean
  /** `vertical`: eje a la izquierda. `alternating`: hitos a los dos lados del eje, para
   *  narrativas cortas; por debajo del breakpoint `md` vuelve a vertical. */
  layout?: LayoutTimeline
  /** Sin hitos todavía, pinta tres hitos de Skeleton con `aria-busy`. Con hitos ya
   *  pintados, es la carga de más: un Spinner al final del eje. */
  loading?: boolean
  /** Trae más hitos. El foco no se mueve: se anuncia cuántos llegaron. */
  onLoadMore?: () => void
  /** Quedan hitos por cargar: muestra «Cargar más actividad». */
  hasMore?: boolean
  /** Contenido sin actividad, en lugar de un eje vacío. Sin él se pinta el Empty State
   *  «Sin actividad todavía». */
  emptyState?: ReactNode
  /** Nombre accesible de la lista. Dice de qué es el historial —«Historial de la unidad
   *  402»— para quien salta de región en región. */
  label?: string
  /** Locale del formato de fechas y de las cabeceras de día. */
  locale?: string
}

/**
 * Historial de un registro: una lista ordenada (`ol`) de hitos con fecha, autor y lo
 * que cambió. El orden cronológico es la información principal, el eje y los marcadores
 * son decorativos y el tipo de hito se dice con palabras.
 */
export const Timeline = forwardRef<HTMLOListElement, PropsTimeline>(function Timeline(
  {
    events = [],
    groupByDay = false,
    layout = 'vertical',
    loading = false,
    onLoadMore,
    hasMore = false,
    emptyState,
    label = 'Historial',
    locale = 'es-PE',
    ...resto
  },
  ref,
) {
  // La carga progresiva se anuncia sin mover el foco: quien estaba leyendo sigue leyendo.
  const [aviso, setAviso] = useState('')
  const previos = useRef(events.length)
  useEffect(() => {
    const antes = previos.current
    previos.current = events.length
    if (antes > 0 && events.length > antes) {
      const n = events.length - antes
      setAviso(n === 1 ? 'Se añadió 1 hito más al historial.' : `Se añadieron ${n} hitos más al historial.`)
    }
  }, [events.length])

  // La alternada pasa a vertical por debajo del breakpoint md: el ancho sale del token, no
  // de una media query con un literal que la regla de tokens no admite.
  const estrecho = useMasEstrechoQue('--aybar-breakpoint-md')
  const disposicion: LayoutTimeline = layout === 'alternating' && estrecho ? 'vertical' : layout

  const region = (
    <p className="ay-visually-hidden" role="status">
      {aviso}
    </p>
  )

  if (loading && events.length === 0) {
    return (
      <>
        <ol {...resto} ref={ref} className={cx('ay-timeline', `ay-timeline--${disposicion}`)} aria-label={label} aria-busy="true">
          {[0, 1, 2].map((i) => (
            <li key={i} className="ay-timeline__event">
              <span className="ay-timeline__dot" aria-hidden="true" />
              <div className="ay-timeline__body">
                <Esqueleto className="ay-timeline__skel-title" />
                <Esqueleto className="ay-timeline__skel-time" />
              </div>
            </li>
          ))}
        </ol>
        {region}
      </>
    )
  }

  if (events.length === 0) {
    // Empty State en lugar de un eje vacío; `emptyState` lo sustituye. El envoltorio es el
    // mismo que en Angular, donde el contenido propio llega por `[ayVacio]`.
    return (
      <>
        <div className="ay-timeline__vacio">
          {emptyState != null && emptyState !== false ? (
            <div className="ay-timeline__vacio-propio">{emptyState}</div>
          ) : (
            <Vacio title="Sin actividad todavía" />
          )}
        </div>
        {region}
      </>
    )
  }

  const fechas = events.map((e) => aFecha(e.date))
  const relativos = fechas.map((f) => textoRelativo(f, locale))
  const textoDe = (i: number): string | undefined => {
    const fecha = fechas[i] as Date
    // Bajo la cabecera del día, el hito no repite la fecha: solo la hora.
    if (groupByDay) return horaMinutos(fecha, locale)
    // Dos hitos con el mismo texto relativo se distinguen por la hora con minutos.
    const repetido = relativos[i] === relativos[i - 1] || relativos[i] === relativos[i + 1]
    return repetido ? `${relativos[i]} · ${horaMinutos(fecha, locale)}` : undefined
  }

  return (
    <>
      <ol
        {...resto}
        ref={ref}
        className={cx('ay-timeline', `ay-timeline--${disposicion}`)}
        aria-label={label}
        aria-busy={loading || undefined}
      >
        {events.map((e, i) => {
          const fecha = fechas[i] as Date
          const anterior = fechas[i - 1]
          const nuevoDia = groupByDay && (anterior === undefined || !mismoDia(fecha, anterior))
          return (
            <Fragment key={e.id}>
              {nuevoDia && (
                // encabezado real: permite saltar por días con el lector
                <li className="ay-timeline__day">
                  <h3 className="ay-timeline__daytitle">{diaCompleto(fecha, locale)}</h3>
                </li>
              )}
              <Hito
                title={e.title}
                date={fecha}
                author={e.author}
                tone={e.tone}
                detail={e.detail}
                avatar={e.avatar}
                icon={e.icon}
                action={e.action}
                locale={locale}
                textoFecha={textoDe(i)}
              />
            </Fragment>
          )
        })}
      </ol>

      {loading ? (
        // cargando más: Spinner al final del eje, sin tapar lo ya leído
        <FilaSpinner className="ay-timeline__more" label="Cargando más actividad" />
      ) : (
        hasMore && (
          // no mueve el foco: se anuncia cuántos llegaron
          <div className="ay-timeline__more">
            <Boton variant="ghost" size="sm" onClick={onLoadMore}>
              Cargar más actividad
            </Boton>
          </div>
        )
      )}
      {region}
    </>
  )
})

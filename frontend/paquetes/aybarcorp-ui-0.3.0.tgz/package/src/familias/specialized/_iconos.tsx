/**
 * Iconos internos de la familia Specialized. Todos son decorativos —`aria-hidden` y sin
 * foco—: el nombre accesible lo aporta siempre el texto del control que los contiene.
 * El tamaño lo fija la hoja con tokens; `width`/`height` solo son el respaldo sin CSS.
 */
import type { ReactNode, SVGProps } from 'react'

type PropsIcono = Omit<SVGProps<SVGSVGElement>, 'children'>

function Svg({ children, ...resto }: PropsIcono & { children: ReactNode }) {
  return (
    <svg viewBox="0 0 24 24" width={18} height={18} aria-hidden="true" focusable="false" {...resto}>
      {children}
    </svg>
  )
}

const ESTRELLA =
  'M12 2.6l2.9 5.9 6.5.95-4.7 4.6 1.1 6.5L12 17.5l-5.8 3.05 1.1-6.5-4.7-4.6 6.5-.95z'

/**
 * Estrella de Rating. Dos trazos superpuestos: el vacío siempre y el lleno recortado a
 * la mitad o a nada, para que el medio punto no necesite un tercer glifo.
 */
export function IconoEstrella({ relleno, ...resto }: PropsIcono & { relleno: 'full' | 'half' | 'empty' }) {
  return (
    <Svg {...resto} className={`ay-rating__glyph ay-rating__glyph--${relleno}`}>
      <path className="ay-rating__glyph-empty" d={ESTRELLA} />
      <path className="ay-rating__glyph-full" d={ESTRELLA} />
    </Svg>
  )
}

export function IconoBuscar(props: PropsIcono) {
  return (
    <Svg {...props}>
      <circle cx="11" cy="11" r="6.5" fill="none" stroke="currentColor" strokeWidth="2" />
      <path d="M16 16l4.5 4.5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </Svg>
  )
}

export function IconoOjo(props: PropsIcono) {
  return (
    <Svg {...props}>
      <path d="M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12z" fill="none" stroke="currentColor" strokeWidth="2" />
      <circle cx="12" cy="12" r="3" fill="none" stroke="currentColor" strokeWidth="2" />
    </Svg>
  )
}

export function IconoOjoTachado(props: PropsIcono) {
  return (
    <Svg {...props}>
      <path d="M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12z" fill="none" stroke="currentColor" strokeWidth="2" />
      <path d="M4 4l16 16" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </Svg>
  )
}

export function IconoMas(props: PropsIcono) {
  return (
    <Svg {...props}>
      <path d="M12 5v14M5 12h14" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </Svg>
  )
}

export function IconoMenos(props: PropsIcono) {
  return (
    <Svg {...props}>
      <path d="M5 12h14" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </Svg>
  )
}

export function IconoEncuadrar(props: PropsIcono) {
  return (
    <Svg {...props}>
      <path
        d="M4 9V4h5M15 4h5v5M20 15v5h-5M9 20H4v-5"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </Svg>
  )
}

export function IconoPuntos(props: PropsIcono) {
  return (
    <Svg {...props}>
      <circle cx="5" cy="12" r="1.8" fill="currentColor" />
      <circle cx="12" cy="12" r="1.8" fill="currentColor" />
      <circle cx="19" cy="12" r="1.8" fill="currentColor" />
    </Svg>
  )
}

export function IconoAlerta(props: PropsIcono) {
  return (
    <Svg {...props}>
      <path d="M12 3l9.5 17h-19z" fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
      <path d="M12 10v4.5M12 17.5v.01" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </Svg>
  )
}

export function IconoInfo(props: PropsIcono) {
  return (
    <Svg {...props}>
      <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeWidth="2" />
      <path d="M12 11v5.5M12 7.5v.01" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </Svg>
  )
}

/**
 * Círculo con exclamación: el error de un campo, el mismo glifo que Error Message en Form
 * Architecture. A 14 unidades, el tamaño del texto del error, y no a las 18 del resto: va
 * en línea con un mensaje corto, no en un control.
 */
export function IconoErrorCampo(props: PropsIcono) {
  return (
    <Svg width={14} height={14} {...props}>
      <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeWidth="2" />
      <path d="M12 7.5v5M12 16.25v.01" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </Svg>
  )
}

export function IconoCorrecto(props: PropsIcono) {
  return (
    <Svg {...props}>
      <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeWidth="2" />
      <path d="M8 12.5l2.7 2.7L16.5 9.5" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </Svg>
  )
}

/**
 * Marca sobre el formulario de acceso. Es un monograma neutro que hereda `currentColor`
 * (el token `bg.brand` en la hoja); la aplicación que tenga el logotipo vectorial lo
 * sustituye sin tocar el componente, porque la marca es decorativa: el título dice dónde
 * se accede.
 */
export function IconoMarca(props: PropsIcono) {
  return (
    <svg viewBox="0 0 32 32" width={32} height={32} aria-hidden="true" focusable="false" {...props}>
      <rect x="1" y="1" width="30" height="30" rx="8" fill="currentColor" />
      <path className="ay-login__brand-mark" d="M10 23l6-14 6 14M12.6 17.5h6.8" fill="none" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

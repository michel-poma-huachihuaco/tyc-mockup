import { forwardRef, useEffect, useRef, useState } from 'react'
import type { HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import { Alerta, Boton, Confirmacion, Progreso } from './_marcado.js'
import { esFemenino } from './_internos.js'

export type CrudAction = {
  /** Identificador estable de la acción. */
  id: string
  /** Nombre con su alcance, a partir del recuento y la entidad: `(n, i) => \`Exportar ${n} ${i}\``.
   *  «Exportar» a secas no dice sobre qué actúa. */
  label: (count: number, item: string) => string
  /** Jerarquía visual; la destructiva va en `destructiveAction`, no aquí. */
  variant?: 'secondary' | 'ghost' | 'danger'
  /** Ejecuta la acción sobre la selección. */
  onRun: () => Promise<void> | void
  /** `false` si la sesión no tiene permiso: la acción no se muestra, en lugar de
   *  aparecer deshabilitada sin decir qué permiso falta. */
  allowed?: boolean
}

export type PlacementCrudToolbar = 'contextual' | 'fixed' | 'floating'

export interface PropsCrudToolbar extends Omit<HTMLAttributes<HTMLDivElement>, 'className'> {
  /** Registros seleccionados. Su aparición se anuncia en una live region y el foco no se
   *  mueve: quitárselo a la tabla rompe el recorrido de selección. */
  selectedCount?: number
  /** Total de coincidentes. Si supera la selección, se ofrece «Seleccionar las 248
   *  coincidentes», distinto de las visibles: confundirlas provoca borrados masivos. */
  totalCount?: number
  /** La selección abarca todos los coincidentes. La acción destructiva pide entonces
   *  escribir el recuento para confirmar. */
  allMatchingSelected?: boolean
  /** Extiende la selección a todos los coincidentes. */
  onSelectAllMatching?: () => void
  /** Vacía la selección; también con Escape, igual que en el resto del sistema. */
  onClearSelection?: () => void
  /** Acciones en lote, cada una con su alcance en el nombre. */
  actions?: CrudAction[]
  /** Acción destructiva, separada del resto y siempre confirmada con un diálogo que
   *  repite el recuento y el alcance. */
  destructiveAction?: CrudAction
  /** Progreso de la operación en curso: Progress Bar con nombre; el resto de acciones se
   *  retira mientras dura. */
  progress?: { done: number; total: number }
  /** Resultado de la última operación. Un resultado parcial dice cuántos fallaron y
   *  ofrece el detalle: no se presenta como éxito. */
  result?: { ok: number; failed: number; onDetail?: () => void }
  /** Entidad en singular y plural: `['unidad', 'unidades']`. */
  itemLabel?: [string, string]
  /** `contextual`: aparece al haber selección. `fixed`: siempre visible, con las acciones
   *  deshabilitadas hasta que hay selección. `floating`: anclada al pie del viewport. */
  placement?: PlacementCrudToolbar
}

/** El texto de una acción: una función con el recuento, o una cadena ya resuelta (JSON). */
function nombreDe(accion: CrudAction, n: number, item: string): string {
  const etiqueta = accion.label as unknown
  // Una cadena (el catálogo en JSON no transporta funciones) se completa con el alcance:
  // «Exportar» a secas no dice sobre qué actúa.
  return typeof etiqueta === 'function' ? accion.label(n, item) : `${String(etiqueta)} ${n} ${item}`
}

/**
 * Barra de acciones sobre una selección de registros, con el alcance de cada acción
 * siempre explícito: «Liberar 4 unidades», no «Liberar». Sustituye a Table Toolbar
 * mientras hay selección. Las acciones de un solo registro van en su fila.
 */
export const CrudToolbar = forwardRef<HTMLDivElement, PropsCrudToolbar>(function CrudToolbar(
  {
    selectedCount = 0,
    totalCount,
    allMatchingSelected = false,
    onSelectAllMatching,
    onClearSelection,
    actions = [],
    destructiveAction,
    progress,
    result,
    itemLabel = ['registro', 'registros'],
    placement = 'contextual',
    ...resto
  },
  ref,
) {
  const [confirmando, setConfirmando] = useState(false)
  const botonDestructivo = useRef<HTMLButtonElement>(null)
  const [singular, pluralTexto] = itemLabel
  const item = selectedCount === 1 ? singular : pluralTexto
  const fem = esFemenino(singular)
  const recuento = `${selectedCount} ${item} ${fem ? 'seleccionada' : 'seleccionado'}${selectedCount === 1 ? '' : 's'}`
  const visible = placement !== 'contextual' || selectedCount > 0
  const sinSeleccion = selectedCount === 0

  // Escape vacía la selección, salvo que lo esté usando un diálogo, un menú o un campo.
  useEffect(() => {
    if (sinSeleccion || !onClearSelection || confirmando) return
    const alPulsar = (e: KeyboardEvent) => {
      if (e.key !== 'Escape' || e.defaultPrevented) return
      const destino = e.target instanceof HTMLElement ? e.target : null
      // Las casillas de selección de la tabla sí cuentan: es justo desde donde se vacía.
      const ocupado =
        '[role="dialog"], [role="alertdialog"], dialog, [role="menu"], [role="listbox"], ' +
        'input:not([type="checkbox"]):not([type="radio"]), textarea, select, [contenteditable="true"]'
      if (destino?.closest(ocupado)) return
      onClearSelection()
    }
    document.addEventListener('keydown', alPulsar)
    return () => document.removeEventListener('keydown', alPulsar)
  }, [sinSeleccion, onClearSelection, confirmando])

  const cerrarConfirmacion = () => {
    setConfirmando(false)
    // el foco vuelve a la acción que abrió el diálogo
    requestAnimationFrame(() => botonDestructivo.current?.focus())
  }

  const destructiva = destructiveAction && destructiveAction.allowed !== false ? destructiveAction : undefined
  const permitidas = actions.filter((a) => a.allowed !== false)

  return (
    <>
      {visible && (
        <div
          {...resto}
          ref={ref}
          className={cx('ay-crudbar', `ay-crudbar--${placement}`)}
          role="toolbar"
          aria-label="Acciones sobre la selección"
        >
          <p className="ay-crudbar__count">
            {recuento}
            {allMatchingSelected && ` · ${fem ? 'todas las' : 'todos los'} coincidentes`}
          </p>

          {/* visibles frente a coincidentes: confundirlas provoca borrados masivos */}
          {!allMatchingSelected && totalCount != null && totalCount > selectedCount && !sinSeleccion && (
            <Boton variant="ghost" size="sm" onClick={onSelectAllMatching}>
              Seleccionar{' '}
              {totalCount === 1 ? (fem ? 'la' : 'el') : `${fem ? 'las' : 'los'} ${totalCount}`} coincidentes
            </Boton>
          )}

          {progress ? (
            <Progreso
              value={progress.total > 0 ? (progress.done / progress.total) * 100 : 0}
              label={`Procesando ${progress.done} de ${progress.total} ${progress.total === 1 ? singular : pluralTexto}`}
            />
          ) : (
            <>
              {/* sin permiso: no se muestra, en lugar de deshabilitada */}
              {permitidas.map((a) => (
                <Boton
                  key={a.id}
                  variant={a.variant ?? 'secondary'}
                  size="sm"
                  disabled={sinSeleccion}
                  onClick={() => void a.onRun?.()}
                >
                  {/* el alcance va en el nombre */}
                  {nombreDe(a, selectedCount, item)}
                </Boton>
              ))}

              {destructiva && (
                <Boton
                  ref={botonDestructivo}
                  variant="danger"
                  size="sm"
                  disabled={sinSeleccion}
                  onClick={() => setConfirmando(true)}
                >
                  {nombreDe(destructiva, selectedCount, item)}
                </Boton>
              )}
            </>
          )}

          <Boton variant="ghost" size="sm" disabled={sinSeleccion} onClick={onClearSelection}>
            Quitar la selección
          </Boton>
        </div>
      )}

      {/* un resultado parcial no es un éxito; se anuncia una sola vez al terminar */}
      {result &&
        (result.failed > 0 ? (
          <Alerta
            tone="warning"
            actions={
              result.onDetail && (
                <Boton variant="ghost" size="sm" onClick={result.onDetail}>
                  {result.failed === 1 ? 'Ver el que falló' : `Ver los ${result.failed} que fallaron`}
                </Boton>
              )
            }
          >
            Se procesaron {result.ok} de {result.ok + result.failed} {pluralTexto}.
          </Alerta>
        ) : (
          <Alerta tone="success">
            Se procesaron {result.ok} {result.ok === 1 ? singular : pluralTexto}.
          </Alerta>
        ))}

      {/* la destructiva siempre confirma, y el diálogo repite el alcance */}
      {confirmando && destructiva && (
        <Confirmacion
          title={`¿${nombreDe(destructiva, selectedCount, item)}?`}
          description={`Esta acción afecta a ${selectedCount} ${item} y no se puede deshacer.`}
          confirmLabel={nombreDe(destructiva, selectedCount, item)}
          // con todos los coincidentes, se pide escribir el recuento
          phrase={allMatchingSelected ? String(selectedCount) : undefined}
          onConfirm={async () => {
            await destructiva.onRun?.()
            cerrarConfirmacion()
          }}
          onCancel={cerrarConfirmacion}
        />
      )}

      {/* el foco permanece en la tabla: la barra se anuncia, no se enfoca */}
      <p className="ay-visually-hidden" aria-live="polite">
        {selectedCount > 0 ? recuento : ''}
      </p>
    </>
  )
})

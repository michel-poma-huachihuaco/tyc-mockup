import { forwardRef, useEffect, useRef, useState } from 'react'
import type { HTMLAttributes, KeyboardEvent, ReactNode } from 'react'
import { cx } from '../../utiles.js'

export type SegmentedOption = {
  /** Valor que se emite al elegir la opción. */
  value: string
  /** Etiqueta de una o dos palabras, sin artículos ni verbos. */
  label: string
  /** Icono antes de la etiqueta; decorativo. */
  icon?: ReactNode
  /** Número de elementos de la opción; entra en el nombre accesible. */
  count?: number
  /** No elegible. Si nunca va a poder elegirse, no se pasa la opción. */
  disabled?: boolean
}

export type SizeSegmentedControl = 'sm' | 'md'

export interface PropsSegmentedControl extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'defaultValue'> {
  /** Nombre del grupo; obligatorio: sin él, tres palabras sueltas no dicen qué se está
   *  eligiendo. */
  label: string
  /** Opciones, entre dos y cuatro, con etiquetas cortas. Con una sola elegible el control
   *  no se muestra; con más de cuatro, Select. El contador va en el nombre accesible
   *  —«Disponibles, 128»— y se abrevia a «9999+» a la vista. */
  options?: Array<{ value: string; label: string; icon?: ReactNode; count?: number; disabled?: boolean }>
  /** Opción elegida. Si desaparece del conjunto, se elige la primera y se explica. Sin
   *  `value`, el control lleva su propio estado. */
  value?: string
  /** Cambio de opción, con clic, flechas (con ciclo en los extremos), Inicio o Fin. */
  onValueChange?: (v: string) => void
  /** Altura: `sm` en barras de herramientas o `md`, la del control de formulario. */
  size?: SizeSegmentedControl
  /** Los segmentos reparten el ancho del contenedor, todos con el mismo ancho. */
  fullWidth?: boolean
  /** Desactiva el control completo. */
  disabled?: boolean
}

const MAX_CUENTA = 9999

/**
 * Elección exclusiva entre dos y cuatro alternativas cortas, todas visibles:
 * `radiogroup` con `role="radio"` y foco móvil, de modo que Tab atraviesa el control en un
 * paso. Si cambia el contenido de una página es Tabs; si alterna un ajuste, Switch.
 */
export const SegmentedControl = forwardRef<HTMLDivElement, PropsSegmentedControl>(function SegmentedControl(
  { label, options = [], value, onValueChange, size = 'md', fullWidth = false, disabled = false, onKeyDown, ...resto },
  ref,
) {
  const refs = useRef<(HTMLButtonElement | null)[]>([])
  const [interno, setInterno] = useState<string | undefined>(undefined)
  const [aviso, setAviso] = useState('')
  const actual = value ?? interno
  const elegibles = options.filter((o) => !o.disabled)

  const elegir = (v: string) => {
    if (value === undefined) setInterno(v)
    onValueChange?.(v)
  }

  // Opción elegida que desaparece del conjunto: se selecciona la primera y se explica.
  const firma = options.map((o) => `${o.value}${o.disabled ? '!' : ''}`).join('|')
  useEffect(() => {
    if (actual === undefined || elegibles.length < 2) return
    if (elegibles.some((o) => o.value === actual)) return
    const primera = elegibles[0]
    if (!primera) return
    elegir(primera.value)
    setAviso(`«${primera.label}» seleccionada: la opción anterior ya no está disponible.`)
    // `firma` resume `options`: un arreglo nuevo en cada render no debe reelegir.
  }, [actual, firma])

  // una sola opción disponible: el control no aporta nada
  if (elegibles.length < 2) return null

  const indiceActual = options.findIndex((o) => o.value === actual && !o.disabled)
  // Foco móvil: la activa, o la primera elegible si todavía no hay ninguna.
  const enfocable = indiceActual >= 0 ? indiceActual : options.findIndex((o) => !o.disabled)

  const ir = (j: number) => {
    const o = options[j]
    if (!o) return
    elegir(o.value)
    refs.current[j]?.focus()
  }

  const mover = (delta: number) => {
    const n = options.length
    const desde = indiceActual >= 0 ? indiceActual : enfocable
    let j = desde
    // ciclo en los extremos, saltando los deshabilitados
    do {
      j = (j + delta + n) % n
    } while (options[j]?.disabled && j !== desde)
    ir(j)
  }

  const teclado = (e: KeyboardEvent<HTMLDivElement>) => {
    onKeyDown?.(e)
    if (disabled || e.defaultPrevented) return
    if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
      e.preventDefault()
      mover(1)
    } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
      e.preventDefault()
      mover(-1)
    } else if (e.key === 'Home') {
      e.preventDefault()
      ir(options.findIndex((o) => !o.disabled))
    } else if (e.key === 'End') {
      e.preventDefault()
      ir(options.length - 1 - [...options].reverse().findIndex((o) => !o.disabled))
    }
  }

  return (
    <>
      <div
        {...resto}
        ref={ref}
        className={cx('ay-segmented', `ay-segmented--${size}`, fullWidth && 'ay-segmented--fill')}
        role="radiogroup"
        aria-label={label}
        aria-disabled={disabled || undefined}
        onKeyDown={teclado}
      >
        {options.map((o, i) => {
          const activo = i === indiceActual
          const cuenta = o.count != null ? (o.count > MAX_CUENTA ? `${MAX_CUENTA}+` : String(o.count)) : null
          return (
            <button
              key={o.value}
              ref={(el) => {
                refs.current[i] = el
              }}
              type="button"
              role="radio"
              aria-checked={activo}
              aria-disabled={o.disabled || disabled || undefined}
              // foco móvil: Tab atraviesa el control en un paso
              tabIndex={i === enfocable ? 0 : -1}
              // el contador entra en la etiqueta accesible, con su valor exacto
              aria-label={o.count != null ? `${o.label}, ${o.count}` : undefined}
              className={cx('ay-segmented__item', activo && 'ay-segmented__item--selected')}
              onClick={() => {
                if (!o.disabled && !disabled) elegir(o.value)
              }}
            >
              {o.icon && (
                <span className="ay-segmented__icon" aria-hidden="true">
                  {o.icon}
                </span>
              )}
              {o.label}
              {cuenta && (
                <span className="ay-segmented__count" aria-hidden="true">
                  {cuenta}
                </span>
              )}
            </button>
          )
        })}
      </div>
      {/* presente desde el principio: una live region que nace con texto no se anuncia */}
      <span className="ay-visually-hidden" role="status">
        {aviso}
      </span>
    </>
  )
})

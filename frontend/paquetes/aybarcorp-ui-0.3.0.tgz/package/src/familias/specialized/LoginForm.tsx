import { forwardRef, useEffect, useId, useRef, useState } from 'react'
import type { ClipboardEvent, ElementType, FormEvent, HTMLAttributes, KeyboardEvent, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { IconoErrorCampo, IconoMarca, IconoOjo, IconoOjoTachado } from './_iconos.js'
import { Alerta, Boton } from './_marcado.js'

export type StepLoginForm = 'credentials' | 'second-factor'
export type SizeLoginForm = 'md' | 'lg'
/** Elemento raíz del acceso: `div` dentro de una página que ya tiene su `main`; `main`
 *  cuando el acceso es la página entera; `section` dentro de un panel partido. */
export type ElementLoginForm = 'div' | 'main' | 'section'
/** Qué identifica a la persona: un correo (`email`) o un usuario, un DNI… (`text`). */
export type IdentifierTypeLoginForm = 'email' | 'text'

/** Los dos campos que se validan al enviar. */
type CampoLoginForm = 'identifier' | 'password'

export interface PropsLoginForm extends Omit<HTMLAttributes<HTMLElement>, 'className' | 'onSubmit' | 'title'> {
  /** Envío de las credenciales, con Enter en cualquier campo o con «Acceder». Mientras
   *  la promesa corre, `submitting` pone los campos en solo lectura. */
  onSubmit: (values: { identifier: string; password: string; remember: boolean }) => Promise<void>
  /** Resumen de error, sobre el formulario: recibe el foco al aparecer y tiene
   *  `role="alert"`. Es genérico a propósito —«Las credenciales no son correctas.»—:
   *  decir qué parte falló revela qué cuentas existen. */
  error?: string
  /** Envío en curso. El botón muestra su carga y los campos pasan a solo lectura, nunca a
   *  deshabilitados: el foco no salta y el contenido sigue legible. */
  submitting?: boolean
  /** Paso actual: credenciales o segundo factor (código de un solo uso). */
  step?: StepLoginForm
  /** Envío del código del segundo factor. Se llama también al completar la última
   *  cifra. */
  onSecondFactor?: (code: string) => Promise<void>
  /** Accesos externos (botón de acceso corporativo), tras el separador «o». */
  providers?: ReactNode
  /** Destino de «No recuerdo la contraseña», bajo el campo de contraseña. Sin él no se
   *  pinta el enlace: uno que apunte a una ruta que la aplicación no tiene es un 404 en la
   *  pantalla donde alguien ya no puede entrar. */
  recoverHref?: string
  /** Muestra, antes del formulario, por qué se pide acceder otra vez. */
  sessionExpired?: boolean
  /** Intentos que quedan antes del bloqueo; con tres o menos se avisan junto al error. */
  attemptsLeft?: number
  /** Cuenta bloqueada: el motivo y la vía de desbloqueo, no solo que no se puede
   *  acceder. Sustituye al resumen de error. */
  accountLocked?: { reason: string; how: string }
  /** Ancho de la tarjeta: `md` por defecto o `lg`, más ancha, en pantalla partida. */
  size?: SizeLoginForm
  /** Elemento raíz. `div` por defecto, porque lo normal es que el acceso viva dentro del
   *  `main` de la aplicación y una página no lleva dos; `main` solo cuando el acceso es la
   *  página entera, sin otro `main` alrededor. */
  as?: ElementLoginForm
  /** Título del paso de credenciales: dónde se entra. Es el nombre accesible del
   *  formulario. */
  title?: string
  /** Etiqueta visible del identificador. Si cambia lo que se pide —un usuario, un DNI—, la
   *  etiqueta lo dice; un placeholder no la sustituye. */
  identifierLabel?: string
  /** `email` pone el teclado de correo en el celular y comprueba el formato al enviar;
   *  `text`, para un usuario o un documento, no comprueba formato. */
  identifierType?: IdentifierTypeLoginForm
  /** Lo que se dice bajo cada campo si se envía vacío. Sin él: «Escribe tu <etiqueta>.» y
   *  «Escribe tu contraseña.». */
  requiredMessages?: { identifier?: string; password?: string }
}

const LONGITUD_CODIGO = 6
const TITULO = 'Acceder a Aybar'
const ETIQUETA_IDENTIFICADOR = 'Correo corporativo'
const MENSAJE_FORMATO = 'Escribe el correo completo, con @ y dominio.'

/**
 * «Correo corporativo» → «correo corporativo», pero «DNI» se queda «DNI»: solo baja la
 * inicial de una palabra que no es una sigla, para que el mensaje por omisión se lea como
 * una frase con cualquier etiqueta.
 */
function enFrase(etiqueta: string): string {
  const [primera = '', segunda = ''] = etiqueta
  return segunda && segunda === segunda.toLowerCase() ? primera.toLowerCase() + etiqueta.slice(1) : etiqueta
}

/**
 * Pantalla de acceso, con contraseña y, si procede, segundo factor. Autentica con el
 * menor número de pasos y deja claro qué falló sin revelar qué cuentas existen.
 * `autoComplete` `username` y `current-password` permiten al gestor de contraseñas
 * rellenar y guardar; el pegado no se bloquea en ningún campo. Un campo vacío o un correo
 * mal formado no llegan a `onSubmit`: el error se dice en el campo y el foco va a él.
 */
export const LoginForm = forwardRef<HTMLElement, PropsLoginForm>(function LoginForm(
  {
    onSubmit,
    error,
    submitting = false,
    step = 'credentials',
    onSecondFactor,
    providers,
    recoverHref,
    sessionExpired = false,
    attemptsLeft,
    accountLocked,
    size = 'md',
    as: elemento = 'div',
    title = TITULO,
    identifierLabel = ETIQUETA_IDENTIFICADOR,
    identifierType = 'email',
    requiredMessages,
    ...resto
  },
  ref,
) {
  // Como `ElementType` y no como la unión literal: el ref es de `HTMLElement`, común a los
  // tres elementos, y con la unión TypeScript lo exige como el de un `div` concreto.
  const Raiz = elemento as ElementType
  const id = useId()
  const [valores, setValores] = useState({ identifier: '', password: '', remember: false })
  const [revelada, setRevelada] = useState(false)
  const [mayusculas, setMayusculas] = useState(false)
  const [codigo, setCodigo] = useState('')
  const resumen = useRef<HTMLDivElement>(null)
  const celdas = useRef<(HTMLInputElement | null)[]>([])
  const pasoAnterior = useRef(step)
  const campoUsuario = useRef<HTMLInputElement>(null)
  const campoClave = useRef<HTMLInputElement>(null)
  // Un error por campo, puesto al enviar y borrado al escribir en ese campo.
  const [errores, setErrores] = useState<Partial<Record<CampoLoginForm, string>>>({})

  // El resumen recibe el foco al aparecer: el usuario está esperando el resultado del envío.
  const mensaje = accountLocked ? `${accountLocked.reason}|${accountLocked.how}` : error
  useEffect(() => {
    if (mensaje) resumen.current?.focus()
  }, [mensaje])

  // Al pasar al segundo factor, el foco va a la primera cifra del código.
  useEffect(() => {
    if (pasoAnterior.current !== step && step === 'second-factor') celdas.current[0]?.focus()
    pasoAnterior.current = step
  }, [step])

  /**
   * Los vacíos y un correo mal formado se dicen en el campo, antes de llamar a `onSubmit`:
   * enviarlos solo para que el servidor responda «credenciales incorrectas» gasta un intento
   * y no dice qué corregir. `noValidate` se mantiene porque el globo del navegador no se
   * puede leer con un lector de pantalla ni darle estilo; la comprobación es la misma
   * (`required` y `validity.typeMismatch`) y el mensaje es nuestro.
   */
  const validar = (): Partial<Record<CampoLoginForm, string>> => {
    const encontrados: Partial<Record<CampoLoginForm, string>> = {}
    if (!valores.identifier.trim()) {
      encontrados.identifier = requiredMessages?.identifier ?? `Escribe tu ${enFrase(identifierLabel)}.`
    } else if (campoUsuario.current?.validity.typeMismatch) {
      encontrados.identifier = MENSAJE_FORMATO
    }
    if (!valores.password) encontrados.password = requiredMessages?.password ?? 'Escribe tu contraseña.'
    return encontrados
  }

  const enviar = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    if (submitting) return
    const encontrados = validar()
    setErrores(encontrados)
    // El foco va al primer campo inválido: su `aria-describedby` lee el error al llegar, y
    // quien ve encuentra el cursor donde tiene que escribir.
    const primero = encontrados.identifier ? campoUsuario.current : encontrados.password ? campoClave.current : null
    if (primero) {
      primero.focus()
      return
    }
    void onSubmit(valores)
  }

  /** Escribir en un campo retira su error: ya no describe lo que hay en él. */
  const corregir = (campo: CampoLoginForm) => {
    if (errores[campo]) setErrores(({ [campo]: _retirado, ...resto }) => resto)
  }

  const verificar = (valor: string) => {
    if (submitting) return
    void onSecondFactor?.(valor)
  }

  const avisoMayusculas = (e: KeyboardEvent<HTMLInputElement>) => {
    // Se avisa sin bloquear: la contraseña puede llevar mayúsculas a propósito.
    setMayusculas(e.getModifierState?.('CapsLock') ?? false)
  }

  const clases = cx('ay-login', size === 'lg' && 'ay-login--lg')

  if (step === 'second-factor') {
    const escribir = (i: number, crudo: string) => {
      // Escribir sobre una celda llena la sustituye; pegar varias cifras las reparte.
      const previo = codigo[i] ?? ''
      const entrada = previo && crudo.length === previo.length + 1 && crudo.startsWith(previo) ? crudo.slice(-1) : crudo
      const limpio = entrada.replace(/[^0-9]/g, '')
      if (!limpio) return
      // pegar reparte el código entre las celdas desde cualquiera de ellas
      const siguiente = (codigo.slice(0, i) + limpio + codigo.slice(i + limpio.length)).slice(0, LONGITUD_CODIGO)
      setCodigo(siguiente)
      celdas.current[Math.min(i + limpio.length, LONGITUD_CODIGO - 1)]?.focus()
      if (siguiente.length === LONGITUD_CODIGO) verificar(siguiente)
    }
    const borrar = (i: number, e: KeyboardEvent<HTMLInputElement>) => {
      if (e.key === 'Backspace' && !codigo[i] && i > 0) {
        e.preventDefault()
        setCodigo(codigo.slice(0, i - 1) + codigo.slice(i))
        celdas.current[i - 1]?.focus()
      } else if (e.key === 'Backspace' && codigo[i]) {
        e.preventDefault()
        setCodigo(codigo.slice(0, i) + codigo.slice(i + 1))
      } else if (e.key === 'ArrowLeft') {
        celdas.current[Math.max(0, i - 1)]?.focus()
      } else if (e.key === 'ArrowRight') {
        celdas.current[Math.min(LONGITUD_CODIGO - 1, i + 1)]?.focus()
      }
    }

    return (
      <Raiz {...resto} ref={ref} className={clases}>
        <form
          className="ay-login__card"
          noValidate
          aria-labelledby={`${id}-titulo`}
          onSubmit={(e) => {
            e.preventDefault()
            verificar(codigo)
          }}
        >
          <IconoMarca className="ay-login__brand" />
          <h1 className="ay-login__title" id={`${id}-titulo`}>
            Verificación en dos pasos
          </h1>
          {/* el contexto se mantiene: a qué cuenta pertenece el código */}
          <p className="ay-login__hint">
            {valores.identifier
              ? `Hemos enviado un código a la cuenta ${valores.identifier}.`
              : 'Hemos enviado un código a tu cuenta.'}
          </p>

          {error && (
            <Alerta tone="danger" ref={resumen} tabIndex={-1}>
              {error}
            </Alerta>
          )}

          <fieldset className="ay-otp">
            <legend className="ay-label">Código de verificación</legend>
            <div className="ay-otp__cells">
              {Array.from({ length: LONGITUD_CODIGO }, (_, i) => (
                <input
                  key={i}
                  ref={(el) => {
                    celdas.current[i] = el
                  }}
                  className="ay-otp__cell"
                  type="text"
                  inputMode="numeric"
                  // permite pegar el código completo en cualquier celda
                  maxLength={LONGITUD_CODIGO}
                  autoComplete={i === 0 ? 'one-time-code' : 'off'}
                  name={i === 0 ? 'code' : undefined}
                  aria-label={`Dígito ${i + 1} de ${LONGITUD_CODIGO}`}
                  value={codigo[i] ?? ''}
                  readOnly={submitting}
                  onChange={(e) => escribir(i, e.target.value)}
                  onPaste={(e: ClipboardEvent<HTMLInputElement>) => {
                    e.preventDefault()
                    escribir(i, e.clipboardData.getData('text'))
                  }}
                  onKeyDown={(e) => borrar(i, e)}
                />
              ))}
            </div>
          </fieldset>

          <Boton type="submit" variant="primary" full loading={submitting}>
            Verificar
          </Boton>
        </form>
      </Raiz>
    )
  }

  return (
    <Raiz {...resto} ref={ref} className={clases}>
      <form className="ay-login__card" noValidate aria-labelledby={`${id}-titulo`} onSubmit={enviar}>
        <IconoMarca className="ay-login__brand" />
        <h1 className="ay-login__title" id={`${id}-titulo`}>
          {title}
        </h1>

        {/* antes del formulario: explica por qué se pide acceder otra vez */}
        {sessionExpired && (
          <Alerta tone="info">Tu sesión ha caducado. Accede de nuevo para continuar.</Alerta>
        )}

        {accountLocked ? (
          <Alerta tone="danger" ref={resumen} tabIndex={-1}>
            {accountLocked.reason} {accountLocked.how}
          </Alerta>
        ) : (
          error && (
            <Alerta tone="danger" ref={resumen} tabIndex={-1}>
              {/* genérico a propósito: no dice qué parte falló */}
              {error}
              {attemptsLeft != null &&
                attemptsLeft <= 3 &&
                (attemptsLeft === 1
                  ? ' Te queda 1 intento antes de que se bloquee la cuenta.'
                  : ` Te quedan ${attemptsLeft} intentos antes de que se bloquee la cuenta.`)}
            </Alerta>
          )
        )}

        <div className="ay-field">
          <label className="ay-label" htmlFor={`${id}-usuario`}>
            {identifierLabel}
          </label>
          <input
            ref={campoUsuario}
            className="ay-input ay-input--md"
            id={`${id}-usuario`}
            name="identifier"
            type={identifierType}
            inputMode={identifierType === 'email' ? 'email' : undefined}
            // sin esto, el gestor de contraseñas no rellena ni guarda
            autoComplete="username"
            autoCapitalize="none"
            spellCheck={false}
            required
            aria-invalid={errores.identifier ? true : undefined}
            aria-describedby={errores.identifier ? `${id}-usuario-error` : undefined}
            // readOnly, no disabled: el foco no salta y el texto sigue legible
            readOnly={submitting}
            value={valores.identifier}
            onChange={(e) => {
              setValores((v) => ({ ...v, identifier: e.target.value }))
              corregir('identifier')
            }}
          />
          {errores.identifier && (
            <p className="ay-error" id={`${id}-usuario-error`}>
              <IconoErrorCampo />
              {errores.identifier}
            </p>
          )}
        </div>

        <div className="ay-field">
          <label className="ay-label" htmlFor={`${id}-clave`}>
            Contraseña
          </label>
          <div className={cx('ay-password', errores.password && 'is-invalid')}>
            <input
              ref={campoClave}
              className="ay-password__field"
              id={`${id}-clave`}
              name="password"
              type={revelada ? 'text' : 'password'}
              autoComplete="current-password"
              required
              readOnly={submitting}
              aria-invalid={errores.password ? true : undefined}
              // primero el error, que es lo que hay que corregir; después el aviso de mayúsculas
              aria-describedby={
                [errores.password && `${id}-clave-error`, mayusculas && `${id}-mayus`].filter(Boolean).join(' ') ||
                undefined
              }
              value={valores.password}
              onChange={(e) => {
                setValores((v) => ({ ...v, password: e.target.value }))
                corregir('password')
              }}
              onKeyDown={avisoMayusculas}
              onKeyUp={avisoMayusculas}
            />
            <button
              type="button"
              className="ay-password__reveal"
              aria-pressed={revelada}
              aria-label={revelada ? 'Ocultar la contraseña' : 'Mostrar la contraseña'}
              aria-controls={`${id}-clave`}
              onClick={() => setRevelada((r) => !r)} // el foco permanece en el botón
            >
              {revelada ? <IconoOjoTachado /> : <IconoOjo />}
            </button>
          </div>
          {errores.password && (
            <p className="ay-error" id={`${id}-clave-error`}>
              <IconoErrorCampo />
              {errores.password}
            </p>
          )}
          <p className="ay-help ay-login__caps" id={`${id}-mayus`} aria-live="polite">
            {mayusculas ? 'Las mayúsculas están activadas.' : ''}
          </p>
          {recoverHref && (
            <a className="ay-link ay-login__recover" href={recoverHref}>
              No recuerdo la contraseña
            </a>
          )}
        </div>

        <label className="ay-check">
          <input
            type="checkbox"
            name="remember"
            checked={valores.remember}
            aria-readonly={submitting || undefined}
            onChange={(e) => {
              if (!submitting) setValores((v) => ({ ...v, remember: e.target.checked }))
            }}
          />
          <span className="ay-check__text">Recordar este acceso</span>
        </label>

        <Boton type="submit" variant="primary" full loading={submitting}>
          Acceder
        </Boton>

        {providers && (
          <>
            <div className="ay-login__sep">
              <span>o</span>
            </div>
            {/* un grupo con nombre: el lector anuncia «Otros accesos» antes de los botones */}
            <div className="ay-login__providers" role="group" aria-label="Otros accesos">
              {providers}
            </div>
          </>
        )}
      </form>
    </Raiz>
  )
})

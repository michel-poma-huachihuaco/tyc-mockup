import { forwardRef, useEffect, useId, useMemo, useRef, useState } from 'react'
import type { HTMLAttributes, KeyboardEvent, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { IconoBuscar } from './_iconos.js'
import { Boton, Spinner } from './_marcado.js'
import {
  atraparTab,
  bloquearScroll,
  enCapa,
  estaEscribiendo,
  inertizarFondo,
  normalizar,
  useAnuncioDiferido,
  useEnCliente,
} from './_internos.js'

export type CommandItem = {
  /** Identificador estable: mantiene activo el mismo resultado cuando llegan los remotos. */
  id: string
  /** Comando en infinitivo («Crear una reserva») o registro («Unidad 402»). */
  title: string
  /** Contexto del registro: «Residencial Miraflores». Entra en el nombre accesible. */
  context?: string
  /** Atajo propio del comando, a la vista: «⌘R». */
  shortcut?: string
  /** Icono decorativo. */
  icon?: ReactNode
  /** Ejecuta el resultado. Si devuelve una promesa, el resultado se marca mientras corre
   *  y la paleta se cierra al terminar. */
  onSelect: () => void
}

export type SizeCommandPalette = 'md' | 'lg'

export interface PropsCommandPalette extends Omit<HTMLAttributes<HTMLDivElement>, 'className'> {
  /** Estado de apertura de la paleta modal, `false` por omisión. Sin `open`, lleva su
   *  propio estado y la abre su atajo. En línea no aplica: la paleta está siempre a la
   *  vista, como cualquier otro control de la página. */
  open?: boolean
  /** Diálogo modal sobre la página (por omisión) o buscador en línea. Modal: se pinta en
   *  `document.body` con velo, `aria-modal`, el resto de la página inerte, trampa de Tab y
   *  el foco en el campo al abrir. En línea (`false`): una región de búsqueda en su sitio,
   *  sin velo ni `aria-modal`, sin trampa de Tab y sin mover el foco al montarse; Escape
   *  vacía la consulta en lugar de cerrar, y ejecutar un resultado no la oculta. */
  modal?: boolean
  /** Cambio de apertura: el atajo, Escape, el velo o la ejecución de un comando. Al
   *  cerrar, el foco vuelve al elemento que lo tenía antes de abrir. */
  onOpenChange?: (open: boolean) => void
  /** Resultados agrupados (acciones, registros, navegación). Las flechas los atraviesan
   *  sin detenerse en las cabeceras. Sin `onQuery`, la paleta filtra estos grupos por
   *  título y contexto; con `onQuery`, los grupos ya llegan filtrados. */
  groups?: Array<{ label: string; items: CommandItem[] }>
  /** Consulta escrita; permite buscar en servidor. */
  onQuery?: (q: string) => void
  /** Resultados cargando: Spinner en la lista, sin bloquear la escritura. */
  loading?: boolean
  /** Últimos usados, que se muestran al abrir antes de escribir nada. */
  recents?: CommandItem[]
  /** Mensaje sin coincidencias. Con `onCreate` ofrece además la salida de crear. */
  emptyMessage?: string
  /** Atajo de teclado global (`⌘K` responde a ⌘ o Ctrl + K): en modal abre la paleta, en
   *  línea lleva el foco a su campo. `null` no registra ninguno. Por omisión es `⌘K` en
   *  modal y `null` en línea: varias paletas en línea en una página se pelearían por la
   *  misma tecla. No captura con el foco en un campo de texto o en un editor. En táctil no
   *  existe: la paleta se abre desde un botón visible. */
  shortcut?: string | null
  /** Nombre accesible del diálogo y del campo. */
  label?: string
  /** Sin resultados pero con una acción posible: ofrece «Crear «consulta»». */
  onCreate?: (q: string) => void
  /** Ancho del diálogo: `md` por defecto o `lg`, más ancho, para resultados con descripción. */
  size?: SizeCommandPalette
}

type Atajo = { modificador: boolean; tecla: string }

function leerAtajo(texto: string): Atajo {
  const modificador = /⌘|ctrl|cmd|meta|control/i.test(texto)
  const tecla = texto.replace(/⌘|ctrl|cmd|meta|control|\+|\s/gi, '').toLowerCase()
  return { modificador, tecla }
}

/** El resultado de un comando, si es una promesa, se espera antes de cerrar. */
function esPromesa(valor: unknown): valor is PromiseLike<unknown> {
  return typeof (valor as PromiseLike<unknown> | undefined)?.then === 'function'
}

/**
 * Paleta de comandos: diálogo modal con trampa de foco —o, con `modal={false}`, buscador
 * en línea— y, dentro, un combobox cuya lista es un listbox. El foco no sale del campo
 * —el resultado activo se señala con `aria-activedescendant`— y el recuento se anuncia al
 * dejar de escribir. Es un acelerador, nunca la única vía a una función.
 */
export const CommandPalette = forwardRef<HTMLDivElement, PropsCommandPalette>(function CommandPalette(
  {
    open,
    modal = true,
    onOpenChange,
    groups = [],
    onQuery,
    loading = false,
    recents,
    emptyMessage = 'Sin resultados',
    shortcut = modal ? '⌘K' : null,
    label = 'Buscar comandos y registros',
    onCreate,
    size = 'md',
    onKeyDown,
    ...resto
  },
  ref,
) {
  const id = useId()
  const [interno, setInterno] = useState(false)
  // En línea la paleta es un control más de la página: siempre a la vista.
  const abierta = modal ? (open ?? interno) : true
  const [q, setQ] = useState('')
  const [activoId, setActivoId] = useState<string | null>(null)
  const [ejecutando, setEjecutando] = useState<string | null>(null)
  const anterior = useRef<HTMLElement | null>(null)
  const campo = useRef<HTMLInputElement>(null)
  const dialogo = useRef<HTMLDivElement | null>(null)
  const velo = useRef<HTMLDivElement | null>(null)
  // La paleta modal va en un portal a `body` en cuanto hay cliente; hasta entonces (el
  // servidor, el primer render) se pinta en su sitio y no se toca el foco ni el fondo.
  const enCliente = useEnCliente()
  const enCuerpo = modal && enCliente

  const cambiarApertura = (valor: boolean) => {
    if (open === undefined) setInterno(valor)
    onOpenChange?.(valor)
  }

  // El atajo no captura con el foco en un campo de texto o en un editor: quien está
  // redactando vería su campo desaparecer bajo un modal que no ha pedido. La escucha se
  // registra una vez por atajo y lee el último manejador de una ref: suscribirse en cada
  // render quitaba y ponía la escucha del documento con cada tecla escrita.
  const atajo = shortcut ? leerAtajo(shortcut) : null
  const alAtajo = useRef<(e: globalThis.KeyboardEvent) => void>(() => {})
  alAtajo.current = (e) => {
    if (!atajo || estaEscribiendo(e.target)) return
    const conModificador = e.metaKey || e.ctrlKey
    if (atajo.modificador !== conModificador || e.key.toLowerCase() !== atajo.tecla) return
    if (!modal) {
      // En línea ya está a la vista: el atajo lleva el foco a su campo.
      e.preventDefault()
      campo.current?.focus()
      return
    }
    if (abierta) return
    e.preventDefault()
    anterior.current = document.activeElement as HTMLElement | null
    cambiarApertura(true)
  }
  const hayAtajo = atajo !== null
  useEffect(() => {
    if (!hayAtajo) return
    const escuchar = (e: globalThis.KeyboardEvent) => alAtajo.current(e)
    document.addEventListener('keydown', escuchar)
    return () => document.removeEventListener('keydown', escuchar)
  }, [hayAtajo])

  // Al abrir: recuerda dónde estaba el foco y lo lleva al campo. Al cerrar: lo devuelve.
  // Empieza en `false`: una paleta que se monta ya abierta también lleva el foco al campo,
  // pero solo cuando ya está en su portal. En línea la paleta es parte de la página y no
  // mueve el foco.
  const estabaAbierta = useRef(false)
  useEffect(() => {
    if (!modal) {
      estabaAbierta.current = abierta
      return
    }
    if (abierta && !enCuerpo) return
    if (abierta && !estabaAbierta.current) {
      anterior.current ??= document.activeElement as HTMLElement | null
      campo.current?.focus()
    }
    if (!abierta && estabaAbierta.current) {
      anterior.current?.focus()
      anterior.current = null
    }
    estabaAbierta.current = abierta
  }, [abierta, modal, enCuerpo])

  // En modal, desde `body`: el resto de la página inerte y el scroll bloqueado. Se libera
  // antes de devolver el foco, porque un elemento inerte no puede recibirlo.
  useEffect(() => {
    if (!abierta || !enCuerpo || !dialogo.current) return
    const nodos = [velo.current, dialogo.current].filter((n): n is HTMLDivElement => n !== null)
    const liberarFondo = inertizarFondo(nodos)
    const liberarScroll = bloquearScroll()
    return () => {
      liberarFondo()
      liberarScroll()
    }
  }, [abierta, enCuerpo])

  // Sin onQuery, el filtro es local: título y contexto, sin tildes ni mayúsculas.
  const visibles = useMemo(() => {
    if (!q) return recents && recents.length > 0 ? [{ label: 'Recientes', items: recents }] : groups
    if (onQuery) return groups
    const buscado = normalizar(q)
    return groups.map((g) => ({
      label: g.label,
      items: g.items.filter((it) => normalizar(`${it.title} ${it.context ?? ''}`).includes(buscado)),
    }))
  }, [q, groups, recents, onQuery])

  // lista plana para las flechas: atraviesan los grupos sin parar en las cabeceras
  const planos = useMemo(() => visibles.flatMap((g) => g.items), [visibles])
  // El activo se guarda por id: los remotos que llegan después no lo reordenan.
  const indiceActivo = Math.max(0, planos.findIndex((it) => it.id === activoId))
  const activo = planos[indiceActivo]

  const recuento = loading || !q ? '' : planos.length === 0 ? emptyMessage : `${planos.length} ${planos.length === 1 ? 'resultado' : 'resultados'}`
  const anuncio = useAnuncioDiferido(recuento, 500)

  if (!abierta) return null

  const vaciar = () => {
    setQ('')
    setActivoId(null)
    // Con búsqueda en servidor, quien consume tiene que saber que la consulta ya está vacía.
    if (!modal && q) onQuery?.('')
  }
  // En línea la paleta no se oculta: terminar (ejecutar, crear) vacía la consulta.
  const cerrar = () => {
    vaciar()
    if (modal) cambiarApertura(false)
  }

  const ejecutar = (item: CommandItem) => {
    // `?.`: el catálogo en JSON trae los callbacks como null
    const resultado: unknown = item.onSelect?.()
    if (esPromesa(resultado)) {
      setEjecutando(item.id)
      void Promise.resolve(resultado).finally(() => {
        setEjecutando(null)
        cerrar()
      })
      return
    }
    cerrar()
  }

  const teclado = (e: KeyboardEvent<HTMLInputElement>) => {
    const n = planos.length
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault()
      if (n === 0) return
      const siguiente = e.key === 'ArrowDown' ? (indiceActivo + 1) % n : (indiceActivo - 1 + n) % n
      setActivoId(planos[siguiente]?.id ?? null)
    } else if (e.key === 'Enter') {
      if (!activo || ejecutando) return
      e.preventDefault()
      ejecutar(activo)
    }
  }

  const listaId = `${id}-lista`
  const opcionId = (it: CommandItem) => `${id}-opt-${planos.indexOf(it)}`

  return enCapa(
    <>
      {modal && <div ref={velo} className="ay-scrim" data-open="true" onClick={cerrar} />}
      <div
        {...resto}
        ref={(el) => {
          dialogo.current = el
          if (typeof ref === 'function') ref(el)
          else if (ref) ref.current = el
        }}
        className={cx('ay-palette', size === 'lg' && 'ay-palette--lg', !modal && 'ay-palette--inline')}
        // En línea es un buscador de la página: un landmark de búsqueda con nombre, no un diálogo.
        role={modal ? 'dialog' : 'search'}
        aria-modal={modal ? 'true' : undefined}
        // Un Modal de Overlays abierto debajo no debe traer el Tab de vuelta a su panel: la
        // paleta gestiona el suyo, como cualquier superficie flotante.
        data-ay-flotante={modal ? '' : undefined}
        aria-label={label}
        onKeyDown={(e) => {
          onKeyDown?.(e)
          if (e.key === 'Escape') {
            if (modal) {
              e.preventDefault()
              cerrar()
              return
            }
            // En línea Escape vacía la consulta, como en un buscador; vacía ya, el Escape
            // sigue su camino (un diálogo que contenga la paleta se cierra con él).
            if (q) {
              e.preventDefault()
              vaciar()
            }
            return
          }
          // trampa de foco solo en modal: Tab no recorre los resultados ni sale del diálogo
          if (modal) atraparTab(e, dialogo.current)
        }}
      >
        <div className="ay-palette__field">
          <IconoBuscar className="ay-palette__icon" />
          <label className="ay-visually-hidden" htmlFor={`${id}-q`}>
            {label}
          </label>
          <input
            ref={campo}
            id={`${id}-q`}
            type="text"
            role="combobox"
            aria-expanded={planos.length > 0}
            aria-controls={listaId}
            aria-autocomplete="list"
            // el foco no sale del campo: si sale, no se puede seguir escribiendo
            aria-activedescendant={activo && !loading ? opcionId(activo) : undefined}
            placeholder="Escribe un comando o busca un registro"
            autoComplete="off"
            value={q}
            onChange={(e) => {
              setQ(e.target.value)
              setActivoId(null)
              onQuery?.(e.target.value)
            }}
            onKeyDown={teclado}
          />
        </div>

        {loading ? (
          <div className="ay-palette__list" id={listaId}>
            <p className="ay-palette__status">
              <Spinner size="sm" />
              Buscando…
            </p>
          </div>
        ) : planos.length === 0 ? (
          <div className="ay-palette__list" id={listaId}>
            <div className="ay-palette__status">
              <span>{emptyMessage}</span>
              {/* sin resultados pero con una acción posible: se ofrece la salida */}
              {onCreate && q && (
                <Boton
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    onCreate(q)
                    cerrar()
                  }}
                >
                  Crear «{q}»
                </Boton>
              )}
            </div>
          </div>
        ) : (
          <ul className="ay-palette__list" id={listaId} role="listbox" aria-label="Resultados">
            {visibles.map((g, gi) =>
              g.items.length === 0 ? null : (
                <li key={`${g.label}-${gi}`} role="presentation">
                  {/* el grupo tiene nombre; su cabecera no consume ninguna pulsación */}
                  <ul className="ay-palette__groupitems" role="group" aria-labelledby={`${id}-g${gi}`}>
                    <li className="ay-palette__group" id={`${id}-g${gi}`} role="presentation">
                      {g.label}
                    </li>
                    {g.items.map((item) => {
                      const esActivo = item === activo
                      return (
                        <li
                          key={item.id}
                          id={opcionId(item)}
                          role="option"
                          aria-selected={esActivo}
                          aria-busy={ejecutando === item.id || undefined}
                          data-active={esActivo || undefined}
                          className="ay-palette__item"
                          // «402» a secas no sitúa: el contexto entra en el nombre
                          aria-label={item.context ? `${item.title}, ${item.context}` : item.title}
                          onMouseMove={() => item !== activo && setActivoId(item.id)}
                          onMouseDown={(e) => {
                            e.preventDefault()
                            ejecutar(item)
                          }}
                        >
                          {item.icon && (
                            <span className="ay-palette__itemicon" aria-hidden="true">
                              {item.icon}
                            </span>
                          )}
                          <span className="ay-palette__title">{item.title}</span>
                          {item.context && <span className="ay-palette__context">{item.context}</span>}
                          {item.shortcut && <span className="ay-palette__shortcut">{item.shortcut}</span>}
                        </li>
                      )
                    })}
                  </ul>
                </li>
              ),
            )}
          </ul>
        )}

        <div className="ay-palette__footer">
          <span>↑↓ para navegar</span>
          <span>↵ para ejecutar</span>
          <span>{modal ? 'esc para cerrar' : 'esc para borrar'}</span>
        </div>

        {/* agrupado y con retardo: en cada tecla taparía lo que el usuario escribe */}
        <p className="ay-visually-hidden" aria-live="polite">
          {anuncio}
        </p>
      </div>
    </>,
    enCuerpo,
  )
})

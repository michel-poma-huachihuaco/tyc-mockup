import { forwardRef, useEffect, useId, useMemo, useRef, useState } from 'react'
import type { CSSProperties, HTMLAttributes, KeyboardEvent } from 'react'
import { cx } from '../../utiles.js'
import { IconoEncuadrar, IconoMas, IconoMenos } from './_iconos.js'

export type UnitStatus = 'available' | 'reserved' | 'sold'

export type Unit = {
  /** Identificador estable de la unidad. */
  id: string
  /** Código visible en el marcador: «402», no un número de orden. */
  code: string
  /** Posición horizontal, en % del ancho del plano. */
  x: number
  /** Posición vertical, en % del alto del plano. */
  y: number
  /** Estado de negocio de la unidad. */
  status: UnitStatus
}

export type BaseUnitMap = 'site' | 'map'
export type SizeUnitMap = 'panel' | 'full'

export interface PropsUnitMap extends Omit<HTMLAttributes<HTMLElement>, 'className' | 'onSelect'> {
  /** Unidades con su posición relativa al plano (0–100 en cada eje). El marcador lleva el
   *  código además del color: el verde y el ámbar no sobreviven al daltonismo. */
  units?: { id: string; code: string; x: number; y: number; status: UnitStatus }[]
  /** Plano propio de la promoción (`site`) o base cartográfica de calles (`map`). */
  base?: BaseUnitMap
  /** Imagen del plano. Sin ella (`undefined`), la promoción no tiene emplazamiento y se
   *  sirve la lista con la causa; con `null`, o si la imagen falla, el plano no se pudo
   *  cargar y la lista sigue disponible. */
  baseUrl?: string | null
  /** Unidad seleccionada (marcador activo y su panel de detalle). */
  selectedId?: string
  /** Selección de una unidad, con Enter, Space o clic. El encuadre no se mueve. */
  onSelect?: (id: string) => void
  /** Agrupa los marcadores que se solapan a la escala actual, con su recuento; se
   *  separan al acercar. Dos unidades en la misma posición exacta se agrupan siempre. */
  cluster?: boolean
  /** Unidades que el filtro deja fuera. «36 de 248 unidades» se anuncia en una live
   *  region: quien no ve desaparecer marcadores necesita saberlo. */
  excludedCount?: number
  /** Destino de la lista equivalente, junto a la leyenda y con el mismo peso: la
   *  posición sobre un plano no se puede leer. */
  listHref?: string
  /** Web pública: sin acciones de gestión. El contenido del panel de detalle no debe
   *  mostrar importes de vendidas ni datos del comprador. */
  readOnly?: boolean
  /** `panel`: dentro de una card, con la leyenda debajo. `full`: el área de contenido,
   *  con el panel de detalle al lado. */
  size?: SizeUnitMap
}

const ETIQUETA: Record<UnitStatus, string> = { available: 'disponible', reserved: 'reservada', sold: 'vendida' }
const ESTADOS: UnitStatus[] = ['available', 'reserved', 'sold']
const ESCALAS = [1, 1.5, 2, 3, 4]
/** Distancia, en % del plano a escala 1, por debajo de la cual dos marcadores se agrupan. */
const UMBRAL = 4

type Marcador = { clave: string; x: number; y: number; unidades: Unit[] }

/** Orden de lectura —de arriba abajo y de inicio a fin—, no de proximidad geométrica. */
const lectura = (a: { x: number; y: number }, b: { x: number; y: number }) => a.y - b.y || a.x - b.x

function agrupar(unidades: Unit[], escala: number, agruparSolapes: boolean): Marcador[] {
  // Sin agrupación, solo se juntan las que comparten posición exacta (un dúplex): pintar
  // una encima de otra perdería la de abajo.
  const umbral = agruparSolapes ? UMBRAL / escala : 0.01
  const grupos: Marcador[] = []
  for (const u of [...unidades].sort(lectura)) {
    const g = grupos.find((m) => Math.hypot(m.x - u.x, m.y - u.y) < umbral)
    if (!g) {
      grupos.push({ clave: u.id, x: u.x, y: u.y, unidades: [u] })
      continue
    }
    g.unidades.push(u)
    const n = g.unidades.length
    g.x = (g.x * (n - 1) + u.x) / n
    g.y = (g.y * (n - 1) + u.y) / n
    g.clave = g.unidades.map((m) => m.id).join('+')
  }
  return grupos.sort(lectura)
}

const mismaPosicion = (m: Marcador) => m.unidades.every((u) => u.x === m.unidades[0]?.x && u.y === m.unidades[0]?.y)

/**
 * Las unidades de una promoción sobre su plano de emplazamiento. El lienzo es un único
 * punto de tabulación (`role="application"`) que se recorre con flechas en orden de
 * lectura; la leyenda es texto permanente y la lista equivalente está junto al mapa.
 * El contenido que se pasa como `children` es el panel de detalle de la unidad
 * seleccionada (con Escape se cierra y el foco vuelve al lienzo).
 */
export const UnitMap = forwardRef<HTMLElement, PropsUnitMap>(function UnitMap(
  {
    units = [],
    base = 'site',
    baseUrl,
    selectedId,
    onSelect,
    cluster = true,
    excludedCount = 0,
    listHref,
    readOnly = false,
    size = 'full',
    children,
    'aria-label': ariaLabel,
    'aria-labelledby': ariaLabelledby,
    ...resto
  },
  ref,
) {
  const id = useId()
  const lienzo = useRef<HTMLDivElement>(null)
  const [nivel, setNivel] = useState(0)
  const [activo, setActivo] = useState(0)
  const [panel, setPanel] = useState<Unit[] | null>(null)
  const [fallo, setFallo] = useState(false)
  const [aviso, setAviso] = useState('')
  const escala = ESCALAS[nivel] ?? 1

  const marcadores = useMemo(() => agrupar(units, escala, cluster), [units, escala, cluster])
  const indiceActivo = Math.min(activo, Math.max(0, marcadores.length - 1))
  const total = units.length + excludedCount

  // «36 de 248 unidades»: la vista ya no muestra el total.
  useEffect(() => {
    if (excludedCount > 0) setAviso(`${units.length} de ${total} unidades.`)
  }, [excludedCount, units.length, total])

  // El marcador activo se encuadra si quedó fuera al acercar; el resto del mapa no se mueve.
  useEffect(() => {
    const el = document.getElementById(`${id}-m-${indiceActivo}`)
    el?.scrollIntoView?.({ block: 'nearest', inline: 'nearest' })
  }, [id, indiceActivo, nivel])

  useEffect(() => setFallo(false), [baseUrl])

  const sinPlano = baseUrl === undefined || baseUrl === ''
  const errorDeCarga = baseUrl === null || fallo

  const acercar = (delta: number) => {
    const siguiente = Math.min(ESCALAS.length - 1, Math.max(0, nivel + delta))
    if (siguiente === nivel) return
    setNivel(siguiente)
    setAviso(`Escala ${String(ESCALAS[siguiente]).replace('.', ',')} aumentos.`)
  }

  const encuadrar = () => {
    setNivel(0)
    setActivo(0)
    lienzo.current?.scrollTo?.({ left: 0, top: 0 })
    setAviso('Toda la promoción encuadrada.')
  }

  const activar = (m: Marcador) => {
    if (m.unidades.length === 1) {
      const u = m.unidades[0] as Unit
      onSelect?.(u.id)
      setPanel([u])
      return
    }
    // Un grupo se separa al acercar; si comparte posición exacta, el panel lista sus unidades.
    if (!mismaPosicion(m) && nivel < ESCALAS.length - 1) {
      acercar(1)
      return
    }
    setPanel(m.unidades)
  }

  const teclado = (e: KeyboardEvent<HTMLDivElement>) => {
    const ultimo = marcadores.length - 1
    switch (e.key) {
      case 'ArrowDown':
      case 'ArrowRight':
        e.preventDefault()
        setActivo(indiceActivo >= ultimo ? 0 : indiceActivo + 1)
        break
      case 'ArrowUp':
      case 'ArrowLeft':
        e.preventDefault()
        setActivo(indiceActivo <= 0 ? ultimo : indiceActivo - 1)
        break
      case 'Home':
        e.preventDefault()
        encuadrar()
        break
      case 'End':
        e.preventDefault()
        setActivo(ultimo)
        break
      case 'Enter':
      case ' ': {
        e.preventDefault()
        const m = marcadores[indiceActivo]
        // El encuadre no se mueve: el usuario perdería la referencia de dónde estaba.
        if (m) activar(m)
        break
      }
      case 'Escape':
        if (panel) {
          e.preventDefault()
          setPanel(null)
        }
        break
      case '+':
      case '=':
        e.preventDefault()
        acercar(1)
        break
      case '-':
      case '_':
        e.preventDefault()
        acercar(-1)
        break
    }
  }

  const cerrarPanel = () => {
    setPanel(null)
    lienzo.current?.focus() // vuelve al lienzo, donde sigue activo el marcador que lo abrió
  }

  const marcadorActivo = marcadores[indiceActivo]
  const nombreMarcador = (m: Marcador) => {
    if (m.unidades.length === 1) {
      const u = m.unidades[0] as Unit
      return `Unidad ${u.code}, ${ETIQUETA[u.status]}`
    }
    return `Grupo de ${m.unidades.length} unidades: ${m.unidades.map((u) => `${u.code} ${ETIQUETA[u.status]}`).join(', ')}`
  }

  const enlaceLista = listHref && (
    // mismo peso que los controles, no un enlace de cortesía al final
    <a className="ay-unitmap__list" href={listHref}>
      Ver las {total} unidades en lista
    </a>
  )

  return (
    <section
      {...resto}
      ref={ref}
      className={cx(
        'ay-unitmap',
        `ay-unitmap--${size}`,
        `ay-unitmap--${base}`,
        readOnly && 'ay-unitmap--readonly',
        panel && 'ay-unitmap--detail',
      )}
      aria-label={ariaLabelledby ? ariaLabel : (ariaLabel ?? 'Plano de emplazamiento')}
      aria-labelledby={ariaLabelledby}
      data-readonly={readOnly || undefined}
    >
      {sinPlano || errorDeCarga ? (
        <div className="ay-unitmap__fallback" role="status">
          <p>
            {sinPlano
              ? `Esta promoción todavía no tiene plano de emplazamiento. Las ${total} unidades están disponibles en el listado.`
              : 'No hemos podido cargar el plano. Las unidades siguen disponibles en el listado.'}
          </p>
          {enlaceLista}
        </div>
      ) : (
        <div className="ay-unitmap__viewport">
          {/* en la esquina de inicio del lienzo, separados de los marcadores */}
          <div className="ay-unitmap__controls" role="group" aria-label="Escala del plano">
            <button
              type="button"
              className="ay-iconbtn ay-iconbtn--secondary ay-iconbtn--sm"
              aria-label="Acercar"
              disabled={nivel >= ESCALAS.length - 1}
              onClick={() => acercar(1)}
            >
              <IconoMas className="ay-iconbtn__glyph" />
            </button>
            <button
              type="button"
              className="ay-iconbtn ay-iconbtn--secondary ay-iconbtn--sm"
              aria-label="Alejar"
              disabled={nivel === 0}
              onClick={() => acercar(-1)}
            >
              <IconoMenos className="ay-iconbtn__glyph" />
            </button>
            <button
              type="button"
              className="ay-iconbtn ay-iconbtn--secondary ay-iconbtn--sm"
              aria-label="Encuadrar toda la promoción"
              onClick={encuadrar}
            >
              <IconoEncuadrar className="ay-iconbtn__glyph" />
            </button>
          </div>

          {/* un solo punto de tabulación: 248 paradas harían la página intransitable */}
          <div
            ref={lienzo}
            className="ay-unitmap__canvas"
            role="application"
            tabIndex={0}
            aria-roledescription="plano"
            aria-label={`Unidades sobre el plano: ${units.length}`}
            aria-describedby={`${id}-ayuda`}
            aria-activedescendant={marcadorActivo ? `${id}-m-${indiceActivo}` : undefined}
            onKeyDown={teclado}
          >
            <div className="ay-unitmap__layer" style={{ '--ay-escala': escala } as CSSProperties}>
              <img src={baseUrl ?? undefined} alt="" className="ay-unitmap__base" onError={() => setFallo(true)} />

              {marcadores.map((m, i) => {
                const unica = m.unidades.length === 1 ? (m.unidades[0] as Unit) : null
                const seleccionado = m.unidades.some((u) => u.id === selectedId)
                return (
                  <button
                    key={m.clave}
                    id={`${id}-m-${i}`}
                    type="button"
                    tabIndex={-1}
                    className={cx(
                      'ay-unitmap__pin',
                      unica ? `ay-unitmap__pin--${unica.status}` : 'ay-unitmap__pin--cluster',
                      seleccionado && 'is-selected',
                      i === indiceActivo && 'is-active',
                    )}
                    style={{ '--x': `${m.x}%`, '--y': `${m.y}%` } as CSSProperties}
                    aria-label={nombreMarcador(m)}
                    aria-pressed={unica ? seleccionado : undefined}
                    onClick={() => {
                      setActivo(i)
                      activar(m)
                    }}
                  >
                    {/* el código va en el marcador: el color solo no sobrevive al daltonismo */}
                    {unica ? unica.code : m.unidades.length}
                  </button>
                )
              })}
            </div>

            {units.length === 0 && (
              // el plano sigue de fondo para no perder el contexto
              <div className="ay-unitmap__empty">
                <p>{excludedCount > 0 ? 'Ninguna unidad cumple el filtro actual.' : 'Esta promoción no tiene unidades.'}</p>
              </div>
            )}
          </div>
        </div>
      )}

      <p id={`${id}-ayuda`} className="ay-visually-hidden">
        Usa las flechas para recorrer las unidades, Enter para abrir el detalle, más y menos para cambiar la
        escala e Inicio para encuadrar toda la promoción.
      </p>

      {panel && (panel.length > 1 || children) && (
        <aside className="ay-unitmap__detail" aria-label="Detalle de la unidad">
          {panel.length > 1 ? (
            <>
              <p className="ay-unitmap__detailtitle">Unidades en esta posición</p>
              <ul className="ay-unitmap__members">
                {panel.map((u) => (
                  <li key={u.id}>
                    <button
                      type="button"
                      className="ay-btn ay-btn--ghost ay-btn--sm"
                      aria-pressed={u.id === selectedId}
                      onClick={() => onSelect?.(u.id)}
                    >
                      <span className="ay-btn__label">
                        Unidad {u.code}, {ETIQUETA[u.status]}
                      </span>
                    </button>
                  </li>
                ))}
              </ul>
            </>
          ) : (
            children
          )}
          <button type="button" className="ay-btn ay-btn--ghost ay-btn--sm" onClick={cerrarPanel}>
            <span className="ay-btn__label">Cerrar el detalle</span>
          </button>
        </aside>
      )}

      <div className="ay-unitmap__foot">
        {/* texto permanente: es la clave de lectura de todo lo demás */}
        <ul className="ay-unitmap__legend" aria-label="Leyenda">
          {ESTADOS.map((s) => (
            <li key={s}>
              <span className={`ay-dot ay-dot--${s}`} aria-hidden="true" />
              {ETIQUETA[s].charAt(0).toUpperCase() + ETIQUETA[s].slice(1)}
            </li>
          ))}
        </ul>
        {!(sinPlano || errorDeCarga) && enlaceLista}
      </div>

      <p className="ay-visually-hidden" role="status" aria-live="polite">
        {aviso}
      </p>
    </section>
  )
})

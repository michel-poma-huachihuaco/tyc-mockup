/**
 * Ayudas internas de la familia Specialized. No se exportan desde el índice: no son API,
 * son lo que comparten Timeline, Notification, Calendar Event y el resto para no escribir
 * cinco veces el mismo formato de fecha o la misma trampa de foco.
 */
import { useEffect, useLayoutEffect, useRef, useState } from 'react'
import type { ReactNode } from 'react'
import { createPortal } from 'react-dom'

// ── Fechas ────────────────────────────────────────────────────────────────────

/**
 * Normaliza lo que llega como fecha. El tipo público es `Date`, pero el catálogo del
 * sistema de diseño solo transporta JSON y entrega una cadena ISO: convertirla aquí evita
 * que un ejemplo del catálogo reviente en `toISOString`.
 */
export function aFecha(valor: Date | string | number): Date {
  return valor instanceof Date ? valor : new Date(valor)
}

const MINUTOS_DIA = 24 * 60

/**
 * Relativo solo dentro de las últimas 24 horas (o las próximas, para un hito programado);
 * fuera de esa ventana, la fecha completa: lo relativo deja de ser cierto en cuanto la
 * pestaña lleva un rato abierta.
 */
export function textoRelativo(fecha: Date, locale: string, ahora = Date.now()): string {
  const minutos = (fecha.getTime() - ahora) / 60000
  if (Math.abs(minutos) > MINUTOS_DIA) {
    const larga = fecha.toLocaleDateString(locale, { dateStyle: 'long' })
    // Un hito futuro dice que es futuro: «20 de febrero» a secas se lee como pasado.
    return minutos > 0 ? `Programado para el ${larga}` : larga
  }
  const rtf = new Intl.RelativeTimeFormat(locale, { numeric: 'auto' })
  if (Math.abs(minutos) < 1) return rtf.format(0, 'second')
  if (Math.abs(minutos) < 60) return rtf.format(Math.round(minutos), 'minute')
  return rtf.format(Math.round(minutos / 60), 'hour')
}

/** Fecha completa con la hora y la zona: es lo que permite fechar lo que se lee. */
export function fechaCompleta(fecha: Date, locale: string): string {
  return new Intl.DateTimeFormat(locale, {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
    timeZoneName: 'short',
  }).format(fecha)
}

/** «10:30», en 24 horas: en una agenda o bajo la cabecera de un día no cabe «a. m.». */
export function horaMinutos(fecha: Date, locale: string): string {
  return fecha.toLocaleTimeString(locale, { hour: '2-digit', minute: '2-digit', hourCycle: 'h23' })
}

/** «lunes, 16 de febrero de 2026»: la cabecera de un día. */
export function diaCompleto(fecha: Date, locale: string): string {
  return fecha.toLocaleDateString(locale, { dateStyle: 'full' })
}

export function mismoDia(a: Date, b: Date): boolean {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate()
}

// ── Texto ─────────────────────────────────────────────────────────────────────

/**
 * Género gramatical de la entidad a partir de su singular, para concordar «4 unidades
 * seleccionadas» y «4 registros seleccionados» sin pedir un tercer dato. Cubre las
 * terminaciones femeninas regulares (-a, -dad, -ción, -sión, -tud, -umbre); una entidad
 * irregular («sistema», «mano») sale con la concordancia de la regla.
 */
export function esFemenino(singular: string): boolean {
  return /(a|dad|tad|ción|sión|tud|umbre|ie)$/i.test(singular.trim())
}

export function plural(n: number, singular: string, pluralTexto: string): string {
  return n === 1 ? singular : pluralTexto
}

/** Comparación sin mayúsculas ni tildes: «miraflores» encuentra «Miraflores». */
export function normalizar(texto: string): string {
  return texto.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase()
}

// ── Foco ──────────────────────────────────────────────────────────────────────

const ENFOCABLES = [
  'a[href]',
  'button:not([disabled])',
  'input:not([disabled]):not([type="hidden"])',
  'select:not([disabled])',
  'textarea:not([disabled])',
  '[tabindex]:not([tabindex="-1"])',
].join(',')

export function enfocables(contenedor: HTMLElement): HTMLElement[] {
  return Array.from(contenedor.querySelectorAll<HTMLElement>(ENFOCABLES)).filter(
    (el) => !el.hasAttribute('hidden') && !el.closest('[hidden]'),
  )
}

/** Trampa de foco de un diálogo modal: Tab y Mayús+Tab dan la vuelta dentro de él. */
export function atraparTab(evento: { key: string; shiftKey: boolean; preventDefault(): void }, contenedor: HTMLElement | null): void {
  if (evento.key !== 'Tab' || !contenedor) return
  const lista = enfocables(contenedor)
  if (lista.length === 0) {
    evento.preventDefault()
    return
  }
  const primero = lista[0]
  const ultimo = lista[lista.length - 1]
  const activo = document.activeElement
  if (evento.shiftKey && activo === primero) {
    evento.preventDefault()
    ultimo?.focus()
  } else if (!evento.shiftKey && activo === ultimo) {
    evento.preventDefault()
    primero?.focus()
  } else if (!contenedor.contains(activo)) {
    evento.preventDefault()
    primero?.focus()
  }
}

// ── Capa ──────────────────────────────────────────────────────────────────────

/**
 * `false` en el servidor y en el primer render del cliente; `true` antes de que el
 * navegador pinte. Decide cuándo una capa ya puede ir en un portal: el servidor no
 * admite portales, y un primer render distinto del marcado del servidor rompería la
 * hidratación. Con `useLayoutEffect` el cambio llega sin un fotograma en su sitio.
 */
export function useEnCliente(): boolean {
  const [enCliente, setEnCliente] = useState(false)
  const usar = typeof document === 'undefined' ? useEffect : useLayoutEffect
  usar(() => setEnCliente(true), [])
  return enCliente
}

/**
 * Pinta la capa en `document.body` para que ningún `overflow`, `transform` ni `z-index` de
 * un ancestro la recorte, y para que el fondo que se vuelve inerte sea solo lo que queda
 * fuera de ella. Copia del patrón `enCapa` de Overlays —las familias no se importan entre
 * sí—, con una diferencia: el portal espera a `useEnCliente`, porque el catálogo y las
 * pruebas pintan la paleta abierta con `react-dom/server` y allí no hay portales.
 */
export function enCapa(contenido: ReactNode, activo: boolean): ReactNode {
  if (!activo || typeof document === 'undefined') return contenido
  return createPortal(contenido, document.body)
}

const SIN_INERT = new Set(['SCRIPT', 'STYLE', 'TEMPLATE', 'LINK', 'META', 'NOSCRIPT'])

/**
 * Vuelve inerte todo lo que no es la capa. Con la capa en un portal sus nodos cuelgan de
 * `body`, así que basta con marcar sus hermanos: el resto de la página. `inert` y no
 * `aria-hidden`, que deja los controles alcanzables con Tab. Solo se retira lo que esta
 * capa marcó: lo que ya era inerte sigue siéndolo. Copia de `inertizarFondo` de Overlays.
 */
export function inertizarFondo(conservar: HTMLElement[]): () => void {
  const marcados: Element[] = []
  const conservados = new Set<Element>(conservar)
  const camino = new Set<Element>()
  for (const nodo of conservar) {
    let actual: Element | null = nodo.parentElement
    while (actual && actual !== document.body) {
      camino.add(actual)
      actual = actual.parentElement
    }
  }
  const recorrer = (padre: Element): void => {
    for (const hijo of Array.from(padre.children)) {
      if (conservados.has(hijo)) continue
      if (camino.has(hijo)) {
        recorrer(hijo)
        continue
      }
      if (hijo.hasAttribute('inert') || SIN_INERT.has(hijo.tagName)) continue
      hijo.setAttribute('inert', '')
      marcados.push(hijo)
    }
  }
  recorrer(document.body)
  return () => {
    for (const el of marcados) el.removeAttribute('inert')
  }
}

let bloqueos = 0
let estiloPrevio: { overflow: string; relleno: string } | null = null

/**
 * Bloquea el scroll del documento mientras la capa modal está abierta, compensando el
 * ancho de la barra para que la página no salte. Misma mecánica que `bloquearScroll` de
 * Overlays: guarda el estilo previo y lo restaura con el último desbloqueo, así que una
 * paleta abierta sobre un Modal deja el documento como lo encontró.
 */
export function bloquearScroll(): () => void {
  const cuerpo = document.body
  if (bloqueos === 0) {
    const anchoUtil = document.documentElement.clientWidth
    const barra = anchoUtil > 0 ? Math.max(0, window.innerWidth - anchoUtil) : 0
    estiloPrevio = { overflow: cuerpo.style.overflow, relleno: cuerpo.style.paddingInlineEnd }
    if (barra > 0) {
      const actual = parseFloat(getComputedStyle(cuerpo).paddingInlineEnd) || 0
      cuerpo.style.paddingInlineEnd = `${actual + barra}px`
    }
    cuerpo.style.overflow = 'hidden'
  }
  bloqueos += 1
  let liberado = false
  return () => {
    if (liberado) return
    liberado = true
    bloqueos -= 1
    if (bloqueos === 0 && estiloPrevio) {
      cuerpo.style.overflow = estiloPrevio.overflow
      cuerpo.style.paddingInlineEnd = estiloPrevio.relleno
      estiloPrevio = null
    }
  }
}

/** Con el foco en un campo de texto o en un editor, un atajo global no captura la tecla. */
export function estaEscribiendo(destino: EventTarget | null): boolean {
  if (!(destino instanceof HTMLElement)) return false
  return /^(INPUT|TEXTAREA|SELECT)$/.test(destino.tagName) || destino.isContentEditable
}

// ── Anuncios ──────────────────────────────────────────────────────────────────

/**
 * Texto para una live region que solo cambia cuando el valor deja de moverse durante
 * `ms`: anunciar en cada tecla o en cada casilla llena la escucha de cifras que cambian
 * antes de terminar de oírse.
 */
export function useAnuncioDiferido(texto: string, ms = 600): string {
  const [anuncio, setAnuncio] = useState('')
  useEffect(() => {
    const t = setTimeout(() => setAnuncio(texto), ms)
    return () => clearTimeout(t)
  }, [texto, ms])
  return anuncio
}

/** El valor de la vuelta anterior del render, para detectar transiciones. */
export function useAnterior<T>(valor: T): T | undefined {
  const ref = useRef<T | undefined>(undefined)
  useEffect(() => {
    ref.current = valor
  }, [valor])
  return ref.current
}

/**
 * Si la ventana es más estrecha que un breakpoint del sistema. El ancho se lee del token
 * (`--aybar-breakpoint-sm`…) y no se escribe aquí: si el manual de marca lo mueve, el
 * componente lo sigue. En el servidor devuelve `false`.
 */
export function useMasEstrechoQue(token: string): boolean {
  const [estrecho, setEstrecho] = useState(false)
  useEffect(() => {
    if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') return
    const ancho = getComputedStyle(document.documentElement).getPropertyValue(token).trim()
    if (!ancho) return
    const consulta = window.matchMedia(`(max-width: ${ancho})`)
    const actualizar = () => setEstrecho(consulta.matches)
    actualizar()
    consulta.addEventListener('change', actualizar)
    return () => consulta.removeEventListener('change', actualizar)
  }, [token])
  return estrecho
}

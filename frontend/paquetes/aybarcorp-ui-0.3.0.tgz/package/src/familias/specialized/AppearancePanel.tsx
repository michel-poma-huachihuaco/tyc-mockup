import { forwardRef, useId, useState } from 'react'
import type { CSSProperties, HTMLAttributes } from 'react'
import type { AppearanceAxis, AppearancePreset, AppearanceValues } from '@aybarcorp/tokens'
import { readAppearance } from '@aybarcorp/tokens/apariencia'
import { cx } from '../../utiles.js'
import { useAppearance } from '../foundations/apariencia.js'
import { Boton } from './_marcado.js'
import { SegmentedControl } from './SegmentedControl.js'

export type HeadingLevelAppearancePanel = 2 | 3 | 4

export interface PropsAppearancePanel extends Omit<HTMLAttributes<HTMLElement>, 'className' | 'title' | 'onChange'> {
  /** Título visible del panel; nombra la región (`section` con `aria-labelledby`). */
  title?: string
  /** Nivel del título en el esquema de la página: `3` dentro de una sección o de un
   *  panel lateral que ya tiene su `h2`. */
  headingLevel?: HeadingLevelAppearancePanel
  /** Los ejes que se muestran y en qué orden, por su id de `APPEARANCE` (`'theme'`,
   *  `'palette'`…). Por omisión, todos en el orden en que los declara @aybarcorp/tokens. Un
   *  id que no existe se ignora. */
  axes?: AppearanceAxis[]
  /** Las combinaciones de la marca (Petróleo Aybar, Océano, Jade, Grafito sobrio) como
   *  botones encima de los ejes: aplicar una fija sus ejes uno por uno. */
  showPresets?: boolean
  /** Después de cada cambio hecho en el panel —un valor, una combinación o restablecer—,
   *  con la apariencia que resulta. Lo que cambie fuera del panel no llega por aquí: para
   *  eso está `useAppearance()`. */
  onChange?: (appearance: AppearanceValues) => void
}

/** Cómo se enseña la muestra de cada eje que la tiene: un color, una esquina o la letra. */
const TIPO_DE_MUESTRA: Partial<Record<AppearanceAxis, 'color' | 'radius' | 'font'>> = {
  palette: 'color',
  accent: 'color',
  neutral: 'color',
  radius: 'radius',
  font: 'font',
}

/**
 * La muestra de un valor, decorativa: el nombre lo da la etiqueta. Es el valor resuelto que
 * publica `APPEARANCE` para ese valor —no el `var()` del token, que vale lo que esté elegido
 * ahora—, y llega a la hoja como `--ay-muestra`.
 */
function Muestra({ eje, valor }: { eje: AppearanceAxis; valor: string }) {
  const tipo = TIPO_DE_MUESTRA[eje] ?? 'color'
  return (
    <span
      className={cx('ay-appearance__swatch', `ay-appearance__swatch--${tipo}`)}
      style={{ '--ay-muestra': valor } as CSSProperties}
      aria-hidden="true"
    >
      {tipo === 'font' ? 'Aa' : null}
    </span>
  )
}

const enUso = (preset: AppearancePreset, actual: AppearanceValues): boolean =>
  Object.entries(preset.values).every(([eje, valor]) => actual[eje as AppearanceAxis] === valor)

/**
 * Personalización en vivo de la apariencia: un grupo por eje de `APPEARANCE` —con su nombre
 * como leyenda y su descripción asociada—, las combinaciones de la marca y «Restablecer», que
 * vuelve a lo que declara `<html>`. Lee y escribe el núcleo de @aybarcorp/tokens/apariencia
 * con `useAppearance()`: lo elegido se aplica en `<html>`, se recuerda según el núcleo y lo
 * ven el anfitrión y los remotos.
 *
 * Los ejes con muestra (paleta, acento, grises, radio, tipografía) son radios con la muestra
 * como decoración; los demás, un Segmented Control. Cada cambio se anuncia en una región
 * `status`, sin mover el foco. Cabe en 320 px: las opciones y las combinaciones envuelven.
 */
export const AppearancePanel = forwardRef<HTMLElement, PropsAppearancePanel>(function AppearancePanel(
  { title = 'Apariencia', headingLevel = 2, axes, showPresets = true, onChange, ...resto },
  ref,
) {
  const { appearance, set, reset, axes: metadatos, presets } = useAppearance()
  const [aviso, setAviso] = useState('')
  const id = useId()
  const idTitulo = `${id}-titulo`
  const idCombinaciones = `${id}-combinaciones`

  const ejes = (axes ?? (Object.keys(metadatos) as AppearanceAxis[])).filter((eje) =>
    Object.prototype.hasOwnProperty.call(metadatos, eje),
  )

  const avisar = (texto: string) => {
    setAviso(texto)
    onChange?.(readAppearance())
  }

  const elegir = (eje: AppearanceAxis, valor: string) => {
    const meta = metadatos[eje]
    const opcion = meta.values.find((v) => v.id === valor)
    if (!opcion || appearance[eje] === valor) return
    set(eje, valor as AppearanceValues[typeof eje])
    avisar(`${meta.label}: ${opcion.label}`)
  }

  const aplicar = (preset: AppearancePreset) => {
    for (const [eje, valor] of Object.entries(preset.values) as [AppearanceAxis, string][]) {
      set(eje, valor as AppearanceValues[typeof eje])
    }
    avisar(`Combinación ${preset.label} aplicada`)
  }

  const restablecer = () => {
    reset()
    avisar('Apariencia restablecida')
  }

  const Titulo = `h${headingLevel}` as 'h2' | 'h3' | 'h4'
  const muestraDePaleta = (preset: AppearancePreset) =>
    metadatos.palette.values.find((v) => v.id === preset.values.palette)?.swatch

  return (
    <section {...resto} ref={ref} className="ay-appearance" aria-labelledby={idTitulo}>
      <div className="ay-appearance__head">
        <Titulo className="ay-appearance__title" id={idTitulo}>
          {title}
        </Titulo>
        <Boton variant="ghost" size="sm" onClick={restablecer}>
          Restablecer
        </Boton>
      </div>

      {showPresets && presets.length > 0 && (
        <div className="ay-appearance__presets" role="group" aria-labelledby={idCombinaciones}>
          <p className="ay-legend" id={idCombinaciones}>
            Combinaciones
          </p>
          <ul className="ay-appearance__preset-list">
            {presets.map((preset) => {
              const muestra = muestraDePaleta(preset)
              const usada = enUso(preset, appearance)
              return (
                <li key={preset.id} className="ay-appearance__preset" data-en-uso={usada || undefined}>
                  <Boton variant="secondary" size="sm" onClick={() => aplicar(preset)}>
                    {muestra && <Muestra eje="palette" valor={muestra} />}
                    {preset.label}
                    {usada && <span className="ay-visually-hidden">, en uso</span>}
                  </Boton>
                </li>
              )
            })}
          </ul>
        </div>
      )}

      {ejes.map((eje) => {
        const meta = metadatos[eje]
        const idDescripcion = `${id}-${eje}-desc`
        const conMuestra = meta.values.some((v) => v.swatch)
        return (
          <fieldset key={eje} className="ay-group ay-group--simple ay-appearance__axis" aria-describedby={idDescripcion}>
            <legend className="ay-legend">{meta.label}</legend>
            <p className="ay-help" id={idDescripcion}>
              {meta.description}
            </p>
            {conMuestra ? (
              <div className="ay-appearance__options">
                {meta.values.map((v) => (
                  <label key={v.id} className="ay-radio">
                    <input
                      type="radio"
                      name={`${id}-${eje}`}
                      value={v.id}
                      checked={appearance[eje] === v.id}
                      onChange={() => elegir(eje, v.id)}
                    />
                    <span className="ay-radio__text">
                      <span className="ay-appearance__option">
                        {v.swatch && <Muestra eje={eje} valor={v.swatch} />}
                        {v.label}
                      </span>
                    </span>
                  </label>
                ))}
              </div>
            ) : (
              <SegmentedControl
                label={meta.label}
                options={meta.values.map((v) => ({ value: v.id, label: v.label }))}
                value={appearance[eje]}
                onValueChange={(valor) => elegir(eje, valor)}
                fullWidth
              />
            )}
          </fieldset>
        )
      })}

      {/* presente desde el principio: una live region que nace con texto no se anuncia */}
      <p className="ay-visually-hidden" role="status">
        {aviso}
      </p>
    </section>
  )
})

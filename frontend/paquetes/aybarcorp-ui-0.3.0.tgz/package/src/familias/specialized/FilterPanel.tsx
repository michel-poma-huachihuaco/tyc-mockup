import { forwardRef, useId, useRef, useState } from 'react'
import type { HTMLAttributes, KeyboardEvent, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { Boton, Esqueleto, Insignia } from './_marcado.js'
import { useAnuncioDiferido, useMasEstrechoQue } from './_internos.js'

export type ApplyModeFilterPanel = 'immediate' | 'explicit'
export type PlacementFilterPanel = 'sidebar' | 'drawer'
export type SizeFilterPanel = 'md' | 'lg'

export interface PropsFilterPanel extends Omit<HTMLAttributes<HTMLElement>, 'className'> {
  /** Grupos de filtros, uno por criterio («Estado», «Precio», «Dormitorios»). Cada uno es
   *  un `fieldset` con `legend` y se pliega desde su cabecera. `control` es el Checkbox,
   *  Radio, Range Slider o Date Range Picker del criterio; `loading` pinta un Skeleton
   *  con `aria-busy` en ese grupo, no en el panel entero. */
  groups?: Array<{ id: string; label: string; control: ReactNode; appliedCount?: number; loading?: boolean }>
  /** Filtros aplicados. El recuento va en la cabecera: sin él, quien no ve los Chips no
   *  sabe que el listado está filtrado. */
  appliedCount?: number
  /** Limpia todos. El botón dice cuántos quita y el foco vuelve a la cabecera del panel,
   *  porque los controles que había debajo desaparecen. */
  onClearAll?: () => void
  /** `immediate`: cada cambio reconsulta y el nuevo recuento se anuncia con retardo.
   *  `explicit`: los cambios se acumulan hasta «Aplicar», fijo al pie, que dice el
   *  recuento previsto; Enter aplica. */
  applyMode?: ApplyModeFilterPanel
  /** Aplica los cambios pendientes en el modo explícito. */
  onApply?: () => void
  /** Resultados previstos al aplicar, en el modo explícito. */
  pendingCount?: number
  /** Resultados actuales. Con 0, el panel propone quitar el último filtro por su nombre. */
  resultCount?: number
  /** Combinaciones guardadas, como accesos a la vista sobre los grupos. */
  savedFilters?: Array<{ id: string; label: string }>
  /** `sidebar`: panel fijo junto al listado, en escritorio; por debajo del breakpoint
   *  `lg` se oculta, porque ahí el panel pasa a Drawer con el botón de abrir en la
   *  toolbar. `drawer`: el mismo panel dentro de un Drawer modal (el Drawer aporta la
   *  trampa de foco y Escape). */
  placement?: PlacementFilterPanel
  /** Nombre de la entidad en plural, para los recuentos: «171 unidades». */
  itemLabel?: string
  /** Quita el último filtro aplicado, cuando no hay resultados. */
  onRemoveLast?: () => void
  /** Nombre del último filtro aplicado, para ofrecer quitarlo: «Quitar «Vendida»». */
  lastFilterLabel?: string
  /** Ancho del panel: `md` por defecto o `lg`, más ancho, para facetas con etiquetas largas. */
  size?: SizeFilterPanel
}

/**
 * Panel que combina varios filtros con el estado aplicado siempre visible y una forma
 * clara de limpiarlo. Es una región con nombre; los Chips de aplicados viven sobre el
 * listado, no dentro del panel. Con dos o tres filtros, Filter Control en la Table
 * Toolbar ocupa menos.
 */
export const FilterPanel = forwardRef<HTMLElement, PropsFilterPanel>(function FilterPanel(
  {
    groups = [],
    appliedCount = 0,
    onClearAll,
    applyMode = 'immediate',
    onApply,
    pendingCount,
    resultCount,
    savedFilters,
    placement = 'sidebar',
    itemLabel = 'resultados',
    onRemoveLast,
    lastFilterLabel,
    size = 'md',
    onKeyDown,
    ...resto
  },
  ref,
) {
  const id = useId()
  const cabecera = useRef<HTMLHeadingElement>(null)
  const [plegados, setPlegados] = useState<ReadonlySet<string>>(() => new Set())

  const plegar = (grupo: string) =>
    setPlegados((actual) => {
      const siguiente = new Set(actual)
      if (siguiente.has(grupo)) siguiente.delete(grupo)
      else siguiente.add(grupo)
      return siguiente
    })

  const limpiar = () => {
    onClearAll?.()
    cabecera.current?.focus() // el foco vuelve a la cabecera, no a un control retirado
  }

  // En el modo explícito se anuncia el previsto; en el inmediato, el nuevo recuento. Con
  // retardo en los dos: no en cada casilla.
  const recuento =
    applyMode === 'explicit'
      ? pendingCount != null
        ? `${pendingCount} ${itemLabel} al aplicar`
        : ''
      : resultCount != null
        ? `${resultCount} ${itemLabel}`
        : ''
  const anuncio = useAnuncioDiferido(recuento, 700)

  // Por debajo de lg el lateral pasa a Drawer: el ancho sale del token, no de una media
  // query con un literal que la regla de tokens no admite.
  const estrecho = useMasEstrechoQue('--aybar-breakpoint-lg')

  const teclado = (e: KeyboardEvent<HTMLElement>) => {
    onKeyDown?.(e)
    if (e.defaultPrevented || applyMode !== 'explicit' || e.key !== 'Enter') return
    const destino = e.target as HTMLElement
    // Enter en un botón o un enlace hace lo suyo; en una casilla o un campo, aplica.
    if (destino.closest('button, a, textarea, [role="combobox"]')) return
    e.preventDefault()
    onApply?.()
  }

  return (
    <aside
      {...resto}
      ref={ref}
      className={cx('ay-filterpanel', `ay-filterpanel--${placement}`, size === 'lg' && 'ay-filterpanel--lg')}
      role="region"
      aria-labelledby={`${id}-titulo`}
      data-narrow={placement === 'sidebar' && estrecho ? 'true' : undefined}
      onKeyDown={teclado}
    >
      <div className="ay-filterpanel__head">
        <h2 className="ay-filterpanel__title" id={`${id}-titulo`} ref={cabecera} tabIndex={-1}>
          Filtros
          {appliedCount > 0 && (
            <>
              <Insignia aria-hidden="true">{appliedCount}</Insignia>
              <span className="ay-visually-hidden">
                ({appliedCount} {appliedCount === 1 ? 'aplicado' : 'aplicados'})
              </span>
            </>
          )}
        </h2>

        {appliedCount > 0 && (
          // dice cuántos limpia
          <Boton variant="ghost" size="sm" onClick={limpiar}>
            Limpiar {appliedCount === 1 ? 'el filtro' : `los ${appliedCount} filtros`}
          </Boton>
        )}
      </div>

      {savedFilters && savedFilters.length > 0 && (
        <div className="ay-filterpanel__saved" role="group" aria-label="Filtros guardados">
          {savedFilters.map((f) => (
            <span key={f.id} className="ay-chip">
              <span className="ay-chip__text">{f.label}</span>
            </span>
          ))}
        </div>
      )}

      {groups.map((g) => {
        const plegado = plegados.has(g.id)
        return (
          // aria-busy en el grupo, no en el panel completo
          <fieldset key={g.id} className="ay-filterpanel__group" aria-busy={g.loading || undefined}>
            <legend className="ay-filterpanel__grouptitle">
              <button
                type="button"
                className="ay-filterpanel__toggle"
                aria-expanded={!plegado}
                aria-controls={`${id}-${g.id}`}
                onClick={() => plegar(g.id)}
              >
                {g.label}
                {g.appliedCount ? (
                  <>
                    <Insignia aria-hidden="true">{g.appliedCount}</Insignia>
                    <span className="ay-visually-hidden">
                      ({g.appliedCount} {g.appliedCount === 1 ? 'aplicado' : 'aplicados'})
                    </span>
                  </>
                ) : null}
              </button>
            </legend>
            <div className="ay-filterpanel__groupbody" id={`${id}-${g.id}`} hidden={plegado}>
              {g.loading ? <Esqueleto className="ay-filterpanel__skel" /> : g.control}
            </div>
          </fieldset>
        )
      })}

      {resultCount === 0 && lastFilterLabel && (
        // salida concreta, en lugar de dejar probando combinaciones
        <div className="ay-filterpanel__noresults">
          <p>No hay {itemLabel} que cumplan todos los filtros.</p>
          <Boton variant="secondary" size="sm" onClick={onRemoveLast}>
            Quitar «{lastFilterLabel}»
          </Boton>
        </div>
      )}

      {applyMode === 'explicit' && (
        <div className="ay-filterpanel__actions">
          <Boton variant="primary" size="sm" full onClick={onApply}>
            {/* el previsto, antes de aplicar */}
            Aplicar{pendingCount != null ? ` · ${pendingCount} ${itemLabel}` : ''}
          </Boton>
        </div>
      )}

      <p className="ay-visually-hidden" aria-live="polite">
        {anuncio}
      </p>
    </aside>
  )
})

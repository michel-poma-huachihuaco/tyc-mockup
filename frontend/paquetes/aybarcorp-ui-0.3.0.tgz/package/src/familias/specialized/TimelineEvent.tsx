import { forwardRef, useId, useState } from 'react'
import type { LiHTMLAttributes, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { aFecha, fechaCompleta, textoRelativo } from './_internos.js'

export type ToneTimelineEvent = 'default' | 'accent' | 'success' | 'danger'

// Un hito de la secuencia que recibe `Timeline` en `events`: los mismos datos que pinta
// `TimelineEvent`, más el `id` estable que conserva el orden de llegada. Comparte nombre
// con el componente a propósito —es el mismo hito como dato y como pieza—; el JSDoc va en
// el componente para que el catálogo no mezcle las dos descripciones.
export type TimelineEvent = {
  /** Identificador estable del hito. */
  id: string
  /** Qué cambió, como frase con verbo: «cambió el estado a reservada». */
  title: ReactNode
  /** Momento del hito. */
  date: Date
  /** Quién lo hizo; sin autor se escribe «Sistema». */
  author?: string
  /** Tono del marcador; el tipo de hito se dice también en `title`. */
  tone?: ToneTimelineEvent
  /** Valores anterior y nuevo u otro contenido largo, plegado. */
  detail?: ReactNode
  /** Avatar del autor en lugar del punto. */
  avatar?: ReactNode
  /** Icono del tipo de hito en lugar del punto. */
  icon?: ReactNode
  /** Acción del hito: enlace o botón al final del contenido. */
  action?: ReactNode
}

export interface PropsTimelineEvent extends Omit<LiHTMLAttributes<HTMLLIElement>, 'className' | 'title'> {
  /** Descripción del cambio, como frase con sujeto y verbo: «cambió el estado a
   *  reservada». El tipo de hito se lee aquí y no en el color del marcador. */
  title: ReactNode
  /** Momento del hito. Se pinta en un `time` con `datetime` ISO; el texto es relativo
   *  dentro de las últimas 24 horas y la fecha completa, con zona, va en su `title`. */
  date: Date
  /** Autor del cambio. Un hito sin autor dice «Sistema»: dejarlo vacío hace pensar en un
   *  dato que falta. Un autor dado de baja conserva su nombre con la indicación. */
  author?: string
  /** Avatar del autor; sustituye al punto como marcador. Es decorativo: el nombre ya va
   *  escrito en el hito. */
  avatar?: ReactNode
  /** Icono del tipo de hito; sustituye al punto como marcador, también decorativo. */
  icon?: ReactNode
  /** Tono del marcador. Acompaña al texto, no lo sustituye: el motivo de un hito de error
   *  va escrito en `title`. Un hito con fecha futura se pinta además con el marcador hueco
   *  de «programado». */
  tone?: ToneTimelineEvent
  /** Contenido adicional (valores anterior y nuevo en un `dl`), plegado tras un
   *  disparador con `aria-expanded` y `aria-controls`. Plegado no reserva espacio. */
  detail?: ReactNode
  /** Acción del hito —deshacer, ver el documento—, al final del contenido y no junto a la
   *  fecha. Una acción que ya no está disponible no se pasa, en vez de deshabilitarla. */
  action?: ReactNode
  /** Locale del formato de fecha. */
  locale?: string
}

type PropsHito = PropsTimelineEvent & {
  /** Solo desde Timeline: el texto visible de la fecha cuando el contexto lo cambia
   *  (la hora bajo la cabecera de un día, o la hora con minutos de dos hitos simultáneos). */
  textoFecha?: string
}

/** Cuerpo compartido entre `TimelineEvent` y las filas que pinta `Timeline`. */
export const Hito = forwardRef<HTMLLIElement, PropsHito>(function Hito(
  {
    title,
    date,
    author = 'Sistema',
    avatar,
    icon,
    tone = 'default',
    detail,
    action,
    locale = 'es-PE',
    textoFecha,
    ...resto
  },
  ref,
) {
  const id = useId()
  const [abierto, setAbierto] = useState(false)
  const fecha = aFecha(date)
  const programado = fecha.getTime() > Date.now()

  return (
    <li {...resto} ref={ref} className="ay-timeline__event">
      {/* marcador decorativo: el tipo de hito se lee en la descripción */}
      {avatar ? (
        <span className="ay-timeline__avatar" aria-hidden="true">
          {avatar}
        </span>
      ) : icon ? (
        <span className={cx('ay-timeline__icon', `ay-timeline__dot--${tone}`)} aria-hidden="true">
          {icon}
        </span>
      ) : (
        <span
          className={cx('ay-timeline__dot', `ay-timeline__dot--${tone}`, programado && 'ay-timeline__dot--pending')}
          aria-hidden="true"
        />
      )}

      <div className="ay-timeline__body">
        <p className="ay-timeline__title">
          {/* vacío haría pensar en un dato que falta */}
          <strong>{author || 'Sistema'}</strong> {title}
        </p>

        <time
          className="ay-timeline__time"
          dateTime={fecha.toISOString()}
          title={fechaCompleta(fecha, locale)}
          // lo relativo depende del reloj: el servidor y el navegador pueden diferir un minuto
          suppressHydrationWarning
        >
          {textoFecha ?? textoRelativo(fecha, locale)}
        </time>

        {detail && (
          <>
            <button
              type="button"
              className="ay-collapsible__trigger"
              aria-expanded={abierto}
              aria-controls={`${id}-detalle`}
              onClick={() => setAbierto((a) => !a)}
            >
              {abierto ? 'Ocultar el detalle' : 'Ver el detalle'}
            </button>
            {/* plegado no reserva espacio: hidden, no altura cero */}
            <div className="ay-timeline__detail" id={`${id}-detalle`} hidden={!abierto}>
              {detail}
            </div>
          </>
        )}

        {action && <div className="ay-timeline__actions">{action}</div>}
      </div>
    </li>
  )
})

/**
 * Un hito de un historial: marcador, autor, descripción, fecha y, si los hay, detalle
 * plegable y acciones. Es un elemento de lista y no un encabezado; vive dentro de
 * `Timeline` (o de un `ol.ay-timeline` propio), nunca suelto.
 */
export const TimelineEvent = forwardRef<HTMLLIElement, PropsTimelineEvent>(function TimelineEvent(
  {
    title,
    date,
    author = 'Sistema',
    avatar,
    icon,
    tone = 'default',
    detail,
    action,
    locale = 'es-PE',
    ...resto
  },
  ref,
) {
  return (
    <Hito
      {...resto}
      ref={ref}
      title={title}
      date={date}
      author={author}
      avatar={avatar}
      icon={icon}
      tone={tone}
      detail={detail}
      action={action}
      locale={locale}
    />
  )
})

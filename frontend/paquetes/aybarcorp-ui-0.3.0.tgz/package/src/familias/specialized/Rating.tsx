import { forwardRef, useId, useState } from 'react'
import type { HTMLAttributes, Ref } from 'react'
import { cx } from '../../utiles.js'
import { IconoEstrella } from './_iconos.js'

export type SizeRating = 'sm' | 'md' | 'lg'

export interface PropsRating extends Omit<HTMLAttributes<HTMLElement>, 'className'> {
  /** Qué se valora; obligatorio: «Valoración de la visita». En lectura abre el nombre
   *  accesible; en entrada es la `legend` del grupo de radios. */
  label: string
  /** Valor actual, 0 por omisión. En lectura admite decimales: se pinta redondeado al
   *  medio punto y el texto conserva el valor exacto. Sin valor (0) se escribe «Sin
   *  valoraciones», nunca «0 de 5». Sin `value` en modo de entrada, el control lleva su
   *  propio estado. */
  value?: number
  /** Cambio de valor. Su presencia activa el modo de entrada: radios reales dentro de un
   *  `fieldset`, con flechas, foco y envío de formulario nativos. Supr limpia la
   *  valoración (llama con 0). */
  onValueChange?: (v: number) => void
  /** Puntos de la escala. Con otra escala distinta de cinco, el texto dice el máximo
   *  real. Por encima de cinco, Radio con etiquetas es más claro. */
  max?: number
  /** Admite medios puntos en lectura. */
  allowHalf?: boolean
  /** Número de valoraciones. Entra en el nombre accesible —«4 de 5, 128
   *  valoraciones»—: dos opiniones y ciento veintiocho no pueden sonar igual. */
  count?: number
  /** Tamaño del icono: `sm` (en tablas), `md` o `lg` (en entrada). */
  size?: SizeRating
  /** Impide valorar: pinta la lectura aunque haya `onValueChange`. Es el paso de una
   *  valoración ya enviada. */
  readOnly?: boolean
  /** Deshabilita la escala mientras se guarda. */
  submitting?: boolean
}

const numero = new Intl.NumberFormat('es-PE', { maximumFractionDigits: 2 })
const entero = new Intl.NumberFormat('es-PE')

/**
 * Valoración en una escala corta, con el valor siempre legible como texto. En lectura no
 * es interactivo —texto con iconos decorativos—; en entrada son radios reales.
 */
export const Rating = forwardRef<HTMLElement, PropsRating>(function Rating(
  {
    label,
    value,
    onValueChange,
    max = 5,
    allowHalf = false,
    count,
    size = 'md',
    readOnly = false,
    submitting = false,
    onKeyDown,
    ...resto
  },
  ref,
) {
  const name = useId()
  const [interno, setInterno] = useState(0)
  // La previsualización al apuntar es solo visual: no toca el valor ni lo que se anuncia.
  const [preview, setPreview] = useState<number | null>(null)
  const actual = value ?? interno
  // «su presencia activa el modo de entrada»: también un `null` explícito, que es como
  // un catálogo en JSON declara un callback.
  const entrada = onValueChange !== undefined && !readOnly

  const texto = actual > 0 ? `${numero.format(actual)} de ${max}` : 'Sin valoraciones'
  const recuento = count != null ? `${entero.format(count)} ${count === 1 ? 'valoración' : 'valoraciones'}` : null
  const descripcion = recuento ? `${texto}, ${recuento}` : texto

  const cambiar = (v: number) => {
    if (value === undefined) setInterno(v)
    onValueChange?.(v)
  }

  if (!entrada) {
    // lectura: texto con iconos decorativos, no controles que prometen una interacción
    const mostrado = allowHalf ? Math.round(actual * 2) / 2 : Math.round(actual)
    return (
      <p
        {...resto}
        onKeyDown={onKeyDown}
        ref={ref as Ref<HTMLParagraphElement>}
        className={cx('ay-rating', `ay-rating--${size}`)}
        aria-label={`${label}: ${descripcion}`}
      >
        <span className="ay-rating__icons" aria-hidden="true">
          {Array.from({ length: max }, (_, i) => (
            <IconoEstrella key={i} relleno={mostrado >= i + 1 ? 'full' : mostrado >= i + 0.5 ? 'half' : 'empty'} />
          ))}
        </span>
        <span className="ay-rating__value">{texto}</span>
        {recuento && <span className="ay-rating__count">{recuento}</span>}
      </p>
    )
  }

  return (
    <fieldset
      {...resto}
      ref={ref as Ref<HTMLFieldSetElement>}
      className={cx('ay-rating', 'ay-rating--input', `ay-rating--${size}`)}
      disabled={submitting}
      aria-busy={submitting || undefined}
      onKeyDown={(e) => {
        onKeyDown?.(e)
        // Supr limpia la valoración: es la única forma de volver a «sin valorar» con radios.
        if (e.key === 'Delete' && actual > 0 && !e.defaultPrevented) {
          e.preventDefault()
          cambiar(0)
        }
      }}
    >
      <legend className="ay-label">{label}</legend>

      <div className="ay-rating__scale" onMouseLeave={() => setPreview(null)}>
        {Array.from({ length: max }, (_, i) => {
          const v = i + 1
          const relleno = (preview ?? actual) >= v
          return (
            <label
              key={v}
              className="ay-rating__star"
              data-filled={relleno || undefined}
              onMouseEnter={() => setPreview(v)}
            >
              {/* radio real: flechas, foco y envío del formulario vienen dados */}
              <input
                type="radio"
                className="ay-visually-hidden"
                name={name}
                value={v}
                checked={actual === v}
                onChange={() => cambiar(v)}
              />
              <IconoEstrella relleno={relleno ? 'full' : 'empty'} />
              {/* «3» a secas no dice de cuánto es ni qué se valora */}
              <span className="ay-visually-hidden">
                {v} de {max} estrellas
              </span>
            </label>
          )
        })}
      </div>

      {/* el valor, siempre en texto */}
      <p className="ay-rating__value">{texto}</p>
    </fieldset>
  )
})

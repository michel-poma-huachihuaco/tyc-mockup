import { forwardRef, useEffect, useId, useRef, useState } from 'react'
import type { HTMLAttributes, KeyboardEvent } from 'react'
import { cx } from '../../utiles.js'
import { Boton, Confirmacion, Insignia } from './_marcado.js'
import { enfocables, useMasEstrechoQue } from './_internos.js'

export type ComparatorItem = {
  /** Identificador estable de la unidad. */
  id: string
  /** Código de la unidad: «Unidad 402». */
  code: string
  /** Precio ya formateado, con la misma cantidad de decimales en todas: «S/ 284,000». */
  price: string
  /** Estado de negocio: «Disponible». */
  status: string
  /** Promoción, cuando se comparan unidades de promociones distintas. */
  promotion?: string
  /** Valor de cada atributo, por su `key`. Un valor ausente se escribe «Sin dato». */
  values: Record<string, unknown>
}

export type ComparatorAttribute = {
  /** Clave del atributo en `values`. */
  key: string
  /** Nombre como en la ficha, con su unidad: «Superficie útil (m²)». */
  label: string
  /** Formato del valor para la celda. */
  format?: (v: unknown) => string
}

export type LayoutComparator = 'table' | 'stacked'

export interface PropsComparator extends Omit<HTMLAttributes<HTMLDivElement>, 'className'> {
  /** Unidades comparadas, máximo cuatro: a partir de ahí no se compara, se lee una
   *  tabla. Cada cabecera lleva código, precio y estado, y la promoción si la hay. */
  items?: ComparatorItem[]
  /** Atributos comparados, en su orden. Cada fila lleva su unidad en el nombre, no en
   *  cada celda. */
  attributes?: { key: string; label: string; format?: (v: unknown) => string }[]
  /** Oculta las filas idénticas y dice cuántas ocultó; si no queda ninguna, dice que las
   *  unidades son equivalentes. `false` por omisión; sin `diffOnly`, el filtro lleva su
   *  propio estado. */
  diffOnly?: boolean
  /** Cambia el filtro «Mostrar solo lo que cambia». */
  onDiffOnlyChange?: (v: boolean) => void
  /** Quita una unidad de la comparación, tras confirmarlo (botón o Supr). El foco pasa a
   *  la columna vecina. */
  onRemove?: (id: string) => void
  /** Abre el selector para añadir otra unidad, desde el hueco de columna. */
  onAdd?: () => void
  /** Plazas disponibles; el hueco de añadir aparece mientras queden. Nunca más de cuatro. */
  maxItems?: number
  /** `table`: columnas paralelas. `stacked`: una unidad tras otra, con el atributo
   *  repetido en cada bloque; es lo que se usa por debajo de 40rem aunque se pida tabla. */
  layout?: LayoutComparator
  /** La columna de atributos no se desplaza en horizontal: sin ella, una cifra de la
   *  tercera columna no se puede atribuir a ningún atributo. */
  stickyAttributes?: boolean
}

const MAXIMO_ABSOLUTO = 4
const vacio = (v: unknown) => v === undefined || v === null || v === ''

/**
 * Dos o tres unidades en columnas paralelas, con los mismos atributos en la misma fila.
 * Es una tabla real con cabeceras de fila y de columna —lo que permite anunciar
 * «Superficie, unidad 403, 96 metros cuadrados»— y la diferencia se marca con fondo y con
 * la palabra «difiere».
 */
export const Comparator = forwardRef<HTMLDivElement, PropsComparator>(function Comparator(
  {
    items = [],
    attributes = [],
    diffOnly,
    onDiffOnlyChange,
    onRemove,
    onAdd,
    maxItems = 3,
    layout = 'table',
    stickyAttributes = true,
    ...resto
  },
  ref,
) {
  const id = useId()
  const contenedor = useRef<HTMLDivElement | null>(null)
  const [interno, setInterno] = useState(false)
  const [quitando, setQuitando] = useState<ComparatorItem | null>(null)
  const [aviso, setAviso] = useState('')
  const enfocarTras = useRef<string | null>(null)
  const estados = useRef(new Map<string, string>())
  const estrecho = useMasEstrechoQue('--aybar-breakpoint-sm')

  const soloDiferencias = diffOnly ?? interno
  const tope = Math.min(maxItems, MAXIMO_ABSOLUTO)
  const columnas = items.slice(0, MAXIMO_ABSOLUTO)
  const disposicion: LayoutComparator = estrecho ? 'stacked' : layout

  // Una unidad que cambia de estado mientras se compara lo anuncia, sin salir de la tabla.
  useEffect(() => {
    const cambios: string[] = []
    for (const i of columnas) {
      const antes = estados.current.get(i.id)
      if (antes !== undefined && antes !== i.status) cambios.push(`${i.code} ahora está ${i.status.toLowerCase()}.`)
      estados.current.set(i.id, i.status)
    }
    if (cambios.length) setAviso(cambios.join(' '))
  })

  // Tras quitar una columna, el foco va a la vecina; si no queda ninguna, al hueco.
  useEffect(() => {
    if (enfocarTras.current === null) return
    const destino =
      contenedor.current?.querySelector<HTMLElement>(`[data-quitar="${enfocarTras.current}"]`) ??
      contenedor.current?.querySelector<HTMLElement>('[data-anadir]')
    destino?.focus()
    enfocarTras.current = null
  }, [items])

  const difiere = (clave: string) => {
    if (columnas.length < 2) return false
    const vs = columnas.map((i) => (vacio(i.values[clave]) ? null : String(i.values[clave])))
    return vs.some((v) => v !== vs[0])
  }

  const filas = attributes.filter((a) => !soloDiferencias || difiere(a.key))
  const ocultas = attributes.length - filas.length
  // «No hay diferencias» y «algo falló» no se distinguen con la tabla vacía.
  const sinDiferencias = soloDiferencias && attributes.length > 0 && filas.length === 0

  const formatear = (a: (typeof attributes)[number], v: unknown) =>
    vacio(v) ? 'Sin dato' : a.format ? a.format(v) : String(v)

  const confirmarQuitar = (item: ComparatorItem) => {
    const i = columnas.findIndex((c) => c.id === item.id)
    const vecina = columnas[i + 1] ?? columnas[i - 1]
    enfocarTras.current = vecina?.id ?? ''
    setQuitando(null)
    onRemove?.(item.id)
  }

  const conHueco = columnas.length < tope

  // Dentro de la rejilla las flechas se mueven de celda en celda como en una tabla, e
  // Inicio y Fin van a la primera y la última columna de la fila actual. Solo entre los
  // controles: la lectura de celdas es cosa del lector, que ya recorre una tabla real.
  const moverEnFila = (e: KeyboardEvent<HTMLTableElement>) => {
    if (e.defaultPrevented || !['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(e.key)) return
    const origen = e.target as HTMLElement
    if (origen.matches('input, textarea, select')) return
    const fila = origen.closest('tr')
    if (!fila) return
    const controles = enfocables(fila)
    const i = controles.indexOf(origen)
    if (i < 0) return
    const destino =
      e.key === 'Home'
        ? controles[0]
        : e.key === 'End'
          ? controles[controles.length - 1]
          : controles[i + (e.key === 'ArrowRight' ? 1 : -1)]
    if (!destino) return
    e.preventDefault()
    destino.focus()
  }

  return (
    <div
      {...resto}
      ref={(el) => {
        contenedor.current = el
        if (typeof ref === 'function') ref(el)
        else if (ref) ref.current = el
      }}
      className={cx('ay-compare-wrap', `ay-compare-wrap--${disposicion}`)}
    >
      <label className="ay-compare__filter ay-check">
        <input
          type="checkbox"
          checked={soloDiferencias}
          onChange={(e) => {
            if (diffOnly === undefined) setInterno(e.target.checked)
            onDiffOnlyChange?.(e.target.checked)
          }}
        />
        <span className="ay-check__text">Mostrar solo lo que cambia</span>
      </label>

      {items.length > MAXIMO_ABSOLUTO && (
        <p className="ay-compare__hint">
          Se comparan las {MAXIMO_ABSOLUTO} primeras de {items.length}: a partir de cuatro no se compara, se lee una tabla.
        </p>
      )}

      {/* la caja se desplaza dentro de su contenedor, nunca la página */}
      <div className="ay-compare__scroll" role="region" aria-labelledby={`${id}-caption`} tabIndex={0}>
        <table className={cx('ay-compare', stickyAttributes && 'is-sticky')} onKeyDown={moverEnFila}>
          <caption id={`${id}-caption`}>Comparación de unidades</caption>

          <thead>
            <tr>
              <td />
              {columnas.map((i) => (
                <th key={i.id} scope="col">
                  {i.code}
                  {/* sin la promoción, dos unidades con el mismo número se confunden */}
                  {i.promotion && <span className="ay-compare__promo">{i.promotion}</span>}
                  <span className="ay-compare__price">{i.price}</span>
                  <Insignia>{i.status}</Insignia>
                </th>
              ))}
              {conHueco && (
                <th scope="col" className="ay-compare__slot">
                  <Boton variant="secondary" size="sm" data-anadir="" onClick={onAdd}>
                    Añadir una unidad
                  </Boton>
                </th>
              )}
            </tr>
          </thead>

          <tbody>
            {filas.map((a) => {
              const d = difiere(a.key)
              return (
                <tr key={a.key} className={cx(d && 'ay-compare__row--diff')}>
                  <th scope="row">
                    {a.label}
                    {/* la palabra, a la vista y no solo el fondo: el color no lo comunica */}
                    {d && (
                      <span className="ay-compare__diff" aria-hidden="true">
                        difiere
                      </span>
                    )}
                  </th>
                  {columnas.map((i) => (
                    <td key={i.id} data-attr={a.label}>
                      {formatear(a, i.values[a.key])}
                      {d && <span className="ay-visually-hidden"> (difiere)</span>}
                    </td>
                  ))}
                  {conHueco && <td className="ay-compare__slot" />}
                </tr>
              )
            })}
          </tbody>

          {columnas.length > 0 && (
            <tfoot>
              {/* las acciones van al pie de cada columna, alineadas entre sí */}
              <tr>
                <td />
                {columnas.map((i) => (
                  <td key={i.id}>
                    <Boton
                      variant="ghost"
                      size="sm"
                      data-quitar={i.id}
                      onClick={() => setQuitando(i)}
                      onKeyDown={(e) => {
                        if (e.key === 'Delete') {
                          e.preventDefault()
                          setQuitando(i)
                        }
                      }}
                    >
                      Quitar {i.code}
                    </Boton>
                  </td>
                ))}
                {conHueco && <td className="ay-compare__slot" />}
              </tr>
            </tfoot>
          )}
        </table>
      </div>

      <p className="ay-compare__hint" role="status" aria-live="polite">
        {sinDiferencias
          ? 'Las unidades comparadas son equivalentes en todo lo comparado.'
          : ocultas > 0
            ? `${ocultas} ${ocultas === 1 ? 'fila igual oculta' : 'filas iguales ocultas'}.`
            : ''}
      </p>
      <p className="ay-visually-hidden" role="status">
        {aviso}
      </p>

      {quitando && (
        <Confirmacion
          title={`¿Quitar ${quitando.code} de la comparación?`}
          description="Las demás unidades siguen comparables; puedes volver a añadirla desde el listado."
          confirmLabel={`Quitar ${quitando.code}`}
          onConfirm={() => confirmarQuitar(quitando)}
          onCancel={() => {
            const devolver = quitando.id
            setQuitando(null)
            requestAnimationFrame(() =>
              contenedor.current?.querySelector<HTMLElement>(`[data-quitar="${devolver}"]`)?.focus(),
            )
          }}
        />
      )}
    </div>
  )
})

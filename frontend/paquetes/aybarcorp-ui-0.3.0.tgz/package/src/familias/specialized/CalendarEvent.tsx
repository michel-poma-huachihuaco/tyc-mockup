import { forwardRef, useId } from 'react'
import type { ButtonHTMLAttributes, CSSProperties, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { aFecha, horaMinutos, mismoDia } from './_internos.js'

export type TypeCalendarEvent = 'visita' | 'firma' | 'entrega'
export type StatusCalendarEvent = 'confirmed' | 'tentative' | 'cancelled'

export interface PropsCalendarEvent
  extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'className' | 'title' | 'type' | 'onSelect'> {
  /** Asunto del evento con su objeto: «Visita a la unidad 402». Se recorta a la vista;
   *  el nombre accesible lo conserva completo. */
  title: string
  /** Inicio. Fija la posición en la rejilla. */
  start: Date
  /** Fin. Con el inicio fija el alto; un evento de 15 minutos mantiene el alto mínimo. */
  end: Date
  /** Tipo, que define el tono de la banda lateral. Se dice también con texto: un
   *  calendario de colores sin texto es ilegible para quien no los distingue. */
  type?: TypeCalendarEvent
  /** Estado. `tentative` pinta borde discontinuo y escribe «por confirmar»;
   *  `cancelled` tacha el título y escribe «cancelada». El estado entra siempre en el
   *  nombre accesible. */
  status?: StatusCalendarEvent
  /** Evento de todo el día: banda en la parte superior, sin horas. */
  allDay?: boolean
  /** Asistentes (Avatar Group), dentro del bloque. */
  attendees?: ReactNode
  /** Posición dentro del solape. El solape reparte el ancho y no entra en el nombre
   *  accesible: no es información del evento. */
  overlapIndex?: number
  /** Eventos que comparten franja. */
  overlapCount?: number
  /** Abre el detalle (Popover o Side Panel). Enter y Space lo activan. */
  onSelect?: () => void
  /** Hora de inicio de la rejilla (0–23), para calcular la posición. */
  dayStart?: number
  /** Hora de fin de la rejilla (1–24). */
  dayEnd?: number
  /** Locale del formato de hora. */
  locale?: string
}

const ESTADO: Record<StatusCalendarEvent, string> = {
  confirmed: 'confirmada',
  tentative: 'por confirmar',
  cancelled: 'cancelada',
}

/**
 * Un evento dentro de una rejilla de calendario. Es un botón cuyo nombre accesible lleva
 * todo lo que el tamaño obliga a recortar —«Visita a la unidad 402, de 10:00 a 11:00,
 * confirmada»—. La rejilla lo posiciona en absoluto y lo pinta en orden cronológico en el
 * DOM, para que el teclado siga el tiempo y no las coordenadas.
 */
export const CalendarEvent = forwardRef<HTMLButtonElement, PropsCalendarEvent>(function CalendarEvent(
  {
    title,
    start,
    end,
    type = 'visita',
    status = 'confirmed',
    allDay = false,
    attendees,
    overlapIndex = 0,
    overlapCount = 1,
    onSelect,
    dayStart = 8,
    dayEnd = 20,
    locale = 'es-PE',
    style,
    onClick,
    ...resto
  },
  ref,
) {
  const idTipo = useId()
  const inicio = aFecha(start)
  const fin = aFecha(end)
  const total = Math.max(1, (dayEnd - dayStart) * 60)
  const desde = (inicio.getHours() - dayStart) * 60 + inicio.getMinutes()
  const duracion = Math.max(0, (fin.getTime() - inicio.getTime()) / 60000)
  const solapes = Math.max(1, overlapCount)
  const cruzaDia = !allDay && !mismoDia(inicio, fin)
  const estadoTexto = ESTADO[status]

  const horas = allDay
    ? 'todo el día'
    : `de ${horaMinutos(inicio, locale)} a ${horaMinutos(fin, locale)}${cruzaDia ? ' del día siguiente' : ''}`

  const posicion = allDay
    ? {}
    : {
        '--ay-top': `${(desde / total) * 100}%`,
        '--ay-height': `${(Math.min(duracion, total - desde) / total) * 100}%`,
        // el solape reparte el ancho; no es información del evento
        '--ay-width': `${100 / solapes}%`,
        '--ay-offset': `${(100 / solapes) * overlapIndex}%`,
      }

  return (
    <button
      {...resto}
      ref={ref}
      type="button"
      className={cx(
        'ay-calevent',
        `ay-calevent--${type}`,
        status !== 'confirmed' && `ay-calevent--${status}`,
        allDay && 'ay-calevent--allday',
        cruzaDia && 'ay-calevent--continues',
        fin.getTime() < Date.now() && 'ay-calevent--past',
      )}
      style={{ ...posicion, ...style } as CSSProperties}
      // todo lo que el tamaño recorta, aquí completo
      aria-label={`${title}, ${horas}, ${estadoTexto}`}
      // el tipo, escrito: el color de la banda no se lee
      aria-describedby={idTipo}
      onClick={(e) => {
        onClick?.(e)
        onSelect?.()
      }}
      suppressHydrationWarning
    >
      {!allDay && (
        <span className="ay-calevent__time">
          <time dateTime={inicio.toISOString()}>{horaMinutos(inicio, locale)}</time>–
          <time dateTime={fin.toISOString()}>{horaMinutos(fin, locale)}</time>
        </span>
      )}

      <span className="ay-calevent__title">{title}</span>

      {status !== 'confirmed' && (
        // el estado, escrito: el tachado o el borde no se leen
        <span className="ay-calevent__status">{estadoTexto}</span>
      )}
      {cruzaDia && <span className="ay-calevent__status">continúa al día siguiente</span>}

      <span className="ay-visually-hidden" id={idTipo}>
        Tipo: {type}
      </span>

      {attendees}
    </button>
  )
})

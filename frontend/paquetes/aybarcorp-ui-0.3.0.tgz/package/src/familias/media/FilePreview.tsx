import { forwardRef, useEffect, useState } from 'react'
import type { HTMLAttributes, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { IconoArchivoAviso, IconoTipoArchivo } from './_iconos.js'
import { extensionDe, familiaDeArchivo, formatearPeso, recortarPorElMedio } from './_internos.js'

export type EstadoVistaPrevia = 'ready' | 'loading' | 'error'
export type PosicionAcciones = 'overlay' | 'below'
export type TamanoCaja = 'sm' | 'md' | 'lg'

export interface PropsFilePreview extends Omit<HTMLAttributes<HTMLElement>, 'className'> {
  /** Nombre del archivo, tal cual. Visible bajo la vista previa y completo en `title`. */
  name: string
  /** Peso en bytes; se escribe con unidad legible («2,4 MB») para decidir antes de abrir. */
  size?: number
  /** Tipo MIME. Elige el marcador por tipo cuando no hay miniatura. */
  type?: string
  /** Origen de la miniatura. Si falta o no carga, la caja cae al marcador por tipo: nunca
   *  se deja vacía. */
  thumbnail?: string
  /** Alternativa de la miniatura. Vacía por omisión: el nombre ya está visible y repetirlo
   *  en el alt lo haría leer dos veces. */
  alt?: string
  /** Estado. `loading` reserva la proporción con un Skeleton; `error` escribe el fallo y
   *  ofrece reintentar. */
  status?: EstadoVistaPrevia
  /** Acciones (descargar, eliminar). Cada una nombra el archivo. */
  actions?: ReactNode
  /** Posición de las acciones: en velo sobre la caja o debajo. En velo siguen visibles con
   *  el foco dentro, no solo al apuntar. */
  actionsPosition?: PosicionAcciones
  /** Abre el visor. Con él, la vista previa es un botón «Ver <nombre>». */
  onOpen?: () => void
  /** Tamaño de la caja: `sm` (ocho rem de ancho máximo), `md` (doce) o `lg` (dieciséis). */
  boxSize?: TamanoCaja
  /** Reintenta la carga. Con él, el estado de fallo ofrece «Reintentar». */
  onRetry?: () => void
}

/**
 * Vista previa de un archivo con su estado de carga y acceso a verlo completo o
 * descargarlo. Si el archivo no tiene representación visual útil, File Item dice lo
 * mismo ocupando menos.
 */
export const FilePreview = forwardRef<HTMLElement, PropsFilePreview>(function FilePreview(
  {
    name,
    size,
    type,
    thumbnail,
    alt = '',
    status = 'ready',
    actions,
    actionsPosition = 'overlay',
    onOpen,
    boxSize = 'md',
    onRetry,
    ...resto
  },
  ref,
) {
  // Si la miniatura falla, se cae al marcador por tipo: la caja no se deja vacía.
  const [miniaturaFallida, setMiniaturaFallida] = useState(false)
  useEffect(() => setMiniaturaFallida(false), [thumbnail])

  const extension = extensionDe(name).slice(1).toUpperCase()
  const recortado = recortarPorElMedio(name)
  const peso = formatearPeso(size)
  const conMiniatura = !!thumbnail && !miniaturaFallida

  const contenido =
    status === 'loading' ? (
      <span className="ay-skel ay-skel--block ay-filepreview__skel" aria-hidden="true" />
    ) : status === 'error' ? (
      <div className="ay-filepreview__error">
        <IconoArchivoAviso lado={24} />
        <span>No se pudo cargar la vista previa</span>
        {onRetry && (
          <button type="button" className="ay-btn ay-btn--ghost ay-btn--sm" onClick={onRetry} aria-label={`Reintentar la vista previa de ${name}`}>
            <span className="ay-btn__label">Reintentar</span>
          </button>
        )}
      </div>
    ) : conMiniatura ? (
      <img src={thumbnail} alt={alt} loading="lazy" decoding="async" onError={() => setMiniaturaFallida(true)} />
    ) : (
      // Marcador por tipo: aria-hidden, el tipo ya lo anuncia el nombre.
      <div className="ay-filepreview__type" aria-hidden="true">
        <IconoTipoArchivo familia={familiaDeArchivo(type, name)} lado={28} />
        {extension && <span>{extension}</span>}
      </div>
    )

  const abrible = !!onOpen && status === 'ready'

  return (
    <figure
      {...resto}
      ref={ref}
      className={cx('ay-filepreview', `ay-filepreview--${boxSize}`, status !== 'ready' && `ay-filepreview--${status}`)}
      aria-busy={status === 'loading' || undefined}
    >
      {abrible ? (
        // Una imagen con manejador de clic no se anuncia como control: es un botón.
        <button type="button" className="ay-filepreview__box" aria-label={`Ver ${name}`} onClick={onOpen}>
          {contenido}
        </button>
      ) : (
        <div className={cx('ay-filepreview__box', !conMiniatura && status === 'ready' && 'ay-filepreview__box--type')}>
          {contenido}
        </div>
      )}

      {actions != null && actions !== false && status !== 'loading' && (
        <div className={cx('ay-filepreview__actions', `ay-filepreview__actions--${actionsPosition}`)}>{actions}</div>
      )}

      <figcaption className="ay-filepreview__caption">
        {/* Nombre muy largo: se recorta por el medio conservando la extensión; el completo
            queda en el título y en el texto accesible, porque el recorte es solo visual. */}
        <span className="ay-filepreview__name" title={name}>
          {recortado === name ? (
            name
          ) : (
            <>
              <span aria-hidden="true">{recortado}</span>
              <span className="ay-visually-hidden">{name}</span>
            </>
          )}
        </span>
        {peso && <span className="ay-filepreview__meta">{peso}</span>}
      </figcaption>
    </figure>
  )
})

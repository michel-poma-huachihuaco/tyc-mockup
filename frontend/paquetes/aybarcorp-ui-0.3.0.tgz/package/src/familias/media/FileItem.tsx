import { Fragment, forwardRef } from 'react'
import type { CSSProperties, LiHTMLAttributes, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { IconoTipoArchivo } from './_iconos.js'
import { acotar, familiaDeArchivo, formatearPeso, recortarPorElMedio } from './_internos.js'

export type EstadoArchivo = 'ready' | 'uploading' | 'error'

export interface PropsFileItem extends Omit<LiHTMLAttributes<HTMLLIElement>, 'className'> {
  /** Nombre del archivo, tal cual está guardado. Si es largo se recorta por el medio
   *  conservando la extensión; el completo queda en `title` y en el texto accesible. */
  name: string
  /** Peso en bytes; se formatea al mostrar («2,4 MB», no «2411724»). Desconocido: se
   *  omite, no se pone 0 bytes. */
  size?: number
  /** Tipo MIME o extensión. Elige el icono de tipo, que es decorativo. */
  type?: string
  /** Estado. `uploading` muestra el progreso; `error`, el motivo escrito. */
  status?: EstadoArchivo
  /** Porcentaje durante la subida (0–100). Se anuncia como `progressbar` y se escribe. */
  progress?: number
  /** Motivo del fallo: qué pasó y qué hacer. «El archivo supera 10 MB. Comprímelo o divídelo». */
  error?: string
  /** Fecha y autoría, tras el peso: «12 mar 2026 · María Rojas». */
  meta?: ReactNode
  /** Acciones de la fila. Cada una nombra el archivo: «Descargar contrato-402.pdf». */
  actions?: ReactNode
  /** Estado de selección, para acciones en lote. */
  selected?: boolean
  /** Cambio de selección. Si está, la fila muestra la casilla «Seleccionar <nombre>». */
  onSelectedChange?: (selected: boolean) => void
}

/**
 * Un archivo en una lista: tipo, nombre, peso y las acciones que admite. Va dentro de
 * un `ul`; eliminar siempre pasa por confirmación, nunca por una tecla suelta.
 */
export const FileItem = forwardRef<HTMLLIElement, PropsFileItem>(function FileItem(
  {
    name,
    size,
    type,
    status = 'ready',
    progress,
    error,
    meta,
    actions,
    selected,
    onSelectedChange,
    ...resto
  },
  ref,
) {
  const peso = formatearPeso(size)
  const recortado = recortarPorElMedio(name)
  const valor = progress == null ? null : Math.round(acotar(progress, 0, 100))
  const subido = valor != null && size != null ? formatearPeso((size * valor) / 100) : null

  const metadatos = [peso, meta].filter((x) => x != null && x !== '' && x !== false)

  return (
    <li
      {...resto}
      ref={ref}
      className={cx(
        'ay-fileitem',
        status !== 'ready' && `ay-fileitem--${status}`,
        selected && 'ay-fileitem--selected',
      )}
    >
      {onSelectedChange && (
        <label className="ay-check ay-fileitem__check">
          <input type="checkbox" checked={!!selected} onChange={(e) => onSelectedChange(e.target.checked)} />
          <span className="ay-visually-hidden">Seleccionar {name}</span>
        </label>
      )}

      {/* Decorativo: el tipo ya lo dice la extensión del nombre. */}
      <IconoTipoArchivo familia={familiaDeArchivo(type, name)} className="ay-fileitem__icon" />

      <div className="ay-fileitem__main">
        {/* El recorte es solo visual: el lector oye el nombre entero. */}
        <span className="ay-fileitem__name" title={name}>
          {recortado === name ? (
            name
          ) : (
            <>
              <span aria-hidden="true">{recortado}</span>
              <span className="ay-visually-hidden">{name}</span>
            </>
          )}
        </span>

        {status === 'uploading' && valor != null && (
          <>
            <div
              className="ay-progress__track ay-fileitem__progress"
              role="progressbar"
              aria-label={`Subiendo ${name}`}
              aria-valuenow={valor}
              aria-valuemin={0}
              aria-valuemax={100}
            >
              <div className="ay-progress__fill" style={{ '--ay-value': `${valor}%` } as CSSProperties} />
            </div>
            {/* El porcentaje también escrito: no se depende del relleno de la barra. */}
            <span className="ay-fileitem__meta">
              {valor}%{peso && (subido ? ` · ${subido} de ${peso}` : ` · de ${peso}`)}
            </span>
          </>
        )}

        {status === 'ready' && metadatos.length > 0 && (
          <span className="ay-fileitem__meta">
            {metadatos.map((x, i) => (
              <Fragment key={i}>
                {i > 0 && ' · '}
                {x}
              </Fragment>
            ))}
          </span>
        )}

        {/* Región polite presente desde el principio: el fallo se anuncia al ocurrir, y el
            motivo va escrito, no solo el borde en tono danger. */}
        <span className="ay-fileitem__error" role="status" aria-live="polite">
          {status === 'error' ? error || `No se pudo subir ${name}.` : ''}
        </span>
      </div>

      {actions != null && actions !== false && <div className="ay-fileitem__actions">{actions}</div>}
    </li>
  )
})

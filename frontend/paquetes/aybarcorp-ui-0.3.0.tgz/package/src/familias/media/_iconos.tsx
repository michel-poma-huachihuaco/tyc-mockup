/**
 * Glifos de la familia Media. Internos: no se exportan en el índice.
 *
 * Todos son decorativos —`aria-hidden` y sin `focusable`— porque el nombre accesible lo
 * da siempre el control que los contiene o el texto que los acompaña. Heredan el color
 * con `currentColor`; el tamaño lo fija la hoja con la clase de cada uso y el atributo
 * numérico solo cubre el caso de que la hoja no haya cargado.
 */
import type { ReactNode, SVGAttributes } from 'react'
import type { FamiliaArchivo } from './_internos.js'

type PropsIcono = Omit<SVGAttributes<SVGSVGElement>, 'children'> & { lado?: number }

function Icono({ lado, children, ...resto }: PropsIcono & { children: ReactNode }) {
  return (
    <svg
      {...resto}
      width={lado ?? 20}
      height={lado ?? 20}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.75"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
    >
      {children}
    </svg>
  )
}

export const IconoImagenRota = (p: PropsIcono) => (
  <Icono {...p}>
    <path d="M3 3l18 18" />
    <path d="M21 15V5a2 2 0 0 0-2-2H9" />
    <path d="M3 7v12a2 2 0 0 0 2 2h12" />
    <path d="M3 16l5-5 4 4" />
  </Icono>
)

export const IconoArchivoAviso = (p: PropsIcono) => (
  <Icono {...p}>
    <path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z" />
    <path d="M14 3v5h5" />
    <path d="M12 11v4" />
    <path d="M12 18h.01" />
  </Icono>
)

export const IconoAcercar = (p: PropsIcono) => (
  <Icono {...p}>
    <circle cx="11" cy="11" r="7" />
    <path d="M21 21l-4.3-4.3M11 8v6M8 11h6" />
  </Icono>
)

export const IconoAlejar = (p: PropsIcono) => (
  <Icono {...p}>
    <circle cx="11" cy="11" r="7" />
    <path d="M21 21l-4.3-4.3M8 11h6" />
  </Icono>
)

export const IconoEncuadrar = (p: PropsIcono) => (
  <Icono {...p}>
    <path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5" />
  </Icono>
)

export const IconoRestablecer = (p: PropsIcono) => (
  <Icono {...p}>
    <path d="M3 12a9 9 0 1 0 3-6.7" />
    <path d="M3 4v5h5" />
  </Icono>
)

export const IconoCerrar = (p: PropsIcono) => (
  <Icono {...p}>
    <path d="M6 6l12 12M18 6L6 18" />
  </Icono>
)

export const IconoAnterior = (p: PropsIcono) => (
  <Icono {...p}>
    <path d="M15 18l-6-6 6-6" />
  </Icono>
)

export const IconoSiguiente = (p: PropsIcono) => (
  <Icono {...p}>
    <path d="M9 18l6-6-6-6" />
  </Icono>
)

export const IconoDescargar = (p: PropsIcono) => (
  <Icono {...p}>
    <path d="M12 4v11M7 10l5 5 5-5M5 20h14" />
  </Icono>
)

/** Icono del tipo de archivo, deducido de la familia. Decorativo: el tipo lo dice la extensión. */
export function IconoTipoArchivo({ familia, ...p }: PropsIcono & { familia: FamiliaArchivo }) {
  return (
    <Icono {...p}>
      <path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z" />
      <path d="M14 3v5h5" />
      {familia === 'imagen' && <path d="M8 17l3-3 2 2 3-3" />}
      {familia === 'pdf' && <path d="M8 13h8M8 16h5" />}
      {familia === 'documento' && <path d="M8 12h8M8 15h8M8 18h5" />}
      {familia === 'hoja' && <path d="M8 12h8v6H8zM12 12v6M8 15h8" />}
      {familia === 'plano' && <path d="M8 11h8v7H8zM12 11v3h4" />}
    </Icono>
  )
}

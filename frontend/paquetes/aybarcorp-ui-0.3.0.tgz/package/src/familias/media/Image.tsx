import { forwardRef, useEffect, useRef, useState } from 'react'
import type { CSSProperties, HTMLAttributes, Ref } from 'react'
import { cx } from '../../utiles.js'
import { IconoImagenRota } from './_iconos.js'

export type EncajeImagen = 'cover' | 'contain'
export type CargaImagen = 'lazy' | 'eager'
export type RadioImagen = 'none' | 'md' | 'lg'

export interface PropsImage extends Omit<HTMLAttributes<HTMLElement>, 'className'> {
  /** Origen de la imagen. Una cadena vacía pinta el marcador «sin imagen» con el `alt`
   *  como texto de lo que iría ahí, en lugar de una caja vacía que parece un fallo. */
  src: string
  /** Texto alternativo. Describe la función de la imagen en su contexto, no lo que se ve,
   *  y no empieza por «Imagen de». Cadena vacía si es decorativa: sin `alt`, el lector lee
   *  el nombre del archivo. */
  alt: string
  /** Proporción de la caja en formato CSS (`'16 / 9'`, `'4 / 3'`, `'1 / 1'`). Reserva el
   *  hueco antes de cargar para que el contenido no salte. */
  ratio?: string
  /** Encaje. `cover` para fotografías; `contain` para planos, que no se pueden recortar. */
  fit?: EncajeImagen
  /** Punto de anclaje del recorte con `cover` (`'center'`, `'top'`, `'50% 20%'`). En un
   *  retrato dentro de una caja horizontal, `'top'` evita cortar caras. */
  position?: string
  /** Carga diferida. `lazy` salvo la imagen principal visible al cargar la página. Al
   *  imprimir se fuerza la carga completa. */
  loading?: CargaImagen
  /** Pie visible. Envuelve la imagen en `figure` con `figcaption`; aporta el dato que la
   *  imagen no dice: fecha, autoría, referencia. */
  caption?: string
  /** Radio de la caja. `md` para tarjetas; `none` cuando la imagen va a sangre. */
  radius?: RadioImagen
  /** Fuentes por ancho (`srcset`), para servir la resolución adecuada a cada pantalla. */
  srcSet?: string
  /** Ancho que ocupará la imagen en cada punto de corte (`sizes`), para elegir del `srcSet`. */
  sizes?: string
}

type EstadoImagen = 'cargando' | 'ok' | 'error'

/**
 * Imagen de contenido con proporción declarada, encaje controlado y un estado de fallo
 * con texto que no rompe el layout. No es interactiva: si abre el visor, el disparador
 * es un botón que la envuelve.
 */
export const Image = forwardRef<HTMLElement, PropsImage>(function Image(
  {
    src,
    alt,
    ratio = '16 / 9',
    fit = 'cover',
    position = 'center',
    loading = 'lazy',
    caption,
    radius = 'md',
    srcSet,
    sizes,
    style,
    ...resto
  },
  ref,
) {
  const [estado, setEstado] = useState<EstadoImagen>('cargando')
  const imagen = useRef<HTMLImageElement>(null)

  // Una imagen nueva empieza a cargar de cero: el fallo de la anterior no se hereda.
  useEffect(() => setEstado('cargando'), [src])

  // Una imagen que ya estaba en caché puede terminar antes de hidratar y no disparar
  // `load`: se lee su estado real al montar.
  useEffect(() => {
    const el = imagen.current
    if (el?.complete) setEstado(el.naturalWidth > 0 ? 'ok' : 'error')
  }, [src])

  // Al imprimir, la imagen sale a resolución completa y sin carga diferida.
  useEffect(() => {
    if (typeof window === 'undefined') return
    const forzar = () => {
      if (imagen.current) imagen.current.loading = 'eager'
    }
    window.addEventListener('beforeprint', forzar)
    return () => window.removeEventListener('beforeprint', forzar)
  }, [])

  const decorativa = alt === ''
  const sinImagen = src === ''
  const estadoVisible: EstadoImagen | 'vacia' = sinImagen ? 'vacia' : estado

  const caja = (
    <div
      {...(caption ? {} : resto)}
      ref={caption ? undefined : (ref as Ref<HTMLDivElement>)}
      className={cx('ay-image', `ay-image--r-${radius}`, `ay-image--${estadoVisible}`)}
      // aspect-ratio reserva el hueco: el contenido no salta al cargar.
      style={{ aspectRatio: ratio, ...(caption ? {} : style) } as CSSProperties}
    >
      {sinImagen ? (
        // Marcador «sin imagen»: dice qué iría ahí.
        decorativa ? null : <span className="ay-image__placeholder">{alt}</span>
      ) : estado === 'error' ? (
        // El fallo tiene texto, no solo un icono roto.
        <div className="ay-image__error">
          <IconoImagenRota lado={24} className="ay-image__error-icon" />
          <span>No se pudo cargar la imagen</span>
        </div>
      ) : (
        <img
          ref={imagen}
          className="ay-image__img"
          src={src}
          srcSet={srcSet}
          sizes={sizes}
          alt={alt}
          // Decorativa: alt vacío, no ausente, y fuera del árbol de accesibilidad.
          aria-hidden={decorativa || undefined}
          loading={loading}
          decoding="async"
          style={{ objectFit: fit, objectPosition: position }}
          onLoad={() => setEstado('ok')}
          onError={() => setEstado('error')}
        />
      )}
    </div>
  )

  if (!caption) return caja
  return (
    <figure {...resto} ref={ref} className="ay-image__figure" style={style}>
      {caja}
      <figcaption className="ay-image__caption">{caption}</figcaption>
    </figure>
  )
})

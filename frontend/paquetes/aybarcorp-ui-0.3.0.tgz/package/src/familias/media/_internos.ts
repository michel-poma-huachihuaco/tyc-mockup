/**
 * Ayudas internas de la familia Media. No se exportan en el índice: no son API.
 *
 * Viven aparte de los componentes porque `props-desde-tipos.mjs` lee los valores por
 * omisión de toda desestructuración con inicializador del `.tsx`; una función auxiliar
 * con `{ max = 32 }` en el mismo archivo se colaría en la tabla de props.
 */
import { useEffect, useLayoutEffect, useState } from 'react'
import type { ReactNode } from 'react'
import { createPortal } from 'react-dom'

/** Unidades del peso legible: «2,4 MB» y no «2411724». */
const UNIDADES = ['B', 'KB', 'MB', 'GB', 'TB'] as const

/**
 * Formato numérico de la familia: coma decimal, como escriben las fichas («2,4 MB»,
 * «4,20 m»). `es-PE` de CLDR usa punto decimal y contradiría el contenido aprobado.
 */
export const LOCALE_NUMEROS = 'es'

/**
 * Peso con unidad legible. Devuelve `null` si el peso es desconocido: se omite, no se
 * pinta «0 B», que diría que el archivo está vacío.
 */
export function formatearPeso(bytes?: number | null): string | null {
  if (bytes == null || !Number.isFinite(bytes) || bytes < 0) return null
  let indice = 0
  let valor = bytes
  while (valor >= 1024 && indice < UNIDADES.length - 1) {
    valor /= 1024
    indice += 1
  }
  return `${valor.toLocaleString(LOCALE_NUMEROS, { maximumFractionDigits: 1 })} ${UNIDADES[indice]}`
}

/** La extensión con su punto (`.pdf`), o cadena vacía si el nombre no la tiene. */
export function extensionDe(nombre: string): string {
  const punto = nombre.lastIndexOf('.')
  return punto > 0 && punto < nombre.length - 1 ? nombre.slice(punto) : ''
}

/**
 * Recorta por el medio conservando la extensión, que es la parte que identifica el
 * tipo: «contrato-reserva-unid…402-firmado.pdf». El recorte es solo visual; quien lo
 * usa debe dejar el nombre completo en `title` y en el texto accesible.
 */
export function recortarPorElMedio(nombre: string, maximo = 32): string {
  if (nombre.length <= maximo) return nombre
  const extension = extensionDe(nombre)
  const base = extension ? nombre.slice(0, -extension.length) : nombre
  const visible = Math.max(2, maximo - extension.length - 1)
  const inicio = Math.ceil(visible * 0.6)
  const fin = Math.floor(visible * 0.4)
  return `${base.slice(0, inicio)}…${fin > 0 ? base.slice(-fin) : ''}${extension}`
}

/** Familias de archivo que tienen icono propio. */
export type FamiliaArchivo = 'pdf' | 'imagen' | 'documento' | 'hoja' | 'plano' | 'otro'

/** Deduce la familia del archivo por su tipo MIME o, si falta, por la extensión del nombre. */
export function familiaDeArchivo(tipo: string | undefined, nombre = ''): FamiliaArchivo {
  const mime = (tipo ?? '').toLowerCase()
  const extension = extensionDe(nombre).slice(1).toLowerCase() || mime.replace(/^\./, '')
  if (mime === 'application/pdf' || extension === 'pdf') return 'pdf'
  if (/^(dwg|dxf|vnd\.dwg|image\/vnd\.dwg)$/.test(extension) || mime.includes('dwg')) return 'plano'
  if (mime.startsWith('image/') || /^(png|jpe?g|gif|webp|avif|svg|tiff?|bmp|heic)$/.test(extension)) return 'imagen'
  if (/(spreadsheet|excel|csv)/.test(mime) || /^(xlsx?|ods|csv)$/.test(extension)) return 'hoja'
  if (/(word|opendocument\.text|rtf|msword)/.test(mime) || /^(docx?|odt|rtf|txt)$/.test(extension)) return 'documento'
  return 'otro'
}

/**
 * Sigue `prefers-reduced-motion`. En el servidor y en el primer render devuelve `false`
 * y se corrige en el efecto: así el marcado del servidor coincide con el del cliente.
 */
export function usePrefiereMovimientoReducido(): boolean {
  const [reducido, setReducido] = useState(false)
  useEffect(() => {
    if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') return
    const consulta = window.matchMedia('(prefers-reduced-motion: reduce)')
    const actualizar = () => setReducido(consulta.matches)
    actualizar()
    consulta.addEventListener?.('change', actualizar)
    return () => consulta.removeEventListener?.('change', actualizar)
  }, [])
  return reducido
}

/**
 * `false` en el servidor y en el render de hidratación; `true` desde el primer efecto.
 * Sirve para no pintar un estado de carga que solo el cliente puede resolver: en un
 * marcado estático (el catálogo, una página sin JavaScript) un esqueleto o un indicador
 * de carga se quedarían ahí para siempre tapando un contenido que sí está.
 */
export function useMontado(): boolean {
  const [montado, setMontado] = useState(false)
  useEffect(() => setMontado(true), [])
  return montado
}

const ENFOCABLES = [
  'a[href]',
  'area[href]',
  'button:not([disabled])',
  'input:not([disabled]):not([type="hidden"])',
  'select:not([disabled])',
  'textarea:not([disabled])',
  'iframe',
  'object',
  '[contenteditable="true"]',
  '[tabindex]:not([tabindex="-1"])',
].join(',')

/** Los elementos que reciben foco con Tab dentro de `raiz`, en orden de documento. */
export function enfocablesDentro(raiz: HTMLElement): HTMLElement[] {
  return Array.from(raiz.querySelectorAll<HTMLElement>(ENFOCABLES)).filter(
    (el) => !el.hasAttribute('inert') && !el.closest('[inert]') && el.getAttribute('aria-hidden') !== 'true',
  )
}

/**
 * Marca como inerte todo lo que no es `elemento` ni uno de sus antecesores: el fondo de
 * un diálogo modal. Recorre hacia arriba hasta `body` y, en cada nivel, vuelve inertes a
 * los hermanos. Devuelve la función que deshace exactamente lo que hizo, sin tocar un
 * `inert` que ya estuviera puesto por otra razón.
 */
export function volverInerteElFondo(elemento: HTMLElement): () => void {
  const tocados: HTMLElement[] = []
  let actual: HTMLElement | null = elemento
  while (actual && actual.parentElement && actual !== document.body) {
    const padre: HTMLElement = actual.parentElement
    for (const hermano of Array.from(padre.children)) {
      if (hermano === actual || !(hermano instanceof HTMLElement)) continue
      if (hermano.hasAttribute('inert') || hermano.tagName === 'SCRIPT' || hermano.tagName === 'STYLE') continue
      hermano.setAttribute('inert', '')
      tocados.push(hermano)
    }
    actual = padre
  }
  return () => {
    for (const el of tocados) el.removeAttribute('inert')
  }
}

/**
 * `false` en el servidor y en el primer render del cliente; `true` antes de que el
 * navegador pinte. Decide cuándo una capa ya puede ir en un portal: el servidor no
 * admite portales, y un primer render distinto del marcado del servidor rompería la
 * hidratación. Con `useLayoutEffect` el cambio llega sin un fotograma en su sitio.
 */
export function useEnCliente(): boolean {
  const [enCliente, setEnCliente] = useState(false)
  const usar = typeof document === 'undefined' ? useEffect : useLayoutEffect
  usar(() => setEnCliente(true), [])
  return enCliente
}

/**
 * Pinta la capa en `document.body` para que ningún `overflow`, `transform` ni `z-index` de
 * un ancestro la recorte, y para que el fondo que se vuelve inerte sea solo lo que queda
 * fuera de ella. Copia del patrón `enCapa` de Overlays —las familias no se importan entre
 * sí—, con una diferencia: aquí el portal espera a `useEnCliente`, porque el catálogo y
 * las pruebas pintan el visor abierto con `react-dom/server` y allí no hay portales.
 */
export function enCapa(contenido: ReactNode, activo: boolean): ReactNode {
  if (!activo || typeof document === 'undefined') return contenido
  return createPortal(contenido, document.body)
}

let bloqueos = 0
let estiloPrevio: { overflow: string; relleno: string } | null = null

/**
 * Bloquea el scroll del documento mientras el visor modal está abierto, compensando el
 * ancho de la barra: si la página salta al abrir, quien usa magnificador pierde el punto
 * que miraba. Misma mecánica que `bloquearScroll` de Overlays: guarda el estilo previo y
 * lo restaura con el último desbloqueo, así que un visor abierto desde un Modal (que ya
 * bloqueó) deja el documento como lo encontró.
 */
export function bloquearScroll(): () => void {
  const cuerpo = document.body
  if (bloqueos === 0) {
    const anchoUtil = document.documentElement.clientWidth
    const barra = anchoUtil > 0 ? Math.max(0, window.innerWidth - anchoUtil) : 0
    estiloPrevio = { overflow: cuerpo.style.overflow, relleno: cuerpo.style.paddingInlineEnd }
    if (barra > 0) {
      const actual = parseFloat(getComputedStyle(cuerpo).paddingInlineEnd) || 0
      cuerpo.style.paddingInlineEnd = `${actual + barra}px`
    }
    cuerpo.style.overflow = 'hidden'
  }
  bloqueos += 1
  let liberado = false
  return () => {
    if (liberado) return
    liberado = true
    bloqueos -= 1
    if (bloqueos === 0 && estiloPrevio) {
      cuerpo.style.overflow = estiloPrevio.overflow
      cuerpo.style.paddingInlineEnd = estiloPrevio.relleno
      estiloPrevio = null
    }
  }
}

/** Mantiene un valor entre dos extremos. */
export function acotar(valor: number, minimo: number, maximo: number): number {
  return Math.min(maximo, Math.max(minimo, valor))
}

/**
 * `false` para los esquemas que ejecutan código (`javascript:`, `vbscript:`). El plano se
 * asigna con `setAttribute('data', …)` sobre un `object`, fuera del saneado de React: la
 * comprobación tiene que estar aquí.
 */
export function esUrlSegura(url: string): boolean {
  return !/^\s*(?:javascript|vbscript):/i.test(url)
}

/**
 * Centro de la zona `[data-zone="<id>"]` del SVG incrustado, en coordenadas del contenido
 * desplazable del lienzo. `null` si no hay zona, si el SVG no es del mismo origen (no se
 * puede leer su documento) o si la zona no tiene caja.
 */
export function centroDeZona(
  objeto: HTMLObjectElement | null,
  lienzo: HTMLElement,
  id: string,
): { x: number; y: number } | null {
  if (!objeto || !id) return null
  let documento: Document | null
  try {
    documento = objeto.contentDocument
  } catch {
    return null
  }
  if (!documento) return null
  const zona = Array.from(documento.querySelectorAll('[data-zone]')).find((z) => z.getAttribute('data-zone') === id)
  if (!zona) return null
  const caja = zona.getBoundingClientRect()
  if (!caja.width && !caja.height) return null
  const marco = objeto.getBoundingClientRect()
  const vista = lienzo.getBoundingClientRect()
  return {
    x: marco.left - vista.left - lienzo.clientLeft + lienzo.scrollLeft + caja.left + caja.width / 2,
    y: marco.top - vista.top - lienzo.clientTop + lienzo.scrollTop + caja.top + caja.height / 2,
  }
}

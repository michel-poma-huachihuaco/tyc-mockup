import { forwardRef, useCallback, useEffect, useId, useImperativeHandle, useRef, useState } from 'react'
import type {
  CSSProperties,
  HTMLAttributes,
  KeyboardEvent as KeyboardEventReact,
  MouseEvent as MouseEventReact,
  PointerEvent as PointerEventReact,
} from 'react'
import { cx } from '../../utiles.js'
import {
  acotar,
  bloquearScroll,
  enCapa,
  enfocablesDentro,
  useEnCliente,
  useMontado,
  volverInerteElFondo,
} from './_internos.js'
import {
  IconoAcercar,
  IconoAlejar,
  IconoAnterior,
  IconoCerrar,
  IconoDescargar,
  IconoImagenRota,
  IconoSiguiente,
} from './_iconos.js'

/** Una imagen del visor. El `alt` es el mismo que en la rejilla y se muestra como pie. */
export interface ImagenVisor {
  src: string
  alt: string
  /** Original descargable; si está, el visor ofrece «Descargar el original». */
  download?: string
}

export interface PropsImageViewer extends Omit<HTMLAttributes<HTMLDivElement>, 'className'> {
  /** Visibilidad. En modal, con `open` el foco entra, queda atrapado y el resto de la
   *  página se marca como inerte; en línea, el visor aparece en su sitio sin tocar el foco. */
  open?: boolean
  /** Diálogo modal a pantalla completa (por omisión) o visor en línea. Modal: se pinta en
   *  `document.body`, el foco entra y queda atrapado, el resto de la página queda inerte y
   *  el scroll, bloqueado. En línea (`false`): una región con nombre que ocupa su sitio en
   *  la página, sin `aria-modal`, sin inert, sin mover el foco al montarse y sin trampa de
   *  Tab; Escape cierra solo con el foco dentro. Varios visores en línea conviven en la
   *  misma página sin bloquearse entre sí. */
  modal?: boolean
  /** Conjunto que se recorre. Con una sola imagen no se muestran anterior y siguiente. */
  images?: ImagenVisor[]
  /** Imagen visible (desde 0). Si cambia el conjunto mientras está abierto, se ajusta. */
  index?: number
  /** Cambio de imagen, con flechas, con los controles o con la tira de miniaturas. */
  onIndexChange?: (i: number) => void
  /** Cierre con Escape, con el botón «Cerrar el visor» o, en modal, con clic en el velo. */
  onClose?: () => void
  /** Tira de miniaturas al pie, para saltar a una imagen concreta. */
  thumbnails?: boolean
  /** Zoom máximo (3 = 300 %). Alcanzado el máximo, «Acercar» se deshabilita. */
  maxZoom?: number
  /** Elemento al que vuelve el foco al cerrar: la miniatura de origen. Sin él, vuelve al
   *  elemento que tenía el foco al abrir. */
  returnFocusTo?: HTMLElement | null
}

type EstadoCarga = 'cargando' | 'ok' | 'error'

const PASO_ZOOM = 0.5
/** Fracción del escenario que avanza cada flecha con la imagen ampliada. */
const PASO_DESPLAZAMIENTO = 0.15

const porcentaje = (zoom: number) => `${Math.round(zoom * 100)}%`

/**
 * Visor de imágenes con zoom, recorrido por el conjunto y retorno exacto del foco a la
 * miniatura de origen. Por omisión es un diálogo modal a pantalla completa; con
 * `modal={false}` se pinta en línea, como parte de la página.
 */
export const ImageViewer = forwardRef<HTMLDivElement, PropsImageViewer>(function ImageViewer(
  {
    open = false,
    modal = true,
    images = [],
    index = 0,
    onIndexChange,
    onClose,
    thumbnails = false,
    maxZoom = 3,
    returnFocusTo,
    onKeyDown,
    onClick,
    style,
    ...resto
  },
  ref,
) {
  const dialogo = useRef<HTMLDivElement>(null)
  const escenario = useRef<HTMLDivElement>(null)
  const cerrar = useRef<HTMLButtonElement>(null)

  const total = images.length
  const ultimo = Math.max(0, total - 1)
  // Controlado y no controlado: `index` manda cuando cambia; sin `onIndexChange` que lo
  // actualice, el visor recorre por su cuenta.
  const [interno, setInterno] = useState(index)
  useEffect(() => setInterno(index), [index])
  const indice = acotar(interno, 0, ultimo)
  const imagen = images[indice]

  const zoomMaximo = Math.max(1, maxZoom)
  const [zoom, setZoom] = useState(1)
  const [carga, setCarga] = useState<EstadoCarga>('cargando')
  const [reintento, setReintento] = useState(0)
  const idPie = useId()
  const montado = useMontado()

  const irA = useCallback(
    (destino: number) => {
      const valido = acotar(destino, 0, ultimo)
      if (valido === indice) return
      setInterno(valido)
      onIndexChange?.(valido)
    },
    [indice, ultimo, onIndexChange],
  )

  // El conjunto cambió y el índice quedó fuera: se ajusta y se avisa a quien lo controla.
  useEffect(() => {
    if (open && total > 0 && interno !== indice) {
      setInterno(indice)
      onIndexChange?.(indice)
    }
  }, [open, total, interno, indice, onIndexChange])

  // Una imagen en caché puede terminar de cargar antes de que React escuche `load`: su
  // estado real se lee del elemento, no se supone.
  const elementoImagen = useRef<HTMLImageElement | null>(null)
  const estadoReal = (el: HTMLImageElement | null): EstadoCarga =>
    el?.complete && el.currentSrc !== '' ? (el.naturalWidth > 0 ? 'ok' : 'error') : 'cargando'
  const alMontarImagen = useCallback((el: HTMLImageElement | null) => {
    elementoImagen.current = el
    if (el?.complete && el.currentSrc !== '') setCarga(el.naturalWidth > 0 ? 'ok' : 'error')
  }, [])

  // Cambio de imagen: el zoom se restablece y la nueva empieza a cargar.
  useEffect(() => {
    setZoom(1)
    setCarga(estadoReal(elementoImagen.current))
  }, [indice, imagen?.src])

  // Al ampliar, el centro de lo que se veía sigue en el centro.
  const zoomPrevio = useRef(1)
  useEffect(() => {
    const el = escenario.current
    const anterior = zoomPrevio.current
    zoomPrevio.current = zoom
    if (!el || anterior === zoom) return
    const centroX = (el.scrollLeft + el.clientWidth / 2) / anterior
    const centroY = (el.scrollTop + el.clientHeight / 2) / anterior
    el.scrollLeft = centroX * zoom - el.clientWidth / 2
    el.scrollTop = centroY * zoom - el.clientHeight / 2
  }, [zoom])

  // Foco: en modal entra al abrir, queda atrapado, el fondo se vuelve inerte y al cerrar
  // vuelve exactamente a la miniatura de origen. En línea el visor es parte de la página.
  const destinoFoco = useRef<HTMLElement | null | undefined>(returnFocusTo)
  destinoFoco.current = returnFocusTo
  const visible = open && imagen !== undefined
  // El modal va en un portal a `body` en cuanto hay cliente; hasta entonces (el servidor,
  // el primer render) se pinta en su sitio y no se toca el foco ni el fondo.
  const enCliente = useEnCliente()
  const enCuerpo = modal && enCliente
  useImperativeHandle(ref, () => dialogo.current as HTMLDivElement, [visible, enCuerpo])
  const arrastre = useRef<{ x: number; y: number; izquierda: number; arriba: number; movido: boolean } | null>(null)
  useEffect(() => {
    if (!visible || typeof document === 'undefined') return
    if (modal && !enCuerpo) return
    const el = dialogo.current
    if (!el) return
    if (!modal) {
      // En línea no se vuelve inerte nada ni se mueve el foco al montarse: con varios
      // visores en la misma página, cada uno es un control más. Solo si se cierra con el
      // foco dentro, el foco vuelve al origen en lugar de caer al inicio del documento.
      return () => {
        const activo = document.activeElement
        const perdido = !activo || activo === document.body || el.contains(activo)
        const destino = destinoFoco.current
        if (perdido && destino && destino.isConnected) destino.focus()
      }
    }
    const previo = document.activeElement instanceof HTMLElement ? document.activeElement : null
    // Desde `body`, `inert` solo alcanza a los hermanos de la capa: el resto de la página.
    const restaurarFondo = volverInerteElFondo(el)
    const liberarScroll = bloquearScroll()
    ;(cerrar.current ?? el).focus()
    return () => {
      restaurarFondo()
      liberarScroll()
      const destino = destinoFoco.current ?? previo
      if (destino && destino.isConnected) destino.focus()
    }
  }, [visible, modal, enCuerpo])

  if (!visible || !imagen) return null

  const acercar = () => setZoom((z) => Math.min(zoomMaximo, z + PASO_ZOOM))
  const alejar = () => setZoom((z) => Math.max(1, z - PASO_ZOOM))
  const desplazar = (dx: number, dy: number) => {
    const el = escenario.current
    if (!el) return
    el.scrollBy?.({ left: dx * el.clientWidth * PASO_DESPLAZAMIENTO, top: dy * el.clientHeight * PASO_DESPLAZAMIENTO })
  }

  const alPulsarTecla = (e: KeyboardEventReact<HTMLDivElement>) => {
    onKeyDown?.(e)
    if (e.defaultPrevented) return
    const ampliada = zoom > 1
    switch (e.key) {
      case 'Escape':
        e.preventDefault()
        onClose?.()
        return
      case 'ArrowLeft':
        e.preventDefault()
        if (ampliada) desplazar(-1, 0)
        else irA(indice - 1)
        return
      case 'ArrowRight':
        e.preventDefault()
        if (ampliada) desplazar(1, 0)
        else irA(indice + 1)
        return
      case 'ArrowUp':
      case 'ArrowDown':
        if (!ampliada) return
        e.preventDefault()
        desplazar(0, e.key === 'ArrowUp' ? -1 : 1)
        return
      case '+':
      case '=':
        e.preventDefault()
        acercar()
        return
      case '-':
      case '_':
        e.preventDefault()
        alejar()
        return
      case '0':
        e.preventDefault()
        setZoom(1)
        return
      case 'Tab': {
        // En modal, Tab recorre los controles en ciclo, sin salir del visor. En línea sigue
        // el orden de la página: atraparlo dejaría al teclado encerrado en un trozo de ella.
        if (!modal) return
        const el = dialogo.current
        if (!el) return
        const enfocables = enfocablesDentro(el)
        const primero = enfocables[0]
        const final = enfocables[enfocables.length - 1]
        if (!primero || !final) {
          e.preventDefault()
          return
        }
        const activo = document.activeElement
        if (e.shiftKey && (activo === primero || activo === el)) {
          e.preventDefault()
          final.focus()
        } else if (!e.shiftKey && activo === final) {
          e.preventDefault()
          primero.focus()
        }
        return
      }
    }
  }

  // Arrastre de la imagen ampliada dentro del escenario.
  const alPresionar = (e: PointerEventReact<HTMLDivElement>) => {
    const el = escenario.current
    if (zoom <= 1 || !el || e.button !== 0) return
    arrastre.current = { x: e.clientX, y: e.clientY, izquierda: el.scrollLeft, arriba: el.scrollTop, movido: false }
    el.setPointerCapture?.(e.pointerId)
  }
  const alMover = (e: PointerEventReact<HTMLDivElement>) => {
    const el = escenario.current
    const inicio = arrastre.current
    if (!el || !inicio) return
    const dx = e.clientX - inicio.x
    const dy = e.clientY - inicio.y
    if (Math.abs(dx) + Math.abs(dy) > 3) inicio.movido = true
    el.scrollLeft = inicio.izquierda - dx
    el.scrollTop = inicio.arriba - dy
  }
  const alSoltar = () => {
    // El clic que cierra un arrastre no debe cerrar el visor.
    window.setTimeout(() => (arrastre.current = null), 0)
  }

  // El velo se cierra con clic, pero nunca es la única salida: Escape y el botón están.
  // En línea no hay velo: el fondo oscuro es el escenario y un clic en él no cierra nada.
  const alHacerClic = (e: MouseEventReact<HTMLDivElement>) => {
    onClick?.(e)
    if (!modal || e.defaultPrevented || arrastre.current?.movido) return
    const objetivo = e.target as HTMLElement
    const enVelo =
      objetivo === dialogo.current ||
      (zoom <= 1 && (objetivo === escenario.current || objetivo.classList.contains('ay-viewer__frame')))
    if (enVelo) onClose?.()
  }

  const varias = total > 1
  const etiquetaPosicion = `${indice + 1} de ${total}`

  return enCapa(
    <div
      {...resto}
      ref={dialogo}
      className={cx(
        'ay-viewer',
        !modal && 'ay-viewer--inline',
        zoom > 1 && 'ay-viewer--zoom',
        varias && 'ay-viewer--nav',
        thumbnails && varias && 'ay-viewer--thumbs',
      )}
      // En línea es una región con nombre: un landmark que se recorre, no un diálogo.
      role={modal ? 'dialog' : 'region'}
      aria-modal={modal ? 'true' : undefined}
      // Un Modal de Overlays abierto debajo no debe traer el Tab de vuelta a su panel: el
      // visor gestiona el suyo, como cualquier superficie flotante.
      data-ay-flotante={modal ? '' : undefined}
      // El nombre incluye la posición: es lo que el lector anuncia al entrar.
      aria-label={`Imagen ${etiquetaPosicion}`}
      aria-describedby={imagen.alt ? idPie : undefined}
      tabIndex={-1}
      style={style}
      onKeyDown={alPulsarTecla}
      onClick={alHacerClic}
    >
      <div className="ay-viewer__bar">
        {varias && <span className="ay-viewer__pos">{etiquetaPosicion}</span>}
        <button
          type="button"
          className="ay-iconbtn ay-iconbtn--ghost ay-iconbtn--md"
          // La acción y el nivel resultante: sin la cifra no se sabe si hizo algo.
          aria-label={`Alejar, zoom actual ${porcentaje(zoom)}`}
          disabled={zoom <= 1}
          onClick={alejar}
        >
          <IconoAlejar className="ay-iconbtn__glyph" />
        </button>
        <button
          type="button"
          className="ay-iconbtn ay-iconbtn--ghost ay-iconbtn--md"
          aria-label={`Acercar, zoom actual ${porcentaje(zoom)}`}
          disabled={zoom >= zoomMaximo}
          onClick={acercar}
        >
          <IconoAcercar className="ay-iconbtn__glyph" />
        </button>
        {imagen.download && (
          <a className="ay-iconbtn ay-iconbtn--ghost ay-iconbtn--md" href={imagen.download} download aria-label="Descargar el original">
            <IconoDescargar className="ay-iconbtn__glyph" />
          </a>
        )}
        <button
          ref={cerrar}
          type="button"
          className="ay-iconbtn ay-iconbtn--ghost ay-iconbtn--md"
          aria-label="Cerrar el visor"
          onClick={() => onClose?.()}
        >
          <IconoCerrar className="ay-iconbtn__glyph" />
        </button>
      </div>

      {varias && (
        <button
          type="button"
          className="ay-iconbtn ay-iconbtn--ghost ay-iconbtn--md ay-viewer__nav ay-viewer__nav--prev"
          aria-label="Imagen anterior"
          disabled={indice === 0}
          onClick={() => irA(indice - 1)}
        >
          <IconoAnterior className="ay-iconbtn__glyph" />
        </button>
      )}

      <div
        ref={escenario}
        className="ay-viewer__stage"
        aria-busy={(montado && carga === 'cargando') || undefined}
        onPointerDown={alPresionar}
        onPointerMove={alMover}
        onPointerUp={alSoltar}
        onPointerCancel={alSoltar}
      >
        <div className="ay-viewer__frame" style={{ '--ay-zoom': zoom } as CSSProperties}>
          {carga === 'error' ? (
            // El fallo no cierra el visor: dice qué pasó y ofrece reintentar.
            <div className="ay-viewer__error">
              <IconoImagenRota lado={32} />
              <p>No se pudo cargar la imagen.</p>
              <button
                type="button"
                className="ay-btn ay-btn--secondary ay-btn--sm"
                onClick={() => {
                  setCarga('cargando')
                  setReintento((n) => n + 1)
                }}
              >
                <span className="ay-btn__label">Reintentar</span>
              </button>
            </div>
          ) : (
            <img
              key={`${imagen.src}#${reintento}`}
              ref={alMontarImagen}
              className="ay-viewer__img"
              src={imagen.src}
              alt={imagen.alt}
              draggable={false}
              onLoad={() => setCarga('ok')}
              onError={() => setCarga('error')}
            />
          )}
          {montado && carga === 'cargando' && (
            <span className="ay-viewer__spinner" aria-hidden="true">
              <svg className="ay-spinner" viewBox="0 0 24 24" fill="none" width={32} height={32}>
                <circle className="ay-spinner__track" cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="2.5" />
                <circle className="ay-spinner__arc" cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="2.5" />
              </svg>
            </span>
          )}
        </div>
      </div>

      {varias && (
        <button
          type="button"
          className="ay-iconbtn ay-iconbtn--ghost ay-iconbtn--md ay-viewer__nav ay-viewer__nav--next"
          aria-label="Imagen siguiente"
          disabled={indice === ultimo}
          onClick={() => irA(indice + 1)}
        >
          <IconoSiguiente className="ay-iconbtn__glyph" />
        </button>
      )}

      {/* El alt es el contenido: se muestra, no solo se declara. */}
      {imagen.alt && (
        <p id={idPie} className="ay-viewer__caption">
          {imagen.alt}
        </p>
      )}

      {thumbnails && varias && (
        <ul className="ay-viewer__thumbs">
          {images.map((miniatura, i) => (
            <li key={`${i}-${miniatura.src}`}>
              <button
                type="button"
                className="ay-viewer__thumb"
                aria-label={`Ir a la imagen ${i + 1} de ${total}, ${miniatura.alt}`}
                aria-current={i === indice || undefined}
                onClick={() => irA(i)}
              >
                <img src={miniatura.src} alt="" loading="lazy" decoding="async" />
              </button>
            </li>
          ))}
        </ul>
      )}

      {/* La imagen se sustituye sin mover el foco: el cambio se anuncia. */}
      <p className="ay-visually-hidden" aria-live="polite">
        {`Imagen ${etiquetaPosicion}${imagen.alt ? `, ${imagen.alt}` : ''}`}
      </p>
    </div>,
    enCuerpo,
  )
})

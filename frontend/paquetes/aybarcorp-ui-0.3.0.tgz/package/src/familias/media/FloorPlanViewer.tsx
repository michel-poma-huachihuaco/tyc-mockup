import { forwardRef, useCallback, useEffect, useId, useMemo, useRef, useState } from 'react'
import type {
  CSSProperties,
  HTMLAttributes,
  KeyboardEvent as KeyboardEventReact,
  PointerEvent as PointerEventReact,
} from 'react'
import { cx } from '../../utiles.js'
import { IconoAcercar, IconoAlejar, IconoEncuadrar, IconoRestablecer } from './_iconos.js'
import { LOCALE_NUMEROS, acotar, centroDeZona, esUrlSegura, useMontado } from './_internos.js'

/** Una capa del plano. `locked` impide apagarla: apagar la distribución dejaría las
 *  cotas flotando sin plano. */
export interface CapaPlano {
  id: string
  label: string
  on: boolean
  locked?: boolean
}

/** Una zona pulsable: una estancia o una unidad, con su superficie en metros cuadrados. */
export interface ZonaPlano {
  id: string
  label: string
  area?: number
}

export type TamanoPlano = 'panel' | 'full'

export interface PropsFloorPlanViewer extends Omit<HTMLAttributes<HTMLElement>, 'className'> {
  /** Plano de la planta. Un SVG da zonas y capas; un mapa de bits (`.png`, `.jpg`…) solo
   *  admite la vista y lo dice. Sin plano, el visor muestra el estado vacío. Las capas se
   *  aplican a los grupos `[data-layer="<id>"]` del SVG y la zona activa marca
   *  `[data-zone="<id>"]` con `aria-current` cuando el SVG es del mismo origen. */
  planUrl?: string
  /** Capas y su estado. Son casillas reales con su etiqueta, no iconos de ojo. */
  layers?: CapaPlano[]
  /** Enciende o apaga una capa. El cambio se anuncia en una región polite. */
  onLayerToggle?: (id: string, on: boolean) => void
  /** Zonas pulsables. Cada una es un control cuyo nombre lleva la estancia y su superficie:
   *  «Dormitorio principal, 14 metros cuadrados». */
  zones?: ZonaPlano[]
  /** Zona resaltada. Cadena vacía: ninguna. */
  activeZoneId?: string
  /** Selección de una zona; con Escape llega `''`, que quita el resaltado sin tocar la escala. */
  onZoneSelect?: (id: string) => void
  /** Escala inicial (1 = encuadre completo). «Restablecer» vuelve a ella; la escala se
   *  limita entre el encuadre y el 400 %. */
  zoom?: number
  /** Plano original descargable. Se mantiene siempre: mucha gente lee un plano impreso. */
  downloadHref?: string
  /** Tabla de estancias equivalente: la forma de entregar el plano a quien usa lector. */
  tableHref?: string
  /** Escala del visor. `panel` pliega las capas en un Collapsible dentro de la ficha;
   *  `full` las deja fijas al lado. */
  size?: TamanoPlano
}

type EstadoPlano = 'cargando' | 'listo' | 'error'

const ESCALA_MAXIMA = 4
const PASO_ESCALA = 0.25
const MAPA_DE_BITS = /(?:\.(?:png|jpe?g|gif|webp|avif|bmp|tiff?)(?:[?#].*)?$)|(?:^data:image\/(?:png|jpe?g|gif|webp|avif|bmp|tiff?)[;,])/i

const numero = (n: number) => n.toLocaleString(LOCALE_NUMEROS, { maximumFractionDigits: 2 })
const textoEscala = (escala: number) => `${Math.round(escala * 100)} %`
const nombreZona = (z: ZonaPlano) => (z.area != null ? `${z.label}, ${numero(z.area)} metros cuadrados` : z.label)
const datoZona = (z: ZonaPlano) => (z.area != null ? `${z.label} · ${numero(z.area)} m²` : z.label)

/**
 * Plano de una planta con capas y zonas pulsables, para leer la distribución sin
 * descargar un PDF. Propio de Aybar: ficha de unidad y vista de planta.
 */
export const FloorPlanViewer = forwardRef<HTMLElement, PropsFloorPlanViewer>(function FloorPlanViewer(
  {
    planUrl,
    layers = [],
    onLayerToggle,
    zones = [],
    activeZoneId,
    onZoneSelect,
    zoom = 1,
    downloadHref,
    tableHref,
    size = 'full',
    'aria-label': etiquetaAria,
    ...resto
  },
  ref,
) {
  const idDescripcion = useId()
  const idAyuda = useId()
  const nombre = etiquetaAria ?? 'Plano de la planta'
  const lienzo = useRef<HTMLDivElement>(null)
  const objeto = useRef<HTMLObjectElement>(null)
  const listaZonas = useRef<HTMLUListElement>(null)

  // Un esquema que ejecuta código no llega al `object`: se trata como un plano que no carga.
  const inseguro = !!planUrl && !esUrlSegura(planUrl)
  const esMapaDeBits = !!planUrl && !inseguro && MAPA_DE_BITS.test(planUrl)
  // Sobre un mapa de bits no se fingen zonas pulsables.
  const zonasActivas = esMapaDeBits || !planUrl ? [] : zones

  // Escala: empieza en `zoom` y se ajusta con los controles y el teclado.
  const escalaInicial = acotar(zoom, 1, ESCALA_MAXIMA)
  const [escala, setEscala] = useState(escalaInicial)
  useEffect(() => setEscala(escalaInicial), [escalaInicial])

  // Zona activa: controlada por `activeZoneId` y con estado propio si nadie la controla.
  const [zonaInterna, setZonaInterna] = useState(activeZoneId ?? '')
  useEffect(() => setZonaInterna(activeZoneId ?? ''), [activeZoneId])
  const zonaActiva = zonasActivas.find((z) => z.id === zonaInterna)

  // Capas: lo que diga la prop, más lo que se haya conmutado aquí si nadie lo devuelve.
  const [conmutadas, setConmutadas] = useState<Record<string, boolean>>({})
  const firmaCapas = layers.map((l) => `${l.id}:${l.on}`).join('|')
  useEffect(() => setConmutadas({}), [firmaCapas])
  const capas = useMemo(
    () => layers.map((l) => ({ ...l, on: conmutadas[l.id] ?? l.on })),
    [layers, conmutadas],
  )

  const [estado, setEstado] = useState<EstadoPlano>('listo')
  // Un plano nuevo vuelve a pintarse aunque el anterior hubiera fallado.
  const [planPrevio, setPlanPrevio] = useState(planUrl)
  if (planPrevio !== planUrl) {
    setPlanPrevio(planUrl)
    setEstado('listo')
  }
  const [aviso, setAviso] = useState('')
  const [enfocada, setEnfocada] = useState(0)

  // Carga del plano. El esqueleto y el panel inerte solo existen en el cliente: en un
  // marcado estático nadie resolvería la carga y taparían un plano que sí está.
  const montado = useMontado()
  const imagenPlano = useRef<HTMLImageElement>(null)
  useEffect(() => {
    if (!planUrl || inseguro) return
    if (esMapaDeBits) {
      const img = imagenPlano.current
      setEstado(img?.complete ? (img.naturalWidth > 0 ? 'listo' : 'error') : 'cargando')
      return
    }
    const el = objeto.current
    if (!el) return
    setEstado('cargando')
    // `object` no propaga siempre `load` y `error` a React: se escuchan en nativo, y se
    // vuelve a asignar `data` para que un plano que ya cargó antes de hidratar avise.
    const listo = () => setEstado('listo')
    const fallo = () => setEstado('error')
    el.addEventListener('load', listo)
    el.addEventListener('error', fallo)
    el.setAttribute('data', planUrl)
    return () => {
      el.removeEventListener('load', listo)
      el.removeEventListener('error', fallo)
    }
  }, [planUrl, esMapaDeBits, inseguro])

  // Capas y zona activa dentro del SVG, cuando el documento es accesible (mismo origen).
  useEffect(() => {
    if (estado !== 'listo' || esMapaDeBits) return
    let documento: Document | null = null
    try {
      documento = objeto.current?.contentDocument ?? null
    } catch {
      documento = null
    }
    if (!documento) return
    for (const capa of capas) {
      const id = typeof CSS !== 'undefined' && CSS.escape ? CSS.escape(capa.id) : capa.id.replace(/["\\]/g, '\\$&')
      documento.querySelectorAll(`[data-layer="${id}"]`).forEach((g) => g.toggleAttribute('hidden', !capa.on))
    }
    documento.querySelectorAll('[data-zone]').forEach((z) => {
      if (z.getAttribute('data-zone') === zonaInterna && zonaInterna) z.setAttribute('aria-current', 'true')
      else z.removeAttribute('aria-current')
    })
  }, [estado, esMapaDeBits, capas, zonaInterna])

  // Al cambiar la escala, la zona activa queda centrada: el foco no se queda fuera del
  // área visible y no se pierde el sitio. Sin zona activa, o con un SVG de otro origen
  // que no se puede leer, el centro de lo que se veía se queda en el centro.
  const escalaPrevia = useRef(escala)
  const zonaParaCentrar = useRef(zonaInterna)
  zonaParaCentrar.current = zonaInterna
  useEffect(() => {
    const el = lienzo.current
    const anterior = escalaPrevia.current
    escalaPrevia.current = escala
    if (!el || anterior === escala) return
    const zona = centroDeZona(objeto.current, el, zonaParaCentrar.current)
    if (zona) {
      el.scrollLeft = zona.x - el.clientWidth / 2
      el.scrollTop = zona.y - el.clientHeight / 2
      return
    }
    const centroX = (el.scrollLeft + el.clientWidth / 2) / anterior
    const centroY = (el.scrollTop + el.clientHeight / 2) / anterior
    el.scrollLeft = centroX * escala - el.clientWidth / 2
    el.scrollTop = centroY * escala - el.clientHeight / 2
  }, [escala])

  const cambiarEscala = useCallback((destino: number) => {
    const nueva = acotar(Math.round(destino / PASO_ESCALA) * PASO_ESCALA, 1, ESCALA_MAXIMA)
    setEscala(nueva)
    // La escala se limita y se dice cuál es el máximo, en vez de un plano ilegible.
    setAviso(
      nueva >= ESCALA_MAXIMA
        ? `Escala máxima: ${textoEscala(ESCALA_MAXIMA)}.`
        : nueva <= 1
          ? 'Plano encuadrado completo.'
          : `Escala ${textoEscala(nueva)}.`,
    )
  }, [])

  const seleccionar = (id: string) => {
    setZonaInterna(id)
    onZoneSelect?.(id)
    const zona = zonasActivas.find((z) => z.id === id)
    setAviso(zona ? `${nombreZona(zona)}, resaltada.` : 'Sin zona resaltada.')
  }

  const conmutar = (capa: CapaPlano) => {
    if (capa.locked) return
    const on = !capa.on
    setConmutadas((previas) => ({ ...previas, [capa.id]: on }))
    onLayerToggle?.(capa.id, on)
    // El efecto ocurre en el plano: quien no lo ve necesita la confirmación.
    setAviso(`Capa ${capa.label} ${on ? 'visible' : 'oculta'}.`)
  }

  const enfocarZona = (i: number) => {
    const total = zonasActivas.length
    if (!total) return
    const destino = (i + total) % total
    setEnfocada(destino)
    const boton = listaZonas.current?.querySelectorAll<HTMLButtonElement>('button')[destino]
    boton?.focus()
  }

  const alPulsarTecla = (e: KeyboardEventReact<HTMLElement>) => {
    const enLista = listaZonas.current?.contains(e.target as Node) ?? false
    switch (e.key) {
      case 'ArrowRight':
      case 'ArrowDown':
      case 'ArrowLeft':
      case 'ArrowUp': {
        // Sin zonas, las flechas desplazan el lienzo: es el scroll nativo.
        if (!zonasActivas.length) return
        e.preventDefault()
        const adelante = e.key === 'ArrowRight' || e.key === 'ArrowDown'
        if (!enLista) {
          const actual = zonaActiva ? zonasActivas.indexOf(zonaActiva) : -1
          enfocarZona(actual >= 0 ? actual : adelante ? 0 : zonasActivas.length - 1)
        } else {
          enfocarZona(enfocada + (adelante ? 1 : -1))
        }
        return
      }
      case 'Home':
      case 'End':
        if (!enLista) return
        e.preventDefault()
        enfocarZona(e.key === 'Home' ? 0 : zonasActivas.length - 1)
        return
      case '+':
      case '=':
        e.preventDefault()
        cambiarEscala(escala + PASO_ESCALA)
        return
      case '-':
      case '_':
        e.preventDefault()
        cambiarEscala(escala - PASO_ESCALA)
        return
      case '0':
        e.preventDefault()
        cambiarEscala(1)
        return
      case 'Escape':
        // Quita el resaltado, no la escala: son dos cosas distintas.
        if (!zonaInterna) return
        e.preventDefault()
        seleccionar('')
        return
    }
  }

  // Arrastre del plano ampliado dentro del lienzo.
  const arrastre = useRef<{ x: number; y: number; izquierda: number; arriba: number } | null>(null)
  const alPresionar = (e: PointerEventReact<HTMLDivElement>) => {
    const el = lienzo.current
    if (escala <= 1 || !el || e.button !== 0) return
    arrastre.current = { x: e.clientX, y: e.clientY, izquierda: el.scrollLeft, arriba: el.scrollTop }
    el.setPointerCapture?.(e.pointerId)
  }
  const alMover = (e: PointerEventReact<HTMLDivElement>) => {
    const el = lienzo.current
    const inicio = arrastre.current
    if (!el || !inicio) return
    el.scrollLeft = inicio.izquierda - (e.clientX - inicio.x)
    el.scrollTop = inicio.arriba - (e.clientY - inicio.y)
  }
  const alSoltar = () => {
    arrastre.current = null
  }

  const descripcion = useMemo(() => {
    if (!zonasActivas.length) return ''
    const lista = zonasActivas.map(nombreZona).join('; ')
    const conArea = zonasActivas.every((z) => z.area != null)
    const suma = conArea ? zonasActivas.reduce((n, z) => n + (z.area ?? 0), 0) : null
    return (
      `Plano con ${zonasActivas.length} ${zonasActivas.length === 1 ? 'zona' : 'zonas'}: ${lista}.` +
      (suma != null ? ` Superficie total de las zonas: ${numero(suma)} metros cuadrados.` : '')
    )
  }, [zonasActivas])

  const cargando = montado && !!planUrl && estado === 'cargando'
  const conFallo = !!planUrl && (inseguro || estado === 'error')

  const panelCapas = capas.length > 0 && (
    <fieldset className="ay-plan__layers" disabled={cargando || !planUrl || undefined}>
      <legend className={size === 'panel' ? 'ay-visually-hidden' : undefined}>Capas</legend>
      {capas.map((capa) => (
        <label key={capa.id} className={cx('ay-plan__layer', capa.locked && 'is-locked')}>
          <input type="checkbox" checked={capa.on} disabled={capa.locked} onChange={() => conmutar(capa)} />
          <span>{capa.label}</span>
        </label>
      ))}
    </fieldset>
  )

  return (
    <section
      {...resto}
      ref={ref}
      className={cx('ay-plan', `ay-plan--${size}`, zonaActiva && 'ay-plan--zone-active')}
      aria-label={nombre}
    >
      <div className="ay-plan__view">
        <div
          ref={lienzo}
          className={cx('ay-plan__canvas', escala > 1 && 'ay-plan__canvas--zoom')}
          tabIndex={0}
          role="group"
          aria-roledescription="plano"
          aria-label={nombre}
          aria-describedby={`${descripcion ? idDescripcion : ''} ${idAyuda}`.trim()}
          aria-busy={cargando || undefined}
          onKeyDown={alPulsarTecla}
          onPointerDown={alPresionar}
          onPointerMove={alMover}
          onPointerUp={alSoltar}
          onPointerCancel={alSoltar}
        >
          <div className="ay-plan__frame" style={{ '--ay-zoom': escala } as CSSProperties}>
            {!planUrl ? (
              // Sin plano: estado vacío con la vía para conseguirlo, no un lienzo en blanco.
              <div className="ay-plan__empty">
                <p className="ay-plan__empty-title">Esta unidad todavía no tiene plano cargado.</p>
                <p className="ay-plan__empty-desc">
                  {tableHref ? 'Las estancias y sus superficies están en la tabla.' : 'Solicítalo al equipo de la promoción.'}
                </p>
              </div>
            ) : conFallo ? (
              <div className="ay-plan__error" role="alert">
                No hemos podido abrir el plano.{downloadHref ? ' Puedes descargarlo.' : ''}
              </div>
            ) : esMapaDeBits ? (
              <img
                ref={imagenPlano}
                className="ay-plan__svg"
                src={planUrl}
                alt={nombre}
                onLoad={() => setEstado('listo')}
                onError={() => setEstado('error')}
                draggable={false}
              />
            ) : (
              // role img y descripción: un SVG mudo es una pila de trazados sin significado.
              <object
                ref={objeto}
                className="ay-plan__svg"
                data={planUrl}
                type="image/svg+xml"
                role="img"
                aria-label={nombre}
                aria-describedby={descripcion ? idDescripcion : undefined}
              />
            )}
          </div>
          {cargando && <span className="ay-skel ay-skel--block ay-plan__skel" aria-hidden="true" />}
        </div>

        {/* Escrito, no solo tamaño en pantalla: quien usa lupa necesita el número. */}
        {planUrl && !conFallo && (
          <p className="ay-plan__zoom" aria-live="off">
            {textoEscala(escala)}
          </p>
        )}

        {zonaActiva && (
          <p className="ay-plan__zone-data" aria-hidden="true">
            {datoZona(zonaActiva)}
          </p>
        )}

        {planUrl && !conFallo && (
          <div className="ay-plan__controls" role="group" aria-label="Escala del plano">
            <button
              type="button"
              className="ay-iconbtn ay-iconbtn--secondary ay-iconbtn--sm"
              aria-label={`Alejar, escala actual ${textoEscala(escala)}`}
              disabled={escala <= 1}
              onClick={() => cambiarEscala(escala - PASO_ESCALA)}
            >
              <IconoAlejar className="ay-iconbtn__glyph" lado={16} />
            </button>
            <button
              type="button"
              className="ay-iconbtn ay-iconbtn--secondary ay-iconbtn--sm"
              aria-label={
                escala >= ESCALA_MAXIMA
                  ? `Acercar, escala máxima ${textoEscala(ESCALA_MAXIMA)} alcanzada`
                  : `Acercar, escala actual ${textoEscala(escala)}`
              }
              disabled={escala >= ESCALA_MAXIMA}
              onClick={() => cambiarEscala(escala + PASO_ESCALA)}
            >
              <IconoAcercar className="ay-iconbtn__glyph" lado={16} />
            </button>
            <button
              type="button"
              className="ay-iconbtn ay-iconbtn--secondary ay-iconbtn--sm"
              aria-label="Encuadrar el plano completo"
              disabled={escala === 1}
              onClick={() => cambiarEscala(1)}
            >
              <IconoEncuadrar className="ay-iconbtn__glyph" lado={16} />
            </button>
            {escalaInicial !== 1 && (
              <button
                type="button"
                className="ay-iconbtn ay-iconbtn--secondary ay-iconbtn--sm"
                aria-label={`Restablecer la escala a ${textoEscala(escalaInicial)}`}
                disabled={escala === escalaInicial}
                onClick={() => cambiarEscala(escalaInicial)}
              >
                <IconoRestablecer className="ay-iconbtn__glyph" lado={16} />
              </button>
            )}
          </div>
        )}
      </div>

      <div className="ay-plan__side">
        {esMapaDeBits && (
          <p className="ay-plan__note">Este plano es una imagen: solo está disponible la vista, sin zonas pulsables.</p>
        )}

        {zonasActivas.length > 0 && (
          <ul ref={listaZonas} className="ay-plan__zones" aria-label="Zonas del plano" onKeyDown={alPulsarTecla}>
            {zonasActivas.map((zona, i) => {
              const activa = zona.id === zonaInterna
              return (
                <li key={zona.id}>
                  <button
                    type="button"
                    className="ay-plan__zone"
                    // El nombre lleva la superficie: es el dato que se busca.
                    aria-label={nombreZona(zona)}
                    aria-current={activa || undefined}
                    tabIndex={i === enfocada ? 0 : -1}
                    onFocus={() => setEnfocada(i)}
                    onClick={() => seleccionar(zona.id)}
                  >
                    {datoZona(zona)}
                  </button>
                </li>
              )
            })}
          </ul>
        )}

        {panelCapas &&
          (size === 'panel' ? (
            // En panel las capas se pliegan y el visor conserva su altura.
            <details className="ay-collapsible ay-plan__collapsible">
              <summary>Capas</summary>
              {panelCapas}
            </details>
          ) : (
            panelCapas
          ))}

        {(downloadHref || tableHref) && (
          <p className="ay-plan__actions">
            {/* Siempre disponible: mucha gente lee un plano imprimiéndolo. */}
            {downloadHref && (
              <a className="ay-link" href={downloadHref} download>
                Descargar el plano
              </a>
            )}
            {tableHref && (
              <a className="ay-link" href={tableHref}>
                Ver las estancias en tabla
              </a>
            )}
          </p>
        )}
      </div>

      {descripcion && (
        <p id={idDescripcion} className="ay-visually-hidden">
          {descripcion}
        </p>
      )}
      <p id={idAyuda} className="ay-visually-hidden">
        {zonasActivas.length
          ? 'Flechas para recorrer las zonas, Más y Menos para la escala, 0 para encuadrar y Escape para quitar el resaltado.'
          : 'Más y Menos para la escala y 0 para encuadrar; con el plano ampliado, las flechas lo desplazan.'}
      </p>
      <p className="ay-visually-hidden" role="status" aria-live="polite">
        {aviso}
      </p>
    </section>
  )
})

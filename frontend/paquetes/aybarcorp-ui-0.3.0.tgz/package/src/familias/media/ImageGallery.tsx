import { forwardRef, useEffect, useId, useState } from 'react'
import type { HTMLAttributes, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { IconoImagenRota } from './_iconos.js'

/** Una imagen del conjunto. El `alt` se define una vez y se reutiliza en la rejilla y en el visor. */
export interface ImagenGaleria {
  src: string
  alt: string
  /** Miniatura para la rejilla; si falta se usa `src`. */
  thumb?: string
}

export type TamanoGaleria = 'sm' | 'md'

export interface PropsImageGallery extends Omit<HTMLAttributes<HTMLElement>, 'className'> {
  /** Imágenes del conjunto. El `alt` de cada una describe su contenido en contexto y es el
   *  mismo que mostrará el visor. */
  images?: ImagenGaleria[]
  /** Nombre accesible del conjunto; obligatorio. Dice de qué es: «Fotografías de la
   *  unidad 402». El lector lo anuncia junto con el número de imágenes. */
  label: string
  /** Imágenes visibles antes del excedente. La última celda visible lleva el velo «+N» y
   *  abre el visor en la primera imagen oculta. Sin valor, se muestran todas. */
  maxVisible?: number
  /** La primera imagen ocupa dos columnas y dos filas. */
  featured?: boolean
  /** Tamaño mínimo de celda: `md` (ocho rem) o `sm` (cinco rem), para adjuntos. */
  size?: TamanoGaleria
  /** Abre el visor en la imagen indicada. Quien lo abre debe devolver el foco a la
   *  miniatura de origen al cerrarlo (`returnFocusTo` de ImageViewer). */
  onOpen?: (index: number) => void
  /** Contenido cuando no hay imágenes: un Empty State con la acción de subir. */
  emptyState?: ReactNode
}

/**
 * Conjunto de imágenes en rejilla. Cada miniatura es un botón que abre el visor y su
 * nombre accesible incluye la posición: «Abrir la imagen 3 de 12, cocina».
 */
export const ImageGallery = forwardRef<HTMLElement, PropsImageGallery>(function ImageGallery(
  { images = [], label, maxVisible, featured = false, size = 'md', onOpen, emptyState, ...resto },
  ref,
) {
  const id = useId()
  const [fallidas, setFallidas] = useState<ReadonlySet<string>>(() => new Set())

  // Un conjunto nuevo no hereda los fallos del anterior. La firma son los orígenes, no
  // la identidad del arreglo: un padre que lo recrea en cada render no borra los fallos.
  const firma = images.map((imagen) => imagen.thumb ?? imagen.src).join('\n')
  useEffect(() => setFallidas((previas) => (previas.size ? new Set() : previas)), [firma])

  if (images.length === 0) return <>{emptyState}</>

  const limite = maxVisible != null && maxVisible > 0 ? Math.floor(maxVisible) : images.length
  const visibles = images.slice(0, limite)
  const restantes = images.length - visibles.length
  const total = images.length

  return (
    <section {...resto} ref={ref} aria-labelledby={id}>
      {/* El conjunto lleva nombre: el lector anuncia cuántas imágenes hay. */}
      <h3 id={id} className="ay-visually-hidden">
        {label}, {total} {total === 1 ? 'imagen' : 'imágenes'}
      </h3>

      <ul
        className={cx(
          'ay-gallery',
          `ay-gallery--${size}`,
          featured && total > 1 && 'ay-gallery--featured',
          // Una sola imagen se muestra a ancho completo, sin rejilla.
          total === 1 && 'ay-gallery--single',
        )}
      >
        {visibles.map((imagen, i) => {
          const conExcedente = i === visibles.length - 1 && restantes > 0
          const clave = `${i}-${imagen.src}`
          const fallo = fallidas.has(clave)
          return (
            <li key={clave}>
              <button
                type="button"
                className={cx('ay-gallery__cell', conExcedente && 'ay-gallery__cell--more', fallo && 'ay-gallery__cell--error')}
                // La posición va en el nombre: «3 de 12» sitúa al usuario. «+8» a secas
                // es un signo y una cifra; el botón dice lo que hace.
                aria-label={
                  conExcedente
                    ? restantes === 1
                      ? 'Ver la imagen restante'
                      : `Ver las ${restantes} imágenes restantes`
                    : `Abrir la imagen ${i + 1} de ${total}, ${imagen.alt}`
                }
                onClick={() => onOpen?.(conExcedente ? visibles.length : i)}
              >
                {fallo ? (
                  // La miniatura que no carga muestra el fallo y sigue abriendo el visor.
                  <span className="ay-gallery__error" aria-hidden="true">
                    <IconoImagenRota lado={20} />
                    <span>Sin vista previa</span>
                  </span>
                ) : (
                  <img
                    src={imagen.thumb ?? imagen.src}
                    alt=""
                    loading="lazy"
                    decoding="async"
                    onError={() => setFallidas((previas) => new Set(previas).add(clave))}
                  />
                )}
                {conExcedente && (
                  <span className="ay-gallery__overflow" aria-hidden="true">
                    +{restantes}
                  </span>
                )}
              </button>
            </li>
          )
        })}
      </ul>
    </section>
  )
})

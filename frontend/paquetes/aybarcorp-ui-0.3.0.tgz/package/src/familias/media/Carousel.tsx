import { forwardRef, useCallback, useEffect, useRef, useState } from 'react'
import type {
  CSSProperties,
  FocusEvent as FocusEventReact,
  HTMLAttributes,
  KeyboardEvent as KeyboardEventReact,
  ReactNode,
} from 'react'
import { IconoAnterior, IconoSiguiente } from './_iconos.js'
import { acotar, usePrefiereMovimientoReducido } from './_internos.js'

export interface PropsCarousel extends Omit<HTMLAttributes<HTMLElement>, 'className'> {
  /** Diapositivas, de ancho uniforme. Nada importante debería vivir solo aquí: lo que
   *  queda fuera de la vista casi nadie lo recorre. */
  items?: ReactNode[]
  /** Nombre del conjunto; obligatorio. Dice qué se recorre: «Fotografías de la promoción». */
  label: string
  /** Diapositivas visibles a la vez. Con menos diapositivas que visibles, la pista no se
   *  desplaza y los controles no se muestran. */
  visible?: number
  /** Diapositiva actual (la primera visible), desde 0. */
  index?: number
  /** Cambio de posición: controles, indicadores, teclado, reproducción o arrastre táctil. */
  onIndexChange?: (i: number) => void
  /** Indicadores de posición. Con más de ocho diapositivas pasan a cifras («3 de 24»). */
  indicators?: boolean
  /** Reproducción automática; opt-in. Exige el control de pausa, se detiene al apuntar o
   *  enfocar dentro, no arranca con `prefers-reduced-motion` y se para al primer gesto
   *  del usuario. */
  autoplay?: boolean
  /** Intervalo de la reproducción, en milisegundos. */
  interval?: number
  /** Ciclo en los extremos. Sin él, «Anterior» se deshabilita en la primera y «Siguiente»
   *  en la última. */
  loop?: boolean
}

/** A partir de aquí los puntos dejan de servir: veinticuatro puntos no se cuentan. */
const MAXIMO_PUNTOS = 8

/**
 * Recorre un conjunto en un espacio fijo, con controles alcanzables y sin movimiento
 * automático por defecto. No es una live region: anunciaría cada avance entero.
 */
export const Carousel = forwardRef<HTMLElement, PropsCarousel>(function Carousel(
  {
    items = [],
    label,
    visible = 1,
    index = 0,
    onIndexChange,
    indicators = true,
    autoplay = false,
    interval = 6000,
    loop = false,
    onMouseEnter,
    onMouseLeave,
    onFocus,
    onBlur,
    ...resto
  },
  ref,
) {
  const pista = useRef<HTMLUListElement>(null)
  const reducido = usePrefiereMovimientoReducido()
  const total = items.length
  const visibles = Math.max(1, Math.floor(visible))
  const ultima = Math.max(0, total - visibles)
  const desplazable = total > visibles

  const [interno, setInterno] = useState(index)
  useEffect(() => setInterno(index), [index])
  const indice = acotar(interno, 0, ultima)

  // Pausas: al apuntar, con el foco dentro, con el botón, y para siempre tras un gesto.
  const [apuntado, setApuntado] = useState(false)
  const [enfocado, setEnfocado] = useState(false)
  const [pausaManual, setPausaManual] = useState(false)
  const [detenido, setDetenido] = useState(false)

  const irA = useCallback(
    (destino: number, porUsuario = true) => {
      const valido = loop
        ? destino < 0
          ? ultima
          : destino > ultima
            ? 0
            : destino
        : acotar(destino, 0, ultima)
      // El primer gesto del usuario detiene la reproducción y no se reanuda sola.
      if (porUsuario) setDetenido(true)
      if (valido === indice) return
      setInterno(valido)
      onIndexChange?.(valido)
    },
    [loop, ultima, indice, onIndexChange],
  )

  // El índice mueve la pista; el scroll nativo es el que manda (ver `alDesplazar`).
  const primerDesplazamiento = useRef(true)
  useEffect(() => {
    const el = pista.current
    const diapositiva = el?.children[indice] as HTMLElement | undefined
    if (!el || !diapositiva) return
    const destino = diapositiva.offsetLeft
    if (Math.abs(el.scrollLeft - destino) < 1) return
    const instantaneo = reducido || primerDesplazamiento.current
    primerDesplazamiento.current = false
    if (typeof el.scrollTo === 'function') el.scrollTo({ left: destino, behavior: instantaneo ? 'auto' : 'smooth' })
    else el.scrollLeft = destino
  }, [indice, reducido])

  // El scroll es la fuente de verdad: un arrastre táctil también cambia la posición.
  const espera = useRef<number | undefined>(undefined)
  const alDesplazar = () => {
    window.clearTimeout(espera.current)
    espera.current = window.setTimeout(() => {
      const el = pista.current
      if (!el) return
      let cercana = 0
      let distancia = Number.POSITIVE_INFINITY
      Array.from(el.children).forEach((hijo, i) => {
        const d = Math.abs((hijo as HTMLElement).offsetLeft - el.scrollLeft)
        if (d < distancia) {
          distancia = d
          cercana = i
        }
      })
      cercana = acotar(cercana, 0, ultima)
      if (cercana !== indice) {
        setInterno(cercana)
        onIndexChange?.(cercana)
      }
    }, 120)
  }
  useEffect(() => () => window.clearTimeout(espera.current), [])

  // Reproducción automática: opt-in, nunca con movimiento reducido ni con algo que la pause.
  const avanzar = useRef(() => {})
  avanzar.current = () => irA(indice + 1, false)
  const reproduciendo = autoplay && !reducido && desplazable && !apuntado && !enfocado && !pausaManual && !detenido
  useEffect(() => {
    if (!reproduciendo) return
    const temporizador = window.setInterval(() => avanzar.current(), Math.max(1000, interval))
    return () => window.clearInterval(temporizador)
  }, [reproduciendo, interval])

  const alPulsarTecla = (e: KeyboardEventReact<HTMLUListElement>) => {
    const destinos: Record<string, number> = {
      ArrowLeft: indice - 1,
      ArrowRight: indice + 1,
      Home: 0,
      End: ultima,
    }
    const destino = destinos[e.key]
    if (destino === undefined || !desplazable) return
    e.preventDefault()
    irA(destino)
  }

  const alSalirElFoco = (e: FocusEventReact<HTMLElement>) => {
    onBlur?.(e)
    if (!e.currentTarget.contains(e.relatedTarget as Node | null)) setEnfocado(false)
  }

  // Una sola diapositiva: ni controles ni indicadores.
  if (total <= 1) return <>{items}</>

  const muestraPausa = autoplay && !reducido
  const pausado = pausaManual || detenido

  return (
    <section
      {...resto}
      ref={ref}
      className="ay-carousel"
      role="group"
      aria-roledescription="carrusel"
      aria-label={label}
      onMouseEnter={(e) => {
        onMouseEnter?.(e)
        setApuntado(true)
      }}
      onMouseLeave={(e) => {
        onMouseLeave?.(e)
        setApuntado(false)
      }}
      onFocus={(e) => {
        onFocus?.(e)
        setEnfocado(true)
      }}
      onBlur={alSalirElFoco}
    >
      {muestraPausa && (
        <button
          type="button"
          className="ay-btn ay-btn--ghost ay-btn--sm ay-carousel__pause"
          onClick={() => {
            if (pausado) {
              setPausaManual(false)
              setDetenido(false)
            } else {
              setPausaManual(true)
            }
          }}
        >
          <span className="ay-btn__label">{pausado ? 'Reanudar el carrusel' : 'Pausar el carrusel'}</span>
        </button>
      )}

      {desplazable && (
        <button
          type="button"
          className="ay-iconbtn ay-iconbtn--secondary ay-iconbtn--md ay-carousel__nav ay-carousel__nav--prev"
          aria-label="Anterior"
          disabled={!loop && indice === 0}
          onClick={() => irA(indice - 1)}
        >
          <IconoAnterior className="ay-iconbtn__glyph" />
        </button>
      )}

      <ul
        ref={pista}
        className="ay-carousel__track"
        // Con el foco en la pista, las flechas recorren; sin foco no habría forma de usarlas.
        tabIndex={desplazable ? 0 : undefined}
        aria-label={desplazable ? 'Diapositivas' : undefined}
        style={{ '--ay-visible': visibles } as CSSProperties}
        onKeyDown={alPulsarTecla}
        onScroll={alDesplazar}
      >
        {items.map((item, i) => {
          // Fuera de la vista: ni enfocable ni leída, o el Tab se pierde en lo invisible.
          const fuera = i < indice || i >= indice + visibles
          return (
            <li
              key={i}
              className="ay-carousel__slide"
              aria-label={`${i + 1} de ${total}`}
              aria-hidden={fuera || undefined}
              inert={fuera || undefined}
            >
              {item}
            </li>
          )
        })}
      </ul>

      {desplazable && (
        <button
          type="button"
          className="ay-iconbtn ay-iconbtn--secondary ay-iconbtn--md ay-carousel__nav ay-carousel__nav--next"
          aria-label="Siguiente"
          disabled={!loop && indice >= ultima}
          onClick={() => irA(indice + 1)}
        >
          <IconoSiguiente className="ay-iconbtn__glyph" />
        </button>
      )}

      {indicators &&
        desplazable &&
        (total > MAXIMO_PUNTOS ? (
          <p className="ay-carousel__count">
            {indice + 1} de {total}
          </p>
        ) : (
          <div className="ay-carousel__dots">
            {Array.from({ length: ultima + 1 }, (_, i) => (
              <button
                key={i}
                type="button"
                aria-label={`Ir a la diapositiva ${i + 1} de ${total}`}
                aria-current={i === indice || undefined}
                onClick={() => irA(i)}
              />
            ))}
          </div>
        ))}
    </section>
  )
})

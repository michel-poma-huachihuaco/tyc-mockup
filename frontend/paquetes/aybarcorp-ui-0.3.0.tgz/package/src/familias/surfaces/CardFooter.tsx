import { forwardRef } from 'react'
import type { HTMLAttributes, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { estaVacio } from './_internos.js'

export type AlineacionCardFooter = 'end' | 'between'

export interface PropsCardFooter extends Omit<HTMLAttributes<HTMLDivElement>, 'className'> {
  /** Metadato de cierre —«Actualizado hace 2 días»—, al inicio, en tamaño xs y color subtle.
   *  No entra en el nombre accesible de la Card: cambia solo y no sirve para identificarla. */
  meta?: ReactNode
  /** Separador superior. Se quita cuando el contenido ya termina en un borde. */
  divider?: boolean
  /** Distribución de las zonas: `end` alinea las acciones al final —también con una sola,
   *  para que la posición sea constante entre cards—; `between` separa al máximo los
   *  metadatos de las acciones. */
  align?: AlineacionCardFooter
}

/**
 * Cierra una Card con sus acciones —los hijos, dos como máximo, con la primaria la última
 * en el DOM y en el orden visual— o con un metadato de cierre. Lleva z-index propio para
 * que un clic en el pie de una card interactiva no navegue al detalle. Un pie sin
 * contenido no se renderiza, ni siquiera el separador.
 */
export const CardFooter = forwardRef<HTMLDivElement, PropsCardFooter>(function CardFooter(
  { meta, divider = true, align = 'end', children, ...resto },
  ref,
) {
  const sinMeta = estaVacio(meta)
  const sinAcciones = estaVacio(children)
  if (sinMeta && sinAcciones) return null
  return (
    <div
      {...resto}
      ref={ref}
      className={cx('ay-card__footer', divider && 'ay-card__footer--divider', `ay-card__footer--${align}`)}
    >
      {!sinMeta && <p className="ay-card__meta">{meta}</p>}
      {!sinAcciones && <div className="ay-card__footer-actions">{children}</div>}
    </div>
  )
})

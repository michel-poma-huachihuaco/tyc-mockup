import { forwardRef, isValidElement, useContext } from 'react'
import type { HTMLAttributes, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { ContextoCard } from './Card.js'

export type NivelCardHeader = 'h2' | 'h3' | 'h4'

export interface PropsCardHeader extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'title'> {
  /** Título: nombra el objeto, no la sección —«Unidad 402»—. En una Card interactiva con
   *  `href` se envuelve en el enlace de la card; si ya trae su propio `<a>`, se respeta. */
  title: ReactNode
  /** Nivel del encabezado según la jerarquía de la página, no según el tamaño: quien navega
   *  saltando de encabezado en encabezado lo usa como índice. */
  as?: NivelCardHeader
  /** Subtítulo con el dato que distingue —«Residencial Miraflores · 3.ª planta»—, en tamaño
   *  sm y color muted. */
  subtitle?: ReactNode
  /** Icono o Avatar inicial. La zona mantiene un ancho fijo para que los títulos formen columna. */
  lead?: ReactNode
  /** Acciones de la cabecera, una o dos como máximo. Su nombre accesible incluye el objeto
   *  —«Editar la unidad 402»— y quedan por encima del área activable de una card interactiva.
   *  Nunca aparecen solo al pasar el ratón. */
  actions?: ReactNode
  /** Separador inferior, cuando el contenido lo requiere. */
  divider?: boolean
  /** Id del título, para que la Card apunte a él con `aria-labelledby` y se anuncie de qué
   *  unidad se trata en lugar de un «región» suelto. */
  titleId?: string
}

/**
 * Encabeza una Card con su título, un subtítulo opcional y las acciones que aplican a su
 * contenido. No tiene estados propios: viven en la Card y en sus acciones. Sin título
 * visible pero con acciones, el título se oculta con la clase `ay-visually-hidden` —no con
 * `display: none`— para que la región siga teniendo nombre.
 */
export const CardHeader = forwardRef<HTMLDivElement, PropsCardHeader>(function CardHeader(
  { title, as: Nivel = 'h3', subtitle, lead, actions, divider = false, titleId, ...resto },
  ref,
) {
  const { href } = useContext(ContextoCard)
  // El enlace envuelve el título, no la card: así el nombre accesible es el título.
  const traeEnlace = isValidElement(title) && title.type === 'a'
  const titulo = href && !traeEnlace ? <a href={href}>{title}</a> : title

  return (
    <div {...resto} ref={ref} className={cx('ay-card__header', divider && 'ay-card__header--divider')}>
      {lead != null && lead !== false && <div className="ay-card__lead">{lead}</div>}
      <div className="ay-card__heading">
        <Nivel className="ay-card__title" id={titleId}>
          {titulo}
        </Nivel>
        {subtitle != null && subtitle !== false && subtitle !== '' && <p className="ay-card__subtitle">{subtitle}</p>}
      </div>
      {actions != null && actions !== false && <div className="ay-card__actions">{actions}</div>}
    </div>
  )
})

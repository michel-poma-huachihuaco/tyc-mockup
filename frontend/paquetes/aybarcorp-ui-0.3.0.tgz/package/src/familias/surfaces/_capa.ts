/**
 * Capa superior del navegador para las superficies flotantes, sin React ni Angular: la
 * suben (`popover="manual"` + `showPopover()`), la bajan y, si la hoja la colocaba en su
 * sitio con `position: absolute`, la mantienen junto a su ancla con `position: fixed`.
 *
 * Por qué: con `position: absolute` o `fixed` y un `z-index` de `--aybar-z-dropdown`
 * (1000), una superficie queda debajo de todo lo pegajoso (`--aybar-z-sticky`, 1100: una
 * Navbar fija, un Banner fijo), la recorta el `overflow` de un ancestro y la desplaza su
 * `transform` (una tarjeta con Tilt). En la capa superior no le pasa nada de eso: va por
 * encima de todo el documento, Modal y Drawer incluidos, sin salir de su sitio en el DOM
 * —el foco, el clic fuera y la trampa de Tab siguen viéndola donde está—.
 *
 * Manual y no `auto`: el cierre lo gobierna cada componente (Escape, clic fuera, foco que
 * sale), y `auto` añadiría un cierre ligero propio que competiría con él. Sin la API
 * (se mira en el elemento, como `'showPopover' in HTMLElement.prototype`), todo sigue como
 * antes: la hoja coloca la superficie y nada de aquí la toca.
 *
 * Es interna: no se exporta en el índice. La usan varias familias, como `_tirador.ts` de
 * Layout. `@aybarcorp/ui-angular` lleva una copia literal del mismo archivo, porque los dos
 * paquetes no dependen el uno del otro y la conducta tiene que ser la misma en los dos; una
 * prueba de @aybarcorp/ui exige que sean idénticos.
 */

/** Atributo que marca una superficie subida por aquí: la hoja anula con él los estilos
 *  que el navegador pone a `[popover]` y la superficie no fija ya. */
export const ATRIBUTO_CAPA = 'data-ay-capa'

/**
 * Sube el panel a la capa superior. Se llama antes de medirlo o de mover el foco dentro:
 * un `[popover]` que no se muestra no tiene caja ni admite el foco. Sin la API, el panel
 * sigue con su `position: fixed` o `absolute`.
 */
export function mostrarEnCapaSuperior(panel: HTMLElement): void {
  if (typeof panel.showPopover !== 'function') return
  if (!panel.hasAttribute('popover')) panel.setAttribute('popover', 'manual')
  panel.setAttribute(ATRIBUTO_CAPA, '')
  try {
    panel.showPopover()
  } catch {
    // Un motor antiguo lanza si ya estaba abierto; uno a medias, si algo no le gusta. En
    // los dos casos el panel sigue visible con su posición de la hoja.
  }
}

/** Saca el panel de la capa superior; sin la API, o si no estaba en ella, no hace nada. */
export function ocultarDeCapaSuperior(panel: HTMLElement | null | undefined): void {
  if (!panel || typeof panel.hidePopover !== 'function' || !panel.hasAttribute('popover')) return
  try {
    panel.hidePopover()
  } catch {
    // Ya estaba oculto en un motor que lo trata como error: nada que deshacer.
  }
}

// ── Superficies ancladas ─────────────────────────────────────────────────────

/** Lado del ancla por donde sale la superficie. `lado` es el final en línea (la derecha
 *  en LTR), el de un submenú. */
export type LadoCapa = 'abajo' | 'arriba' | 'lado'

/** Alineación en el otro eje: con el borde de inicio del ancla, con el de fin o centrada. */
export type AlineacionCapa = 'inicio' | 'fin' | 'centro'

export interface AnclajeCapa {
  /** Lado preferido; si no cabe y en el opuesto sí, se voltea. Por omisión, `abajo`. */
  lado?: LadoCapa
  /** Alineación con el ancla; si no cabe, se alinea al otro borde. Por omisión, `inicio`.
   *  Con `lado`, la superficie empieza a la altura del ancla. */
  alineacion?: AlineacionCapa
  /** Separación con el ancla: la misma que le da la hoja, en píxeles o con el nombre del
   *  token de espacio (`'--aybar-space-1'`), que se lee en tiempo de ejecución. */
  separacion?: number | string
  /** Desplazamiento en el eje de la alineación, en píxeles. Un submenú sube lo que mide su
   *  relleno para que su primer ítem quede a la altura del ítem padre. */
  desplazamiento?: number
  /** `igual`: el ancho del ancla (la lista de un campo); `minimo`: como poco, el suyo (el
   *  menú de un Split Button). Sin él, el ancho propio de la superficie. */
  ancho?: 'igual' | 'minimo'
}

/** Lo que se escribe en el estilo en línea del panel, para quitarlo al bajar. El margen va
 *  por lados: hay motores que al quitar el atajo dejan los cuatro lados escritos. */
const PROPIEDADES = [
  'position',
  'top',
  'left',
  'right',
  'bottom',
  'margin',
  'margin-top',
  'margin-right',
  'margin-bottom',
  'margin-left',
  'box-sizing',
  'width',
  'min-width',
] as const

/**
 * Sube a la capa superior una superficie que la hoja coloca en su sitio con
 * `position: absolute` y la deja junto a `ancla` con `position: fixed`, como la dejaría la
 * hoja: el mismo lado, la misma alineación y la misma separación, con volteo si no cabe y
 * sin salirse nunca del área útil. Se recoloca con el scroll, el redimensionado y los
 * cambios de tamaño del ancla o de la propia superficie (una lista que se filtra).
 *
 * Se llama con la superficie ya visible (sin `hidden`) y antes de medirla o de mover el
 * foco dentro. Devuelve la baja: la saca de la capa, quita la posición en línea y el
 * atributo `popover`, de modo que, cerrada, queda como sin la API. Sin la API, no hace
 * nada y la baja tampoco.
 */
export function anclarEnCapaSuperior(panel: HTMLElement, ancla: HTMLElement, anclaje: AnclajeCapa = {}): () => void {
  if (typeof panel.showPopover !== 'function') return () => {}
  const documento = panel.ownerDocument
  const vista = documento.defaultView
  // Los tokens se leen una vez: no cambian mientras la superficie está abierta.
  const medidas: Medidas = {
    separacion: aPixeles(documento, anclaje.separacion),
    desplazamiento: anclaje.desplazamiento ?? 0,
  }
  mostrarEnCapaSuperior(panel)
  // En línea y no en la hoja: gana a cualquier regla de la superficie (sus volteos y sus
  // modificadores incluidos) sin pelear por especificidad. La posición sale de JS.
  panel.style.setProperty('position', 'fixed')
  panel.style.setProperty('right', 'auto')
  panel.style.setProperty('bottom', 'auto')
  panel.style.setProperty('margin', '0')
  if (anclaje.ancho) panel.style.setProperty('box-sizing', 'border-box')
  const colocar = (): void => colocarJuntoA(panel, ancla, anclaje, medidas)
  colocar()
  // El scroll dentro de la propia superficie (una lista larga) no la mueve.
  const alDesplazar = (evento: Event): void => {
    if (evento.target instanceof Node && panel.contains(evento.target)) return
    colocar()
  }
  vista?.addEventListener('scroll', alDesplazar, true)
  vista?.addEventListener('resize', colocar)
  const Observador = vista?.ResizeObserver
  const observador = typeof Observador === 'function' ? new Observador(colocar) : null
  observador?.observe(ancla)
  observador?.observe(panel)
  let bajada = false
  return () => {
    if (bajada) return
    bajada = true
    vista?.removeEventListener('scroll', alDesplazar, true)
    vista?.removeEventListener('resize', colocar)
    observador?.disconnect()
    ocultarDeCapaSuperior(panel)
    for (const propiedad of PROPIEDADES) panel.style.removeProperty(propiedad)
    panel.removeAttribute(ATRIBUTO_CAPA)
    panel.removeAttribute('popover')
  }
}

/**
 * Coloca el panel junto al ancla, en coordenadas de la ventana. Mismo criterio que el
 * posicionamiento de Overlays: voltea si no cabe en el lado pedido y sí en el opuesto; si
 * no cabe en ninguno, se queda dentro del área útil aunque tape parte del ancla.
 */
function colocarJuntoA(panel: HTMLElement, ancla: HTMLElement, anclaje: AnclajeCapa, medidas: Medidas): void {
  const { lado = 'abajo', alineacion = 'inicio', ancho } = anclaje
  const { separacion, desplazamiento } = medidas
  if (!ancla.isConnected || !panel.isConnected) return
  const caja = ancla.getBoundingClientRect()
  if (ancho === 'igual') panel.style.setProperty('width', `${caja.width}px`)
  else if (ancho === 'minimo') panel.style.setProperty('min-width', `${caja.width}px`)
  // Se mide desde el borde izquierdo: así el ancho que se ajusta al contenido no depende
  // de dónde quedó la vez anterior (pegada al borde derecho tendría menos sitio y saldría
  // más estrecha). offsetWidth/offsetHeight y no la caja: la entrada anima la escala, y a
  // mitad de la animación la caja aún es un poco más pequeña que la superficie.
  panel.style.setProperty('left', '0')
  const propio = { ancho: panel.offsetWidth, alto: panel.offsetHeight }
  const area = areaUtil(panel.ownerDocument)
  const rtl = panel.ownerDocument.defaultView?.getComputedStyle(ancla).direction === 'rtl'
  const dentro = (valor: number, tamano: number, limite: number): number =>
    Math.max(0, Math.min(valor, limite - tamano))

  let x: number
  let y: number
  if (lado === 'lado') {
    const aLaDerecha = caja.right + separacion
    const aLaIzquierda = caja.left - separacion - propio.ancho
    const [preferida, opuesta] = rtl ? [aLaIzquierda, aLaDerecha] : [aLaDerecha, aLaIzquierda]
    const cabe = (valor: number): boolean => valor >= 0 && valor + propio.ancho <= area.ancho
    x = cabe(preferida) || !cabe(opuesta) ? preferida : opuesta
    y = caja.top + desplazamiento
  } else {
    const abajo = caja.bottom + separacion
    const arriba = caja.top - separacion - propio.alto
    const cabeAbajo = abajo + propio.alto <= area.alto
    const cabeArriba = arriba >= 0
    const haciaArriba = lado === 'arriba' ? cabeArriba || !cabeAbajo : !cabeAbajo && cabeArriba
    y = haciaArriba ? arriba : abajo

    const alInicio = rtl ? caja.right - propio.ancho : caja.left
    const alFinal = rtl ? caja.left : caja.right - propio.ancho
    const cabe = (valor: number): boolean => valor >= 0 && valor + propio.ancho <= area.ancho
    if (alineacion === 'centro') x = caja.left + (caja.width - propio.ancho) / 2
    else if (alineacion === 'fin') x = cabe(alFinal) || !cabe(alInicio) ? alFinal : alInicio
    else x = cabe(alInicio) || !cabe(alFinal) ? alInicio : alFinal
    x += desplazamiento
  }
  panel.style.setProperty('left', `${dentro(x, propio.ancho, area.ancho)}px`)
  panel.style.setProperty('top', `${dentro(y, propio.alto, area.alto)}px`)
}

interface Medidas {
  separacion: number
  desplazamiento: number
}

/** Píxeles de una medida del anclaje: un número tal cual, o el valor de un token. */
function aPixeles(documento: Document, medida: number | string | undefined): number {
  if (typeof medida === 'number') return medida
  return medida ? pixelesDeToken(documento, medida) : 0
}

/**
 * Área útil de la ventana: ancho y alto sin las barras de scroll. Copia de `areaVisible`
 * (este archivo no importa nada, para poder ser copia literal en los dos paquetes).
 */
function areaUtil(documento: Document): { ancho: number; alto: number } {
  const raiz = documento.documentElement
  const vista = documento.defaultView
  return {
    ancho: raiz.clientWidth || vista?.innerWidth || 0,
    alto: raiz.clientHeight || vista?.innerHeight || 0,
  }
}

/**
 * El valor de un token de espacio (`--aybar-space-1`), en píxeles: es la separación que
 * la hoja da a la superficie, y aquí se lee del token en vez de repetirla.
 */
export function pixelesDeToken(documento: Document, token: string): number {
  const vista = documento.defaultView
  if (!vista) return 0
  const valor = vista.getComputedStyle(documento.documentElement).getPropertyValue(token).trim()
  const numero = parseFloat(valor)
  if (Number.isNaN(numero)) return 0
  if (valor.endsWith('rem')) {
    return numero * (parseFloat(vista.getComputedStyle(documento.documentElement).fontSize) || 16)
  }
  return numero
}

import { forwardRef, useRef, useState } from 'react'
import type { HTMLAttributes, KeyboardEvent, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { IconoCerrar } from './_iconos.js'
import { focoTrasRetirar, textoPlano, unirRefs } from './_internos.js'

export type VarianteChip = 'selectable' | 'removable' | 'input'

export interface PropsChip extends Omit<HTMLAttributes<HTMLElement>, 'className'> {
  /** Comportamiento. `selectable` es un `button` con `aria-pressed` que alterna como un
   *  checkbox compacto; `removable` muestra un botón de retirar y el chip en sí no es
   *  clicable; `input` es un valor de un campo de tokens, siempre eliminable. */
  variant?: VarianteChip
  /** Estado seleccionado de un chip `selectable`: fondo lleno, no solo borde. Por omisión
   *  `false` y no controlado: sin esta prop el chip guarda su propio estado. */
  selected?: boolean
  /** Cambio de selección, con el estado nuevo. */
  onSelectedChange?: (selected: boolean) => void
  /** Retirada del valor. Al retirarse, el foco pasa al chip siguiente o, si era el último,
   *  al contenedor, para que no caiga al documento. */
  onRemove?: () => void
  /** Nombre accesible del botón de retirar, con el valor incluido —«Quitar el filtro
   *  Miraflores»—. Obligatorio si hay `onRemove`: seis botones «Quitar» seguidos obligan a
   *  contar posiciones. */
  removeLabel?: string
  /** Icono o avatar inicial que identifica el valor. */
  leading?: ReactNode
  /** Desactiva el chip; un chip seleccionado conserva su selección. */
  disabled?: boolean
}

/**
 * Valor concreto que el usuario puede seleccionar o retirar: un filtro aplicado, una
 * etiqueta asignada, un destinatario. Si no es interactivo es un Tag; si comunica un
 * estado que el usuario no controla, un Badge. Un conjunto de chips de filtro va en una
 * región con nombre, «Filtros aplicados».
 */
export const Chip = forwardRef<HTMLElement, PropsChip>(function Chip(
  {
    variant = 'selectable',
    selected,
    onSelectedChange,
    onRemove,
    removeLabel,
    leading,
    disabled = false,
    children,
    onClick,
    ...resto
  },
  ref,
) {
  const [seleccionInterna, setSeleccionInterna] = useState(false)
  const raiz = useRef<HTMLElement | null>(null)
  const texto = textoPlano(children)
  // Un valor truncado conserva el valor completo en el `title`.
  const titulo = typeof children === 'string' || typeof children === 'number' ? texto : undefined

  if (variant === 'selectable') {
    const seleccionado = selected ?? seleccionInterna
    return (
      <button
        {...resto}
        ref={unirRefs(ref, raiz) as (nodo: HTMLButtonElement | null) => void}
        type="button"
        className="ay-chip"
        aria-pressed={seleccionado}
        disabled={disabled}
        onClick={(evento) => {
          onClick?.(evento)
          if (evento.defaultPrevented) return
          if (selected === undefined) setSeleccionInterna(!seleccionado)
          onSelectedChange?.(!seleccionado)
        }}
      >
        {leading}
        <span className="ay-chip__text" title={titulo}>
          {children}
        </span>
      </button>
    )
  }

  const retirar = () => {
    const chip = raiz.current
    const destino = focoTrasRetirar(chip)
    onRemove?.()
    // El foco solo se mueve si el chip desapareció de verdad tras el re-render.
    setTimeout(() => {
      if (chip && !chip.isConnected) destino?.focus()
    }, 0)
  }
  const alPulsarTecla = (evento: KeyboardEvent<HTMLButtonElement>) => {
    // En un campo de tokens, Retroceso o Suprimir sobre el botón retiran el valor.
    if (variant === 'input' && (evento.key === 'Backspace' || evento.key === 'Delete')) {
      evento.preventDefault()
      retirar()
    }
  }

  return (
    <span
      {...resto}
      onClick={onClick}
      ref={unirRefs(ref, raiz)}
      className={cx('ay-chip', 'ay-chip--removable', variant === 'input' && 'ay-chip--input', disabled && 'is-disabled')}
    >
      {leading}
      <span className="ay-chip__text" title={titulo}>
        {children}
      </span>
      <button
        type="button"
        className="ay-chip__remove"
        aria-label={removeLabel ?? (texto ? `Quitar ${texto}` : 'Quitar')}
        disabled={disabled}
        onClick={retirar}
        onKeyDown={alPulsarTecla}
      >
        <IconoCerrar tamano={14} />
      </button>
    </span>
  )
})

import { forwardRef } from 'react'
import type { HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import { estaVacio } from './_internos.js'

export type VarianteTag = 'neutral' | 'brand' | 'outline'
export type TamanoTag = 'sm' | 'md'

export interface PropsTag extends Omit<HTMLAttributes<HTMLSpanElement>, 'className'> {
  /** Apariencia. `neutral` es fondo sunken y texto muted; `brand`, fondo accent-subtle para
   *  categorías destacadas; `outline`, solo borde, para fondos con imagen o series largas. */
  variant?: VarianteTag
  /** Altura. `sm` dentro de celdas de tabla, para no aumentar la altura de fila. */
  size?: TamanoTag
  /** Color del punto, como pista categórica —un `var(--aybar-*)`—. Es decorativo y siempre
   *  va acompañado del texto: el color nunca es el único portador de significado. */
  dotColor?: string
}

/**
 * Etiqueta un registro con una categoría o atributo —«Obra nueva», «Dúplex»— sin ser
 * interactiva: es un `span` sin foco. Si se puede seleccionar o quitar es un Chip; si
 * comunica un estado del ciclo de vida, un Badge. Las series van en Tag List. Sin
 * categoría no se pinta: ni una etiqueta vacía ni un punto de color sin texto.
 */
export const Tag = forwardRef<HTMLSpanElement, PropsTag>(function Tag(
  { variant = 'neutral', size = 'md', dotColor, children, ...resto },
  ref,
) {
  if (estaVacio(children)) return null
  return (
    <span {...resto} ref={ref} className={cx('ay-tag', `ay-tag--${variant}`, `ay-tag--${size}`)}>
      {dotColor && <span className="ay-tag__dot" aria-hidden="true" style={{ background: dotColor }} />}
      {children}
    </span>
  )
})

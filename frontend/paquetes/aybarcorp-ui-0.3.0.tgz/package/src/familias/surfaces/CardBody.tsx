import { forwardRef } from 'react'
import type { HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import { estaVacio } from './_internos.js'

export type PaddingCardBody = 'md' | 'sm' | 'none'
export type GapCardBody = 'sm' | 'md'

export interface PropsCardBody extends Omit<HTMLAttributes<HTMLDivElement>, 'className'> {
  /** Padding interno. `md` es space.5; `sm` es space.4, para cards dentro de listas; `none`
   *  es para contenido que llega al borde —una tabla, una imagen—, y los hermanos conservan
   *  el suyo. */
  padding?: PaddingCardBody
  /** Separación vertical entre bloques: grid con gap, nunca márgenes entre hijos. */
  gap?: GapCardBody
}

/**
 * Contiene el contenido de una Card con el padding y el ritmo vertical que le
 * corresponden. Es un contenedor de presentación sin semántica propia: el contenido aporta
 * su marcado —pares de dato y valor en `dl`, con Card Pairs—. Sin contenido no se
 * renderiza.
 */
export const CardBody = forwardRef<HTMLDivElement, PropsCardBody>(function CardBody(
  { padding = 'md', gap = 'md', children, ...resto },
  ref,
) {
  if (estaVacio(children)) return null
  return (
    <div
      {...resto}
      ref={ref}
      className={cx('ay-card__body', `ay-card__body--p-${padding}`, `ay-card__body--gap-${gap}`)}
    >
      {children}
    </div>
  )
})

/**
 * Utilidades internas de la familia Surfaces. No se exportan desde el índice: son el
 * motor compartido de Tooltip y Popover (posicionamiento con volteo) y los cálculos
 * puros de Avatar y Chip. Nada aquí declara un color ni una medida: las distancias
 * se leen de los tokens en tiempo de ejecución.
 */
import { Children, isValidElement } from 'react'
import type { ReactNode, Ref } from 'react'
import { areaVisible } from '../../utiles.js'

// ── Avatar ────────────────────────────────────────────────────────────────────

/**
 * Primera letra del nombre y del primer apellido. Se toma el primer carácter
 * completo —un grafema, no un code unit— para que un nombre con tildes compuestas o
 * con escritura no latina no se parta por la mitad.
 */
export function iniciales(nombre?: string): string {
  const partes = (nombre ?? '').trim().split(/\s+/).filter(Boolean).slice(0, 2)
  return partes.map((parte) => primerGrafema(parte)).join('').toLocaleUpperCase('es')
}

function primerGrafema(texto: string): string {
  const Segmentador = (Intl as { Segmenter?: typeof Intl.Segmenter }).Segmenter
  if (Segmentador) {
    for (const { segment } of new Segmentador('es', { granularity: 'grapheme' }).segment(texto)) return segment
  }
  return [...texto][0] ?? ''
}

/** Texto accesible del indicador de presencia: el punto de color no se anuncia. */
export const TEXTO_ESTADO_AVATAR = {
  online: 'En línea',
  busy: 'Ocupado',
  away: 'Ausente',
  offline: 'Desconectado',
} as const

// ── Contenido ─────────────────────────────────────────────────────────────────

/** Un hijo que no pinta nada: así Card Body y Card Footer no dejan una franja vacía. */
export function estaVacio(nodo: ReactNode): boolean {
  if (nodo === null || nodo === undefined || typeof nodo === 'boolean' || nodo === '') return true
  if (Array.isArray(nodo)) return nodo.every(estaVacio)
  return false
}

/** Texto plano de un nodo, para un `title` o un nombre accesible derivado. */
export function textoPlano(nodo: ReactNode): string {
  if (typeof nodo === 'string' || typeof nodo === 'number') return String(nodo)
  if (Array.isArray(nodo)) return nodo.map(textoPlano).join('')
  if (isValidElement<{ children?: ReactNode }>(nodo)) return textoPlano(nodo.props.children)
  return ''
}

/** Cuenta hijos que sí pintan algo, para decidir entre `items` y la composición directa. */
export function hayHijos(nodo: ReactNode): boolean {
  return Children.toArray(nodo).length > 0
}

// ── Referencias ───────────────────────────────────────────────────────────────

/** Une varias refs en una: la propia del componente y la que trae el elemento clonado. */
export function unirRefs<T>(...refs: (Ref<T> | undefined | null)[]): (nodo: T | null) => void {
  return (nodo) => {
    for (const ref of refs) {
      if (typeof ref === 'function') ref(nodo)
      else if (ref && typeof ref === 'object') (ref as { current: T | null }).current = nodo
    }
  }
}

/**
 * La ref que trae un elemento hijo. React 19 la pasa como prop; React 18 la deja en el
 * elemento. Se lee de las dos maneras para no perder la del consumidor al clonar.
 */
export function refDeElemento<T>(elemento: unknown, versionMayor: number): Ref<T> | undefined {
  if (!isValidElement(elemento)) return undefined
  if (versionMayor >= 19) return (elemento.props as { ref?: Ref<T> }).ref
  return (elemento as unknown as { ref?: Ref<T> }).ref
}

// ── Foco ──────────────────────────────────────────────────────────────────────

export const SELECTOR_ENFOCABLE =
  'a[href], button:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"]), [contenteditable="true"]'

/** El elemento que recibe el foco dentro de `raiz`: ella misma si es enfocable. */
export function enfocableDe(raiz: Element | null): HTMLElement | null {
  if (!raiz) return null
  if (raiz.matches(SELECTOR_ENFOCABLE)) return raiz as HTMLElement
  return raiz.querySelector<HTMLElement>(SELECTOR_ENFOCABLE)
}

/**
 * A dónde va el foco cuando un chip desaparece: al siguiente chip del mismo conjunto
 * o, si era el último, al contenedor. El elemento enfocado deja de existir y, sin esto,
 * el foco caería al documento y devolvería al usuario al principio de la página.
 */
export function focoTrasRetirar(chip: HTMLElement | null): HTMLElement | null {
  if (!chip) return null
  const contenedor =
    chip.parentElement?.closest<HTMLElement>('[role="group"], [role="region"], [role="list"], ul, ol, fieldset') ??
    chip.parentElement
  if (!contenedor) return null
  const chips = Array.from(contenedor.querySelectorAll<HTMLElement>('.ay-chip'))
  const siguiente = chips[chips.indexOf(chip) + 1]
  const destino = siguiente ? (enfocableDe(siguiente) ?? siguiente) : contenedor
  if (destino === contenedor && !contenedor.matches(SELECTOR_ENFOCABLE) && !contenedor.hasAttribute('tabindex')) {
    contenedor.setAttribute('tabindex', '-1')
  }
  return destino
}

// ── Posicionamiento flotante (Tooltip y Popover) ──────────────────────────────

export type Lado = 'top' | 'bottom' | 'start' | 'end'
export type LadoFisico = 'top' | 'bottom' | 'left' | 'right'

export interface Posicion {
  /** Lado lógico resultante, después de voltear si no cabía. */
  lado: Lado
  /** Lado físico, para orientar la flecha. */
  fisico: LadoFisico
  top: number
  left: number
  /** Desplazamiento de la flecha sobre el eje transversal, desde el borde del panel. */
  flecha: number
}

/**
 * Convierte el valor de un token de longitud a píxeles. Los tokens se declaran en `rem`
 * o en `px`; leerlos aquí evita escribir en el código una separación que el manual de
 * marca ya fija.
 */
export function pixelesDeToken(elemento: Element, token: string, respaldo: number): number {
  const vista = elemento.ownerDocument.defaultView
  if (!vista) return respaldo
  const valor = vista.getComputedStyle(elemento).getPropertyValue(token).trim()
  const numero = parseFloat(valor)
  if (!Number.isFinite(numero)) return respaldo
  if (valor.endsWith('rem')) {
    const raiz = parseFloat(vista.getComputedStyle(elemento.ownerDocument.documentElement).fontSize)
    return numero * (Number.isFinite(raiz) ? raiz : 16)
  }
  return numero
}

const OPUESTO: Record<LadoFisico, LadoFisico> = { top: 'bottom', bottom: 'top', left: 'right', right: 'left' }

/**
 * Coloca un panel flotante junto a su ancla en coordenadas de viewport (`position: fixed`).
 *
 * Se prueba el lado preferido; si no cabe, el opuesto; si tampoco, el que tenga más
 * espacio, y entonces la posición se recorta dentro del área útil: tapar parte del ancla
 * es mejor que dejar el panel cortado fuera de la ventana. En el eje transversal se centra
 * respecto del ancla y se desplaza para no salir del viewport, y la flecha se recoloca
 * para seguir apuntando al ancla.
 */
export function calcularPosicion(
  ancla: DOMRect,
  panel: { width: number; height: number },
  preferido: Lado,
  opciones: { separacion: number; margen: number; rtl: boolean; viewport: { width: number; height: number } },
): Posicion {
  const { separacion, margen, rtl, viewport } = opciones
  const aFisico = (lado: Lado): LadoFisico =>
    lado === 'start' ? (rtl ? 'right' : 'left') : lado === 'end' ? (rtl ? 'left' : 'right') : lado
  const aLogico = (fisico: LadoFisico): Lado =>
    fisico === 'left' ? (rtl ? 'end' : 'start') : fisico === 'right' ? (rtl ? 'start' : 'end') : fisico

  const espacio: Record<LadoFisico, number> = {
    top: ancla.top - margen,
    bottom: viewport.height - ancla.bottom - margen,
    left: ancla.left - margen,
    right: viewport.width - ancla.right - margen,
  }
  const necesita = (f: LadoFisico) => (f === 'top' || f === 'bottom' ? panel.height : panel.width) + separacion
  const cabe = (f: LadoFisico) => espacio[f] >= necesita(f)

  const deseado = aFisico(preferido)
  let fisico = deseado
  if (!cabe(deseado)) {
    const opuesto = OPUESTO[deseado]
    fisico = cabe(opuesto) ? opuesto : espacio[opuesto] > espacio[deseado] ? opuesto : deseado
  }

  const limitar = (valor: number, min: number, max: number) => Math.min(Math.max(valor, min), Math.max(min, max))
  let top: number
  let left: number
  let flecha: number
  // Ni el lado elegido cabe: no cabe en ninguno de los dos.
  const apretado = !cabe(fisico)
  if (fisico === 'top' || fisico === 'bottom') {
    top = fisico === 'top' ? ancla.top - separacion - panel.height : ancla.bottom + separacion
    if (apretado) top = limitar(top, margen, viewport.height - panel.height - margen)
    left = limitar(ancla.left + ancla.width / 2 - panel.width / 2, margen, viewport.width - panel.width - margen)
    flecha = limitar(ancla.left + ancla.width / 2 - left, margen, panel.width - margen)
  } else {
    left = fisico === 'left' ? ancla.left - separacion - panel.width : ancla.right + separacion
    if (apretado) left = limitar(left, margen, viewport.width - panel.width - margen)
    top = limitar(ancla.top + ancla.height / 2 - panel.height / 2, margen, viewport.height - panel.height - margen)
    flecha = limitar(ancla.top + ancla.height / 2 - top, margen, panel.height - margen)
  }
  return { lado: aLogico(fisico), fisico, top: Math.round(top), left: Math.round(left), flecha: Math.round(flecha) }
}

/**
 * Posiciona `panel` respecto de `ancla` leyendo separación y margen de los tokens. El
 * viewport es el área útil, sin las barras de scroll: con `innerWidth` un panel pegado al
 * borde derecho quedaba encima de la barra vertical.
 */
export function posicionarRespectoDe(ancla: HTMLElement, panel: HTMLElement, preferido: Lado): Posicion {
  const vista = ancla.ownerDocument.defaultView
  const rtl = vista ? vista.getComputedStyle(ancla).direction === 'rtl' : false
  const caja = panel.getBoundingClientRect()
  const area = areaVisible(ancla.ownerDocument)
  return calcularPosicion(ancla.getBoundingClientRect(), { width: caja.width, height: caja.height }, preferido, {
    separacion: pixelesDeToken(panel, '--aybar-space-2', 8),
    margen: pixelesDeToken(panel, '--aybar-space-2', 8),
    rtl,
    viewport: { width: area.ancho || caja.width, height: area.alto || caja.height },
  })
}

/** El ancla salió del viewport al desplazar: el panel se cierra en lugar de quedar flotando. */
export function fueraDeVista(ancla: HTMLElement): boolean {
  if (!ancla.ownerDocument.defaultView) return false
  const { ancho, alto } = areaVisible(ancla.ownerDocument)
  const caja = ancla.getBoundingClientRect()
  return caja.bottom < 0 || caja.top > alto || caja.right < 0 || caja.left > ancho
}

// ── Capa superior ─────────────────────────────────────────────────────────────
// La mecánica vive en `_capa.ts`, sin React ni Angular, y la comparten todas las familias.
export { mostrarEnCapaSuperior, ocultarDeCapaSuperior } from './_capa.js'

// ── Coordinación entre instancias ─────────────────────────────────────────────

let cerrarPopoverAbierto: (() => void) | null = null

/**
 * Solo un Popover abierto a la vez: al abrir uno se cierra el anterior. Devuelve la
 * función que lo da de baja al cerrarse.
 */
export function registrarPopoverAbierto(cerrar: () => void): () => void {
  if (cerrarPopoverAbierto && cerrarPopoverAbierto !== cerrar) cerrarPopoverAbierto()
  cerrarPopoverAbierto = cerrar
  return () => {
    if (cerrarPopoverAbierto === cerrar) cerrarPopoverAbierto = null
  }
}

let ultimoCierreTooltip = 0

/** Al pasar de un disparador a otro, el segundo tooltip abre sin repetir el retardo. */
export function tooltipRecienCerrado(ventana: number): boolean {
  return Date.now() - ultimoCierreTooltip < ventana
}

export function marcarCierreTooltip(): void {
  ultimoCierreTooltip = Date.now()
}

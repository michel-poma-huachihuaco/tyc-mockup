import { forwardRef } from 'react'
import type { HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import { Avatar } from './Avatar.js'

export type TamanoAvatarGroup = 'sm' | 'md' | 'lg'

export interface PropsAvatarGroup extends Omit<HTMLAttributes<HTMLDivElement>, 'className'> {
  /** Personas del grupo. Sin foto se pintan sus iniciales; el contador cuenta personas, no
   *  nombres distintos. */
  people?: Array<{ id: string; name: string; src?: string }>
  /** Avatares visibles antes del contador de excedente, que nunca se omite. */
  max?: number
  /** Tamaño de los avatares: `sm` en celdas de tabla, `lg` en cabeceras de detalle. */
  size?: TamanoAvatarGroup
  /** Solape entre avatares. El borde que los separa usa el color del fondo, no
   *  transparencia, para que el solape se distinga también en forced-colors. */
  overlap?: boolean
  /** Nombre accesible que resume el conjunto y nombra el rol: «4 asesores asignados».
   *  Obligatorio: los avatares individuales quedan decorativos. */
  label: string
  /** Hace del contador un botón —la única parada de teclado del grupo— que abre la lista
   *  completa, normalmente en un Popover. */
  onOverflowClick?: () => void
}

/** La forma de cada persona de `people`. */
export type PersonaAvatarGroup = NonNullable<PropsAvatarGroup['people']>[number]

/**
 * Muestra un conjunto de personas de forma compacta: los primeros solapados y el resto
 * contado, «y 3 más». Es un `role="group"` con nombre; los avatares no reciben foco. Si
 * hay que identificar a cada persona, una List con Avatar y nombre es más clara.
 */
export const AvatarGroup = forwardRef<HTMLDivElement, PropsAvatarGroup>(function AvatarGroup(
  { people = [], max = 4, size = 'md', overlap = true, label, onOverflowClick, ...resto },
  ref,
) {
  const visibles = people.slice(0, Math.max(0, max))
  const excedente = people.length - visibles.length
  const contenidoExcedente = (
    <>
      <span aria-hidden="true">+{excedente}</span>
      <span className="ay-visually-hidden">y {excedente} más</span>
    </>
  )

  return (
    <div
      {...resto}
      ref={ref}
      role="group"
      aria-label={label}
      className={cx('ay-avatars', `ay-avatars--${size}`, overlap && 'ay-avatars--overlap')}
    >
      {visibles.map((persona, i) => (
        <Avatar
          key={persona.id}
          name={persona.name}
          src={persona.src}
          size={size}
          decorative
          aria-hidden="true"
          title={persona.name}
          // El primero queda encima: el z-index desciende de izquierda a derecha.
          style={{ zIndex: visibles.length - i }}
        />
      ))}
      {excedente > 0 &&
        (onOverflowClick !== undefined ? (
          <button type="button" className="ay-avatars__more" onClick={() => onOverflowClick?.()}>
            {contenidoExcedente}
          </button>
        ) : (
          <span className="ay-avatars__more">{contenidoExcedente}</span>
        ))}
    </div>
  )
})

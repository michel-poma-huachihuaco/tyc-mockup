import { cloneElement, forwardRef, isValidElement } from 'react'
import type { HTMLAttributes, ReactElement, ReactNode } from 'react'
import { cx } from '../../utiles.js'

export interface PropsListItem extends Omit<HTMLAttributes<HTMLLIElement>, 'className' | 'title'> {
  /** Contenido de la zona inicial, de ancho fijo: icono, Avatar o Checkbox. Un glifo se
   *  oculta al lector; un control como el Checkbox, no. */
  lead?: ReactNode
  /** Título del elemento, empezando por lo que lo distingue: el nombre del documento, no
   *  «Documento». Si es un `<a>`, se convierte en el área activable del elemento. */
  title: ReactNode
  /** Metadatos de la segunda línea, dos o tres datos separados por punto medio, en tamaño
   *  sm y color subtle. */
  meta?: ReactNode
  /** Contenido de la zona final: Badge, valor o acciones. Las acciones nombran el elemento
   *  —«Descargar Contrato de reserva.pdf»— y quedan fuera del área activable. */
  trail?: ReactNode
  /** Destino; hace el elemento interactivo. El enlace vive en el título y extiende su área
   *  con un pseudoelemento: un solo destino por elemento, sin envolver los botones. */
  href?: string
  /** Estado seleccionado: fondo accent-subtle. El estado lo comunica el Checkbox real de la
   *  zona inicial, no el color. */
  selected?: boolean
  /** Desactiva el elemento: texto atenuado y enlace sin destino. Si sigue siendo
   *  interesante, el motivo va en los metadatos. */
  disabled?: boolean
}

const CONTROLES = new Set(['input', 'button', 'a', 'select', 'textarea', 'label'])

/** Un glifo o un punto decorativo se oculta al lector; un componente o un control, no. */
function leadDecorativo(lead: ReactNode): boolean {
  return isValidElement(lead) && typeof lead.type === 'string' && !CONTROLES.has(lead.type)
}

/**
 * Elemento de lista en tres zonas —inicial, principal y final— para que el contenido
 * principal se alinee en columna y las acciones queden siempre en el mismo sitio. Es un
 * `li`: no existe fuera de una `ul` u `ol`. Si necesita superficie e imagen propias, es
 * una Card.
 */
export const ListItem = forwardRef<HTMLLIElement, PropsListItem>(function ListItem(
  { lead, title, meta, trail, href, selected = false, disabled = false, ...resto },
  ref,
) {
  const enlaceEnTitulo = isValidElement<{ className?: string }>(title) && title.type === 'a'
  const interactivo = Boolean(href) || enlaceEnTitulo

  let titulo: ReactNode
  if (href) {
    titulo = disabled ? (
      // Sin `href` el enlace no es alcanzable ni activable: deshabilitado de verdad, no solo atenuado.
      <a className="ay-list__title" role="link" aria-disabled="true">
        {title}
      </a>
    ) : (
      <a href={href} className="ay-list__title">
        {title}
      </a>
    )
  } else if (enlaceEnTitulo) {
    const enlace = title as ReactElement<{ className?: string; href?: string; role?: string; 'aria-disabled'?: boolean }>
    titulo = cloneElement(enlace, {
      className: cx('ay-list__title', enlace.props.className),
      ...(disabled ? { href: undefined, role: 'link', 'aria-disabled': true } : {}),
    })
  } else {
    titulo = <span className="ay-list__title">{title}</span>
  }

  return (
    <li
      {...resto}
      ref={ref}
      className={cx(
        'ay-list__item',
        interactivo && 'ay-list__item--interactive',
        selected && 'ay-list__item--selected',
        disabled && 'ay-list__item--disabled',
      )}
    >
      {lead != null && lead !== false && (
        <span className="ay-list__lead" aria-hidden={leadDecorativo(lead) || undefined}>
          {lead}
        </span>
      )}
      <span className="ay-list__main">
        {titulo}
        {meta != null && meta !== false && meta !== '' && <span className="ay-list__meta">{meta}</span>}
      </span>
      {trail != null && trail !== false && <span className="ay-list__trail">{trail}</span>}
    </li>
  )
})

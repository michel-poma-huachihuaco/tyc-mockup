import { Fragment, forwardRef } from 'react'
import type { HTMLAttributes, ReactNode } from 'react'

export interface PropsCardPairs extends Omit<HTMLAttributes<HTMLDListElement>, 'className' | 'children'> {
  /** Pares de dato y valor, en orden: `[etiqueta, valor]`. Se marcan con `dt` y `dd` para que
   *  el lector los anuncie asociados; las cifras usan tabular-nums para alinearse entre cards. */
  pairs: Array<[string, ReactNode]>
}

/**
 * Rejilla de pares de dato y valor dentro de un Card Body: la etiqueta a la izquierda en
 * color muted y el valor a la derecha. Es la pieza que el Card Body nombra para los
 * atributos de un registro.
 */
export const CardPairs = forwardRef<HTMLDListElement, PropsCardPairs>(function CardPairs({ pairs, ...resto }, ref) {
  return (
    <dl {...resto} ref={ref} className="ay-card__pairs">
      {pairs.map(([clave, valor], i) => (
        <Fragment key={`${clave}-${i}`}>
          <dt>{clave}</dt>
          <dd>{valor}</dd>
        </Fragment>
      ))}
    </dl>
  )
})

import { cloneElement, forwardRef, isValidElement } from 'react'
import type { ForwardedRef, HTMLAttributes, ReactElement, ReactNode, RefAttributes } from 'react'
import { cx } from '../../utiles.js'
import { hayHijos } from './_internos.js'
import { ListItem } from './ListItem.js'

export interface PropsList<T = unknown> extends Omit<HTMLAttributes<HTMLUListElement>, 'className'> {
  /** Elementos de la colección. Sin elementos —y sin List Item compuestos como hijos— se
   *  muestra `emptyState`, nunca una lista de altura cero. */
  items?: T[]
  /** Contenido de cada elemento. Si devuelve un List Item, ese `li` es el elemento; si
   *  devuelve otra cosa, se envuelve en uno. Sin esta función se pinta el elemento tal cual. */
  renderItem?: (item: T) => ReactNode
  /** Clave estable de cada elemento. Sin ella se usa el propio elemento si es texto, o su
   *  posición. */
  getKey?: (item: T) => string
  /** `ol` en lugar de `ul`, cuando el orden es significativo: la etiqueta comunica si la
   *  posición importa. */
  ordered?: boolean
  /** Separadores entre elementos, en CSS y no con `hr`, que rompería la estructura. */
  dividers?: boolean
  /** Nombre accesible de la lista. Con varias listas en la página, sin nombre no hay forma de
   *  saber cuál es la de unidades y cuál la de documentos. */
  label?: string
  /** Id del título visible que nombra la lista; alternativa a `label`. */
  labelledBy?: string
  /** Contenido cuando no hay elementos: un Empty State. Un texto se pinta como Empty State
   *  compacto. */
  emptyState?: ReactNode
  /** Muestra elementos de Skeleton con la misma altura, y marca la lista como ocupada. */
  loading?: boolean
}

const ESQUELETOS = [0, 1, 2, 3, 4]

function claveDe<T>(item: T, indice: number, getKey?: ((item: T) => string) | null): string {
  if (typeof getKey === 'function') return getKey(item)
  if (typeof item === 'string' || typeof item === 'number') return `${String(item)}-${indice}`
  return String(indice)
}

function pintarPorOmision(item: unknown): ReactNode {
  if (item === null || item === undefined || typeof item === 'boolean') return null
  if (typeof item === 'string' || typeof item === 'number' || isValidElement(item)) return item as ReactNode
  return String(item)
}

function ListInterna<T>(
  {
    items = [],
    renderItem,
    getKey,
    ordered = false,
    dividers = true,
    label,
    labelledBy,
    emptyState,
    loading = false,
    children,
    ...resto
  }: PropsList<T>,
  ref: ForwardedRef<HTMLUListElement>,
) {
  const Etiqueta = ordered ? 'ol' : 'ul'
  const clases = cx('ay-list', dividers && 'ay-list--dividers')

  if (loading) {
    return (
      <Etiqueta {...resto} ref={ref as ForwardedRef<HTMLOListElement & HTMLUListElement>} className={clases} aria-busy="true" aria-label={label} aria-labelledby={labelledBy}>
        {ESQUELETOS.map((i) => (
          <li key={i} className="ay-list__item">
            <span className="ay-skel ay-skel--text ay-list__skel" aria-hidden="true" />
          </li>
        ))}
      </Etiqueta>
    )
  }

  const compuesta = hayHijos(children)
  if (items.length === 0 && !compuesta) {
    if (emptyState === undefined || emptyState === null || emptyState === false) return null
    // Un texto suelto se pinta con el marcado de un Empty State compacto, anunciado como estado.
    if (typeof emptyState === 'string') {
      return (
        <div className="ay-empty ay-empty--compact" role="status">
          <p className="ay-empty__title">{emptyState}</p>
        </div>
      )
    }
    return <>{emptyState}</>
  }

  const pintar = typeof renderItem === 'function' ? renderItem : pintarPorOmision
  return (
    <Etiqueta
      {...resto}
      ref={ref as ForwardedRef<HTMLOListElement & HTMLUListElement>}
      className={clases}
      aria-label={label}
      aria-labelledby={labelledBy}
    >
      {items.map((item, i) => {
        const clave = claveDe(item, i, getKey)
        const contenido = pintar(item)
        // Un List Item ya es el `li`: envolverlo en otro rompería la estructura de la lista.
        if (isValidElement(contenido) && contenido.type === ListItem) {
          return cloneElement(contenido as ReactElement, { key: clave })
        }
        return (
          <li key={clave} className="ay-list__item">
            {contenido}
          </li>
        )
      })}
      {children}
    </Etiqueta>
  )
}

/**
 * Colección vertical de elementos que se leen por separado —documentos de un expediente,
 * actividad reciente— cuando no hay campos que comparar en columnas (eso es una Table).
 * Es una `ul` u `ol` real con nombre accesible, y las flechas no hacen nada: solo un Menu
 * o un Data Grid las capturan. Los elementos pueden venir de `items` o componerse como
 * hijos con List Item.
 */
export const List = forwardRef(ListInterna) as <T = unknown>(
  props: PropsList<T> & RefAttributes<HTMLUListElement | HTMLOListElement>,
) => ReactElement | null

import { forwardRef } from 'react'
import type { HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import { estaVacio } from './_internos.js'

export type TonoBadge = 'neutral' | 'success' | 'warning' | 'danger' | 'info'
export type TamanoBadge = 'sm' | 'md'

export interface PropsBadge extends Omit<HTMLAttributes<HTMLSpanElement>, 'className'> {
  /** Carga semántica. `success` para un estado favorable, `warning` para uno que requiere
   *  atención, `danger` para uno problemático, `info` para uno en curso y `neutral` sin
   *  carga. El mismo estado lleva el mismo tono en todo el producto. */
  tone?: TonoBadge
  /** Altura y padding. `sm` dentro de filas de tabla y junto a iconos; `md` en cabeceras y cards. */
  size?: TamanoBadge
  /** Punto de estado que refuerza el tono sin depender del color del texto. Es decorativo:
   *  el estado siempre va escrito. */
  dot?: boolean
  /** Variante numérica, sobre un icono o una pestaña. En `0` no se renderiza. La cifra va
   *  también en el nombre accesible del control que la lleva —«Notificaciones, 3 sin leer»—,
   *  y entonces este badge lleva `aria-hidden`. */
  count?: number
  /** Por encima del máximo muestra «99+», para no deformar la pastilla. */
  max?: number
}

/**
 * Etiqueta compacta que marca el estado o el recuento de un elemento, legible de un
 * vistazo dentro de una lista. No es interactiva ni tabulable: si necesita acción es un
 * Chip o un Button. Un estado desconocido se escribe «Sin estado», nunca una pastilla vacía.
 */
export const Badge = forwardRef<HTMLSpanElement, PropsBadge>(function Badge(
  { tone = 'neutral', size = 'md', dot = false, count, max = 99, children, ...resto },
  ref,
) {
  if (count === 0) return null
  const esRecuento = count !== undefined && count !== null
  const sinTexto = !esRecuento && estaVacio(children)
  return (
    <span
      {...resto}
      ref={ref}
      className={cx(
        'ay-badge',
        `ay-badge--${sinTexto ? 'neutral' : tone}`,
        `ay-badge--${size}`,
        esRecuento && 'ay-badge--count',
      )}
    >
      {dot && <span className="ay-badge__dot" aria-hidden="true" />}
      {esRecuento ? (count > max ? `${max}+` : count) : sinTexto ? 'Sin estado' : children}
    </span>
  )
})

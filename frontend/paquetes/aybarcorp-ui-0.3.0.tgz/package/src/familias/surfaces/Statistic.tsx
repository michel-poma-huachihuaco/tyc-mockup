import { forwardRef } from 'react'
import type { HTMLAttributes, Ref } from 'react'
import { cx } from '../../utiles.js'
import { IconoTendencia } from './_iconos.js'

export type TamanoStatistic = 'sm' | 'md' | 'lg'
export type IntencionStatistic = 'positive' | 'negative' | 'auto'
export type DireccionDelta = 'up' | 'down' | 'flat'

export interface PropsStatistic extends Omit<HTMLAttributes<HTMLElement>, 'className'> {
  /** Nombre de la cifra, sin el periodo: «Unidades disponibles». */
  label: string
  /** Valor ya formateado, o número a formatear con separador de miles. Una cifra muy larga
   *  se abrevia en pantalla y el valor exacto queda en el `title` y en el texto accesible.
   *  Sin dato, un guion conservando la etiqueta. */
  value: string | number
  /** Unidad o símbolo, integrado en el valor en tamaño menor. */
  unit?: string
  /** Variación respecto del periodo anterior, en porcentaje. Se escribe con signo explícito y
   *  con la dirección en texto, nunca solo con color. Sin periodo anterior —división por
   *  cero— no se muestra: no se pone 0%. */
  delta?: { value: number; direction: DireccionDelta }
  /** Periodo de comparación, en su propia línea: «frente al mes anterior». */
  period?: string
  /** Si subir es bueno o malo. En morosidad subir es negativo: `negative` invierte el tono,
   *  no el icono. */
  intent?: IntencionStatistic
  /** Escala del valor: `md` 3xl por defecto, `lg` 4xl para una cifra protagonista y `sm` xl
   *  para barras laterales. */
  size?: TamanoStatistic
  /** Muestra el Skeleton con la silueta de la etiqueta y del valor. */
  loading?: boolean
}

/** La forma de `delta`, para quien la construye aparte. */
export type DeltaStatistic = NonNullable<PropsStatistic['delta']>

const LOCALE = 'es-PE'
const UMBRAL_ABREVIADO = 1_000_000
const TEXTO_DIRECCION: Record<DireccionDelta, string> = { up: 'Sube', down: 'Baja', flat: 'Sin variación' }

function formatear(valor: string | number): { completo: string; corto: string | null } {
  if (valor === '' || valor === null || valor === undefined) return { completo: '—', corto: null }
  if (typeof valor !== 'number') return { completo: valor, corto: null }
  if (!Number.isFinite(valor)) return { completo: '—', corto: null }
  const completo = new Intl.NumberFormat(LOCALE).format(valor)
  const corto =
    Math.abs(valor) >= UMBRAL_ABREVIADO
      ? new Intl.NumberFormat(LOCALE, { notation: 'compact', maximumFractionDigits: 1 }).format(valor)
      : null
  return { completo, corto }
}

/**
 * Destaca una cifra clave con su etiqueta y, si procede, su variación respecto de un
 * periodo anterior. La etiqueta y el valor forman un par `dt`/`dd`, para que se anuncien
 * juntos; las cifras usan tabular-nums para alinearse en una rejilla. Más de cuatro juntas
 * dejan de destacar: eso es una tabla.
 */
export const Statistic = forwardRef<HTMLElement, PropsStatistic>(function Statistic(
  { label, value, unit, delta, period, intent = 'auto', size = 'md', loading = false, ...resto },
  ref,
) {
  if (loading) {
    return (
      <div {...resto} ref={ref as Ref<HTMLDivElement>} className={cx('ay-stat', `ay-stat--${size}`)} aria-busy="true">
        <span className="ay-visually-hidden">{label}</span>
        <span className="ay-skel ay-skel--text ay-stat__skel-label" aria-hidden="true" />
        <span className="ay-skel ay-skel--text ay-stat__skel-value" aria-hidden="true" />
      </div>
    )
  }

  const { completo, corto } = formatear(value)
  const sinDato = completo === '—'
  const deltaVisible = delta !== undefined && delta !== null && Number.isFinite(delta.value)

  // `intent` invierte el tono, no el icono: en morosidad, subir es malo.
  let tono: DireccionDelta = 'flat'
  if (deltaVisible && delta.direction !== 'flat') {
    const bueno = intent === 'negative' ? delta.direction === 'down' : delta.direction === 'up'
    tono = bueno ? 'up' : 'down'
  }
  const cifraDelta = deltaVisible
    ? `${delta.value > 0 ? '+' : ''}${new Intl.NumberFormat(LOCALE, { maximumFractionDigits: 1 }).format(delta.value)}%`
    : ''

  return (
    <dl {...resto} ref={ref as Ref<HTMLDListElement>} className={cx('ay-stat', `ay-stat--${size}`)}>
      <dt className="ay-stat__label">{label}</dt>
      <dd className="ay-stat__value" title={corto ? completo : undefined}>
        {corto ? (
          <>
            <span aria-hidden="true">{corto}</span>
            <span className="ay-visually-hidden">{completo}</span>
          </>
        ) : sinDato ? (
          <>
            <span aria-hidden="true">—</span>
            <span className="ay-visually-hidden">Sin dato</span>
          </>
        ) : (
          completo
        )}
        {unit && !sinDato && <span className="ay-stat__unit"> {unit}</span>}
      </dd>
      {deltaVisible && (
        <dd className={cx('ay-stat__delta', `ay-stat__delta--${tono}`)}>
          <IconoTendencia direccion={delta.direction} tamano={14} />
          <span className="ay-visually-hidden">{TEXTO_DIRECCION[delta.direction]} </span>
          {cifraDelta}
          {period && <span className="ay-stat__period"> {period}</span>}
        </dd>
      )}
    </dl>
  )
})

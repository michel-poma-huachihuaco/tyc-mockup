import { forwardRef } from 'react'
import type { HTMLAttributes } from 'react'
import { Tag } from './Tag.js'

export interface PropsTagList extends Omit<HTMLAttributes<HTMLUListElement>, 'className' | 'children'> {
  /** Etiquetas de la serie, de una taxonomía cerrada y no de texto libre. */
  tags: string[]
  /** Etiquetas visibles antes de contar el resto como «+N»: se reduce el número antes que
   *  truncar ninguna. */
  max?: number
}

/**
 * Serie de Tag en una lista real (`ul`), para que el lector anuncie cuántas etiquetas hay.
 * Muestra las primeras y cierra con «+N», con su significado escrito para el lector.
 * Sin etiquetas no se pinta: una lista vacía se anunciaría como «lista, 0 elementos».
 */
export const TagList = forwardRef<HTMLUListElement, PropsTagList>(function TagList({ tags, max = 3, ...resto }, ref) {
  if (tags.length === 0) return null
  const visibles = tags.slice(0, Math.max(0, max))
  const resto_ = tags.length - visibles.length
  return (
    <ul {...resto} ref={ref} className="ay-tags">
      {visibles.map((etiqueta, i) => (
        <li key={`${etiqueta}-${i}`}>
          <Tag>{etiqueta}</Tag>
        </li>
      ))}
      {resto_ > 0 && (
        <li>
          <Tag variant="outline">
            <span aria-hidden="true">+{resto_}</span>
            <span className="ay-visually-hidden">y {resto_} más</span>
          </Tag>
        </li>
      )}
    </ul>
  )
})

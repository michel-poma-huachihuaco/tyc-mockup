import { createContext, forwardRef, useMemo, useState } from 'react'
import type { ChangeEvent, HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'

export type VarianteCard = 'default' | 'elevated' | 'interactive' | 'selectable'
export type DisposicionCard = 'vertical' | 'horizontal'
/** El material de la card: superficie opaca o vidrio translúcido. */
export type SuperficieCard = 'solid' | 'glass'

/** Lo que la Card comparte con su Card Header: el destino de la card entera. */
export const ContextoCard = createContext<{ href?: string }>({})

export interface PropsCard extends Omit<HTMLAttributes<HTMLElement>, 'className' | 'onSelect'> {
  /** Comportamiento y elevación. `default` es borde subtle sin sombra; `elevated` añade
   *  shadow.md y se reserva a cards que flotan sobre otro contenido; `interactive` hace que
   *  toda la superficie navegue —con hover y foco visibles en la card entera—, y
   *  `selectable` marca la selección con borde accent a partir de un Checkbox o Radio real. */
  variant?: VarianteCard
  /** Disposición interna. `horizontal` pone la media a la izquierda con un ancho fijo y el
   *  contenido a la derecha, para listas densas. */
  layout?: DisposicionCard
  /** El material. `glass` deja ver desenfocado lo que hay detrás —una banda de marca, una
   *  foto, las capas de un Parallax— con la opacidad depth.glass-opacity, que es la medida
   *  para que el texto por defecto y el atenuado cumplan AA aun con el fondo contrario
   *  detrás; dentro, el texto tenue sube a atenuado. Con `data-depth="plano"`, transparencia
   *  reducida, colores forzados, al imprimir o sin `backdrop-filter` es la superficie opaca
   *  de siempre. Se combina con cualquier `variant`. */
  surface?: SuperficieCard
  /** Con `variant="interactive"`, destino de la card entera. El enlace envuelve el título de
   *  la Card Header —no la card— y se extiende con un pseudoelemento, para que el nombre
   *  accesible sea el título y no todo el bloque leído de corrido. */
  href?: string
  /** Estado seleccionado en la variante `selectable`; solo pinta el borde accent. El estado
   *  lo aporta el control real que va dentro. Por omisión `false` y no controlado: sin esta
   *  prop, la card sigue al Checkbox que contiene. */
  selected?: boolean
  /** Cambio de selección, en la variante `selectable`. Se dispara cuando cambia el Checkbox
   *  o el Radio que la card contiene, con su estado marcado. */
  onSelect?: (selected: boolean) => void
}

/**
 * Superficie que agrupa el contenido y las acciones de una misma entidad —una unidad, una
 * promoción, un expediente— para que se lea y se manipule como una unidad. Es un
 * `article` sin rol propio: el elemento interactivo real es el enlace del título o el
 * control que contiene. Se compone con Card Header, Card Body y Card Footer; en una
 * rejilla, las cards van en `ul`/`li` para que el lector anuncie cuántas hay.
 */
export const Card = forwardRef<HTMLElement, PropsCard>(function Card(
  { variant = 'default', layout = 'vertical', surface = 'solid', href, selected, onSelect, onChange, children, ...resto },
  ref,
) {
  const [seleccionInterna, setSeleccionInterna] = useState(false)
  const seleccionable = variant === 'selectable'
  const seleccionada = seleccionable && (selected ?? seleccionInterna)

  // La selección la decide el control real: el `change` del Checkbox o del Radio burbujea
  // hasta la card, que solo refleja su estado en el borde.
  const alCambiar = (evento: ChangeEvent<HTMLElement>) => {
    onChange?.(evento)
    if (!seleccionable) return
    const control = evento.target as HTMLInputElement
    if (control.tagName !== 'INPUT' || (control.type !== 'checkbox' && control.type !== 'radio')) return
    if (selected === undefined) setSeleccionInterna(control.checked)
    onSelect?.(control.checked)
  }

  const contexto = useMemo(() => ({ href: variant === 'interactive' ? href : undefined }), [variant, href])

  return (
    <article
      {...resto}
      ref={ref}
      onChange={alCambiar}
      className={cx(
        'ay-card',
        `ay-card--${variant}`,
        `ay-card--${layout}`,
        surface === 'glass' && 'ay-card--glass',
        seleccionada && 'is-selected',
      )}
      data-selected={seleccionada || undefined}
    >
      <ContextoCard.Provider value={contexto}>{children}</ContextoCard.Provider>
    </article>
  )
})

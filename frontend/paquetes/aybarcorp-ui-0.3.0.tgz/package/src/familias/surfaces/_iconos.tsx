/**
 * Glifos internos de la familia Surfaces. Son decorativos —siempre `aria-hidden`— y
 * toman el color del texto con `currentColor`, así que no declaran ningún color. El
 * tamaño va en los atributos `width`/`height` del SVG, como en el marcado canónico.
 */
import type { SVGProps } from 'react'

type PropsIcono = Omit<SVGProps<SVGSVGElement>, 'children'> & { tamano?: number }

function Glifo({ tamano = 16, ...resto }: PropsIcono & { children: SVGProps<SVGSVGElement>['children'] }) {
  return (
    <svg
      viewBox="0 0 24 24"
      width={tamano}
      height={tamano}
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
      focusable="false"
      aria-hidden="true"
      {...resto}
    />
  )
}

/** Aspa de retirar o cerrar. */
export function IconoCerrar(props: PropsIcono) {
  return (
    <Glifo {...props}>
      <path d="M18 6 6 18M6 6l12 12" />
    </Glifo>
  )
}

/** Dirección de una variación: ascendente, descendente o plana (guion). */
export function IconoTendencia({ direccion, ...props }: PropsIcono & { direccion: 'up' | 'down' | 'flat' }) {
  return (
    <Glifo {...props}>
      {direccion === 'up' && <path d="M12 19V5M5 12l7-7 7 7" />}
      {direccion === 'down' && <path d="M12 5v14M19 12l-7 7-7-7" />}
      {direccion === 'flat' && <path d="M5 12h14" />}
    </Glifo>
  )
}

/** Persona genérica: fallback final del Avatar cuando no hay imagen ni nombre. */
export function IconoPersona(props: PropsIcono) {
  return (
    <Glifo {...props}>
      <circle cx="12" cy="8" r="4" />
      <path d="M4 21a8 8 0 0 1 16 0" />
    </Glifo>
  )
}

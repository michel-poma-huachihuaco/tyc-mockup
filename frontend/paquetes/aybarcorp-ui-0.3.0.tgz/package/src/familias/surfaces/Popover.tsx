import {
  cloneElement,
  forwardRef,
  isValidElement,
  useCallback,
  useEffect,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  version,
} from 'react'
import type { FocusEvent, HTMLAttributes, MouseEvent, ReactElement, ReactNode, Ref } from 'react'
import { cx } from '../../utiles.js'
import { IconoCerrar } from './_iconos.js'
import {
  SELECTOR_ENFOCABLE,
  fueraDeVista,
  mostrarEnCapaSuperior,
  posicionarRespectoDe,
  refDeElemento,
  registrarPopoverAbierto,
  unirRefs,
} from './_internos.js'
import type { Lado, Posicion } from './_internos.js'

export type PosicionPopover = Lado
export type TamanoPopover = 'sm' | 'md' | 'lg'

const useEfectoDeDisposicion = typeof window === 'undefined' ? useEffect : useLayoutEffect
const VERSION_MAYOR = Number.parseInt(version, 10)

type PropsDisparador = {
  onClick?: (evento: MouseEvent<HTMLElement>) => void
  'aria-expanded'?: boolean
  'aria-controls'?: string
}

export interface PropsPopover extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'title'> {
  /** Elemento que abre el panel —un Button o un Icon Button—. Recibe `aria-expanded` y
   *  `aria-controls`. Un texto se pinta como botón secundario. */
  trigger: ReactNode
  /** Estado controlado. Sin esta prop el Popover guarda su propio estado y lo alterna el
   *  disparador. */
  open?: boolean
  /** Cambio de estado: al pulsar el disparador, con Escape, con un clic fuera, al salir con
   *  Tab y con el botón de cerrar. */
  onOpenChange?: (open: boolean) => void
  /** Posición preferida respecto del disparador; se voltea si no cabe y la flecha se recoloca. */
  placement?: PosicionPopover
  /** Ancho del panel, nunca mayor que el viewport menos el doble del margen:
   *  `sm` 16rem, `md` 22rem y `lg` 28rem. */
  size?: TamanoPopover
  /** Título de la cabecera, con botón de cerrar. Nombra el contenido, no la acción:
   *  «Asesores asignados». */
  title?: string
  /** Muestra la flecha que apunta al disparador. Es decorativa (`aria-hidden`). */
  arrow?: boolean
}

/**
 * Contenido enriquecido anclado a un disparador, sin bloquear el resto de la interfaz: el
 * detalle de un dato, un formulario breve, la lista tras un contador de excedente. No es
 * modal ni atrapa el foco: Tab sale de él cerrándolo, y Escape lo cierra y devuelve el foco
 * al disparador. Con controles dentro es un `role="dialog"` con nombre y el foco entra en
 * él; uno de solo lectura no roba el foco. Solo hay uno abierto a la vez.
 */
export const Popover = forwardRef<HTMLDivElement, PropsPopover>(function Popover(
  { trigger, open, onOpenChange, placement = 'bottom', size = 'md', title, arrow = true, id, style, children, onBlur, ...resto },
  ref,
) {
  const idAuto = useId()
  const idPanel = id ?? `ay-pop-${idAuto.replace(/[^a-zA-Z0-9_-]/g, '')}`
  const idTitulo = `${idPanel}-titulo`
  const [abiertoInterno, setAbiertoInterno] = useState(false)
  const abierto = open ?? abiertoInterno
  const [posicion, setPosicion] = useState<Posicion | null>(null)
  const [conControles, setConControles] = useState(false)
  const [desbordado, setDesbordado] = useState(false)
  const disparador = useRef<HTMLElement | null>(null)
  const panel = useRef<HTMLDivElement | null>(null)

  // Las props más recientes, para que los manejadores sean estables aunque el consumidor
  // pase una función nueva en cada render.
  const ultimas = useRef({ open, onOpenChange })
  useEfectoDeDisposicion(() => {
    ultimas.current = { open, onOpenChange }
  })
  const cambiar = useCallback((siguiente: boolean) => {
    if (ultimas.current.open === undefined) setAbiertoInterno(siguiente)
    ultimas.current.onOpenChange?.(siguiente)
  }, [])
  const anclaActual = () => disparador.current ?? (panel.current?.previousElementSibling as HTMLElement | null) ?? null
  const cerrarYDevolverFoco = useCallback(() => {
    const ancla = disparador.current ?? (panel.current?.previousElementSibling as HTMLElement | null)
    cambiar(false)
    // El panel deja de existir: sin devolución, el foco caería al documento.
    ancla?.focus()
  }, [cambiar])

  // Solo uno abierto a la vez.
  useEffect(() => {
    if (!abierto) return
    return registrarPopoverAbierto(() => cambiar(false))
  }, [abierto, cambiar])

  // Escape y clic fuera.
  useEffect(() => {
    if (!abierto) return
    const documento = panel.current?.ownerDocument ?? document
    const alPulsar = (evento: KeyboardEvent) => {
      if (evento.key !== 'Escape' || evento.defaultPrevented) return
      cerrarYDevolverFoco()
    }
    const alApuntar = (evento: globalThis.PointerEvent) => {
      const objetivo = evento.target as Node | null
      if (!objetivo) return
      if (panel.current?.contains(objetivo)) return
      // El disparador ya alterna con su propio clic: contarlo como «fuera» lo reabriría.
      if (anclaActual()?.contains(objetivo)) return
      cambiar(false)
    }
    documento.addEventListener('keydown', alPulsar)
    documento.addEventListener('pointerdown', alApuntar)
    return () => {
      documento.removeEventListener('keydown', alPulsar)
      documento.removeEventListener('pointerdown', alApuntar)
    }
  }, [abierto, cambiar, cerrarYDevolverFoco])

  // A la capa superior en cuanto se pinta, antes de enfocar dentro o de medir: un panel en
  // `popover` que aún no se muestra no tiene caja ni admite el foco. Al cerrar, el panel
  // sale del DOM y el navegador lo retira de la capa. Sin la API, `position: fixed`.
  useEfectoDeDisposicion(() => {
    if (abierto && panel.current) mostrarEnCapaSuperior(panel.current)
  }, [abierto])

  // Rol y foco al abrir: una sola vez por apertura.
  useEfectoDeDisposicion(() => {
    if (!abierto) {
      setConControles(false)
      return
    }
    const controles = Array.from(panel.current?.querySelectorAll<HTMLElement>(SELECTOR_ENFOCABLE) ?? []).filter(
      (control) => !control.closest('.ay-popover__header'),
    )
    setConControles(controles.length > 0)
    // El foco entra solo si hay algo que hacer dentro.
    controles[0]?.focus()
  }, [abierto])

  // Posición: al abrir, al redimensionar y al desplazar.
  useEfectoDeDisposicion(() => {
    if (!abierto) {
      setPosicion(null)
      setDesbordado(false)
      return
    }
    const nodo = panel.current
    if (!nodo) return
    const colocar = () => {
      const ancla = anclaActual()
      if (!ancla || !panel.current) return
      if (fueraDeVista(ancla)) return cambiar(false)
      // Más alto que el viewport: scroll interno (la clase lo activa) con la cabecera fija.
      setDesbordado(panel.current.scrollHeight > panel.current.clientHeight + 1)
      setPosicion(posicionarRespectoDe(ancla, panel.current, placement))
    }
    colocar()
    const vista = nodo.ownerDocument.defaultView
    vista?.addEventListener('resize', colocar)
    vista?.addEventListener('scroll', colocar, true)
    return () => {
      vista?.removeEventListener('resize', colocar)
      vista?.removeEventListener('scroll', colocar, true)
    }
  }, [abierto, placement, size, cambiar])

  // Tab fuera del panel lo cierra: un Popover no atrapa el foco.
  const alPerderFoco = (evento: FocusEvent<HTMLDivElement>) => {
    onBlur?.(evento)
    const destino = evento.relatedTarget as Node | null
    if (!destino) return
    if (panel.current?.contains(destino) || anclaActual()?.contains(destino)) return
    cambiar(false)
  }

  const propsDisparador = (propios: PropsDisparador): PropsDisparador => ({
    'aria-expanded': abierto,
    'aria-controls': abierto ? idPanel : undefined,
    onClick: (evento: MouseEvent<HTMLElement>) => {
      propios.onClick?.(evento)
      if (!evento.defaultPrevented) cambiar(!abierto)
    },
  })

  let elementoDisparador: ReactNode
  if (isValidElement<PropsDisparador>(trigger)) {
    elementoDisparador = cloneElement(trigger as ReactElement<PropsDisparador>, {
      ...propsDisparador(trigger.props),
      ref: unirRefs(refDeElemento<HTMLElement>(trigger, VERSION_MAYOR), disparador),
    } as PropsDisparador)
  } else {
    elementoDisparador = (
      <button
        type="button"
        ref={disparador as Ref<HTMLButtonElement>}
        className="ay-btn ay-btn--secondary"
        {...propsDisparador({})}
      >
        {trigger}
      </button>
    )
  }

  const flecha =
    posicion === null
      ? undefined
      : posicion.fisico === 'top' || posicion.fisico === 'bottom'
        ? { left: posicion.flecha }
        : { top: posicion.flecha }

  return (
    <>
      {elementoDisparador}
      {abierto && (
        <div
          {...resto}
          ref={unirRefs(ref, panel)}
          id={idPanel}
          className={cx('ay-popover', `ay-popover--${size}`, desbordado && 'ay-popover--scroll')}
          data-placement={posicion?.lado ?? placement}
          data-side={posicion?.fisico}
          // Rol dialog solo con controles; un panel informativo no lo necesita.
          role={conControles ? 'dialog' : undefined}
          aria-labelledby={conControles && title ? idTitulo : undefined}
          style={posicion ? { ...style, top: posicion.top, left: posicion.left } : style}
          onBlur={alPerderFoco}
        >
          {arrow && <div className="ay-popover__arrow" aria-hidden="true" style={flecha} />}
          {title && (
            <div className="ay-popover__header">
              <h3 className="ay-popover__title" id={idTitulo}>
                {title}
              </h3>
              <button
                type="button"
                className="ay-iconbtn ay-iconbtn--ghost ay-iconbtn--sm"
                aria-label="Cerrar"
                onClick={cerrarYDevolverFoco}
              >
                <IconoCerrar className="ay-iconbtn__glyph" tamano={16} />
              </button>
            </div>
          )}
          {children}
        </div>
      )}
    </>
  )
})

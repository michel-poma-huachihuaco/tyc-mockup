import { forwardRef, useEffect, useRef, useState } from 'react'
import type { HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import { IconoPersona } from './_iconos.js'
import { TEXTO_ESTADO_AVATAR, iniciales } from './_internos.js'

export type TamanoAvatar = 'xs' | 'sm' | 'md' | 'lg' | 'xl'
export type FormaAvatar = 'circle' | 'square'
export type EstadoAvatar = 'online' | 'busy' | 'away' | 'offline'

export interface PropsAvatar extends Omit<HTMLAttributes<HTMLSpanElement>, 'className'> {
  /** URL de la imagen. Si falla al cargar, el avatar degrada a iniciales sin dejar el icono
   *  roto del navegador. */
  src?: string
  /** Nombre completo, tal como se muestra en el resto de la interfaz. Genera las iniciales
   *  —primera letra del nombre y del primer apellido— y el nombre accesible. */
  name?: string
  /** Diámetro, igual en los dos ejes:
   *  `xs` 20px dentro de texto, `sm` 24px en filas de tabla, `md` 32px por defecto,
   *  `lg` 40px en cabeceras y `xl` 64px en la ficha de perfil. */
  size?: TamanoAvatar
  /** Forma. `square` se reserva a entidades y empresas, no a personas. */
  shape?: FormaAvatar
  /** Indicador de presencia en la esquina, con su propio texto accesible —«En línea»—:
   *  un punto de color no se anuncia. */
  status?: EstadoAvatar
  /** Cuando el nombre ya está escrito al lado: la imagen lleva `alt` vacío y no se añade
   *  texto oculto, para que la fila no se anuncie «María Rojas, María Rojas». */
  decorative?: boolean
}

/**
 * Representa a una persona o una entidad con su imagen, y degrada a iniciales o a un icono
 * genérico cuando la imagen no existe o no carga. No es interactivo: si abre un menú o un
 * perfil, el control real es un `button` o un enlace que lo envuelve.
 */
export const Avatar = forwardRef<HTMLSpanElement, PropsAvatar>(function Avatar(
  { src, name, size = 'md', shape = 'circle', status, decorative = false, ...resto },
  ref,
) {
  const [fallo, setFallo] = useState(false)
  const imagen = useRef<HTMLImageElement>(null)

  // Una imagen nueva merece un intento nuevo; y una que ya falló antes de que React
  // enganchara `onError` (render en servidor) se detecta al montar.
  useEffect(() => {
    setFallo(false)
    const nodo = imagen.current
    if (nodo && nodo.complete && nodo.naturalWidth === 0 && nodo.currentSrc) setFallo(true)
  }, [src])

  const conImagen = Boolean(src) && !fallo
  const letras = iniciales(name)

  return (
    <span {...resto} ref={ref} className={cx('ay-avatar', `ay-avatar--${size}`, `ay-avatar--${shape}`)}>
      {conImagen ? (
        <img ref={imagen} src={src} alt={decorative ? '' : (name ?? '')} onError={() => setFallo(true)} />
      ) : letras ? (
        <span className="ay-avatar__initials" aria-hidden="true">
          {letras}
        </span>
      ) : (
        <IconoPersona className="ay-avatar__icon" />
      )}
      {!conImagen && !decorative && name && <span className="ay-visually-hidden">{name}</span>}
      {status && (
        <span className={cx('ay-avatar__status', `is-${status}`)}>
          <span className="ay-visually-hidden">{TEXTO_ESTADO_AVATAR[status]}</span>
        </span>
      )}
    </span>
  )
})

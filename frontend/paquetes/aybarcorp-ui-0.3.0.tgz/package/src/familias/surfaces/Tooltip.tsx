import {
  cloneElement,
  forwardRef,
  isValidElement,
  useCallback,
  useEffect,
  useId,
  useLayoutEffect,
  useRef,
  useState,
  version,
} from 'react'
import type { FocusEvent, HTMLAttributes, PointerEvent, ReactElement } from 'react'
import { cx } from '../../utiles.js'
import {
  fueraDeVista,
  marcarCierreTooltip,
  mostrarEnCapaSuperior,
  ocultarDeCapaSuperior,
  posicionarRespectoDe,
  refDeElemento,
  tooltipRecienCerrado,
  unirRefs,
} from './_internos.js'
import type { Lado, Posicion } from './_internos.js'

export type PosicionTooltip = Lado

// En el servidor no hay disposición que medir; así no se avisa por usar useLayoutEffect.
const useEfectoDeDisposicion = typeof window === 'undefined' ? useEffect : useLayoutEffect
const VERSION_MAYOR = Number.parseInt(version, 10)

/** Margen para cruzar con el puntero el hueco entre el disparador y el tooltip. */
const TOLERANCIA_CIERRE = 120

type PropsDisparador = {
  onPointerEnter?: (evento: PointerEvent<HTMLElement>) => void
  onPointerLeave?: (evento: PointerEvent<HTMLElement>) => void
  onFocus?: (evento: FocusEvent<HTMLElement>) => void
  onBlur?: (evento: FocusEvent<HTMLElement>) => void
  'aria-describedby'?: string
}

export interface PropsTooltip extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'content' | 'children'> {
  /** Texto del tooltip: una frase corta, sin punto final y sin nodos interactivos —no se
   *  puede llegar a ellos sin que el tooltip se cierre—. Lo imprescindible para decidir va
   *  visible, no aquí. */
  content: string
  /** Disparador. Recibe los manejadores de puntero y foco y el id de descripción, y conserva
   *  su propio nombre accesible. Un texto suelto se envuelve en un `span` enfocable, para
   *  que el tooltip también exista para quien navega con teclado. */
  children: ReactElement
  /** Posición preferida respecto del disparador; se voltea si no cabe y se desplaza para no
   *  salir del viewport. */
  placement?: PosicionTooltip
  /** Retardo de apertura con puntero, en milisegundos. Con el foco de teclado aparece de
   *  inmediato, y al pasar de un disparador a otro no se repite. */
  delay?: number
  /** Usa `aria-labelledby` en lugar de `aria-describedby`: solo cuando el control no tiene
   *  otro nombre, porque sustituye el nombre en vez de ampliarlo. */
  asLabel?: boolean
  /** Muestra la flecha que apunta al disparador. */
  arrow?: boolean
}

/**
 * Descripción breve de un elemento al apuntarlo o enfocarlo, sin ocupar espacio
 * permanente. Aparece con el foco de teclado, Escape lo cierra sin mover el foco, y en
 * táctil —donde no hay hover— no se muestra: la información pasa a ser visible o a un
 * Popover. El texto está siempre en el DOM, oculto, para que la descripción exista aunque
 * el tooltip no se vea.
 */
export const Tooltip = forwardRef<HTMLDivElement, PropsTooltip>(function Tooltip(
  { content, children, placement = 'top', delay = 300, asLabel = false, arrow = true, id, style, onPointerEnter, onPointerLeave, ...resto },
  ref,
) {
  const idAuto = useId()
  const idTooltip = id ?? `ay-tip-${idAuto.replace(/[^a-zA-Z0-9_-]/g, '')}`
  const [abierto, setAbierto] = useState(false)
  const [posicion, setPosicion] = useState<Posicion | null>(null)
  const ancla = useRef<HTMLElement | null>(null)
  const panel = useRef<HTMLDivElement | null>(null)
  const temporizador = useRef<ReturnType<typeof setTimeout> | undefined>(undefined)

  const limpiar = () => clearTimeout(temporizador.current)
  const abrir = useCallback(
    (inmediato: boolean) => {
      clearTimeout(temporizador.current)
      if (inmediato || tooltipRecienCerrado(delay)) setAbierto(true)
      else temporizador.current = setTimeout(() => setAbierto(true), delay)
    },
    [delay],
  )
  const cerrar = useCallback(() => {
    clearTimeout(temporizador.current)
    setAbierto((antes) => {
      if (antes) marcarCierreTooltip()
      return false
    })
  }, [])
  const cerrarConTolerancia = () => {
    clearTimeout(temporizador.current)
    temporizador.current = setTimeout(cerrar, TOLERANCIA_CIERRE)
  }

  useEffect(() => limpiar, [])

  // Escape cierra sin mover el foco: el usuario sigue donde estaba.
  useEffect(() => {
    if (!abierto) return
    const documento = ancla.current?.ownerDocument ?? document
    const alPulsar = (evento: KeyboardEvent) => {
      if (evento.key === 'Escape') cerrar()
    }
    documento.addEventListener('keydown', alPulsar)
    return () => documento.removeEventListener('keydown', alPulsar)
  }, [abierto, cerrar])

  // Abierto, el panel sube a la capa superior antes de medirse: así no lo recorta ni lo
  // desplaza ningún ancestro. Sin la API sigue con su `position: fixed`.
  useEfectoDeDisposicion(() => {
    if (!abierto) {
      ocultarDeCapaSuperior(panel.current)
      setPosicion(null)
      return
    }
    if (panel.current) mostrarEnCapaSuperior(panel.current)
    const colocar = () => {
      if (!ancla.current || !panel.current) return
      if (fueraDeVista(ancla.current)) return cerrar()
      setPosicion(posicionarRespectoDe(ancla.current, panel.current, placement))
    }
    colocar()
    const vista = ancla.current?.ownerDocument.defaultView
    vista?.addEventListener('resize', colocar)
    vista?.addEventListener('scroll', colocar, true)
    return () => {
      vista?.removeEventListener('resize', colocar)
      vista?.removeEventListener('scroll', colocar, true)
    }
  }, [abierto, placement, content, cerrar])

  const manejadores = (propios: PropsDisparador) => ({
    onPointerEnter: (evento: PointerEvent<HTMLElement>) => {
      propios.onPointerEnter?.(evento)
      // En táctil no hay hover: el tooltip se suprime.
      if (evento.pointerType !== 'touch') abrir(false)
    },
    onPointerLeave: (evento: PointerEvent<HTMLElement>) => {
      propios.onPointerLeave?.(evento)
      cerrarConTolerancia()
    },
    onFocus: (evento: FocusEvent<HTMLElement>) => {
      propios.onFocus?.(evento)
      abrir(true)
    },
    onBlur: (evento: FocusEvent<HTMLElement>) => {
      propios.onBlur?.(evento)
      cerrar()
    },
  })

  const relacion = asLabel ? 'aria-labelledby' : 'aria-describedby'
  let disparador: ReactElement
  if (isValidElement<PropsDisparador>(children)) {
    const propios = children.props
    const descripcionPrevia = asLabel ? undefined : propios['aria-describedby']
    disparador = cloneElement(children, {
      ...manejadores(propios),
      [relacion]: [descripcionPrevia, idTooltip].filter(Boolean).join(' '),
      ref: unirRefs(refDeElemento<HTMLElement>(children, VERSION_MAYOR), ancla),
    } as PropsDisparador)
  } else {
    disparador = (
      <span ref={ancla} className="ay-tooltip__anchor" tabIndex={0} {...{ [relacion]: idTooltip }} {...manejadores({})}>
        {children}
      </span>
    )
  }

  const flecha =
    posicion === null
      ? undefined
      : posicion.fisico === 'top' || posicion.fisico === 'bottom'
        ? { left: posicion.flecha }
        : { top: posicion.flecha }

  return (
    <>
      {children !== undefined && children !== null && disparador}
      <div
        {...resto}
        ref={unirRefs(ref, panel)}
        id={idTooltip}
        role="tooltip"
        hidden={!abierto}
        className={cx('ay-tooltip', `ay-tooltip--${posicion?.lado ?? placement}`)}
        data-placement={posicion?.lado ?? placement}
        data-side={posicion?.fisico}
        style={posicion ? { ...style, top: posicion.top, left: posicion.left } : style}
        // Mientras el puntero está sobre el tooltip, sigue abierto.
        onPointerEnter={(evento) => {
          onPointerEnter?.(evento)
          limpiar()
        }}
        onPointerLeave={(evento) => {
          onPointerLeave?.(evento)
          cerrarConTolerancia()
        }}
      >
        {content}
        {arrow && <span className="ay-tooltip__arrow" aria-hidden="true" style={flecha} />}
      </div>
    </>
  )
})

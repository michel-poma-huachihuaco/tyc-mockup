/**
 * Mecánica de DOM compartida por la familia Overlays, sin React: la capa modal (foco que
 * entra, trampa de Tab, Escape, fondo inerte, scroll bloqueado y foco que vuelve), el
 * posicionamiento anclado de las superficies flotantes y la lectura de breakpoints.
 *
 * Es interna: no se exporta en el índice. `@aybarcorp/ui-angular` lleva una copia literal
 * del mismo archivo, porque los dos paquetes no dependen el uno del otro y la conducta
 * tiene que ser la misma en los dos.
 */

const SELECTOR_ENFOCABLE = [
  'a[href]',
  'area[href]',
  'button:not([disabled])',
  'input:not([disabled]):not([type="hidden"])',
  'select:not([disabled])',
  'textarea:not([disabled])',
  'iframe',
  'audio[controls]',
  'video[controls]',
  'summary',
  '[contenteditable]:not([contenteditable="false"])',
  '[tabindex]',
].join(',')

/**
 * Los elementos alcanzables con Tab dentro de `contenedor`, en orden de documento.
 * Se descarta lo deshabilitado, lo oculto con `hidden`, lo inerte y lo que lleva un
 * `tabindex` negativo: ninguno de esos recibe el foco con el teclado.
 */
export function enfocables(contenedor: ParentNode): HTMLElement[] {
  return Array.from(contenedor.querySelectorAll<HTMLElement>(SELECTOR_ENFOCABLE)).filter((el) => {
    const indice = el.getAttribute('tabindex')
    if (indice !== null && Number(indice) < 0) return false
    if (el.closest('[hidden], [inert]')) return false
    return !(el as HTMLButtonElement).disabled
  })
}

/** Enfoca sin desplazar la página: el foco que entra a una capa no debe mover el fondo. */
export function enfocar(el: HTMLElement | null | undefined): boolean {
  if (!el || !el.isConnected) return false
  el.focus({ preventScroll: true })
  return document.activeElement === el
}

// ── Capa modal ───────────────────────────────────────────────────────────────

export interface OpcionesCapa {
  /** Superficie que atrapa el foco y donde entra al abrir. */
  panel: HTMLElement
  /** Nodos que se quedan fuera del `inert` (el panel y, si hay, su velo). */
  nodos: HTMLElement[]
  /** Modal: fondo inerte, scroll bloqueado y Tab atrapado. No modal: nada de eso. */
  modal: boolean
  /** Se llama con Escape cuando esta capa es la de arriba. */
  alEscape: () => void
  /** Destino del foco al abrir; si devuelve nada, el primer enfocable y luego el panel. */
  focoInicial?: () => HTMLElement | null | undefined
}

interface Capa extends OpcionesCapa {
  previo: HTMLElement | null
}

/**
 * Pila de capas abiertas. Solo la de arriba atiende Escape y Tab: un diálogo abierto
 * sobre otro se cierra solo, y el de abajo no se entera.
 */
const pila: Capa[] = []

function alTeclado(evento: KeyboardEvent): void {
  const capa = pila[pila.length - 1]
  if (!capa) return
  const dentro = capa.panel.contains(document.activeElement)
  if (evento.key === 'Escape') {
    // Un menú o un desplegable abierto dentro de la capa ya consumió su Escape.
    if (evento.defaultPrevented) return
    // Una capa no modal solo responde si el foco está en ella: el resto de la página
    // sigue siendo utilizable y su Escape no le pertenece.
    if (!capa.modal && !dentro) return
    evento.preventDefault()
    capa.alEscape()
    return
  }
  // Una superficie flotante abierta desde la capa (un desplegable, un menú) gestiona su
  // propio Tab: se pinta en un portal, fuera del panel, y no hay que traer el foco de vuelta.
  const objetivo = evento.target instanceof Element ? evento.target : null
  if (evento.key === 'Tab' && capa.modal && !objetivo?.closest('[data-ay-flotante]')) {
    atraparTab(evento, capa.panel)
  }
}

function atraparTab(evento: KeyboardEvent, panel: HTMLElement): void {
  const lista = enfocables(panel)
  const activo = document.activeElement
  // Sin nada enfocable el Tab se quedaría suelto detrás del velo: el foco no se mueve.
  if (lista.length === 0) {
    evento.preventDefault()
    enfocar(panel)
    return
  }
  const primero = lista[0] as HTMLElement
  const ultimo = lista[lista.length - 1] as HTMLElement
  if (!panel.contains(activo)) {
    evento.preventDefault()
    enfocar(evento.shiftKey ? ultimo : primero)
    return
  }
  if (evento.shiftKey && (activo === primero || activo === panel)) {
    evento.preventDefault()
    enfocar(ultimo)
  } else if (!evento.shiftKey && activo === ultimo) {
    evento.preventDefault()
    enfocar(primero)
  }
}

const SIN_INERT = new Set(['SCRIPT', 'STYLE', 'TEMPLATE', 'LINK', 'META', 'NOSCRIPT'])

/**
 * Marca con `inert` todo lo que no es la capa: los hermanos de cada ancestro de los nodos
 * conservados, hasta `body`. Así sirve igual para una capa en un portal (hija de `body`)
 * que para una pintada en su sitio dentro de la aplicación.
 *
 * `inert` y no `aria-hidden`: este último la esconde del lector pero deja los controles
 * alcanzables con Tab, y entonces se tabula a ciegas por una página tapada.
 * Solo se retira lo que esta capa marcó: lo que ya era inerte sigue siéndolo.
 */
export function inertizarFondo(conservar: HTMLElement[]): () => void {
  const marcados: Element[] = []
  const conservados = new Set<Element>(conservar)
  const camino = new Set<Element>()
  for (const nodo of conservar) {
    let actual: Element | null = nodo.parentElement
    while (actual && actual !== document.body) {
      camino.add(actual)
      actual = actual.parentElement
    }
  }
  const recorrer = (padre: Element): void => {
    for (const hijo of Array.from(padre.children)) {
      if (conservados.has(hijo)) continue
      if (camino.has(hijo)) {
        recorrer(hijo)
        continue
      }
      if (hijo.hasAttribute('inert') || SIN_INERT.has(hijo.tagName)) continue
      hijo.setAttribute('inert', '')
      marcados.push(hijo)
    }
  }
  recorrer(document.body)
  return () => {
    for (const el of marcados) el.removeAttribute('inert')
  }
}

let bloqueos = 0
let estiloPrevio: { overflow: string; relleno: string } | null = null

/**
 * Bloquea el scroll del documento compensando el ancho de la barra: si la página salta
 * al abrir, el contenido se desplaza bajo el puntero y quien usa magnificador pierde el
 * punto que estaba mirando. Admite capas apiladas: se libera con la última.
 */
export function bloquearScroll(): () => void {
  const cuerpo = document.body
  if (bloqueos === 0) {
    const anchoUtil = document.documentElement.clientWidth
    const barra = anchoUtil > 0 ? Math.max(0, window.innerWidth - anchoUtil) : 0
    estiloPrevio = { overflow: cuerpo.style.overflow, relleno: cuerpo.style.paddingInlineEnd }
    if (barra > 0) {
      const actual = parseFloat(getComputedStyle(cuerpo).paddingInlineEnd) || 0
      cuerpo.style.paddingInlineEnd = `${actual + barra}px`
    }
    cuerpo.style.overflow = 'hidden'
  }
  bloqueos += 1
  let liberado = false
  return () => {
    if (liberado) return
    liberado = true
    bloqueos -= 1
    if (bloqueos === 0 && estiloPrevio) {
      cuerpo.style.overflow = estiloPrevio.overflow
      cuerpo.style.paddingInlineEnd = estiloPrevio.relleno
      estiloPrevio = null
    }
  }
}

/**
 * Abre una capa: guarda el disparador, mete el foco, y si es modal inertiza el fondo y
 * bloquea el scroll. Devuelve la función que la cierra y devuelve el foco al disparador,
 * en ese orden: un elemento inerte no puede recibir el foco.
 */
export function activarCapa(opciones: OpcionesCapa): () => void {
  const activo = document.activeElement
  const capa: Capa = { ...opciones, previo: activo instanceof HTMLElement ? activo : null }
  pila.push(capa)
  if (pila.length === 1) document.addEventListener('keydown', alTeclado)
  const liberarInert = opciones.modal ? inertizarFondo(opciones.nodos) : () => {}
  const liberarScroll = opciones.modal ? bloquearScroll() : () => {}

  const destino = opciones.focoInicial?.() ?? enfocables(opciones.panel)[0] ?? opciones.panel
  enfocar(destino)

  let liberada = false
  return () => {
    if (liberada) return
    liberada = true
    const indice = pila.indexOf(capa)
    if (indice >= 0) pila.splice(indice, 1)
    if (pila.length === 0) document.removeEventListener('keydown', alTeclado)
    liberarInert()
    liberarScroll()
    // Al disparador, y no al inicio del documento: si no, hay que rehacer con el teclado
    // todo el camino hasta la fila en la que se estaba trabajando.
    const foco = document.activeElement
    const focoPerdido = !foco || foco === document.body || !foco.isConnected || opciones.panel.contains(foco)
    if (focoPerdido || opciones.modal) enfocar(capa.previo)
  }
}

// ── Posicionamiento anclado ──────────────────────────────────────────────────

/**
 * Área útil de la ventana: ancho y alto sin las barras de scroll. `innerWidth` las
 * incluye, y un menú pegado al borde derecho quedaba encima de la barra vertical y daba
 * scroll horizontal a la página. Sin caja todavía (`clientWidth` 0), `innerWidth`.
 * Es la misma función que `areaVisible` de `utiles.ts` en @aybarcorp/ui; aquí va copiada
 * porque este archivo es copia literal del de @aybarcorp/ui-angular y no importa nada.
 */
export function areaVisible(documento: Document = document): { ancho: number; alto: number } {
  const raiz = documento.documentElement
  const vista = documento.defaultView
  return {
    ancho: raiz.clientWidth || vista?.innerWidth || 0,
    alto: raiz.clientHeight || vista?.innerHeight || 0,
  }
}

/** Convierte el valor de un token de espacio, en rem o en píxeles, a píxeles. */
export function aPixeles(valor: string): number {
  const numero = parseFloat(valor)
  if (Number.isNaN(numero)) return 0
  if (valor.trim().endsWith('rem')) {
    return numero * (parseFloat(getComputedStyle(document.documentElement).fontSize) || 16)
  }
  return numero
}

export type Colocacion = 'bottom' | 'top'
export type Alineacion = 'start' | 'end'

export interface Posicion {
  x: number
  y: number
  colocacion: Colocacion
  alineacion: Alineacion
}

/**
 * Coloca una superficie junto a su ancla con volteo: si no cabe en la colocación pedida
 * y sí en la opuesta, cambia de lado; nunca se sale del área útil en horizontal, y si no
 * cabe ni arriba ni abajo, la altura se recorta dentro de ella: tapar parte del ancla es
 * mejor que dejar el final del menú fuera de la ventana.
 */
export function calcularPosicion(
  ancla: DOMRect,
  superficie: { width: number; height: number },
  colocacion: Colocacion,
  alineacion: Alineacion,
  separacion: number,
): Posicion {
  const { ancho, alto } = areaVisible()
  let col = colocacion
  const cabeAbajo = ancla.bottom + separacion + superficie.height <= alto
  const cabeArriba = ancla.top - separacion - superficie.height >= 0
  if (col === 'bottom' && !cabeAbajo && cabeArriba) col = 'top'
  else if (col === 'top' && !cabeArriba && cabeAbajo) col = 'bottom'

  let ali = alineacion
  const cabeAlInicio = ancla.left + superficie.width <= ancho
  const cabeAlFinal = ancla.right - superficie.width >= 0
  if (ali === 'start' && !cabeAlInicio && cabeAlFinal) ali = 'end'
  else if (ali === 'end' && !cabeAlFinal && cabeAlInicio) ali = 'start'

  const xBruta = ali === 'start' ? ancla.left : ancla.right - superficie.width
  const x = Math.max(0, Math.min(xBruta, ancho - superficie.width))
  const yBruta = col === 'bottom' ? ancla.bottom + separacion : ancla.top - separacion - superficie.height
  const y = cabeAbajo || cabeArriba ? yBruta : Math.min(yBruta, alto - superficie.height)
  return { x, y: Math.max(0, y), colocacion: col, alineacion: ali }
}

/**
 * Coloca una superficie en un punto (el del puntero en un menú contextual) volteándola
 * en los dos ejes cuando no cabe abajo o a la derecha.
 */
export function posicionEnPunto(
  punto: { x: number; y: number },
  superficie: { width: number; height: number },
): { x: number; y: number } {
  const { ancho, alto } = areaVisible()
  let x = punto.x
  let y = punto.y
  if (x + superficie.width > ancho) x = Math.max(0, x - superficie.width)
  if (y + superficie.height > alto) y = Math.max(0, y - superficie.height)
  return { x, y }
}

/** Separación entre el ancla y la superficie: el token `space-1`, en píxeles. */
export function separacionDeToken(): number {
  const valor = getComputedStyle(document.documentElement).getPropertyValue('--aybar-space-1')
  return aPixeles(valor)
}

/** Verdadero si el ancla vive dentro de una capa modal: la superficie debe ir por encima. */
export function dentroDeCapaModal(el: Element | null | undefined): boolean {
  return Boolean(el?.closest('[aria-modal="true"]'))
}

// ── Breakpoints ──────────────────────────────────────────────────────────────

/**
 * Escucha si el viewport está por debajo del breakpoint `--aybar-breakpoint-<punto>`.
 *
 * Por qué en JS y no con `@media` en la hoja: una media query no admite `var()`, y la
 * hoja no puede llevar el valor literal sin romper la regla de tokens. Aquí el valor sale
 * del token en tiempo de ejecución y la hoja reacciona a `data-compacto`.
 */
export function escucharPantallaCompacta(
  punto: 'sm' | 'md' | 'lg',
  alCambiar: (compacta: boolean) => void,
): () => void {
  if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') return () => {}
  const valor = getComputedStyle(document.documentElement)
    .getPropertyValue(`--aybar-breakpoint-${punto}`)
    .trim()
  if (!valor) return () => {}
  const consulta = window.matchMedia(`(max-width: ${valor})`)
  const avisar = (): void => alCambiar(consulta.matches)
  avisar()
  consulta.addEventListener('change', avisar)
  return () => consulta.removeEventListener('change', avisar)
}

/** Sin puntero fino que pase por encima (táctil): ahí no hay clic derecho. */
export function esTactil(): boolean {
  return typeof window !== 'undefined' && typeof window.matchMedia === 'function'
    ? window.matchMedia('(hover: none)').matches
    : false
}

// ── Texto ────────────────────────────────────────────────────────────────────

/** Minúsculas y sin tildes, para que «É» de «Exportar» se encuentre con la tecla «e». */
export function normalizar(texto: string): string {
  return texto.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase()
}

/**
 * El siguiente enfocable de la página después de `desde` (o antes, con `atras`),
 * saltando lo que esté dentro de `excluir`. Sirve para que Tab desde una superficie en un
 * portal continúe donde estaría si la superficie estuviera junto a su disparador.
 */
export function enfocableVecino(desde: HTMLElement, atras: boolean, excluir?: HTMLElement | null): HTMLElement | null {
  const todos = enfocables(document.body).filter((el) => !excluir?.contains(el))
  const indice = todos.indexOf(desde)
  if (indice < 0) return null
  return todos[atras ? indice - 1 : indice + 1] ?? null
}

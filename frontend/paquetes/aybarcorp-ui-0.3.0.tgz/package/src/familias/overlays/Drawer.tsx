import { forwardRef, useEffect, useId, useRef } from 'react'
import type { HTMLAttributes, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { activarCapa } from './_dom.js'
import { IconoCerrar } from './_iconos.js'
import { enCapa, useRefsCombinadas, useUltimo } from './_internos.js'

export type LadoDrawer = 'start' | 'end' | 'bottom'
export type TamanoDrawer = 'sm' | 'md' | 'lg'

export interface PropsDrawer extends Omit<HTMLAttributes<HTMLElement>, 'className' | 'title'> {
  /** Visibilidad controlada. Cerrado, el panel está fuera del viewport y del DOM. */
  open?: boolean
  /** Cambio de visibilidad: lo piden la X, Escape y, en la variante modal, el clic en el
   *  scrim. Con cambios sin guardar, quien consume pide confirmación antes de cerrar. */
  onOpenChange: (open: boolean) => void
  /** Título; es el nombre accesible. Nombra el contenido —«Filtros», «Unidad 402»— y,
   *  si el panel muestra un registro, es su identificador. */
  title: string
  /** Borde de anclaje: `end` para detalle y filtros, `start` para navegación en
   *  pantallas medianas, `bottom` en móvil, donde equivale a Bottom Sheet. */
  side?: LadoDrawer
  /** Anchura del panel en los lados `start` y `end`. */
  size?: TamanoDrawer
  /** Con scrim, foco atrapado y fondo inerte. En `false` el panel acompaña a la vista:
   *  sin scrim, sin trampa de foco y se puede tabular de vuelta a la lista. */
  modal?: boolean
  /** Acciones del pie, ancladas al borde inferior del panel —«Aplicar filtros»,
   *  «Limpiar»—. */
  footer?: ReactNode
}

/**
 * Panel que se desliza desde un borde con contenido secundario, sin abandonar la vista.
 * Modal por defecto (scrim, trampa de foco, fondo inerte y scroll bloqueado); en la
 * variante no modal el resto de la página sigue siendo utilizable y un cambio de título
 * se anuncia sin mover el foco. Al cerrar, el foco vuelve al disparador.
 */
export const Drawer = forwardRef<HTMLElement, PropsDrawer>(function Drawer(
  { open = false, onOpenChange, title, side = 'end', size = 'md', modal = true, footer, children, ...resto },
  ref,
) {
  const id = useId()
  const idTitulo = `${id}-titulo`
  const panel = useRef<HTMLElement | null>(null)
  const velo = useRef<HTMLDivElement | null>(null)
  const refPanel = useRefsCombinadas(ref, panel)
  const ultimo = useUltimo(onOpenChange)

  useEffect(() => {
    const superficie = panel.current
    if (!open || !superficie) return
    return activarCapa({
      panel: superficie,
      nodos: [velo.current, superficie].filter((n): n is HTMLElement => n !== null),
      modal,
      alEscape: () => ultimo.current?.(false),
    })
  }, [open, modal, ultimo])

  if (!open) return null
  const cerrar = (): void => onOpenChange?.(false)

  return enCapa(
    <>
      {modal ? <div ref={velo} className="ay-scrim" aria-hidden="true" onClick={cerrar} /> : null}
      <aside
        {...resto}
        ref={refPanel}
        className={cx('ay-drawer', `ay-drawer--${side}`, `ay-drawer--${size}`)}
        role="dialog"
        aria-modal={modal ? true : undefined}
        aria-labelledby={idTitulo}
        tabIndex={-1}
      >
        <header className="ay-drawer__header">
          <h2 className="ay-drawer__title" id={idTitulo}>
            {title}
          </h2>
          <button
            type="button"
            className="ay-iconbtn ay-iconbtn--ghost"
            aria-label={`Cerrar ${title.toLowerCase()}`}
            onClick={cerrar}
          >
            <IconoCerrar />
          </button>
        </header>
        <div className="ay-drawer__body">{children}</div>
        {footer ? <footer className="ay-drawer__footer">{footer}</footer> : null}
        {modal ? null : (
          // No modal: al elegir otra fila el panel cambia de registro sin cerrarse, y el
          // cambio se anuncia sin arrastrar el foco fuera de la lista.
          <p className="ay-visualmente-oculto" aria-live="polite">
            {`Mostrando ${title}`}
          </p>
        )}
      </aside>
    </>,
  )
})

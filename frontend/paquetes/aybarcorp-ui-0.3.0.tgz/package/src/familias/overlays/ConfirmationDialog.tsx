import { forwardRef, useEffect, useId, useRef, useState } from 'react'
import type { HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import { activarCapa } from './_dom.js'
import { IconoAlerta } from './_iconos.js'
import { enCapa, usePantallaCompacta, useRefsCombinadas, useUltimo } from './_internos.js'

export type TonoConfirmationDialog = 'danger' | 'neutral'

export interface PropsConfirmationDialog
  extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'title'> {
  /** Estado controlado. Cerrado, el diálogo no está en el DOM. */
  open?: boolean
  /** Cambio de estado. Cancelar, Escape y el clic fuera lo piden con `false`; cerrar
   *  tras confirmar con éxito también es de quien consume, porque si la acción falla el
   *  diálogo tiene que seguir abierto con el error a la vista. */
  onOpenChange: (open: boolean) => void
  /** La pregunta, con el objeto nombrado: «¿Eliminar el contrato 118?». Obligatorio;
   *  nunca «¿Estás seguro?», que no informa de nada. */
  title: string
  /** La consecuencia de confirmar y si es reversible. Obligatoria: va en
   *  `aria-describedby`, porque el título solo pregunta y el cuerpo explica qué pasa. */
  description: string
  /** Etiqueta de confirmar: el verbo de la acción con su objeto —«Eliminar el
   *  contrato»—, no «Aceptar», para que fuera de contexto siga diciendo qué hace. */
  confirmLabel: string
  /** Etiqueta de la salida segura. Recibe el foco al abrir: Enter por reflejo no
   *  destruye nada. En la variante de cambios sin guardar es «Seguir editando». */
  cancelLabel?: string
  /** Tono de confirmar: `danger` para lo destructivo (con icono de aviso), `neutral`
   *  para lo costoso pero no destructivo, que confirma en primary. */
  tone?: TonoConfirmationDialog
  /** Texto que hay que escribir para confirmar, en las acciones muy destructivas.
   *  Confirmar queda deshabilitado hasta que coincide, y el motivo está escrito. */
  confirmPhrase?: string
  /** Ejecuta la acción. Si devuelve una promesa, el diálogo queda ocupado hasta que se
   *  resuelve: confirmar muestra su carga y no se puede cerrar a mitad. */
  onConfirm: () => void | Promise<void>
  /** Acción en curso: confirmar en carga, cancelar deshabilitado, y Escape y el clic
   *  fuera bloqueados. */
  loading?: boolean
}

/**
 * Pide confirmación antes de una acción costosa o irreversible. `role="alertdialog"`
 * para que el lector anuncie el cuerpo al abrir; el foco inicial va a la acción segura y
 * Escape cancela siempre. El hijo opcional se pinta en el cuerpo, que es donde va el
 * Alert cuando la confirmación falla.
 */
export const ConfirmationDialog = forwardRef<HTMLDivElement, PropsConfirmationDialog>(
  function ConfirmationDialog(
    {
      open = false,
      onOpenChange,
      title,
      description,
      confirmLabel,
      cancelLabel = 'Cancelar',
      tone = 'danger',
      confirmPhrase,
      onConfirm,
      loading = false,
      children,
      ...resto
    },
    ref,
  ) {
    const id = useId()
    const idTitulo = `${id}-title`
    const idDescripcion = `${id}-desc`
    const idCampo = `${id}-frase`
    const idMotivo = `${id}-motivo`
    const panel = useRef<HTMLDivElement | null>(null)
    const velo = useRef<HTMLDivElement | null>(null)
    const cancelar = useRef<HTMLButtonElement | null>(null)
    const refPanel = useRefsCombinadas(ref, panel)
    const [escrito, setEscrito] = useState('')
    const [pendiente, setPendiente] = useState(false)
    const montado = useRef(true)
    const compacta = usePantallaCompacta('sm', open)
    const ocupado = loading || pendiente
    const bloqueado = Boolean(confirmPhrase) && escrito.trim() !== confirmPhrase
    const ultimo = useUltimo({ onOpenChange, ocupado })

    useEffect(() => {
      montado.current = true
      return () => {
        montado.current = false
      }
    }, [])

    // Cada apertura empieza con el campo vacío: lo escrito para otro registro no vale.
    useEffect(() => {
      if (!open) setEscrito('')
    }, [open])

    useEffect(() => {
      const superficie = panel.current
      if (!open || !superficie) return
      return activarCapa({
        panel: superficie,
        nodos: [velo.current, superficie].filter((n): n is HTMLDivElement => n !== null),
        modal: true,
        // Escape cancela siempre, salvo a mitad de una acción lenta.
        alEscape: () => {
          if (!ultimo.current.ocupado) ultimo.current.onOpenChange?.(false)
        },
        focoInicial: () => cancelar.current,
      })
    }, [open, ultimo])

    if (!open) return null

    const confirmar = (): void => {
      if (bloqueado || ocupado) return
      const resultado = onConfirm?.()
      if (resultado && typeof (resultado as Promise<void>).then === 'function') {
        setPendiente(true)
        const terminar = (): void => {
          if (montado.current) setPendiente(false)
        }
        ;(resultado as Promise<void>).then(terminar, terminar)
      }
    }

    return enCapa(
      <>
        <div
          ref={velo}
          className="ay-scrim"
          aria-hidden="true"
          onClick={() => {
            if (!ocupado) onOpenChange?.(false)
          }}
        />
        <div
          {...resto}
          ref={refPanel}
          className="ay-confirm"
          role="alertdialog"
          aria-modal="true"
          aria-labelledby={idTitulo}
          aria-describedby={idDescripcion}
          aria-busy={ocupado || undefined}
          data-compacto={compacta ? '' : undefined}
        >
          <div className="ay-confirm__head">
            {tone === 'danger' ? <IconoAlerta /> : null}
            <h2 className="ay-confirm__title" id={idTitulo}>
              {title}
            </h2>
          </div>
          <p className="ay-confirm__desc" id={idDescripcion}>
            {description}
          </p>
          {children}
          {confirmPhrase ? (
            // Marcado canónico de Input (familia Form Controls), sin importarlo: etiqueta
            // real y el motivo del bloqueo escrito, no un botón apagado sin explicación.
            <div className="ay-field">
              <label className="ay-label" htmlFor={idCampo}>
                {`Escribe «${confirmPhrase}» para confirmar`}
              </label>
              <input
                className="ay-input ay-input--md"
                id={idCampo}
                type="text"
                autoComplete="off"
                spellCheck={false}
                value={escrito}
                aria-describedby={idMotivo}
                disabled={ocupado}
                onChange={(evento) => setEscrito(evento.target.value)}
                onKeyDown={(evento) => {
                  if (evento.key === 'Enter') {
                    evento.preventDefault()
                    confirmar()
                  }
                }}
              />
              <p className="ay-help" id={idMotivo}>
                {bloqueado
                  ? `«${confirmLabel}» se habilita cuando escribas «${confirmPhrase}» tal cual.`
                  : `Coincide: ya puedes usar «${confirmLabel}».`}
              </p>
            </div>
          ) : null}
          <div className="ay-confirm__actions">
            <button
              ref={cancelar}
              type="button"
              className="ay-btn ay-btn--secondary"
              disabled={ocupado}
              onClick={() => onOpenChange?.(false)}
            >
              {cancelLabel}
            </button>
            <button
              type="button"
              className={cx('ay-btn', tone === 'danger' ? 'ay-btn--danger' : 'ay-btn--primary')}
              disabled={bloqueado || ocupado}
              aria-busy={ocupado || undefined}
              onClick={confirmar}
            >
              {confirmLabel}
            </button>
          </div>
        </div>
      </>,
    )
  },
)

import { isValidElement, useEffect, useId, useRef, useState } from 'react'
import type { CSSProperties, HTMLAttributes, KeyboardEvent, ReactElement } from 'react'
import { cx } from '../../utiles.js'
import { mostrarEnCapaSuperior, ocultarDeCapaSuperior } from '../surfaces/_capa.js'
import {
  calcularPosicion,
  dentroDeCapaModal,
  enfocables,
  enfocar,
  separacionDeToken,
} from './_dom.js'
import type { Posicion } from './_dom.js'
import {
  clonarDisparador,
  enCapa,
  registrarUnicoAbierto,
  useControlable,
  useEfectoDeLayout,
  useUltimo,
} from './_internos.js'

export type AlineacionDropdown = 'start' | 'end'
export type ColocacionDropdown = 'bottom' | 'top'

export interface PropsDropdown extends Omit<HTMLAttributes<HTMLDivElement>, 'className'> {
  /** Disparador, un Button o un Icon Button. Recibe `aria-expanded` y `aria-controls`, y
   *  nada más: Dropdown no impone rol al contenido. */
  trigger: ReactElement
  /** Estado controlado. Sin él, el desplegable lleva su propio estado. Cerrado, la
   *  superficie no está en el DOM. */
  open?: boolean
  /** Cambio de estado: lo piden el disparador, el clic fuera, Escape, salir con Tab y
   *  el scroll de la página. */
  onOpenChange?: (open: boolean) => void
  /** Alineación con el disparador: `end` para disparadores a la derecha. */
  align?: AlineacionDropdown
  /** Posición preferida; si no cabe, se voltea. */
  placement?: ColocacionDropdown
  /** Iguala el ancho de la superficie al del disparador, como en un selector. */
  matchTriggerWidth?: boolean
  /** Altura máxima antes del scroll interno, como valor CSS (por ejemplo, un `var()` de
   *  token). El disparador nunca se desplaza. */
  maxHeight?: string
}

/**
 * Superficie flotante anclada a un disparador, sin semántica de menú ni de diálogo: un
 * panel de filtros, un calendario, ayuda contextual. Se pinta en un portal con volteo
 * automático; el foco entra si hay controles y se queda quieto si es informativa; Escape
 * cierra y devuelve el foco al disparador; Tab sale y cierra. Solo uno abierto a la vez.
 */
export function Dropdown({
  trigger,
  open,
  onOpenChange,
  align = 'start',
  placement = 'bottom',
  matchTriggerWidth = false,
  maxHeight,
  children,
  id,
  style,
  onKeyDown,
  ...resto
}: PropsDropdown) {
  const base = useId()
  const idSuperficie = id ?? `${base}-superficie`
  const idPropio = isValidElement(trigger) ? (trigger.props as { id?: string }).id : undefined
  const idDisparador = idPropio ?? `${base}-disparador`
  const [abierto, cambiar] = useControlable(open, false, onOpenChange)
  const [posicion, setPosicion] = useState<Posicion | null>(null)
  const [anchoAncla, setAnchoAncla] = useState<number | null>(null)
  const [enModal, setEnModal] = useState(false)
  const disparador = useRef<HTMLElement | null>(null)
  const superficie = useRef<HTMLDivElement | null>(null)
  const ultimo = useUltimo(cambiar)

  const cerrar = (devolverFoco: boolean): void => {
    cambiar(false)
    if (devolverFoco) enfocar(disparador.current)
  }

  // A la capa superior antes de medir y de mover el foco dentro: un `[popover]` que aún no
  // se muestra no tiene caja ni admite el foco. Sin la API sigue con su `position: fixed`.
  useEfectoDeLayout(() => {
    const propia = superficie.current
    if (!abierto || !propia) return
    mostrarEnCapaSuperior(propia)
    return () => ocultarDeCapaSuperior(propia)
  }, [abierto])

  // Posición con volteo y, si se pide, el ancho del disparador.
  useEfectoDeLayout(() => {
    if (!abierto) return
    const ancla = disparador.current
    const propia = superficie.current
    if (!ancla || !propia) return
    const rect = ancla.getBoundingClientRect()
    setEnModal(dentroDeCapaModal(ancla))
    setAnchoAncla(matchTriggerWidth ? rect.width : null)
    setPosicion(calcularPosicion(rect, propia.getBoundingClientRect(), placement, align, separacionDeToken()))
  }, [abierto, placement, align, matchTriggerWidth])

  // El foco entra si hay controles; si la superficie es informativa, se queda quieto.
  useEfectoDeLayout(() => {
    if (!abierto || !superficie.current) return
    const primero = enfocables(superficie.current)[0]
    if (primero) enfocar(primero)
  }, [abierto])

  useEffect(() => {
    if (!abierto) return
    const fuera = (nodo: EventTarget | null): boolean =>
      !(nodo instanceof Node) ||
      (!superficie.current?.contains(nodo) && !disparador.current?.contains(nodo))
    const alPulsar = (evento: PointerEvent): void => {
      if (fuera(evento.target)) ultimo.current(false)
    }
    // Escape en captura: un desplegable dentro de un diálogo se cierra él solo, y el
    // diálogo ve el evento ya atendido.
    const alTeclado = (evento: globalThis.KeyboardEvent): void => {
      if (evento.key !== 'Escape' || evento.defaultPrevented) return
      evento.preventDefault()
      ultimo.current(false)
      enfocar(disparador.current)
    }
    // El scroll de la página cierra: mejor que quedar flotando lejos del disparador.
    const alDesplazar = (evento: Event): void => {
      if (evento.target instanceof Node && superficie.current?.contains(evento.target)) return
      ultimo.current(false)
    }
    // El foco que se va a otra parte de la página cierra: Tab sale y cierra.
    const alEnfocar = (evento: FocusEvent): void => {
      if (fuera(evento.target)) ultimo.current(false)
    }
    const baja = registrarUnicoAbierto(() => ultimo.current(false))
    document.addEventListener('pointerdown', alPulsar)
    document.addEventListener('keydown', alTeclado, true)
    document.addEventListener('focusin', alEnfocar)
    window.addEventListener('scroll', alDesplazar, true)
    return () => {
      baja()
      document.removeEventListener('pointerdown', alPulsar)
      document.removeEventListener('keydown', alTeclado, true)
      document.removeEventListener('focusin', alEnfocar)
      window.removeEventListener('scroll', alDesplazar, true)
    }
  }, [abierto, ultimo])

  // Tab desde el último control (o Mayús+Tab desde el primero) sale de la superficie y
  // la cierra; el recorrido sigue desde el disparador, como si la superficie estuviera
  // junto a él y no al final del documento.
  const alTecladoSuperficie = (evento: KeyboardEvent<HTMLDivElement>): void => {
    onKeyDown?.(evento)
    if (evento.key !== 'Tab' || evento.defaultPrevented || !superficie.current) return
    const lista = enfocables(superficie.current)
    const activo = document.activeElement
    const alFinal = !evento.shiftKey && (lista.length === 0 || activo === lista[lista.length - 1])
    const alInicio = evento.shiftKey && (lista.length === 0 || activo === lista[0])
    if (!alFinal && !alInicio) return
    if (alInicio) evento.preventDefault()
    cerrar(true)
  }

  const estilo: CSSProperties = {
    ...style,
    ...(posicion ? { ['--ay-x' as string]: `${posicion.x}px`, ['--ay-y' as string]: `${posicion.y}px` } : {}),
    ...(anchoAncla !== null ? { inlineSize: anchoAncla } : {}),
    ...(maxHeight ? { maxBlockSize: maxHeight } : {}),
  }

  return (
    <>
      {clonarDisparador(trigger, {
        id: idDisparador,
        ref: (el) => {
          disparador.current = el
        },
        'aria-expanded': abierto,
        // Siempre, como en el marcado canónico: con aria-expanded="false" la referencia a
        // una superficie que aún no está en el DOM es válida y dice qué se desplegará.
        'aria-controls': idSuperficie,
        onClick: () => cambiar(!abierto),
      })}
      {abierto
        ? enCapa(
            <div
              {...resto}
              ref={superficie}
              id={idSuperficie}
              className={cx('ay-dropdown', matchTriggerWidth && 'ay-dropdown--trigger')}
              data-align={posicion?.alineacion ?? align}
              data-placement={posicion?.colocacion ?? placement}
              data-en-capa={enModal ? '' : undefined}
              data-ay-flotante=""
              style={estilo}
              onKeyDown={alTecladoSuperficie}
            >
              {children}
            </div>,
          )
        : null}
    </>
  )
}

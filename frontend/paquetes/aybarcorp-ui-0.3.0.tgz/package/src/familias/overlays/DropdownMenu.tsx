import { isValidElement, useEffect, useId, useRef, useState } from 'react'
import type { CSSProperties, HTMLAttributes, ReactElement, ReactNode } from 'react'
import {
  calcularPosicion,
  dentroDeCapaModal,
  enfocar,
  separacionDeToken,
} from './_dom.js'
import type { Alineacion, Colocacion, Posicion } from './_dom.js'
import { clonarDisparador, enCapa, useControlable, useEfectoDeLayout } from './_internos.js'
import { ListaMenu } from './_menu.js'
import type { ElementoMenu, MotivoCierre } from './_menu.js'

export type ColocacionDropdownMenu = 'bottom-start' | 'bottom-end' | 'top-start'

/** Comando, separador o cabecera de grupo de un Dropdown Menu. */
export type MenuItem =
  | {
      type: 'item'
      /** Valor que recibe `onSelect`. */
      value: string
      /** Comando, empezando por un verbo: «Duplicar unidad». */
      label: string
      /** Icono decorativo antes de la etiqueta. */
      icon?: ReactNode
      /** Atajo de teclado, alineado al final del ítem. */
      shortcut?: string
      /** Comando destructivo: en danger, al final y tras un separador. */
      danger?: boolean
      /** Presente y anunciado como no disponible, pero omitido por las flechas. */
      disabled?: boolean
      /** Variante con selección: `menuitemradio` para modos, `menuitemcheckbox` para
       *  filtros. Son los roles que admiten `aria-checked`. */
      role?: 'menuitem' | 'menuitemradio' | 'menuitemcheckbox'
      /** Estado de la selección, en los roles `menuitemradio` y `menuitemcheckbox`. */
      checked?: boolean
      /** Submenú: un solo nivel de anidamiento. */
      items?: MenuItem[]
    }
  | { type: 'separator' }
  | { type: 'group'; label: string }

export interface PropsDropdownMenu
  extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'onSelect' | 'children'> {
  /** Disparador, normalmente un Icon Button «Más acciones» o un Button con chevron.
   *  Recibe `aria-haspopup="menu"`, `aria-expanded` y la apertura con Enter, Espacio y
   *  las flechas. */
  trigger: ReactElement
  /** Comandos, separadores y grupos, en orden. Más de ocho comandos es señal de que el
   *  patrón no es este. */
  items?: MenuItem[]
  /** Comando elegido, con su `value`. El menú se cierra y el foco vuelve al disparador
   *  (o pasa al modal, si el comando abre uno). */
  onSelect: (value: string) => void
  /** Posición preferida; si no cabe, el panel se voltea y se desplaza dentro del viewport. */
  placement?: ColocacionDropdownMenu
  /** Control externo opcional de la visibilidad. Sin él, el menú lleva su propio estado. */
  open?: boolean
  /** Cambio de visibilidad, en los dos modos. */
  onOpenChange?: (open: boolean) => void
}

/**
 * Lista de comandos desde un disparador, con el patrón menu de APG: el foco entra al
 * primer ítem, las flechas lo mueven con retorno circular, una letra salta al ítem que
 * empieza por ella, y Escape cierra devolviendo el foco al disparador. Para elegir un
 * valor de formulario, Select; para enlaces de navegación, Navigation Menu.
 */
export function DropdownMenu({
  trigger,
  items = [],
  onSelect,
  placement = 'bottom-start',
  open,
  onOpenChange,
  id,
  style,
  ...resto
}: PropsDropdownMenu) {
  const base = useId()
  const idMenu = id ?? `${base}-menu`
  const idPropio = isValidElement(trigger) ? (trigger.props as { id?: string }).id : undefined
  const idDisparador = idPropio ?? `${base}-disparador`
  const [abierto, cambiar] = useControlable(open, false, onOpenChange)
  const [foco, setFoco] = useState<'primero' | 'ultimo'>('primero')
  const [posicion, setPosicion] = useState<Posicion | null>(null)
  const [enModal, setEnModal] = useState(false)
  const disparador = useRef<HTMLElement | null>(null)
  const menu = useRef<HTMLDivElement | null>(null)
  const [colocacion, alineacion] = placement.split('-') as [Colocacion, Alineacion]

  const abrir = (desde: 'primero' | 'ultimo'): void => {
    setFoco(desde)
    cambiar(true)
  }
  const cerrar = (devolverFoco: boolean): void => {
    cambiar(false)
    if (devolverFoco) enfocar(disparador.current)
  }

  // Anclado al disparador, con volteo; se recoloca con el scroll y el redimensionado.
  useEfectoDeLayout(() => {
    if (!abierto) return
    const colocar = (): void => {
      const ancla = disparador.current
      const superficie = menu.current
      if (!ancla || !superficie) return
      setPosicion(
        calcularPosicion(
          ancla.getBoundingClientRect(),
          superficie.getBoundingClientRect(),
          colocacion,
          alineacion,
          separacionDeToken(),
        ),
      )
    }
    setEnModal(dentroDeCapaModal(disparador.current))
    colocar()
    window.addEventListener('resize', colocar)
    window.addEventListener('scroll', colocar, true)
    return () => {
      window.removeEventListener('resize', colocar)
      window.removeEventListener('scroll', colocar, true)
    }
  }, [abierto, colocacion, alineacion])

  // Clic fuera: cierra sin mover el foco, que ya fue adonde se hizo clic.
  useEffect(() => {
    if (!abierto) return
    const alPulsar = (evento: PointerEvent): void => {
      const objetivo = evento.target as Node
      if (menu.current?.contains(objetivo) || disparador.current?.contains(objetivo)) return
      cambiar(false)
    }
    document.addEventListener('pointerdown', alPulsar)
    return () => document.removeEventListener('pointerdown', alPulsar)
  }, [abierto, cambiar])

  const elementos = aElementos(items, (valor) => onSelect?.(valor))
  const estilo: CSSProperties = posicion
    ? { ...style, ['--ay-x' as string]: `${posicion.x}px`, ['--ay-y' as string]: `${posicion.y}px` }
    : { ...style }

  return (
    <>
      {clonarDisparador(trigger, {
        id: idDisparador,
        ref: (el) => {
          disparador.current = el
        },
        'aria-haspopup': 'menu',
        'aria-expanded': abierto,
        'aria-controls': abierto ? idMenu : undefined,
        onClick: () => (abierto ? cerrar(false) : abrir('primero')),
        onKeyDown: (evento) => {
          if (evento.key === 'ArrowDown') {
            evento.preventDefault()
            abrir('primero')
          } else if (evento.key === 'ArrowUp') {
            evento.preventDefault()
            abrir('ultimo')
          } else if (evento.key === 'Escape' && abierto) {
            evento.preventDefault()
            cerrar(true)
          }
        },
      })}
      {abierto
        ? enCapa(
            <ListaMenu
              {...resto}
              id={idMenu}
              aria-labelledby={idDisparador}
              clase="ay-menu ay-menu--desplegable"
              data-placement={posicion?.colocacion ?? colocacion}
              data-align={posicion?.alineacion ?? alineacion}
              data-en-capa={enModal ? '' : undefined}
              style={estilo}
              elementos={elementos}
              recorrerDeshabilitados={false}
              atajo="kbd"
              separador="hr"
              focoInicial={foco}
              refMenu={menu}
              alCerrar={(motivo: MotivoCierre) => {
                // Elegir, Escape y Tab devuelven el foco al disparador. Con Tab el evento
                // sigue su curso y la tabulación continúa desde ahí por la página.
                cerrar(motivo !== 'izquierda')
              }}
            />,
          )
        : null}
    </>
  )
}

function aElementos(items: MenuItem[], alElegir: (valor: string) => void, prefijo = 'i'): ElementoMenu[] {
  return items.map((item, i): ElementoMenu => {
    const clave = `${prefijo}${i}`
    if (item.type === 'separator') return { tipo: 'separator', clave }
    if (item.type === 'group') return { tipo: 'group', clave, etiqueta: item.label }
    return {
      tipo: 'item',
      clave,
      etiqueta: item.label,
      icono: item.icon,
      atajo: item.shortcut,
      peligro: item.danger,
      deshabilitado: item.disabled,
      rol: item.role,
      marcado: item.checked,
      hijos: item.items?.length ? aElementos(item.items, alElegir, `${clave}-`) : undefined,
      activar: () => alElegir(item.value),
    }
  })
}

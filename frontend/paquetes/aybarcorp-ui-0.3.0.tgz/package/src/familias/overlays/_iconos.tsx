/**
 * Glifos propios de la familia Overlays. Son decorativos (`aria-hidden`): el nombre
 * accesible lo pone siempre el control que los contiene. Internos: no se exportan.
 */

/** Aspa de cerrar, con el marcado canónico del glifo de Icon Button. */
export function IconoCerrar() {
  return (
    <svg
      className="ay-iconbtn__glyph"
      aria-hidden="true"
      focusable="false"
      width="20"
      height="20"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
    >
      <path d="M6 6l12 12M18 6L6 18" />
    </svg>
  )
}

/** Triángulo de aviso del Confirmation Dialog: refuerza la severidad ya escrita. */
export function IconoAlerta() {
  return (
    <svg
      className="ay-confirm__icon"
      aria-hidden="true"
      focusable="false"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M12 3.5 2.5 20h19L12 3.5Z" />
      <path d="M12 10v4.5M12 17.5v.01" />
    </svg>
  )
}

/** Chevron del ítem que abre un submenú. */
export function IconoSubmenu() {
  return (
    <svg
      className="ay-menu__chevron"
      aria-hidden="true"
      focusable="false"
      width="14"
      height="14"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="m9 6 6 6-6 6" />
    </svg>
  )
}

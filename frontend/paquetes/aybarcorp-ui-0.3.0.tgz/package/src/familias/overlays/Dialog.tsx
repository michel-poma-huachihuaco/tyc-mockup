import { forwardRef, useEffect, useId, useRef } from 'react'
import type { HTMLAttributes, ReactNode, RefObject } from 'react'
import { cx } from '../../utiles.js'
import { activarCapa, enfocables } from './_dom.js'
import { IconoCerrar } from './_iconos.js'
import { enCapa, usePantallaCompacta, useRefsCombinadas, useUltimo } from './_internos.js'

export type TamanoDialog = 'sm' | 'md' | 'lg'

export interface PropsDialog extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'title'> {
  /** Estado controlado. Cerrado, el diálogo no está en el DOM. */
  open?: boolean
  /** Cambio de estado: lo piden la X, Escape y el clic fuera. Con cambios sin guardar,
   *  quien consume no cierra en silencio: pide confirmación antes de descartar. */
  onOpenChange: (open: boolean) => void
  /** Título; obligatorio, es el nombre accesible. Nombra la tarea: «Registrar reserva»,
   *  no «Formulario». */
  title: string
  /** Descripción de la tarea, asociada con `aria-describedby`: al abrir se oyen seguidos
   *  el título y el motivo. */
  description?: string
  /** Ancho del panel. Por debajo del breakpoint sm ocupa la pantalla completa. */
  size?: TamanoDialog
  /** Acciones del pie, con la primaria última. Sin pie, el diálogo es de lectura y se
   *  cierra con la X, Escape o el clic fuera. */
  footer?: ReactNode
  /** Permite cerrar con Escape y clic fuera, y muestra la X. En `false` (un envío en
   *  curso) el diálogo no se cierra a mitad. */
  dismissible?: boolean
  /** Elemento que recibe el foco al abrir. Sin él, el primer control y, si no hay
   *  ninguno, el propio panel: el foco nunca se queda en el fondo. */
  initialFocus?: RefObject<HTMLElement | null>
}

/**
 * Tarea corta con título, cuerpo y acciones que debe resolverse antes de volver. Comparte
 * con Modal el velo y la trampa de foco: `aria-modal`, fondo inerte, scroll bloqueado y
 * el foco devuelto al elemento que lo abrió. Un error de envío va en un Alert dentro del
 * cuerpo, no en un Toast que desaparece.
 */
export const Dialog = forwardRef<HTMLDivElement, PropsDialog>(function Dialog(
  {
    open = false,
    onOpenChange,
    title,
    description,
    size = 'md',
    footer,
    dismissible = true,
    initialFocus,
    children,
    ...resto
  },
  ref,
) {
  const id = useId()
  const idTitulo = `${id}-title`
  const idDescripcion = `${id}-desc`
  const panel = useRef<HTMLDivElement | null>(null)
  const velo = useRef<HTMLDivElement | null>(null)
  const refPanel = useRefsCombinadas(ref, panel)
  const compacta = usePantallaCompacta('sm', open)
  const ultimo = useUltimo({ onOpenChange, dismissible, initialFocus })

  useEffect(() => {
    const superficie = panel.current
    if (!open || !superficie) return
    return activarCapa({
      panel: superficie,
      nodos: [velo.current, superficie].filter((n): n is HTMLDivElement => n !== null),
      modal: true,
      alEscape: () => {
        if (ultimo.current.dismissible) ultimo.current.onOpenChange?.(false)
      },
      focoInicial: () => ultimo.current.initialFocus?.current ?? enfocables(superficie)[0] ?? superficie,
    })
  }, [open, ultimo])

  if (!open) return null
  const cerrar = (): void => onOpenChange?.(false)

  return enCapa(
    <>
      <div
        ref={velo}
        className="ay-scrim"
        aria-hidden="true"
        data-open="true"
        onClick={() => {
          if (dismissible) cerrar()
        }}
      />
      <div
        {...resto}
        ref={refPanel}
        className={cx('ay-dialog', `ay-dialog--${size}`)}
        role="dialog"
        aria-modal="true"
        aria-labelledby={idTitulo}
        aria-describedby={description ? idDescripcion : undefined}
        tabIndex={-1}
        data-compacto={compacta ? '' : undefined}
      >
        <div className="ay-dialog__header">
          <h2 className="ay-dialog__title" id={idTitulo}>
            {title}
          </h2>
          {dismissible ? (
            <button type="button" className="ay-iconbtn ay-iconbtn--ghost" aria-label="Cerrar" onClick={cerrar}>
              <IconoCerrar />
            </button>
          ) : null}
        </div>
        <div className="ay-dialog__body">
          {description ? <p id={idDescripcion}>{description}</p> : null}
          {children}
        </div>
        {footer ? <div className="ay-dialog__footer">{footer}</div> : null}
      </div>
    </>,
  )
})

import { forwardRef, useEffect, useId, useRef, useState } from 'react'
import type { HTMLAttributes, KeyboardEvent, PointerEvent } from 'react'
import { cx } from '../../utiles.js'
import { activarCapa } from './_dom.js'
import { IconoCerrar } from './_iconos.js'
import { enCapa, useRefsCombinadas, useUltimo } from './_internos.js'

export type AlturaBottomSheet = 'auto' | 'half' | 'full'

export interface PropsBottomSheet extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'title'> {
  /** Estado controlado. Cerrado, el panel no está en el DOM. */
  open?: boolean
  /** Cambio de estado: lo piden la X, Escape, el toque en el velo, el arrastre hacia
   *  abajo pasado el umbral y la flecha abajo desde el anclaje más bajo. */
  onOpenChange: (open: boolean) => void
  /** Título; nombre accesible del panel. Nombra el objeto: «Unidad 402». */
  title?: string
  /** Altura: `auto` la fija el contenido, `half` media pantalla, `full` la pantalla
   *  completa menos la zona superior. */
  height?: AlturaBottomSheet
  /** Muestra el tirador. Nunca es la única salida: la X y Escape cierran siempre. */
  handle?: boolean
  /** Puntos de anclaje en porcentaje del alto de la pantalla, de menor a mayor
   *  (`[40, 90]`). Se alcanzan arrastrando y con las flechas en el tirador. */
  snapPoints?: number[]
}

/**
 * Acciones o contenido en móvil desde el borde inferior, donde llega el pulgar. Es modal
 * como un Dialog —`aria-modal`, trampa de foco, fondo inerte, scroll bloqueado— y el foco
 * vuelve al disparador al cerrar. Respeta la zona segura inferior. En escritorio, el mismo
 * contenido va en Dropdown Menu o Popover.
 */
export const BottomSheet = forwardRef<HTMLDivElement, PropsBottomSheet>(function BottomSheet(
  { open = false, onOpenChange, title, height = 'auto', handle = true, snapPoints, children, style, ...resto },
  ref,
) {
  const id = useId()
  const idTitulo = `${id}-title`
  const panel = useRef<HTMLDivElement | null>(null)
  const velo = useRef<HTMLDivElement | null>(null)
  const refPanel = useRefsCombinadas(ref, panel)
  const [anclaje, setAnclaje] = useState(0)
  const ultimo = useUltimo(onOpenChange)
  const anclajes = snapPoints?.length ? snapPoints : null
  const indice = anclajes ? Math.min(anclaje, anclajes.length - 1) : 0
  const porcentaje = anclajes ? anclajes[indice] : undefined

  // Cada apertura empieza en el anclaje más bajo.
  useEffect(() => {
    if (!open) setAnclaje(0)
  }, [open])

  useEffect(() => {
    const superficie = panel.current
    if (!open || !superficie) return
    return activarCapa({
      panel: superficie,
      nodos: [velo.current, superficie].filter((n): n is HTMLDivElement => n !== null),
      modal: true,
      alEscape: () => ultimo.current?.(false),
      // El foco pasa al panel, no al tirador ni a la primera acción.
      focoInicial: () => superficie,
    })
  }, [open, ultimo])

  if (!open) return null
  const cerrar = (): void => onOpenChange?.(false)

  const alTeclaTirador = (evento: KeyboardEvent<HTMLDivElement>): void => {
    if (evento.key === 'ArrowUp') {
      evento.preventDefault()
      if (anclajes) setAnclaje(Math.min(anclajes.length - 1, indice + 1))
    } else if (evento.key === 'ArrowDown') {
      evento.preventDefault()
      // Bajar desde el anclaje más bajo es lo mismo que arrastrar hasta abajo: cierra.
      if (anclajes && indice > 0) setAnclaje(indice - 1)
      else cerrar()
    }
  }

  // El panel sigue al dedo; al soltar, pasado el umbral se cierra y por debajo vuelve a
  // su sitio (o al anclaje más cercano, si los hay).
  const alArrastrar = (evento: PointerEvent<HTMLDivElement>): void => {
    const superficie = panel.current
    if (!superficie) return
    const tirador = evento.currentTarget
    const inicioY = evento.clientY
    const altoInicial = superficie.getBoundingClientRect().height
    let delta = 0
    tirador.setPointerCapture?.(evento.pointerId)
    superficie.dataset.arrastrando = ''
    const mover = (e: globalThis.PointerEvent): void => {
      delta = e.clientY - inicioY
      // Resistencia hacia arriba: el panel cede poco más allá de su altura.
      const visible = delta < 0 ? delta / 3 : delta
      superficie.style.translate = `0 ${visible}px`
    }
    const soltar = (): void => {
      delete superficie.dataset.arrastrando
      superficie.style.translate = ''
      tirador.removeEventListener('pointermove', mover)
      tirador.removeEventListener('pointerup', soltar)
      tirador.removeEventListener('pointercancel', soltar)
      if (anclajes) {
        const altoPantalla = window.innerHeight || 1
        const deseado = ((altoInicial - delta) / altoPantalla) * 100
        if (indice === 0 && deseado < (anclajes[0] ?? 0) / 2) {
          cerrar()
          return
        }
        let cercano = 0
        anclajes.forEach((p, i) => {
          if (Math.abs(p - deseado) < Math.abs((anclajes[cercano] ?? 0) - deseado)) cercano = i
        })
        setAnclaje(cercano)
      } else if (delta > altoInicial / 4) {
        cerrar()
      }
    }
    tirador.addEventListener('pointermove', mover)
    tirador.addEventListener('pointerup', soltar)
    tirador.addEventListener('pointercancel', soltar)
  }

  return enCapa(
    <>
      <div ref={velo} className="ay-scrim" aria-hidden="true" onClick={cerrar} />
      <div
        {...resto}
        ref={refPanel}
        className={cx('ay-sheet', `ay-sheet--${height}`)}
        role="dialog"
        aria-modal="true"
        aria-labelledby={title ? idTitulo : undefined}
        tabIndex={-1}
        style={porcentaje !== undefined ? { ...style, blockSize: `${porcentaje}%` } : style}
      >
        {handle ? (
          // Un control real con nombre y estado: responde a las flechas, así que el
          // arrastre no es la única forma de cambiar de altura ni de cerrar.
          <div
            className="ay-sheet__handle"
            role="separator"
            aria-orientation="horizontal"
            aria-label="Ajustar la altura del panel"
            aria-valuenow={porcentaje ?? 0}
            aria-valuemin={0}
            aria-valuemax={anclajes ? anclajes[anclajes.length - 1] : 100}
            aria-valuetext={porcentaje !== undefined ? `${porcentaje} % de la pantalla` : 'Altura según el contenido'}
            tabIndex={0}
            onKeyDown={alTeclaTirador}
            onPointerDown={alArrastrar}
          />
        ) : null}
        <div className="ay-sheet__header">
          {title ? (
            <h2 className="ay-sheet__title" id={idTitulo}>
              {title}
            </h2>
          ) : null}
          <button type="button" className="ay-iconbtn ay-iconbtn--ghost" aria-label="Cerrar" onClick={cerrar}>
            <IconoCerrar />
          </button>
        </div>
        <div className="ay-sheet__body">{children}</div>
      </div>
    </>,
  )
})

import { forwardRef, useEffect, useId, useRef, useState } from 'react'
import type { FocusEvent, HTMLAttributes, KeyboardEvent, PointerEvent, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { guardarAlmacenado, leerAlmacenado, seguirArrastre } from '../layout/_tirador.js'
import { activarCapa, enfocar } from './_dom.js'
import { IconoCerrar } from './_iconos.js'
import { usePantallaCompacta, useRefsCombinadas, useUltimo } from './_internos.js'

export type LadoSidePanel = 'start' | 'end'
export type TamanoSidePanel = 'sm' | 'md' | 'lg'

export interface PropsSidePanel extends Omit<HTMLAttributes<HTMLElement>, 'className' | 'title'> {
  /** Estado controlado. Abierto, ocupa su columna y la lista se estrecha; cerrado, la
   *  lista recupera el ancho completo. */
  open?: boolean
  /** Cambio de estado. Si llega, el panel es colapsable: muestra la X y Escape lo cierra
   *  devolviendo el foco a la fila o al control desde el que se entró. */
  onOpenChange?: (open: boolean) => void
  /** Título del registro —«Unidad 402»—; es el nombre accesible de la región. Al cambiar
   *  de registro se actualiza y se anuncia sin mover el foco. Sin título se muestra el
   *  estado sin selección. */
  title?: string
  /** Borde al que se ancla dentro del layout. */
  side?: LadoSidePanel
  /** Ancho de la columna; nunca más de la mitad del viewport, porque la lista sigue
   *  siendo el eje. */
  size?: TamanoSidePanel
  /** Permite ajustar el ancho con un tirador (role separator) arrastrable y también
   *  ajustable con las flechas, en pasos. El ancho se recuerda entre sesiones. */
  resizable?: boolean
  /** Acciones del pie sobre el registro. */
  footer?: ReactNode
  /** Contenido sin selección: un Empty State que invite a elegir un registro. */
  emptyState?: ReactNode
}

/**
 * Detalle o edición de un registro junto a la lista, sin velo ni trampa de foco: no es
 * modal, comparte el ancho con la lista en lugar de taparla y es una región con nombre.
 * Por debajo del breakpoint lg no hay ancho para dos columnas: pasa a Drawer con velo y
 * entonces sí es modal, con trampa de foco y fondo inerte.
 */
export const SidePanel = forwardRef<HTMLElement, PropsSidePanel>(function SidePanel(
  {
    open = true,
    onOpenChange,
    title,
    side = 'end',
    size = 'md',
    resizable = false,
    footer,
    emptyState,
    children,
    style,
    onFocus,
    onKeyDown,
    ...resto
  },
  ref,
) {
  const id = useId()
  const idTitulo = `${id}-title`
  const panel = useRef<HTMLElement | null>(null)
  const velo = useRef<HTMLDivElement | null>(null)
  const refPanel = useRefsCombinadas(ref, panel)
  const origen = useRef<HTMLElement | null>(null)
  const [ancho, setAncho] = useState<number | null>(null)
  const [limites, setLimites] = useState<{ min: number; max: number; actual: number } | null>(null)
  const compacta = usePantallaCompacta('lg', open)
  const colapsable = Boolean(onOpenChange)
  const ultimo = useUltimo(onOpenChange)

  // En pantalla compacta el panel es un Drawer modal: la misma capa que Modal y Drawer.
  useEffect(() => {
    const superficie = panel.current
    if (!open || !compacta || !superficie) return
    return activarCapa({
      panel: superficie,
      nodos: [velo.current, superficie].filter((n): n is HTMLElement => n !== null),
      modal: true,
      alEscape: () => ultimo.current?.(false),
    })
  }, [open, compacta, ultimo])

  // El tirador anuncia su estado: ancho actual, mínimo y máximo, en píxeles.
  useEffect(() => {
    const superficie = panel.current
    if (!open || !resizable || compacta || !superficie) return
    const medir = (): void =>
      setLimites({
        min: limitarAncho(superficie, 0),
        max: limitarAncho(superficie, Number.POSITIVE_INFINITY),
        actual: Math.round(superficie.getBoundingClientRect().width),
      })
    medir()
    window.addEventListener('resize', medir)
    return () => window.removeEventListener('resize', medir)
  }, [open, resizable, compacta, ancho, size])

  // El ancho ajustado se recuerda entre sesiones: se lee al montar (no en el render, que
  // en el servidor no tiene almacenamiento) y se guarda en cada cambio. La clave sale del
  // `id` del panel si lo hay; si no, del lado al que se ancla.
  const clave = `ay-sidepanel-ancho:${resto.id ?? side}`
  useEffect(() => {
    if (!resizable) return
    const guardado = leerAncho(clave)
    if (guardado !== null) setAncho(limitarAncho(panel.current, guardado))
  }, [resizable, clave])
  useEffect(() => {
    if (resizable && ancho !== null) guardarAncho(clave, ancho)
  }, [resizable, clave, ancho])

  if (!open) return null

  const cerrar = (): void => {
    onOpenChange?.(false)
    // Vuelve a la fila desde la que se entró: el panel es el detalle de ese registro.
    if (!compacta) enfocar(origen.current)
  }

  const ajustarCon = (delta: number): void => {
    const actual = ancho ?? panel.current?.getBoundingClientRect().width ?? 0
    setAncho(limitarAncho(panel.current, actual + delta))
  }

  // Un paso de flecha es 1rem en píxeles: el tamaño de letra raíz.
  const paso = (): number =>
    typeof document === 'undefined'
      ? 0
      : parseFloat(getComputedStyle(document.documentElement).fontSize) || 0

  const alTeclaTirador = (evento: KeyboardEvent<HTMLDivElement>): void => {
    // En `end` el tirador está a la izquierda: hacia la izquierda el panel crece.
    const crece = side === 'end' ? 'ArrowLeft' : 'ArrowRight'
    const mengua = side === 'end' ? 'ArrowRight' : 'ArrowLeft'
    if (evento.key === crece) {
      evento.preventDefault()
      ajustarCon(paso())
    } else if (evento.key === mengua) {
      evento.preventDefault()
      ajustarCon(-paso())
    }
  }

  // El arrastre (captura del puntero, `data-activo`, soltar) es el de Splitter: _tirador.ts.
  const alArrastrar = (evento: PointerEvent<HTMLDivElement>): void => {
    const inicioX = evento.clientX
    const inicial = ancho ?? panel.current?.getBoundingClientRect().width ?? 0
    seguirArrastre(evento.currentTarget, evento.nativeEvent, (e) => {
      const delta = side === 'end' ? inicioX - e.clientX : e.clientX - inicioX
      setAncho(limitarAncho(panel.current, inicial + delta))
    })
  }

  const contenido = (
    <aside
      {...resto}
      ref={refPanel}
      className={cx('ay-sidepanel', `ay-sidepanel--${size}`, `ay-sidepanel--${side}`)}
      aria-labelledby={title ? idTitulo : undefined}
      // Compacto es un Drawer: diálogo modal. Ancho, una región complementaria con nombre.
      role={compacta ? 'dialog' : undefined}
      aria-modal={compacta ? true : undefined}
      tabIndex={compacta ? -1 : undefined}
      data-compacto={compacta ? '' : undefined}
      style={ancho !== null && !compacta ? { ...style, inlineSize: ancho } : style}
      onFocus={(evento: FocusEvent<HTMLElement>) => {
        onFocus?.(evento)
        const desde = evento.relatedTarget
        if (desde instanceof HTMLElement && !evento.currentTarget.contains(desde)) origen.current = desde
      }}
      onKeyDown={(evento: KeyboardEvent<HTMLElement>) => {
        onKeyDown?.(evento)
        // Escape solo cierra un panel colapsable, y solo desde dentro: en la lista,
        // Escape no le pertenece. En compacto lo atiende la capa modal.
        if (evento.key === 'Escape' && colapsable && !compacta && !evento.defaultPrevented) {
          evento.preventDefault()
          cerrar()
        }
      }}
    >
      {resizable && !compacta ? (
        <div
          className="ay-sidepanel__grip"
          role="separator"
          aria-orientation="vertical"
          aria-label="Ajustar el ancho del panel"
          aria-valuenow={limites?.actual}
          aria-valuemin={limites?.min}
          aria-valuemax={limites?.max}
          tabIndex={0}
          onKeyDown={alTeclaTirador}
          onPointerDown={alArrastrar}
        />
      ) : null}
      {title ? (
        <>
          <div className="ay-sidepanel__header">
            <h2 className="ay-sidepanel__title" id={idTitulo}>
              {title}
            </h2>
            {colapsable ? (
              <button
                type="button"
                className="ay-iconbtn ay-iconbtn--ghost"
                aria-label={`Cerrar el panel «${title}»`}
                onClick={cerrar}
              >
                <IconoCerrar />
              </button>
            ) : null}
          </div>
          <div className="ay-sidepanel__body">{children}</div>
          {footer ? <div className="ay-sidepanel__footer">{footer}</div> : null}
          <p className="ay-visualmente-oculto" aria-live="polite">
            {`Mostrando ${title}`}
          </p>
        </>
      ) : (
        <div className="ay-sidepanel__empty">{emptyState}</div>
      )}
    </aside>
  )

  if (!compacta) return contenido
  return (
    <>
      <div ref={velo} className="ay-scrim" aria-hidden="true" onClick={() => (colapsable ? cerrar() : undefined)} />
      {contenido}
    </>
  )
})

/** El ancho guardado, en píxeles; lo que falta, no se entiende o no es positivo, nada.
 *  Leer y escribir no lanzan sin almacenamiento (modo privado, sin permiso): _tirador.ts. */
function leerAncho(clave: string): number | null {
  const valor = Number(leerAlmacenado(clave))
  return Number.isFinite(valor) && valor > 0 ? valor : null
}

function guardarAncho(clave: string, valor: number): void {
  guardarAlmacenado(clave, String(Math.round(valor)))
}

/** El ancho queda entre el mínimo de la hoja y la mitad del viewport. */
function limitarAncho(panel: HTMLElement | null, deseado: number): number {
  if (!panel) return deseado
  const minimo = parseFloat(getComputedStyle(panel).minInlineSize) || 0
  const maximo = window.innerWidth / 2
  return Math.round(Math.min(Math.max(deseado, minimo), maximo))
}

import { cloneElement, createElement, isValidElement, useEffect, useRef, useState } from 'react'
import type {
  CSSProperties,
  HTMLAttributes,
  KeyboardEvent,
  MouseEvent,
  ReactElement,
  ReactNode,
} from 'react'
import { dentroDeCapaModal, enfocar, esTactil, posicionEnPunto, separacionDeToken } from './_dom.js'
import { enCapa, useControlable, useEfectoDeLayout, useUltimo } from './_internos.js'
import { ListaMenu } from './_menu.js'
import type { ElementoMenu } from './_menu.js'

/** Acción o separador de un Context Menu. */
export type ContextMenuItem =
  | {
      type?: 'item'
      /** Identificador estable de la acción. */
      id: string
      /** Acción en infinitivo; la destructiva nombra el objeto: «Eliminar la unidad 402». */
      label: string
      /** Icono decorativo antes de la etiqueta. */
      icon?: ReactNode
      /** Atajo visible, escrito con el modificador del sistema. Es texto del ítem: se
       *  anuncia junto al comando. */
      shortcut?: string
      /** Acción destructiva: separada del resto y en tono danger. */
      danger?: boolean
      /** Se recorre con las flechas pero no se activa (`aria-disabled`). */
      disabled?: boolean
      /** Por qué hoy no se puede: se escribe bajo la etiqueta del ítem deshabilitado. */
      disabledReason?: string
      /** Ejecuta la acción. */
      onSelect: () => void
      /** Submenú: un solo nivel. */
      items?: ContextMenuItem[]
    }
  | { type: 'separator' }

/** Punto de invocación, en coordenadas del viewport. */
export interface PosicionContextMenu {
  x: number
  y: number
}

export interface PropsContextMenu extends Omit<HTMLAttributes<HTMLDivElement>, 'className'> {
  /** Acciones: label, icon, shortcut, danger, disabled, onSelect. Sin acciones el menú no
   *  se abre, en lugar de abrirse vacío. Todas deben existir también en un control
   *  visible: un menú contextual no se descubre y en táctil no existe. */
  items?: ContextMenuItem[]
  /** Estado controlado. Sin él (cerrado al empezar), el menú se abre con el clic derecho,
   *  la tecla de menú o Mayús+F10 sobre el elemento. */
  open?: boolean
  /** Cambio de estado, en los dos modos. */
  onOpenChange?: (open: boolean) => void
  /** Punto de invocación controlado. Sin él, el del puntero o el del elemento enfocado. */
  position?: PosicionContextMenu
  /** Nombre accesible del menú: «Acciones de la unidad 402». En selección múltiple dice
   *  a cuántos registros se aplica. */
  label: string
}

/**
 * Acciones de un elemento donde el usuario ya está, con el clic derecho, la tecla de menú
 * o Mayús+F10. `role="menu"` con el modelo de teclado completo: el foco entra al primer
 * elemento, las flechas recorren en ciclo (los deshabilitados también, sin activarse), una
 * letra salta, y Escape cierra devolviendo el foco al elemento. Se voltea en los dos ejes
 * y el scroll lo cierra. El hijo es el elemento sobre el que se invoca.
 */
export function ContextMenu({
  items = [],
  open,
  onOpenChange,
  position,
  label,
  children,
  style,
  ...resto
}: PropsContextMenu) {
  const [abierto, cambiar] = useControlable(open, false, onOpenChange)
  const [puntoPropio, setPunto] = useState<PosicionContextMenu | null>(null)
  const [coordenadas, setCoordenadas] = useState<PosicionContextMenu | null>(null)
  const [enModal, setEnModal] = useState(false)
  const disparador = useRef<HTMLElement | null>(null)
  const menu = useRef<HTMLDivElement | null>(null)
  const ultimo = useUltimo(cambiar)
  const punto = position ?? puntoPropio

  const abrir = (x: number, y: number, origen: HTMLElement): void => {
    disparador.current = origen
    setPunto({ x, y })
    cambiar(true)
  }
  const cerrar = (devolverFoco: boolean): void => {
    cambiar(false)
    if (devolverFoco) enfocar(disparador.current)
  }

  // En el punto de invocación, volteado si no cabe abajo o a la derecha.
  useEfectoDeLayout(() => {
    if (!abierto || !menu.current) return
    const propio = menu.current.getBoundingClientRect()
    setEnModal(dentroDeCapaModal(disparador.current))
    setCoordenadas(punto ? posicionEnPunto(punto, propio) : null)
  }, [abierto, punto?.x, punto?.y])

  useEffect(() => {
    if (!abierto) return
    const alPulsar = (evento: PointerEvent): void => {
      if (evento.target instanceof Node && menu.current?.contains(evento.target)) return
      ultimo.current(false)
    }
    // Menú abierto y scroll: se cierra.
    const alDesplazar = (evento: Event): void => {
      if (evento.target instanceof Node && menu.current?.contains(evento.target)) return
      ultimo.current(false)
    }
    const alRedimensionar = (): void => ultimo.current(false)
    document.addEventListener('pointerdown', alPulsar)
    window.addEventListener('scroll', alDesplazar, true)
    window.addEventListener('resize', alRedimensionar)
    return () => {
      document.removeEventListener('pointerdown', alPulsar)
      window.removeEventListener('scroll', alDesplazar, true)
      window.removeEventListener('resize', alRedimensionar)
    }
  }, [abierto, ultimo])

  const hayAcciones = items.some((item) => item.type !== 'separator')

  const propsDisparador = {
    'aria-haspopup': 'menu' as const,
    onContextMenu: (evento: MouseEvent<HTMLElement>) => {
      propiasDe(children).onContextMenu?.(evento)
      // Sin acciones no se abre, y en táctil no se muestra: el menú del sistema sigue.
      if (evento.defaultPrevented || !hayAcciones || esTactil()) return
      evento.preventDefault()
      abrir(evento.clientX, evento.clientY, evento.currentTarget)
    },
    // La tecla de menú y Mayús+F10: sin ellas el clic derecho es la única vía.
    onKeyDown: (evento: KeyboardEvent<HTMLElement>) => {
      propiasDe(children).onKeyDown?.(evento)
      if (evento.defaultPrevented || !hayAcciones) return
      if (evento.key === 'ContextMenu' || (evento.shiftKey && evento.key === 'F10')) {
        evento.preventDefault()
        const r = evento.currentTarget.getBoundingClientRect()
        const margen = separacionDeToken() * 2
        abrir(r.left + margen, r.bottom - margen, evento.currentTarget)
      }
    },
  }

  const elemento = isValidElement(children)
    ? cloneElement(children as ReactElement<Record<string, unknown>>, propsDisparador)
    : // Un texto suelto se envuelve en un elemento enfocable: sin foco, la tecla de menú y
      // Mayús+F10 no tendrían dónde pulsarse.
      createElement('span', { ...propsDisparador, tabIndex: 0 }, children)

  const estilo: CSSProperties = coordenadas
    ? { ...style, ['--ay-x' as string]: `${coordenadas.x}px`, ['--ay-y' as string]: `${coordenadas.y}px` }
    : punto
      ? { ...style, ['--ay-x' as string]: `${punto.x}px`, ['--ay-y' as string]: `${punto.y}px` }
      : { ...style }

  return (
    <>
      {elemento}
      {abierto && hayAcciones
        ? enCapa(
            <ListaMenu
              {...resto}
              aria-label={label}
              clase="ay-menu ay-menu--contextual"
              data-en-capa={enModal ? '' : undefined}
              style={estilo}
              elementos={aElementos(items)}
              recorrerDeshabilitados
              atajo="shortcut"
              separador="div"
              focoInicial="primero"
              refMenu={menu}
              alCerrar={(motivo) => cerrar(motivo !== 'izquierda')}
            />,
          )
        : null}
    </>
  )
}

function propiasDe(hijo: ReactNode): {
  onContextMenu?: (evento: MouseEvent<HTMLElement>) => void
  onKeyDown?: (evento: KeyboardEvent<HTMLElement>) => void
} {
  return isValidElement(hijo)
    ? (hijo.props as {
        onContextMenu?: (evento: MouseEvent<HTMLElement>) => void
        onKeyDown?: (evento: KeyboardEvent<HTMLElement>) => void
      })
    : {}
}

function aElementos(items: ContextMenuItem[], prefijo = 'c'): ElementoMenu[] {
  return items.map((item, i): ElementoMenu => {
    const clave = `${prefijo}${i}`
    if (item.type === 'separator') return { tipo: 'separator', clave }
    return {
      tipo: 'item',
      clave,
      etiqueta: item.label,
      icono: item.icon,
      atajo: item.shortcut,
      peligro: item.danger,
      deshabilitado: item.disabled,
      motivo: item.disabledReason,
      hijos: item.items?.length ? aElementos(item.items, `${clave}-`) : undefined,
      activar: () => item.onSelect?.(),
    }
  })
}

/**
 * Ganchos de React compartidos por la familia Overlays. Internos: no se exportan en el
 * índice. La mecánica de DOM vive en `_dom.ts`; aquí solo se conecta con el ciclo de
 * vida de React.
 */
import {
  cloneElement,
  createElement,
  isValidElement,
  useCallback,
  useEffect,
  useLayoutEffect,
  useRef,
  useState,
  version,
} from 'react'
import type {
  DependencyList,
  EffectCallback,
  KeyboardEvent as EventoTeclado,
  MouseEvent as EventoRaton,
  MutableRefObject,
  ReactElement,
  ReactNode,
  Ref,
} from 'react'
import { createPortal } from 'react-dom'
import { escucharPantallaCompacta } from './_dom.js'

/** `useLayoutEffect` en el navegador y `useEffect` en el servidor, donde no hay layout. */
export function useEfectoDeLayout(efecto: EffectCallback, dependencias: DependencyList): void {
  const usar = typeof document === 'undefined' ? useEffect : useLayoutEffect
  usar(efecto, dependencias)
}

/** Ref que siempre apunta al último valor: los manejadores leen la prop vigente sin re-suscribirse. */
export function useUltimo<T>(valor: T): MutableRefObject<T> {
  const ref = useRef(valor)
  ref.current = valor
  return ref
}

/**
 * Pinta la capa en `document.body` para que ningún `overflow` ni `z-index` de un ancestro
 * la recorte. En el servidor no hay `document` y el contenido se pinta en su sitio: así
 * `renderToStaticMarkup` (el catálogo, las pruebas) produce el marcado de la capa abierta.
 */
export function enCapa(contenido: ReactNode): ReactNode {
  if (typeof document === 'undefined') return contenido
  return createPortal(contenido, document.body)
}

export function asignarRef<T>(ref: Ref<T> | undefined, valor: T | null): void {
  if (typeof ref === 'function') ref(valor)
  else if (ref) (ref as MutableRefObject<T | null>).current = valor
}

/** Une varias refs en una sola ref de callback, estable mientras no cambien. */
export function useRefsCombinadas<T>(...refs: (Ref<T> | undefined)[]): (valor: T | null) => void {
  return useCallback((valor: T | null) => {
    for (const ref of refs) asignarRef(ref, valor)
    // Las refs son la dependencia: cambian solo si quien consume pasa otra.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, refs)
}

const MAYOR = Number(version.split('.')[0])

/** La ref que trae un elemento: en React 19 es una prop; en 18, un campo del elemento. */
export function refDeElemento(elemento: ReactElement): Ref<unknown> | undefined {
  if (MAYOR >= 19) return (elemento.props as { ref?: Ref<unknown> }).ref
  return (elemento as unknown as { ref?: Ref<unknown> }).ref ?? undefined
}

/**
 * Estado controlado o no controlado: si llega `controlado`, manda; si no, el componente
 * lleva el suyo. `cambiar` notifica siempre, en los dos modos.
 */
export function useControlable(
  controlado: boolean | undefined,
  inicial: boolean,
  alCambiar: ((valor: boolean) => void) | null | undefined,
): [boolean, (valor: boolean) => void] {
  const [interno, setInterno] = useState(inicial)
  const valor = controlado ?? interno
  const aviso = useUltimo(alCambiar)
  const esControlado = controlado !== undefined
  const cambiar = useCallback(
    (nuevo: boolean) => {
      if (!esControlado) setInterno(nuevo)
      aviso.current?.(nuevo)
    },
    [esControlado, aviso],
  )
  return [valor, cambiar]
}

/** Verdadero mientras el viewport esté por debajo del breakpoint del token. */
export function usePantallaCompacta(punto: 'sm' | 'md' | 'lg', activo = true): boolean {
  const [compacta, setCompacta] = useState(false)
  useEffect(() => {
    if (!activo) return
    return escucharPantallaCompacta(punto, setCompacta)
  }, [punto, activo])
  return activo && compacta
}

/** Props que se añaden al disparador de una superficie flotante. */
export interface PropsDisparador {
  id: string
  ref: (el: HTMLElement | null) => void
  onClick: (evento: EventoRaton<HTMLElement>) => void
  onKeyDown?: (evento: EventoTeclado<HTMLElement>) => void
  'aria-haspopup'?: 'menu'
  'aria-expanded': boolean
  'aria-controls'?: string
}

/**
 * Clona el disparador con sus props de ARIA y sus manejadores, sin pisar los suyos.
 * Si llega algo que no es un elemento (el catálogo pasa texto), se pinta el marcado
 * canónico de un Button secundario con ese texto: el disparador tiene que ser un
 * control real, y aquí no se importa el componente de la familia Actions.
 */
export function clonarDisparador(disparador: ReactNode, extra: PropsDisparador): ReactNode {
  if (!isValidElement(disparador)) {
    return createElement(
      'button',
      { ...extra, type: 'button', className: 'ay-btn ay-btn--secondary' },
      disparador,
    )
  }
  const propias = disparador.props as {
    id?: string
    onClick?: (evento: EventoRaton<HTMLElement>) => void
    onKeyDown?: (evento: EventoTeclado<HTMLElement>) => void
  }
  const refPropia = refDeElemento(disparador) as Ref<HTMLElement> | undefined
  return cloneElement(disparador as ReactElement<Record<string, unknown>>, {
    ...extra,
    id: propias.id ?? extra.id,
    ref: (el: HTMLElement | null) => {
      asignarRef(refPropia, el)
      extra.ref(el)
    },
    onClick: (evento: EventoRaton<HTMLElement>) => {
      propias.onClick?.(evento)
      if (!evento.defaultPrevented) extra.onClick(evento)
    },
    onKeyDown: (evento: EventoTeclado<HTMLElement>) => {
      propias.onKeyDown?.(evento)
      if (!evento.defaultPrevented) extra.onKeyDown?.(evento)
    },
  })
}

let cerrarAbierto: (() => void) | null = null

/**
 * Solo un desplegable abierto a la vez: al abrirse uno, se cierra el anterior.
 * Devuelve la función que lo da de baja.
 */
export function registrarUnicoAbierto(cerrar: () => void): () => void {
  if (cerrarAbierto && cerrarAbierto !== cerrar) cerrarAbierto()
  cerrarAbierto = cerrar
  return () => {
    if (cerrarAbierto === cerrar) cerrarAbierto = null
  }
}

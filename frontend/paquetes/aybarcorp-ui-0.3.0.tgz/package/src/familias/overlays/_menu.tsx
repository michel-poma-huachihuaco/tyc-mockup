/**
 * Lista de menú compartida por Dropdown Menu y Context Menu (patrón menu de APG): roving
 * tabindex con foco real, flechas con retorno circular, Inicio/Fin, salto por letra,
 * Enter/Espacio, un nivel de submenú con flecha derecha/izquierda, Escape y Tab.
 *
 * Interna: no se exporta en el índice. Las dos fichas difieren en tres cosas y las tres
 * llegan como opciones: si los deshabilitados se recorren (Context Menu) o se saltan
 * (Dropdown Menu), cómo se pinta el atajo y cómo el separador.
 */
import { useId, useRef, useState } from 'react'
import type { CSSProperties, HTMLAttributes, KeyboardEvent, ReactNode, Ref } from 'react'
import { cx } from '../../utiles.js'
import { mostrarEnCapaSuperior, ocultarDeCapaSuperior } from '../surfaces/_capa.js'
import { areaVisible, enfocar, normalizar } from './_dom.js'
import { IconoSubmenu } from './_iconos.js'
import { useEfectoDeLayout } from './_internos.js'

export interface ElementoMenu {
  tipo: 'item' | 'separator' | 'group'
  clave: string
  etiqueta?: string
  icono?: ReactNode
  atajo?: string
  peligro?: boolean
  deshabilitado?: boolean
  motivo?: string
  rol?: 'menuitem' | 'menuitemradio' | 'menuitemcheckbox'
  marcado?: boolean
  hijos?: ElementoMenu[]
  activar?: () => void
}

/** Por qué se cierra una lista: el componente decide adónde va el foco en cada caso. */
export type MotivoCierre = 'escape' | 'tab' | 'eleccion' | 'izquierda'

export interface PropsListaMenu extends Omit<HTMLAttributes<HTMLDivElement>, 'className'> {
  elementos: ElementoMenu[]
  clase: string
  recorrerDeshabilitados: boolean
  atajo: 'kbd' | 'shortcut'
  separador: 'hr' | 'div'
  focoInicial: 'primero' | 'ultimo'
  alCerrar: (motivo: MotivoCierre) => void
  submenu?: boolean
  refMenu?: Ref<HTMLDivElement>
}

export function ListaMenu({
  elementos,
  clase,
  recorrerDeshabilitados,
  atajo,
  separador,
  focoInicial,
  alCerrar,
  submenu = false,
  refMenu,
  onKeyDown,
  ...resto
}: PropsListaMenu) {
  const base = useId()
  const navegables = elementos.filter(
    (el) => el.tipo === 'item' && (recorrerDeshabilitados || !el.deshabilitado),
  )
  const n = navegables.length
  const [activoCrudo, setActivo] = useState(() => (focoInicial === 'ultimo' ? n - 1 : 0))
  const activo = n === 0 ? -1 : Math.min(Math.max(activoCrudo, 0), n - 1)
  const [abierto, setAbierto] = useState<string | null>(null)
  const botones = useRef(new Map<string, HTMLButtonElement>())
  const contenedor = useRef<HTMLDivElement | null>(null)
  const actual = activo >= 0 ? navegables[activo] : undefined

  // A la capa superior en cuanto se pinta, antes de enfocar un ítem y de que el componente
  // la mida: un `[popover]` que aún no se muestra no tiene caja ni admite el foco. Allí no
  // la tapa una Navbar o un Banner pegajoso, y queda por encima de un Modal. Sin la API
  // sigue con su `position: fixed`. Al cerrar se baja antes de salir del DOM.
  useEfectoDeLayout(() => {
    const nodo = contenedor.current
    if (!nodo) return
    mostrarEnCapaSuperior(nodo)
    return () => ocultarDeCapaSuperior(nodo)
  }, [])

  // El foco sigue al ítem activo; con un submenú abierto, el foco es suyo.
  useEfectoDeLayout(() => {
    if (abierto) return
    const destino = actual ? botones.current.get(actual.clave) : null
    if (!enfocar(destino)) enfocar(contenedor.current)
  }, [activo, abierto, actual?.clave])

  const activar = (el: ElementoMenu): void => {
    if (el.deshabilitado) return
    if (el.hijos?.length) {
      setAbierto((previo) => (previo === el.clave ? null : el.clave))
      return
    }
    el.activar?.()
    alCerrar('eleccion')
  }

  const alTeclado = (evento: KeyboardEvent<HTMLDivElement>): void => {
    onKeyDown?.(evento)
    // Un submenú anidado ya atendió la tecla: no se procesa dos veces al burbujear.
    if (evento.defaultPrevented) return
    switch (evento.key) {
      case 'ArrowDown':
        evento.preventDefault()
        if (n) setActivo((activo + 1) % n)
        return
      case 'ArrowUp':
        evento.preventDefault()
        if (n) setActivo((activo - 1 + n) % n)
        return
      case 'Home':
        evento.preventDefault()
        setActivo(0)
        return
      case 'End':
        evento.preventDefault()
        setActivo(n - 1)
        return
      case 'ArrowRight':
        if (actual?.hijos?.length && !actual.deshabilitado) {
          evento.preventDefault()
          setAbierto(actual.clave)
        }
        return
      case 'ArrowLeft':
        if (submenu) {
          evento.preventDefault()
          alCerrar('izquierda')
        }
        return
      case 'Escape':
        evento.preventDefault()
        alCerrar('escape')
        return
      case 'Enter':
      case ' ':
        evento.preventDefault()
        if (actual) activar(actual)
        return
      case 'Tab':
        // Sin preventDefault: Tab cierra y la tabulación sigue por la página.
        alCerrar('tab')
        return
      default:
        saltarPorLetra(evento)
    }
  }

  // Salta al siguiente ítem que empieza por la letra, en ciclo desde el activo.
  const saltarPorLetra = (evento: KeyboardEvent<HTMLDivElement>): void => {
    if (evento.key.length !== 1 || evento.ctrlKey || evento.metaKey || evento.altKey) return
    if (!/\S/.test(evento.key) || n === 0) return
    const letra = normalizar(evento.key)
    for (let paso = 1; paso <= n; paso++) {
      const indice = (activo + paso) % n
      const candidato = navegables[indice]
      if (candidato && normalizar(candidato.etiqueta ?? '').startsWith(letra)) {
        evento.preventDefault()
        setActivo(indice)
        return
      }
    }
  }

  const pintarItem = (el: ElementoMenu): ReactNode => {
    const indice = navegables.indexOf(el)
    const esActivo = indice >= 0 && indice === activo
    const tieneSubmenu = Boolean(el.hijos?.length)
    const subAbierto = abierto === el.clave
    const idSubmenu = `${base}-sub-${el.clave}`
    const seleccion = el.rol === 'menuitemradio' || el.rol === 'menuitemcheckbox'
    const boton = (
      <button
        key={el.clave}
        ref={(nodo) => {
          if (nodo) botones.current.set(el.clave, nodo)
          else botones.current.delete(el.clave)
        }}
        type="button"
        role={el.rol ?? 'menuitem'}
        tabIndex={esActivo ? 0 : -1}
        className={cx('ay-menu__item', el.peligro && 'ay-menu__item--danger')}
        // Dropdown Menu: deshabilitado nativo, presente pero omitido por las flechas.
        // Context Menu: aria-disabled, recorrible y no activable.
        disabled={!recorrerDeshabilitados && el.deshabilitado ? true : undefined}
        aria-disabled={recorrerDeshabilitados && el.deshabilitado ? true : undefined}
        aria-checked={seleccion ? Boolean(el.marcado) : undefined}
        aria-haspopup={tieneSubmenu ? 'menu' : undefined}
        aria-expanded={tieneSubmenu ? subAbierto : undefined}
        aria-controls={subAbierto ? idSubmenu : undefined}
        data-active={esActivo ? '' : undefined}
        onClick={() => {
          if (indice >= 0) setActivo(indice)
          activar(el)
        }}
      >
        {el.icono}
        <span>
          {el.etiqueta}
          {el.motivo && el.deshabilitado ? <small className="ay-menu__reason">{el.motivo}</small> : null}
        </span>
        {el.atajo ? (
          atajo === 'kbd' ? (
            <kbd className="ay-menu__kbd">{el.atajo}</kbd>
          ) : (
            <span className="ay-menu__shortcut">{el.atajo}</span>
          )
        ) : null}
        {tieneSubmenu ? <IconoSubmenu /> : null}
      </button>
    )
    if (!tieneSubmenu) return boton
    return (
      <div key={el.clave} role="none" className="ay-menu__sub">
        {boton}
        {subAbierto ? (
          <Submenu
            id={idSubmenu}
            ancla={botones.current.get(el.clave) ?? null}
            elementos={el.hijos ?? []}
            etiqueta={el.etiqueta}
            clase={clase}
            recorrerDeshabilitados={recorrerDeshabilitados}
            atajo={atajo}
            separador={separador}
            alCerrar={(motivo) => {
              if (motivo === 'eleccion') alCerrar('eleccion')
              // Tab burbujea hasta esta lista, que cierra todo; Escape y flecha
              // izquierda cierran solo el submenú y el foco vuelve al ítem padre.
              else if (motivo !== 'tab') setAbierto(null)
            }}
          />
        ) : null}
      </div>
    )
  }

  const nodos: ReactNode[] = []
  for (let i = 0; i < elementos.length; ) {
    const el = elementos[i] as ElementoMenu
    if (el.tipo === 'separator') {
      nodos.push(
        separador === 'hr' ? (
          <hr key={el.clave} className="ay-menu__sep" role="separator" />
        ) : (
          <div key={el.clave} role="separator" className="ay-menu__sep" />
        ),
      )
      i += 1
      continue
    }
    if (el.tipo === 'group') {
      // Un grupo con nombre (role=group) y no un <p> suelto: dentro de role=menu solo
      // caben ítems, grupos y separadores, y el lector anuncia el nombre del grupo.
      const miembros: ElementoMenu[] = []
      let j = i + 1
      while (j < elementos.length && (elementos[j] as ElementoMenu).tipo === 'item') {
        miembros.push(elementos[j] as ElementoMenu)
        j += 1
      }
      const idCabecera = `${base}-grupo-${el.clave}`
      nodos.push(
        <div key={el.clave} role="group" aria-labelledby={idCabecera}>
          <p className="ay-menu__group" id={idCabecera} aria-hidden="true">
            {el.etiqueta}
          </p>
          {miembros.map(pintarItem)}
        </div>,
      )
      i = j
      continue
    }
    nodos.push(pintarItem(el))
    i += 1
  }

  return (
    <div
      {...resto}
      ref={(nodo) => {
        contenedor.current = nodo
        if (typeof refMenu === 'function') refMenu(nodo)
        else if (refMenu) (refMenu as { current: HTMLDivElement | null }).current = nodo
      }}
      className={clase}
      role="menu"
      tabIndex={-1}
      data-ay-flotante=""
      onKeyDown={alTeclado}
    >
      {nodos}
    </div>
  )
}

interface PropsSubmenu {
  id: string
  ancla: HTMLElement | null
  elementos: ElementoMenu[]
  etiqueta?: string
  clase: string
  recorrerDeshabilitados: boolean
  atajo: 'kbd' | 'shortcut'
  separador: 'hr' | 'div'
  alCerrar: (motivo: MotivoCierre) => void
}

/** Un submenú se coloca junto a su ítem padre y se voltea a la izquierda si no cabe. */
function Submenu({ id, ancla, elementos, etiqueta, clase, alCerrar, ...opciones }: PropsSubmenu) {
  const menu = useRef<HTMLDivElement | null>(null)
  const [estilo, setEstilo] = useState<CSSProperties>({})

  useEfectoDeLayout(() => {
    if (!ancla || !menu.current) return
    const r = ancla.getBoundingClientRect()
    const propio = menu.current.getBoundingClientRect()
    // El área útil, sin las barras de scroll: con innerWidth el submenú pegado al borde
    // quedaba encima de la barra vertical.
    const { ancho, alto } = areaVisible()
    let x = r.right
    if (x + propio.width > ancho) x = Math.max(0, r.left - propio.width)
    let y = r.top
    if (y + propio.height > alto) y = Math.max(0, alto - propio.height)
    setEstilo({ ['--ay-x' as string]: `${x}px`, ['--ay-y' as string]: `${y}px` })
  }, [ancla])

  return (
    <ListaMenu
      {...opciones}
      id={id}
      aria-label={etiqueta}
      clase={cx(clase, 'ay-menu--submenu')}
      style={estilo}
      submenu
      focoInicial="primero"
      elementos={elementos}
      alCerrar={alCerrar}
      refMenu={menu}
    />
  )
}

import { forwardRef, useEffect, useId, useRef } from 'react'
import type { HTMLAttributes, ReactNode, RefObject } from 'react'
import { cx } from '../../utiles.js'
import { activarCapa, enfocables } from './_dom.js'
import { IconoCerrar } from './_iconos.js'
import { enCapa, usePantallaCompacta, useRefsCombinadas, useUltimo } from './_internos.js'

export type TamanoModal = 'sm' | 'md' | 'lg'

export interface PropsModal extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'title'> {
  /** Visibilidad controlada. Cerrado, el modal no está en el DOM. */
  open?: boolean
  /** Cambio de visibilidad: lo piden la X, Escape y el clic en el scrim. Con cambios sin
   *  guardar, quien consume no cierra aquí sino que pide confirmación antes de descartar. */
  onOpenChange: (open: boolean) => void
  /** Título; obligatorio, porque es el nombre accesible: sin él el lector anuncia
   *  «diálogo» y nada más. Nombra la tarea o la pregunta —«Cancelar la reserva de la
   *  unidad 402»—. */
  title: string
  /** Acciones del pie, con la salida segura a la izquierda de la primaria. El pie queda
   *  fijo cuando el cuerpo se desplaza. */
  footer?: ReactNode
  /** Ancho de la superficie: `sm` para confirmaciones, `md` por defecto, `lg` para
   *  formularios y detalles. */
  size?: TamanoModal
  /** Permite cerrar con Escape y con clic en el scrim. Con una operación en curso se pasa
   *  `false`: los dos cierres quedan bloqueados mientras dura. */
  dismissible?: boolean
  /** Elemento que recibe el foco al abrir. Sin él, el foco va al primer control
   *  interactivo y, si no hay ninguno, al título. */
  initialFocus?: RefObject<HTMLElement | null>
}

/**
 * Capa que interrumpe el flujo y atrapa el foco hasta que la tarea se resuelve o se
 * descarta. `role="dialog"` con `aria-modal` y el título como nombre; el fondo queda
 * inerte, el scroll del documento bloqueado y, al cerrar, el foco vuelve al disparador.
 * Por debajo del breakpoint sm se ancla abajo a ancho completo.
 */
export const Modal = forwardRef<HTMLDivElement, PropsModal>(function Modal(
  {
    open = false,
    onOpenChange,
    title,
    footer,
    size = 'md',
    dismissible = true,
    initialFocus,
    children,
    ...resto
  },
  ref,
) {
  const id = useId()
  const idTitulo = `${id}-titulo`
  const panel = useRef<HTMLDivElement | null>(null)
  const velo = useRef<HTMLDivElement | null>(null)
  const titulo = useRef<HTMLHeadingElement | null>(null)
  const refPanel = useRefsCombinadas(ref, panel)
  const compacta = usePantallaCompacta('sm', open)
  const ultimo = useUltimo({ onOpenChange, dismissible, initialFocus })

  useEffect(() => {
    const superficie = panel.current
    if (!open || !superficie) return
    return activarCapa({
      panel: superficie,
      nodos: [velo.current, superficie].filter((n): n is HTMLDivElement => n !== null),
      modal: true,
      alEscape: () => {
        if (ultimo.current.dismissible) ultimo.current.onOpenChange?.(false)
      },
      focoInicial: () =>
        ultimo.current.initialFocus?.current ?? enfocables(superficie)[0] ?? titulo.current,
    })
  }, [open, ultimo])

  if (!open) return null
  const cerrar = (): void => onOpenChange?.(false)

  return enCapa(
    <>
      <div
        ref={velo}
        className="ay-scrim"
        aria-hidden="true"
        onClick={() => {
          if (dismissible) cerrar()
        }}
      />
      <div
        {...resto}
        ref={refPanel}
        className={cx('ay-modal', `ay-modal--${size}`)}
        role="dialog"
        aria-modal="true"
        aria-labelledby={idTitulo}
        tabIndex={-1}
        data-compacto={compacta ? '' : undefined}
      >
        <header className="ay-modal__header">
          <h2 className="ay-modal__title" id={idTitulo} ref={titulo} tabIndex={-1}>
            {title}
          </h2>
          <button type="button" className="ay-iconbtn ay-iconbtn--ghost" aria-label="Cerrar" onClick={cerrar}>
            <IconoCerrar />
          </button>
        </header>
        <div className="ay-modal__body">{children}</div>
        {footer ? <footer className="ay-modal__footer">{footer}</footer> : null}
      </div>
    </>,
  )
})

import { forwardRef, useId, useMemo, useRef, useState } from 'react'
import type { HTMLAttributes, KeyboardEvent as EventoTeclado } from 'react'
import { cx } from '../../utiles.js'
import {
  claveDia,
  comoFecha,
  enMinuscula,
  fechaCorta,
  mismoDia,
  parsearFecha,
  patronDeFecha,
  primeroDeMes,
  sinHora,
  unir,
} from './_fechas.js'
import { aLaHora, horaDe, horasDeLaLista, masCercana, normalizarHora } from './_horas.js'
import { IconoCalendarioReloj } from './_iconos.js'
import { claveDeFechas, enfocarTrasPintar, useCerrarAlSalir, useSuperficieEnCapa, useTextoDe } from './_internos.js'
import { ListaHoras } from './_ListaHoras.js'
import { RejillaCalendario } from './_Rejilla.js'

export type DateTimePickerSize = 'md' | 'lg'

export interface PropsDateTimePicker extends Omit<HTMLAttributes<HTMLFieldSetElement>, 'className' | 'onSelect'> {
  /** Nombre del momento; obligatorio. Es la leyenda del grupo: «Cita de firma». */
  label: string
  /** Momento completo, fecha y hora. `null` mientras falte cualquiera de las dos. */
  value?: Date | null
  /** Cambio de momento. Con una sola parte llega `null`: el valor no se guarda a medias. */
  onValueChange?: (d: Date | null) => void
  /** Momento mínimo. Se comprueba sobre el par: una fecha válida con una hora anterior
   *  sigue siendo un momento inválido. Si cae el mismo día, las horas pasadas no se ofrecen. */
  minDateTime?: Date
  /** Momento máximo. */
  maxDateTime?: Date
  /** Minutos entre las horas de la lista. */
  timeStep?: number
  /** Zona en la que se interpreta el momento, escrita completa: «hora de Madrid (CET)». */
  timezone?: string
  /** Muestra la zona bajo los campos. Una cita sin zona es ambigua cuando el dato se
   *  comparte entre oficinas. */
  showTimezone?: boolean
  /** Mensaje único del par. Uno por campo haría corregir la fecha y seguir fallando por la hora. */
  error?: string
  /** Formato de la fecha. */
  locale?: string
  /** Altura de los campos: `md` por omisión, `lg` en pantallas de cita. */
  size?: DateTimePickerSize
}

/**
 * Un momento concreto: fecha y hora como un solo valor, validadas juntas y con un único
 * mensaje de error para el par. Cada campo conserva su etiqueta accesible aunque
 * compartan la superficie combinada de calendario y horas.
 */
export const DateTimePicker = forwardRef<HTMLFieldSetElement, PropsDateTimePicker>(function DateTimePicker(
  {
    label,
    value = null,
    onValueChange,
    minDateTime,
    maxDateTime,
    timeStep = 30,
    timezone,
    showTimezone = false,
    error,
    locale = 'es-PE',
    size = 'md',
    onBlur,
    ...resto
  },
  ref,
) {
  const id = useId()
  const idFecha = `${id}-fecha`
  const idHora = `${id}-hora`
  const idError = `${id}-error`
  const idZona = `${id}-tz`
  const idSuperficie = `${id}-surface`
  const idLista = `${id}-list`
  const min = comoFecha(minDateTime)
  const max = comoFecha(maxDateTime)
  const patron = patronDeFecha(locale)

  const valorProp = comoFecha(value) ?? null
  const claveProp = claveDeFechas(valorProp)
  const [fecha, setFecha] = useState<Date | null>(valorProp ? sinHora(valorProp) : null)
  const [hora, setHora] = useState<string | null>(valorProp ? horaDe(valorProp) : null)
  const [propAnterior, setPropAnterior] = useState(claveProp)
  // Lo último que este campo emitió. Con `value` controlado, el `null` que se emite por
  // falta de hora vuelve como prop: ese eco no puede borrar la fecha que ya se escribió.
  const [ultimo, setUltimo] = useState(claveProp)
  if (propAnterior !== claveProp) {
    setPropAnterior(claveProp)
    if (claveProp !== ultimo) {
      setFecha(valorProp ? sinHora(valorProp) : null)
      setHora(valorProp ? horaDe(valorProp) : null)
      setUltimo(claveProp)
    }
  }
  const [textoFecha, setTextoFecha] = useTextoDe(`${claveDeFechas(fecha)}|${locale}`, () =>
    fecha ? fechaCorta(fecha, locale) : '',
  )
  const [textoHora, setTextoHora] = useTextoDe(String(hora), () => hora ?? '')
  const [errorPar, setErrorPar] = useState<string | null>(null)
  const [abierto, setAbierto] = useState(false)
  const [enfocarCalendario, setEnfocarCalendario] = useState(false)
  const [mes, setMes] = useState(() => primeroDeMes(fecha ?? new Date()))
  const [activoHora, setActivoHora] = useState(-1)
  const origen = useRef<HTMLElement | null>(null)
  const disparador = useRef<HTMLButtonElement>(null)
  const superficie = useRef<HTMLDivElement>(null)

  // Si el mínimo cae el mismo día, las horas ya pasadas no aparecen en la lista.
  const horaMinima = min && fecha && mismoDia(fecha, min) ? horaDe(min) : undefined
  const horaMaxima = max && fecha && mismoDia(fecha, max) ? horaDe(max) : undefined
  const horas = useMemo(() => horasDeLaLista(timeStep, horaMinima, horaMaxima), [timeStep, horaMinima, horaMaxima])

  const cerrar = (devolverFoco: boolean) => {
    setAbierto(false)
    setEnfocarCalendario(false)
    if (devolverFoco) (origen.current ?? disparador.current)?.focus()
  }
  const { raiz, alSalir } = useCerrarAlSalir(abierto, () => cerrar(false))
  useSuperficieEnCapa(abierto, superficie, raiz)

  const emitir = (siguiente: Date | null) => {
    const clave = claveDeFechas(siguiente)
    if (clave === ultimo) return
    setUltimo(clave)
    onValueChange?.(siguiente)
  }

  /** El par se valida junto: fecha válida con hora inválida sigue siendo un momento inválido. */
  const revalidar = (f: Date | null, h: string | null) => {
    if (!f || !h) {
      setErrorPar(null)
      return emitir(null) // no se guarda a medias
    }
    const [hh = 0, mm = 0] = h.split(':').map(Number)
    const m = new Date(f.getFullYear(), f.getMonth(), f.getDate(), hh, mm)
    const largo = { dateStyle: 'long', timeStyle: 'short' } as const
    if (min && m < min) return setErrorPar(`Elige un momento posterior a ${min.toLocaleString(locale, largo)}`)
    if (max && m > max) return setErrorPar(`Elige un momento anterior a ${max.toLocaleString(locale, largo)}`)
    setErrorPar(null)
    emitir(m)
  }

  const validarFecha = () => {
    const r = parsearFecha(textoFecha, locale)
    if (r === 'invalida') return setErrorPar(`La fecha: usa el formato ${patron}`)
    setFecha(r)
    if (r) setTextoFecha(fechaCorta(r, locale))
    revalidar(r, hora)
  }

  const validarHora = () => {
    const r = normalizarHora(textoHora)
    if (r === 'invalida') return setErrorPar('La hora: usa el formato hh:mm')
    setHora(r)
    setTextoHora(r ?? '')
    revalidar(fecha, r)
  }

  const abrir = (quien: HTMLElement | null, foco: 'fecha' | 'hora') => {
    origen.current = quien
    setMes(primeroDeMes(fecha ?? new Date()))
    setActivoHora(masCercana(horas, hora ?? horaDe(new Date())))
    setAbierto(true)
    if (foco === 'fecha') setEnfocarCalendario(true)
    else enfocarTrasPintar(() => document.getElementById(`${idLista}-opt-${Math.max(0, masCercana(horas, hora ?? horaDe(new Date())))}`))
  }

  const elegirDia = (d: Date) => {
    setFecha(d)
    setTextoFecha(fechaCorta(d, locale))
    revalidar(d, hora)
    // Con la fecha puesta, se pasa a la hora: el campo de fecha relleno parece tarea terminada.
    if (!hora) enfocarTrasPintar(() => document.getElementById(`${idLista}-opt-${Math.max(0, activoHora)}`))
  }

  const elegirHora = (h: string) => {
    setHora(h)
    setTextoHora(h)
    revalidar(fecha, h)
    if (fecha) cerrar(true)
  }

  /** Pegar un momento completo lo reparte entre los dos campos. */
  const alPegar = (texto: string): boolean => {
    const m = /^\s*(\S+)[\sT,]+(\d{1,2}[:.]\d{2}(?:\s?[ap]\.?\s?m\.?)?)\s*$/i.exec(texto)
    if (!m) return false
    const f = parsearFecha(m[1] ?? '', locale)
    const h = normalizarHora(m[2] ?? '')
    if (!(f instanceof Date) || typeof h !== 'string') return false
    setFecha(f)
    setHora(h)
    setTextoFecha(fechaCorta(f, locale))
    setTextoHora(h)
    revalidar(f, h)
    return true
  }

  const mensaje = error ?? errorPar
  const describe = unir(mensaje && idError, showTimezone && timezone && idZona)

  const teclas = (foco: 'fecha' | 'hora', validar: () => void) => (e: EventoTeclado<HTMLInputElement>) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault()
      abrir(e.currentTarget, foco)
    } else if (e.key === 'Enter') {
      e.preventDefault()
      validar()
    } else if (e.key === 'Escape' && abierto) {
      e.preventDefault()
      setAbierto(false)
    }
  }

  return (
    <fieldset
      {...resto}
      ref={(el) => {
        raiz.current = el
        if (typeof ref === 'function') ref(el)
        else if (ref) ref.current = el
      }}
      className={cx('ay-datetime', `ay-datetime--${size}`)}
      onBlur={(e) => {
        onBlur?.(e)
        alSalir(e)
      }}
    >
      <legend className="ay-label">{label}</legend>

      <div className="ay-datetime__fields">
        {/* cada campo conserva su etiqueta aunque compartan superficie */}
        <div className="ay-field">
          <label className="ay-label ay-label--sm" htmlFor={idFecha}>
            Fecha
          </label>
          <input
            className="ay-datetime__date"
            id={idFecha}
            type="text"
            inputMode="numeric"
            placeholder={patron}
            value={textoFecha}
            aria-describedby={describe}
            aria-invalid={mensaje ? true : undefined}
            onChange={(e) => setTextoFecha(e.target.value)}
            onBlur={validarFecha}
            onPaste={(e) => {
              if (alPegar(e.clipboardData.getData('text'))) e.preventDefault()
            }}
            onKeyDown={teclas('fecha', validarFecha)}
          />
        </div>

        <div className="ay-field">
          <label className="ay-label ay-label--sm" htmlFor={idHora}>
            Hora
          </label>
          <input
            className="ay-datetime__time"
            id={idHora}
            type="text"
            inputMode="numeric"
            placeholder="hh:mm"
            value={textoHora}
            aria-describedby={describe}
            aria-invalid={mensaje ? true : undefined}
            onChange={(e) => setTextoHora(e.target.value)}
            onBlur={validarHora}
            onKeyDown={teclas('hora', validarHora)}
          />
        </div>

        <button
          ref={disparador}
          type="button"
          className="ay-datetime__trigger"
          aria-label="Abrir el calendario y las horas"
          aria-haspopup="dialog"
          aria-expanded={abierto}
          aria-controls={idSuperficie}
          onClick={(e) => (abierto ? cerrar(false) : abrir(e.currentTarget, 'fecha'))}
        >
          <IconoCalendarioReloj />
        </button>
      </div>

      {showTimezone && timezone && (
        // una cita sin zona es ambigua: «a las nueve» son dos momentos para Lima y Madrid
        <p className="ay-datetime__tz" id={idZona}>
          {timezone}
        </p>
      )}

      {mensaje && (
        <p className="ay-error" id={idError}>
          {mensaje}
        </p>
      )}

      <div
        ref={superficie}
        className="ay-datetime__surface"
        id={idSuperficie}
        role="dialog"
        aria-label={`Elegir ${enMinuscula(label)}`}
        hidden={!abierto}
        onKeyDown={(e) => {
          if (e.key === 'Escape') {
            e.preventDefault()
            e.stopPropagation()
            cerrar(true)
          }
        }}
      >
        <RejillaCalendario
          mes={mes}
          meses={1}
          onMes={setMes}
          locale={locale}
          etiqueta="Fecha"
          tamano="md"
          min={min ? sinHora(min) : undefined}
          max={max ? sinHora(max) : undefined}
          estado={(d) => ({ elegido: !!fecha && claveDia(d) === claveDia(fecha), enTramo: false })}
          onElegir={elegirDia}
          activoPreferido={fecha ?? undefined}
          enfocar={enfocarCalendario}
        />
        <ListaHoras
          id={idLista}
          horas={horas}
          valor={hora}
          activo={activoHora}
          formato="24h"
          conFranjas={false}
          onElegir={elegirHora}
          onActivo={setActivoHora}
          foco="real"
        />
      </div>

      <p className="ay-visually-hidden" aria-live="polite">
        {fecha && !hora
          ? 'Elige la hora'
          : fecha && hora && !mensaje
            ? `${fecha.toLocaleDateString(locale, { dateStyle: 'full' })} ${aLaHora(hora)}`
            : ''}
      </p>
    </fieldset>
  )
})

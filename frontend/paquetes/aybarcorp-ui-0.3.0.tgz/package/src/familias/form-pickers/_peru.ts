/**
 * Reglas peruanas de Document Input, Phone Input y Ubigeo Select. Son datos de
 * referencia públicos (formatos de SUNAT y RENIEC, códigos de área, códigos INEI de
 * departamento); ningún dato de una persona.
 */

export type TipoDocumento = 'dni' | 'ruc' | 'ce' | 'pasaporte'

export interface ReglaDocumento {
  etiqueta: string
  maxLength: number
  numerico: boolean
  ayuda: string
  /** Padrón que resuelve el titular: se dice como dato, no como aprobación. */
  padron: string
  validar: (v: string) => string | null
}

/**
 * Módulo 11 de SUNAT sobre los diez primeros dígitos. Un RUC con once dígitos y una
 * tecla mal pulsada es muy distinto de uno incompleto: el verificador los distingue
 * antes de consultar.
 */
export function digitoVerificadorRuc(ruc: string): boolean {
  if (!/^\d{11}$/.test(ruc)) return false
  const pesos = [5, 4, 3, 2, 7, 6, 5, 4, 3, 2]
  const suma = pesos.reduce((acc, peso, i) => acc + peso * Number(ruc[i]), 0)
  const resto = 11 - (suma % 11)
  const esperado = resto === 10 ? 0 : resto === 11 ? 1 : resto
  return esperado === Number(ruc[10])
}

export const REGLAS_DOCUMENTO: Record<TipoDocumento, ReglaDocumento> = {
  dni: {
    etiqueta: 'DNI',
    maxLength: 8,
    numerico: true,
    ayuda: 'Ocho dígitos, sin puntos ni guiones.',
    padron: 'RENIEC',
    validar: (v) => (/^\d{8}$/.test(v) ? null : 'El DNI tiene ocho dígitos.'),
  },
  ruc: {
    etiqueta: 'RUC',
    maxLength: 11,
    numerico: true,
    ayuda: 'Once dígitos. Empieza por 10, 15, 17 o 20.',
    padron: 'SUNAT',
    validar: (v) => {
      if (!/^\d{11}$/.test(v)) return 'El RUC tiene once dígitos y empieza por 10, 15, 17 o 20.'
      if (!/^(10|15|17|20)/.test(v)) return 'El RUC empieza por 10, 15, 17 o 20.'
      return digitoVerificadorRuc(v) ? null : 'El dígito verificador del RUC no cuadra: revisa que no haya una cifra cambiada.'
    },
  },
  ce: {
    etiqueta: 'C. E.',
    maxLength: 12,
    numerico: false,
    ayuda: 'Hasta doce caracteres, letras y números.',
    padron: 'Migraciones',
    validar: (v) => (/^[A-Za-z0-9]{1,12}$/.test(v) ? null : 'El carné admite hasta doce letras o números.'),
  },
  pasaporte: {
    etiqueta: 'Pasaporte',
    maxLength: 12,
    numerico: false,
    ayuda: 'Tal y como aparece en el pasaporte.',
    padron: 'Migraciones',
    validar: (v) => (v.trim().length > 0 ? null : 'Escribe el número del pasaporte.'),
  },
}

/** Copiar de un PDF o de un correo trae guiones, puntos y espacios: se limpian, no se rechazan. */
export const limpiarDocumento = (v: string, numerico: boolean): string =>
  numerico ? v.replace(/\D/g, '') : v.replace(/[\s.\-]/g, '')

// ── Teléfono ─────────────────────────────────────────────────────────────────

export type TipoTelefono = 'mobile' | 'landline' | 'any'

/** Prefijos de país admitidos en la variante internacional. */
export const PREFIJOS: Record<string, string> = {
  PE: '+51',
  AR: '+54',
  BO: '+591',
  BR: '+55',
  CL: '+56',
  CO: '+57',
  EC: '+593',
  ES: '+34',
  MX: '+52',
  US: '+1',
}

/** Códigos de área de la red fija peruana: 1 en Lima y Callao, dos cifras en provincias. */
const AREAS: Record<string, string> = {
  '1': 'Lima',
  '41': 'Amazonas',
  '42': 'San Martín',
  '43': 'Áncash',
  '44': 'La Libertad',
  '51': 'Puno',
  '52': 'Tacna',
  '53': 'Moquegua',
  '54': 'Arequipa',
  '56': 'Ica',
  '61': 'Ucayali',
  '62': 'Huánuco',
  '63': 'Pasco',
  '64': 'Junín',
  '65': 'Loreto',
  '66': 'Ayacucho',
  '67': 'Huancavelica',
  '72': 'Tumbes',
  '73': 'Piura',
  '74': 'Lambayeque',
  '76': 'Cajamarca',
  '82': 'Madre de Dios',
  '83': 'Apurímac',
  '84': 'Cusco',
}

const MOVIL = /^9\d{8}$/

/** El área de un fijo: «1» o dos cifras, según empiece. */
export function areaDe(v: string): string | null {
  if (v.startsWith('1')) return '1'
  const dos = v.slice(0, 2)
  return AREAS[dos] ? dos : null
}

/**
 * Quita lo que trae un número pegado de una firma de correo: espacios, guiones,
 * paréntesis y el prefijo del país si viene repetido.
 */
export function normalizarTelefono(bruto: string, prefijo = '+51'): string {
  let v = bruto.trim().replace(/[^\d+]/g, '')
  const cifras = prefijo.replace('+', '')
  if (v.startsWith('+')) v = v.startsWith(prefijo) ? v.slice(prefijo.length) : v.slice(1)
  else if (v.startsWith(`00${cifras}`)) v = v.slice(2 + cifras.length)
  else if (prefijo === '+51' && v.length === 11 && v.startsWith('51')) v = v.slice(2)
  v = v.replace(/\D/g, '')
  // «(01) 456-7890»: el 0 de larga distancia nacional no es parte del número.
  if (prefijo === '+51' && v.startsWith('0')) v = v.slice(1)
  return v.slice(0, 15)
}

/** 3-3-3 en móvil; un fijo se agrupa tras el código de área. Solo visual. */
export function agruparTelefono(v: string): string {
  if (v.startsWith('9') || v.length > 9) return v.replace(/(\d{3})(?=\d)/g, '$1 ').trim()
  const area = areaDe(v)
  return area && v.length > area.length ? `${area} ${v.slice(area.length)}` : v
}

/** Lo que se reconoció: móvil, o fijo con la ciudad de su código de área. */
export function reconocerTelefono(v: string): { tipo: 'mobile' | 'landline' | null; nota: string } {
  if (MOVIL.test(v)) return { tipo: 'mobile', nota: 'Móvil' }
  const area = areaDe(v)
  if (area && v.length === 8) return { tipo: 'landline', nota: `Fijo · ${AREAS[area]}` }
  return { tipo: null, nota: '' }
}

/** La regla incumplida, concreta: «falta un dígito» y «no es válido» no son el mismo problema. */
export function validarTelefono(v: string, kind: TipoTelefono): string | null {
  if (!v) return null
  const esMovil = kind === 'mobile' || (kind === 'any' && v.startsWith('9'))
  if (esMovil) {
    if (!v.startsWith('9')) return 'El móvil peruano empieza por 9 y tiene nueve dígitos.'
    if (v.length < 9) {
      const faltan = 9 - v.length
      return faltan === 1
        ? 'Falta un dígito: el móvil peruano tiene nueve.'
        : `Faltan ${faltan} dígitos: el móvil peruano tiene nueve.`
    }
    return MOVIL.test(v) ? null : 'El móvil peruano empieza por 9 y tiene nueve dígitos.'
  }
  if (!areaDe(v)) return 'El fijo empieza por el código de área: 1 en Lima o dos cifras en provincias.'
  return v.length === 8 ? null : 'El fijo lleva el código de área y el número: ocho dígitos en total.'
}

// ── Ubigeo ───────────────────────────────────────────────────────────────────

/** Una opción de un nivel de Ubigeo Select: código INEI y nombre. */
export interface OpcionUbigeo {
  codigo: string
  nombre: string
}

/**
 * Los departamentos con su código INEI. El Callao es provincia constitucional, pero se
 * lista como departamento, que es como lo espera quien rellena una dirección.
 */
export const DEPARTAMENTOS: OpcionUbigeo[] = [
  { codigo: '01', nombre: 'Amazonas' },
  { codigo: '02', nombre: 'Áncash' },
  { codigo: '03', nombre: 'Apurímac' },
  { codigo: '04', nombre: 'Arequipa' },
  { codigo: '05', nombre: 'Ayacucho' },
  { codigo: '06', nombre: 'Cajamarca' },
  { codigo: '07', nombre: 'Callao' },
  { codigo: '08', nombre: 'Cusco' },
  { codigo: '09', nombre: 'Huancavelica' },
  { codigo: '10', nombre: 'Huánuco' },
  { codigo: '11', nombre: 'Ica' },
  { codigo: '12', nombre: 'Junín' },
  { codigo: '13', nombre: 'La Libertad' },
  { codigo: '14', nombre: 'Lambayeque' },
  { codigo: '15', nombre: 'Lima' },
  { codigo: '16', nombre: 'Loreto' },
  { codigo: '17', nombre: 'Madre de Dios' },
  { codigo: '18', nombre: 'Moquegua' },
  { codigo: '19', nombre: 'Pasco' },
  { codigo: '20', nombre: 'Piura' },
  { codigo: '21', nombre: 'Puno' },
  { codigo: '22', nombre: 'San Martín' },
  { codigo: '23', nombre: 'Tacna' },
  { codigo: '24', nombre: 'Tumbes' },
  { codigo: '25', nombre: 'Ucayali' },
]

import type { ReactNode, SVGProps } from 'react'

/**
 * Iconos de la familia. Todos son decorativos —`aria-hidden`—: el nombre accesible lo
 * lleva siempre el control que los contiene. Trazo con `currentColor` para que el
 * color salga del token del control y cambie con el tema.
 */
function Icono({ tamano, children, ...resto }: SVGProps<SVGSVGElement> & { tamano: number; children: ReactNode }) {
  return (
    <svg
      {...resto}
      aria-hidden="true"
      focusable="false"
      width={tamano}
      height={tamano}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.75}
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {children}
    </svg>
  )
}

export const IconoCalendario = (props: SVGProps<SVGSVGElement>) => (
  <Icono tamano={18} {...props}>
    <rect x="3" y="5" width="18" height="16" rx="2" />
    <path d="M16 3v4M8 3v4M3 10h18" />
  </Icono>
)

export const IconoReloj = (props: SVGProps<SVGSVGElement>) => (
  <Icono tamano={18} {...props}>
    <circle cx="12" cy="12" r="9" />
    <path d="M12 7v5l3 2" />
  </Icono>
)

export const IconoCalendarioReloj = (props: SVGProps<SVGSVGElement>) => (
  <Icono tamano={18} {...props}>
    <path d="M11 21H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v4M16 3v4M8 3v4M3 10h18" />
    <circle cx="17" cy="17" r="4" />
    <path d="M17 15.5V17l1 1" />
  </Icono>
)

export const IconoSubir = (props: SVGProps<SVGSVGElement>) => (
  <Icono tamano={16} {...props}>
    <path d="M12 16V4M7 9l5-5 5 5M4 20h16" />
  </Icono>
)

export const IconoNubeSubir = (props: SVGProps<SVGSVGElement>) => (
  <Icono tamano={28} {...props}>
    <path d="M7 18a5 5 0 1 1 .9-9.9A6 6 0 0 1 19 10a4 4 0 0 1-1 7.9" />
    <path d="M12 12v9M9 15l3-3 3 3" />
  </Icono>
)

export const IconoCerrar = (props: SVGProps<SVGSVGElement>) => (
  <Icono tamano={16} {...props}>
    <path d="M6 6l12 12M18 6L6 18" />
  </Icono>
)

export const IconoAnterior = (props: SVGProps<SVGSVGElement>) => (
  <Icono tamano={18} {...props}>
    <path d="M15 6l-6 6 6 6" />
  </Icono>
)

export const IconoSiguiente = (props: SVGProps<SVGSVGElement>) => (
  <Icono tamano={18} {...props}>
    <path d="M9 6l6 6-6 6" />
  </Icono>
)

export const IconoCopiar = (props: SVGProps<SVGSVGElement>) => (
  <Icono tamano={16} {...props}>
    <rect x="9" y="9" width="12" height="12" rx="2" />
    <path d="M5 15V5a2 2 0 0 1 2-2h10" />
  </Icono>
)

export const IconoDesplegar = (props: SVGProps<SVGSVGElement>) => (
  <Icono tamano={16} {...props}>
    <path d="M6 9l6 6 6-6" />
  </Icono>
)

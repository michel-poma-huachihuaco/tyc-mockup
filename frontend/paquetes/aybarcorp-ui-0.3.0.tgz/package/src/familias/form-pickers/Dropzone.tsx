import { forwardRef, useEffect, useId, useRef, useState } from 'react'
import type { DragEvent as EventoArrastre, HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import { unir } from './_fechas.js'
import { admitido, formatosLegibles } from './_archivos.js'
import { IconoNubeSubir } from './_iconos.js'

export type DropzoneSize = 'sm' | 'md' | 'lg'

export interface PropsDropzone extends Omit<HTMLAttributes<HTMLDivElement>, 'className'> {
  /** Etiqueta del campo; obligatoria. */
  label: string
  /** Formatos admitidos, como el `accept` nativo: «.pdf,.jpg,.jpeg». */
  accept?: string
  /** Permite varios archivos. Sin ella, de varios soltados se añade el primero y se
   *  dice cuántos se descartaron. */
  multiple?: boolean
  /** Archivos añadidos, por arrastre o por el botón, ya filtrados por formato. */
  onFilesAdd?: (files: File[]) => void
  /** Requisitos asociados al input: «PDF o JPG, hasta 10 MB». */
  requirements?: string
  /** Desactiva el área y el botón: el área deja de responder al arrastre. */
  disabled?: boolean
  /** Alto del área: `md` por omisión, `lg` en pantallas de documentación y `sm`, una sola
   *  fila para paneles laterales. */
  size?: DropzoneSize
  /** Texto principal. Nombra las dos vías: arrastrar no existe en táctil ni con teclado. */
  instruction?: string
}

/**
 * Área amplia para soltar archivos arrastrados, con un botón dentro que es el control
 * real. El área no lleva `role` ni `tabIndex`: un recuadro enfocable que no responde al
 * teclado promete algo que no cumple.
 */
export const Dropzone = forwardRef<HTMLDivElement, PropsDropzone>(function Dropzone(
  {
    label,
    accept,
    multiple = false,
    onFilesAdd,
    requirements,
    disabled = false,
    size = 'md',
    instruction = 'Arrastra los archivos aquí o elígelos',
    ...resto
  },
  ref,
) {
  const id = useId()
  const idRequisitos = `${id}-req`
  const idRechazo = `${id}-rejected`
  const [arrastre, setArrastre] = useState(false)
  const [rechazo, setRechazo] = useState<string | null>(null)
  const [anuncio, setAnuncio] = useState('')
  // dragenter y dragleave se disparan también por los hijos: se cuenta la profundidad
  const profundidad = useRef(0)

  // Soltar fuera del área no abre el archivo en el navegador: se previene en la página.
  useEffect(() => {
    const parar = (e: DragEvent) => {
      if (e.dataTransfer?.types.includes('Files')) e.preventDefault()
    }
    window.addEventListener('dragover', parar)
    window.addEventListener('drop', parar)
    return () => {
      window.removeEventListener('dragover', parar)
      window.removeEventListener('drop', parar)
    }
  }, [])

  const procesar = (archivos: File[]) => {
    if (archivos.length === 0) return
    const validos = archivos.filter((f) => admitido(f, accept))
    if (validos.length === 0) {
      // Un solo anuncio con el formato esperado, no uno por archivo rechazado.
      setRechazo(`Solo se admiten ${formatosLegibles(accept)}`)
      return
    }
    const aceptados = multiple ? validos : validos.slice(0, 1)
    const descartados = archivos.length - aceptados.length
    setRechazo(
      descartados > 0
        ? `${descartados === 1 ? 'Se descartó 1 archivo' : `Se descartaron ${descartados} archivos`}: ${
            multiple ? `solo se admiten ${formatosLegibles(accept)}` : 'solo se admite un archivo'
          }.`
        : null,
    )
    onFilesAdd?.(aceptados)
    // por nombre, no «2 archivos añadidos» sin más: quien arrastra no ve la lista
    setAnuncio(aceptados.map((f) => `${f.name} añadido`).join('. '))
  }

  const soltar = (e: EventoArrastre<HTMLDivElement>) => {
    e.preventDefault()
    profundidad.current = 0
    setArrastre(false)
    if (disabled) return
    const items = Array.from(e.dataTransfer.items ?? [])
    // Una carpeta llega como entrada de directorio, sin tipo: se explica, no se ignora.
    const carpeta = items.some((it) => {
      const entrada = (it as DataTransferItem & { webkitGetAsEntry?: () => { isDirectory: boolean } | null })
        .webkitGetAsEntry?.()
      return !!entrada?.isDirectory
    })
    if (carpeta) {
      setRechazo('Solo se admiten archivos, no carpetas.')
      return
    }
    const archivos = Array.from(e.dataTransfer.files ?? [])
    // Texto o una imagen arrastrada desde otra pestaña: no hay archivo que añadir.
    if (archivos.length === 0) {
      setRechazo('Solo se admiten archivos. Arrastra el archivo desde tu equipo o elígelo con el botón.')
      return
    }
    procesar(archivos)
  }

  return (
    <div {...resto} ref={ref} className="ay-field">
      <label className="ay-label" htmlFor={id}>
        {label}
      </label>
      {requirements && (
        <p className="ay-help" id={idRequisitos}>
          {requirements}
        </p>
      )}

      {/* sin role ni tabindex: el control real es el botón de dentro */}
      <div
        className={cx('ay-dropzone', `ay-dropzone--${size}`, disabled && 'ay-dropzone--disabled')}
        data-dragover={arrastre}
        data-rejected={!!rechazo}
        onDragEnter={(e) => {
          e.preventDefault()
          if (disabled) return
          profundidad.current += 1
          setArrastre(true)
        }}
        onDragOver={(e) => {
          e.preventDefault() // si no, el navegador abre el archivo
          if (disabled) e.dataTransfer.dropEffect = 'none'
        }}
        onDragLeave={(e) => {
          e.preventDefault()
          profundidad.current -= 1
          // al salir del área con el archivo aún arrastrado, el estado vuelve a reposo
          if (profundidad.current <= 0) {
            profundidad.current = 0
            setArrastre(false)
          }
        }}
        onDrop={soltar}
      >
        <IconoNubeSubir className="ay-dropzone__icon" />
        <p className="ay-dropzone__text">{arrastre ? 'Suelta los archivos para añadirlos' : instruction}</p>

        {/* el botón es el control real: teclado, táctil y dictado pasan por aquí */}
        <input
          className="ay-visually-hidden"
          id={id}
          type="file"
          accept={accept}
          multiple={multiple}
          disabled={disabled}
          aria-describedby={unir(requirements && idRequisitos, rechazo && idRechazo)}
          onChange={(e) => {
            procesar(Array.from(e.target.files ?? []))
            e.target.value = ''
          }}
        />
        <label
          className={cx('ay-btn', 'ay-btn--secondary', 'ay-btn--sm', disabled && 'ay-btn--disabled')}
          htmlFor={id}
          aria-disabled={disabled || undefined}
        >
          {multiple ? 'Elegir archivos' : 'Elegir archivo'}
        </label>
      </div>

      {rechazo && (
        <p className="ay-error" id={idRechazo} role="alert">
          {rechazo}
        </p>
      )}

      <p className="ay-visually-hidden" aria-live="polite">
        {anuncio}
      </p>
    </div>
  )
})

import { forwardRef, useId, useRef, useState } from 'react'
import type { HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import {
  comoFecha,
  enMinuscula,
  fechaCorta,
  fueraDeRango,
  mismoDia,
  patronDeFecha,
  primeroDeMes,
  sinHora,
  unir,
  validarFecha,
} from './_fechas.js'
import { IconoCalendario } from './_iconos.js'
import { claveDeFechas, useCerrarAlSalir, useEspejo, useSuperficieEnCapa, useTextoDe } from './_internos.js'
import { RejillaCalendario } from './_Rejilla.js'

export type DatePickerSize = 'md' | 'lg'
/** Acceso rápido sobre el calendario: «Hoy», «En una semana», «Fin de mes». */
export interface DateShortcut {
  label: string
  date: Date
}

export interface PropsDatePicker extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'onSelect'> {
  /** Etiqueta del campo; obligatoria. Nombra el dato: «Fecha de entrega prevista». */
  label: string
  /** Fecha elegida, sin hora. `null` es un campo vacío, nunca la fecha de hoy. */
  value?: Date | null
  /** Cambio de fecha: al elegir en el calendario, al usar un atajo o al salir del campo
   *  con una fecha válida. Vaciar el campo a mano envía `null`. */
  onValueChange?: (d: Date | null) => void
  /** Primera fecha permitida. Lo escrito antes de ella se avisa con el rango, no se borra. */
  minDate?: Date
  /** Última fecha permitida. */
  maxDate?: Date
  /** Deshabilita fechas concretas del calendario y las rechaza si se escriben. */
  isDateDisabled?: (d: Date) => boolean
  /** Formato del campo y calendario: con orden mes-día, el formato y el placeholder
   *  cambian juntos. */
  locale?: string
  /** Atajos en columna junto al calendario. Los nombres son concretos: «Hoy», no «H». */
  shortcuts?: Array<{ label: string; date: Date }>
  /** Mensaje de validación externo. Sustituye a los de formato y rango del propio campo. */
  error?: string
  /** Altura del campo: `md` por omisión, `lg` en formularios de una columna. */
  size?: DatePickerSize
  /** Deshabilita el campo y el disparador a la vez. */
  disabled?: boolean
}

/**
 * Campo de fecha con las dos vías siempre disponibles: escribirla —el campo nunca es de
 * solo lectura— o elegirla en un calendario anclado al campo. El formato esperado está
 * en la ayuda y en el placeholder desde el principio, no solo en el error.
 */
export const DatePicker = forwardRef<HTMLDivElement, PropsDatePicker>(function DatePicker(
  {
    label,
    value = null,
    onValueChange,
    minDate,
    maxDate,
    isDateDisabled,
    locale = 'es-PE',
    shortcuts,
    error,
    size = 'md',
    disabled = false,
    onBlur,
    ...resto
  },
  ref,
) {
  const id = useId()
  const idAyuda = `${id}-help`
  const idError = `${id}-error`
  const idSuperficie = `${id}-cal`
  const min = comoFecha(minDate)
  const max = comoFecha(maxDate)
  const patron = patronDeFecha(locale)

  const valorProp = comoFecha(value)
  const [fecha, setFecha] = useEspejo<Date | null>(valorProp ? sinHora(valorProp) : null, claveDeFechas)
  const [texto, setTexto] = useTextoDe(`${claveDeFechas(fecha)}|${locale}`, () =>
    fecha ? fechaCorta(fecha, locale) : '',
  )
  const [errorLocal, setErrorLocal] = useState<string | null>(null)
  const [abierto, setAbierto] = useState(false)
  const [mes, setMes] = useState(() => primeroDeMes(fecha ?? new Date()))
  const origen = useRef<'campo' | 'disparador'>('disparador')
  const campo = useRef<HTMLInputElement>(null)
  const disparador = useRef<HTMLButtonElement>(null)
  const superficie = useRef<HTMLDivElement>(null)

  const cerrar = (devolverFoco: boolean) => {
    setAbierto(false)
    // El foco vuelve a quien abrió: al disparador, o al campo si se abrió con flecha abajo.
    if (devolverFoco) (origen.current === 'campo' ? campo : disparador).current?.focus()
  }
  const { raiz, alSalir } = useCerrarAlSalir(abierto, () => cerrar(false))
  useSuperficieEnCapa(abierto, superficie, raiz)

  const abrir = (desde: 'campo' | 'disparador') => {
    origen.current = desde
    setMes(primeroDeMes(fecha ?? new Date()))
    setAbierto(true)
  }

  const fijar = (d: Date | null) => {
    setFecha(d)
    setErrorLocal(null)
    setTexto(d ? fechaCorta(d, locale) : '')
    onValueChange?.(d)
  }

  // Se valida al salir o con Enter, no en cada tecla: una fecha a medio escribir no es un error.
  const validar = () => {
    const r = validarFecha(texto, locale, min, max, isDateDisabled)
    if (r.error !== undefined) return setErrorLocal(r.error)
    if (r.fecha === null) return fijar(null) // vacío es null, no hoy
    if (!mismoDia(r.fecha, fecha)) fijar(r.fecha)
    else {
      setErrorLocal(null)
      setTexto(fechaCorta(r.fecha, locale)) // el año de dos cifras se muestra completo
    }
  }

  const mensaje = error ?? errorLocal

  return (
    <div
      {...resto}
      ref={(el) => {
        raiz.current = el
        if (typeof ref === 'function') ref(el)
        else if (ref) ref.current = el
      }}
      className="ay-field"
      onBlur={(e) => {
        onBlur?.(e)
        alSalir(e)
      }}
    >
      <label className="ay-label" htmlFor={id}>
        {label}
      </label>
      {/* el formato, desde el principio: no solo cuando algo falla */}
      <p className="ay-help" id={idAyuda}>
        {patron}
      </p>

      <div className={cx('ay-datepicker', `ay-datepicker--${size}`)} aria-invalid={mensaje ? true : undefined}>
        {/* editable siempre: teclear una fecha conocida es más rápido que abrir el calendario */}
        <input
          ref={campo}
          className="ay-datepicker__field"
          id={id}
          type="text"
          inputMode="numeric"
          placeholder={patron}
          aria-describedby={unir(idAyuda, mensaje && idError)}
          aria-invalid={mensaje ? true : undefined}
          disabled={disabled}
          value={texto}
          onChange={(e) => setTexto(e.target.value)}
          onBlur={validar}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              e.preventDefault()
              validar()
              setAbierto(false)
            } else if (e.key === 'ArrowDown') {
              e.preventDefault()
              abrir('campo')
            } else if (e.key === 'Escape' && abierto) {
              e.preventDefault()
              setAbierto(false)
            }
          }}
        />
        <button
          ref={disparador}
          type="button"
          className="ay-datepicker__trigger"
          aria-label="Abrir el calendario"
          aria-haspopup="dialog"
          aria-expanded={abierto}
          aria-controls={idSuperficie}
          disabled={disabled}
          onClick={() => (abierto ? cerrar(false) : abrir('disparador'))}
        >
          <IconoCalendario />
        </button>
      </div>

      {/* Anclada al campo y sin atrapar el foco: Escape basta y el campo de texto sigue a un Tab. */}
      <div
        ref={superficie}
        className="ay-datepicker__surface"
        id={idSuperficie}
        role="dialog"
        aria-label={`Elegir ${enMinuscula(label)}`}
        hidden={!abierto}
        onKeyDown={(e) => {
          if (e.key === 'Escape') {
            e.preventDefault()
            e.stopPropagation()
            cerrar(true)
          }
        }}
      >
        <RejillaCalendario
          mes={mes}
          meses={1}
          onMes={setMes}
          locale={locale}
          etiqueta={label}
          tamano="md"
          min={min}
          max={max}
          deshabilitada={isDateDisabled}
          estado={(d) => ({ elegido: mismoDia(d, fecha), enTramo: false })}
          onElegir={(d) => {
            fijar(d)
            cerrar(true)
          }}
          activoPreferido={fecha ?? undefined}
          enfocar={abierto}
        />
        {shortcuts && shortcuts.length > 0 && (
          <div className="ay-datepicker__shortcuts">
            {shortcuts.map((s) => {
              const d = comoFecha(s.date)
              const imposible = !d || fueraDeRango(d, min, max) || !!isDateDisabled?.(d)
              return (
                <button
                  key={s.label}
                  type="button"
                  className="ay-btn ay-btn--ghost ay-btn--sm"
                  disabled={imposible}
                  title={imposible ? 'Fuera del periodo permitido' : undefined}
                  onClick={() => {
                    if (!d) return
                    fijar(sinHora(d))
                    cerrar(true)
                  }}
                >
                  {s.label}
                </button>
              )
            })}
          </div>
        )}
      </div>

      {/* La fecha elegida, completa: confirma el 14 de febrero y no el 2 de febrero. */}
      <p className="ay-visually-hidden" aria-live="polite">
        {fecha ? fecha.toLocaleDateString(locale, { dateStyle: 'full' }) : ''}
      </p>

      {mensaje && (
        <p className="ay-error" id={idError}>
          {mensaje}
        </p>
      )}
    </div>
  )
})

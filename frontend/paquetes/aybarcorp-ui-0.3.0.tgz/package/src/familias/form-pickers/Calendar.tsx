import { forwardRef, useState } from 'react'
import type { HTMLAttributes } from 'react'
import { claveDia, comoFecha, mismoDia, primeroDeMes, sinHora } from './_fechas.js'
import { claveDeFechas, useEspejo } from './_internos.js'
import { RejillaCalendario } from './_Rejilla.js'
import type { EstadoDia } from './_Rejilla.js'

export type CalendarMode = 'single' | 'range' | 'multiple'
export type CalendarMonths = 1 | 2
export type CalendarSize = 'md' | 'lg'
/** Selección de Calendar: una fecha, un intervalo `[inicio, fin]` o varias fechas sueltas. */
export type CalendarValue = Date | [Date, Date] | Date[]

export interface PropsCalendar extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'onSelect'> {
  /** Tipo de selección: `single` elige un día, `range` dos extremos con el tramo
   *  resaltado (un intervalo elegido al revés se ordena solo) y `multiple` varios días
   *  sueltos. */
  mode?: CalendarMode
  /** Selección actual: `Date` en `single`, `[inicio, fin]` en `range` y `Date[]` en
   *  `multiple`. Si se omite, el calendario lleva su propia selección. */
  value?: Date | [Date, Date] | Date[]
  /** Cambio de selección. En `range` llega cuando están los dos extremos, ya ordenados. */
  onValueChange?: (v: Date | [Date, Date] | Date[]) => void
  /** Mes visible (cualquier día del mes). Si se omite, el calendario lo lleva solo y
   *  empieza en el mes de la selección o en el de hoy. */
  month?: Date
  /** Cambio de mes, por los botones o por el teclado al salir del mes. */
  onMonthChange?: (d: Date) => void
  /** Primera fecha permitida. Los días anteriores se deshabilitan, no se ocultan. */
  minDate?: Date
  /** Última fecha permitida. */
  maxDate?: Date
  /** Deshabilita fechas concretas dentro del rango permitido: feriados, días sin cita. */
  isDateDisabled?: (d: Date) => boolean
  /** Meses visibles. Dos, lado a lado, para elegir intervalos largos. */
  months?: 1 | 2
  /** Idioma de los nombres y primer día de la semana: lunes en español, domingo en inglés. */
  locale?: string
  /** Nombre accesible de la rejilla. Sin él, la rejilla se nombra con el mes y el año. */
  label?: string
  /** Tamaño de celda: `md` por omisión y `lg`, con el objetivo táctil mínimo, en
   *  pantallas dedicadas al calendario. */
  size?: CalendarSize
}

/**
 * Un mes en rejilla para elegir una fecha, un intervalo o varias fechas, con navegación
 * completa por teclado: flechas, Inicio y Fin de semana, Página arriba y abajo para el
 * mes (con Mayús, el año) y un solo día en el orden de tabulación.
 */
export const Calendar = forwardRef<HTMLDivElement, PropsCalendar>(function Calendar(
  {
    mode = 'single',
    value,
    onValueChange,
    month,
    onMonthChange,
    minDate,
    maxDate,
    isDateDisabled,
    months = 1,
    locale = 'es-PE',
    label,
    size = 'md',
    ...resto
  },
  ref,
) {
  const seleccion = normalizar(mode, value)
  const [interna, setInterna] = useEspejo<Date[]>(seleccion, claveDeFechas)
  const actual = value === undefined ? interna : seleccion

  const primera = actual[0]
  const mesProp = comoFecha(month)
  const [mesInterno, setMesInterno] = useState<Date>(() => primeroDeMes(mesProp ?? primera ?? new Date()))
  const mes = mesProp ? primeroDeMes(mesProp) : mesInterno

  // En intervalo, el primer clic fija el inicio y el calendario espera el fin; el tramo
  // se dibuja hasta el día apuntado para que se vea qué se va a elegir.
  const [ancla, setAncla] = useState<Date | null>(null)
  const [apuntado, setApuntado] = useState<Date | null>(null)

  const cambiarMes = (d: Date) => {
    if (!mesProp) setMesInterno(d)
    onMonthChange?.(d)
  }

  const emitir = (siguiente: Date[]) => {
    if (value === undefined) setInterna(siguiente)
    if (mode === 'single') onValueChange?.(siguiente[0] as Date)
    else if (mode === 'range') onValueChange?.([siguiente[0], siguiente[1]] as [Date, Date])
    else onValueChange?.(siguiente)
  }

  const elegir = (d: Date) => {
    if (mode === 'single') return emitir([d])
    if (mode === 'multiple') {
      const esta = actual.some((x) => mismoDia(x, d))
      const siguiente = esta ? actual.filter((x) => !mismoDia(x, d)) : [...actual, d]
      return emitir(siguiente.sort((a, b) => +a - +b))
    }
    if (!ancla) {
      setAncla(d)
      return
    }
    // Elegido al revés: se ordena en silencio, rechazarlo sería fricción sin motivo.
    const par = [ancla, d].sort((a, b) => +a - +b)
    setAncla(null)
    setApuntado(null)
    emitir(par)
  }

  const estado = (d: Date): EstadoDia => {
    const k = claveDia(d)
    if (mode === 'single') return { elegido: mismoDia(actual[0], d), enTramo: false }
    if (mode === 'multiple') return { elegido: actual.some((x) => mismoDia(x, d)), enTramo: false }
    let a: Date | undefined
    let b: Date | undefined
    if (ancla) {
      a = ancla
      b = apuntado ?? ancla
    } else {
      a = actual[0]
      b = actual[1]
    }
    if (!a || !b) return { elegido: false, enTramo: false }
    const [ini, fin] = claveDia(a) <= claveDia(b) ? [a, b] : [b, a]
    const esIni = k === claveDia(ini)
    const esFin = k === claveDia(fin)
    if (ancla) {
      return { elegido: mismoDia(ancla, d), enTramo: k > claveDia(ini) && k < claveDia(fin), extremo: mismoDia(ancla, d) ? 'inicio' : undefined }
    }
    return {
      elegido: esIni || esFin,
      // El tramo no se anuncia día a día: solo los extremos dicen que son inicio y fin.
      enTramo: k > claveDia(ini) && k < claveDia(fin),
      extremo: esIni ? 'inicio' : esFin ? 'fin' : undefined,
    }
  }

  return (
    <RejillaCalendario
      {...resto}
      ref={ref}
      mes={mes}
      meses={months}
      onMes={cambiarMes}
      locale={locale}
      etiqueta={label}
      tamano={size}
      min={comoFecha(minDate)}
      max={comoFecha(maxDate)}
      deshabilitada={isDateDisabled}
      estado={estado}
      onElegir={elegir}
      onApuntar={mode === 'range' ? setApuntado : undefined}
      activoPreferido={ancla ?? primera}
    >
      {mode === 'range' && (
        // Mientras falta el segundo extremo, el estado se dice: el tramo sombreado es la
        // única pista visual y sin ella el primer clic parece no haberse registrado.
        <p className="ay-visually-hidden" aria-live="polite">
          {ancla ? 'Elige la fecha de fin' : ''}
        </p>
      )}
    </RejillaCalendario>
  )
})

/** La selección como lista de fechas sin hora, sea cual sea la forma de `value`. */
function normalizar(mode: CalendarMode, value: unknown): Date[] {
  const lista = (Array.isArray(value) ? value : value === undefined || value === null ? [] : [value])
    .map(comoFecha)
    .filter((d): d is Date => !!d)
    .map(sinHora)
  if (mode === 'single') return lista.slice(0, 1)
  if (mode === 'range') return lista.slice(0, 2).sort((a, b) => +a - +b)
  return lista
}

import { forwardRef, useEffect, useId, useRef, useState } from 'react'
import type { FieldsetHTMLAttributes, KeyboardEvent as EventoTeclado } from 'react'
import { cx } from '../../utiles.js'
import { unir } from './_fechas.js'
import { claveDeObjeto, enfocarTrasPintar, useEspejo } from './_internos.js'
import { ComboNivel } from './_Combo.js'
import { IconoDesplegar } from './_iconos.js'
import { DEPARTAMENTOS } from './_peru.js'
import type { OpcionUbigeo } from './_peru.js'

export type { OpcionUbigeo } from './_peru.js'
/** Selección por código de cada nivel: «15», «1501», «150122». */
export interface UbigeoValue {
  departamento?: string
  provincia?: string
  distrito?: string
}
export type UbigeoLevel = 'provincia' | 'distrito'
export type UbigeoLayout = 'inline' | 'stacked'
export type UbigeoSelectSize = 'sm' | 'md' | 'lg'

export interface PropsUbigeoSelect extends Omit<FieldsetHTMLAttributes<HTMLFieldSetElement>, 'className'> {
  /** Selección actual, por código de cada nivel. Vacía, `{}`, solo el departamento está habilitado. */
  value?: { departamento?: string; provincia?: string; distrito?: string }
  /** Cambio de cualquiera de los tres niveles. Cambiar uno superior limpia los inferiores. */
  onValueChange?: (v: UbigeoValue) => void
  /** Código de seis dígitos. Al recibirlo se resuelven los tres niveles. */
  ubigeo?: string
  /** Código resultante: el del distrito, o `null` mientras la selección esté incompleta. */
  onUbigeoChange?: (codigo: string | null) => void
  /** Carga las provincias de un departamento o los distritos de una provincia. Si falla,
   *  lo elegido arriba se conserva y se ofrece reintentar solo ese nivel. */
  loadLevel?: (nivel: 'provincia' | 'distrito', padre: string) => Promise<OpcionUbigeo[]>
  /** Usa Combobox con búsqueda; con más de veinte opciones, el nivel lo usa siempre. */
  searchable?: boolean
  /** Muestra el código de ubigeo resuelto, seleccionable: es lo que se transcribe a los
   *  formularios oficiales. */
  showCode?: boolean
  /** `inline`: los tres en fila; `stacked`: apilados en el orden de la cadena. */
  layout?: UbigeoLayout
  /** Modo consulta: los tres niveles como texto y el código debajo. */
  readOnly?: boolean
  /** Altura de los tres selectores. */
  size?: UbigeoSelectSize
  /** Deshabilita los tres niveles a la vez. */
  disabled?: boolean
  /** Leyenda del grupo. Nombra el uso, no «Ubigeo»: «Ubicación de la promoción». */
  label?: string
}

const PLURAL: Record<UbigeoLevel, string> = { provincia: 'provincias', distrito: 'distritos' }

/**
 * Departamento, provincia y distrito como un solo dato encadenado: un nivel se habilita
 * cuando el anterior está elegido y su lista cargada, y el código de ubigeo resultante
 * se muestra como texto seleccionable.
 */
export const UbigeoSelect = forwardRef<HTMLFieldSetElement, PropsUbigeoSelect>(function UbigeoSelect(
  {
    value,
    onValueChange,
    ubigeo,
    onUbigeoChange,
    loadLevel,
    searchable = false,
    showCode = true,
    layout = 'inline',
    readOnly = false,
    size = 'md',
    disabled = false,
    label = 'Ubicación de la promoción',
    ...resto
  },
  ref,
) {
  const id = useId()
  const ids = { departamento: `${id}-dep`, provincia: `${id}-prov`, distrito: `${id}-dist` }

  // Un ubigeo precargado se resuelve en sus tres niveles antes de pintar.
  const deUbigeo: UbigeoValue | null =
    ubigeo && /^\d{6}$/.test(ubigeo)
      ? { departamento: ubigeo.slice(0, 2), provincia: ubigeo.slice(0, 4), distrito: ubigeo }
      : null
  const inicial = value && Object.keys(value).length > 0 ? value : (deUbigeo ?? value ?? {})
  const [valor, setValor] = useEspejo<UbigeoValue>(inicial, claveDeObjeto)

  const [provincias, setProvincias] = useState<{ padre: string; opciones: OpcionUbigeo[] } | null>(null)
  const [distritos, setDistritos] = useState<{ padre: string; opciones: OpcionUbigeo[] } | null>(null)
  const [cargando, setCargando] = useState<UbigeoLevel | null>(null)
  const [fallo, setFallo] = useState<UbigeoLevel | null>(null)
  const [aviso, setAviso] = useState('')
  const focoPendiente = useRef<UbigeoLevel | null>(null)
  const turno = useRef({ provincia: 0, distrito: 0 })

  const cargar = (nivel: UbigeoLevel, padre: string) => {
    if (!loadLevel) return
    const mio = ++turno.current[nivel]
    setCargando(nivel)
    setFallo(null)
    // quien no ve el indicador necesita saber que la espera es del sistema y no suya
    setAviso(`Cargando ${PLURAL[nivel]}…`)
    loadLevel(nivel, padre).then(
      (opciones) => {
        if (mio !== turno.current[nivel]) return
        const lista = Array.isArray(opciones) ? opciones : []
        ;(nivel === 'provincia' ? setProvincias : setDistritos)({ padre, opciones: lista })
        setCargando(null)
        // El foco no salta solo al nivel siguiente: se anuncia y se deja tabular.
        setAviso(`${lista.length} ${PLURAL[nivel]} disponibles.`)
        if (focoPendiente.current === nivel) {
          focoPendiente.current = null
          enfocarTrasPintar(() => document.getElementById(ids[nivel]))
        }
      },
      () => {
        if (mio !== turno.current[nivel]) return
        // No se borra lo elegido arriba: un fallo de red no invalida un trabajo bien hecho.
        setCargando(null)
        setFallo(nivel)
        setAviso(`No hemos podido cargar los ${PLURAL[nivel]}.`)
      },
    )
  }

  // Cada nivel se carga cuando su padre está elegido y su lista no es la de ese padre.
  useEffect(() => {
    if (valor.departamento && provincias?.padre !== valor.departamento) cargar('provincia', valor.departamento)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [valor.departamento])
  useEffect(() => {
    if (valor.provincia && distritos?.padre !== valor.provincia) cargar('distrito', valor.provincia)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [valor.provincia])

  const opcionesProv = provincias && provincias.padre === valor.departamento ? provincias.opciones : []
  const opcionesDist = distritos && distritos.padre === valor.provincia ? distritos.opciones : []

  const emitir = (siguiente: UbigeoValue, codigo: string | null) => {
    setValor(siguiente)
    onValueChange?.(siguiente)
    onUbigeoChange?.(codigo)
  }

  const elegirDepartamento = (codigo: string) => {
    if (codigo === (valor.departamento ?? '')) return
    // Una provincia de otro departamento no es una selección válida: se limpia y se dice.
    if (valor.provincia || valor.distrito) setAviso('Provincia y distrito se han borrado.')
    setFallo(null)
    emitir({ departamento: codigo || undefined }, null)
  }
  const elegirProvincia = (codigo: string) => {
    if (codigo === (valor.provincia ?? '')) return
    if (valor.distrito) setAviso('El distrito se ha borrado.')
    setFallo(null)
    emitir({ ...valor, provincia: codigo || undefined, distrito: undefined }, null)
  }
  const elegirDistrito = (codigo: string) => {
    if (codigo === (valor.distrito ?? '')) return
    emitir({ ...valor, distrito: codigo || undefined }, codigo || null)
  }

  /** Enter confirma y pasa al nivel siguiente en cuanto está cargado: es una petición explícita. */
  const pasarA = (siguiente: UbigeoLevel) => {
    if (cargando === siguiente) focoPendiente.current = siguiente
    else document.getElementById(ids[siguiente])?.focus()
  }

  const nombreDe = (opciones: OpcionUbigeo[], codigo?: string) =>
    codigo ? (opciones.find((o) => o.codigo === codigo)?.nombre ?? codigo) : ''

  const nivel = (
    clave: 'departamento' | UbigeoLevel,
    etiqueta: string,
    opciones: OpcionUbigeo[],
    seleccion: string | undefined,
    elegir: (c: string) => void,
    autoComplete: string,
    placeholder: string,
    motivo: string | null,
    siguiente?: UbigeoLevel,
  ) => {
    const idCampo = ids[clave]
    const idAyuda = `${idCampo}-ayuda`
    const idError = `${idCampo}-error`
    const esperando = clave !== 'departamento' && cargando === clave
    const fallado = clave !== 'departamento' && fallo === clave
    const inactivo = !!motivo || esperando
    const conBusqueda = clave === 'departamento' ? searchable : searchable || opciones.length > 20
    // La lista de ese padre ya llegó y el código no está: la división política cambió. Se
    // conserva el dato histórico del registro y se dice, en lugar de borrarlo.
    const cargada =
      clave === 'departamento' ||
      (clave === 'provincia' ? provincias?.padre === valor.departamento : distritos?.padre === valor.provincia)
    const historico = !!seleccion && cargada && opciones.length > 0 && !opciones.some((o) => o.codigo === seleccion)
    const idHistorico = `${idCampo}-historico`
    const describe = unir(motivo && idAyuda, fallado && idError, historico && idHistorico)
    const alTeclear = (e: EventoTeclado<HTMLSelectElement>) => {
      if (e.key === 'Enter' && siguiente) {
        e.preventDefault()
        pasarA(siguiente)
      }
    }
    // La selección que aún no está en la lista cargada se conserva y se muestra por su código.
    const conHuerfana =
      seleccion && !opciones.some((o) => o.codigo === seleccion) ? [...opciones, { codigo: seleccion, nombre: seleccion }] : opciones

    return (
      <div className="ay-ubigeo__level">
        <label className="ay-label ay-label--sm" htmlFor={idCampo}>
          {etiqueta}
        </label>
        {conBusqueda ? (
          <ComboNivel
            id={idCampo}
            opciones={conHuerfana}
            valor={seleccion ?? ''}
            onCambio={elegir}
            plural={clave === 'departamento' ? 'departamentos' : PLURAL[clave]}
            placeholder={esperando ? `Cargando ${PLURAL[clave as UbigeoLevel]}…` : placeholder}
            disabled={inactivo}
            describedBy={describe}
            autoComplete={autoComplete}
            tamano={size}
            ocupado={esperando}
            onEnter={siguiente ? () => pasarA(siguiente) : undefined}
          />
        ) : (
          <span className={cx('ay-selectwrap', `ay-selectwrap--${size}`)}>
            <select
              id={idCampo}
              className="ay-select"
              // WCAG 1.3.5: un token por nivel para que el navegador rellene la dirección guardada
              autoComplete={autoComplete}
              value={seleccion ?? ''}
              disabled={inactivo}
              aria-describedby={describe}
              aria-busy={esperando || undefined}
              aria-invalid={fallado || undefined}
              onChange={(e) => elegir(e.target.value)}
              onKeyDown={alTeclear}
            >
              {/* el indicador de carga vive dentro del selector afectado */}
              <option value="">{esperando ? `Cargando ${PLURAL[clave as UbigeoLevel]}…` : placeholder}</option>
              {conHuerfana.map((o) => (
                <option key={o.codigo} value={o.codigo}>
                  {o.nombre}
                </option>
              ))}
            </select>
            <IconoDesplegar className="ay-select__chevron" />
          </span>
        )}
        {/* el motivo va en el texto: un select gris sin explicación parece un fallo */}
        {motivo && (
          <p className="ay-helper" id={idAyuda}>
            {motivo}
          </p>
        )}
        {historico && (
          <p className="ay-helper" id={idHistorico}>
            El código {seleccion} ya no figura en la lista; se conserva el dato del registro.
          </p>
        )}
        {fallado && (
          <p className="ay-error-msg" id={idError}>
            No hemos podido cargar los {PLURAL[clave as UbigeoLevel]}.{' '}
            <button
              type="button"
              className="ay-btn ay-btn--ghost ay-btn--sm"
              onClick={() => {
                const padre = clave === 'provincia' ? valor.departamento : valor.provincia
                if (padre) cargar(clave as UbigeoLevel, padre)
              }}
            >
              Reintentar
            </button>
          </p>
        )}
      </div>
    )
  }

  const completo = !!valor.distrito

  return (
    <fieldset
      {...resto}
      ref={ref}
      className={cx('ay-ubigeo', `ay-ubigeo--${layout}`, `ay-ubigeo--${size}`)}
      disabled={disabled}
    >
      {/* un solo dato en tres pasos: fieldset y legend, no tres etiquetas sueltas */}
      <legend className="ay-label">{label}</legend>

      {readOnly ? (
        <div className="ay-ubigeo__row">
          {(
            [
              ['Departamento', nombreDe(DEPARTAMENTOS, valor.departamento)],
              ['Provincia', nombreDe(opcionesProv, valor.provincia)],
              ['Distrito', nombreDe(opcionesDist, valor.distrito)],
            ] as const
          ).map(([etiqueta, texto]) => (
            <p key={etiqueta} className="ay-ubigeo__level">
              <span className="ay-label ay-label--sm">{etiqueta}</span>
              <span className="ay-ubigeo__value">{texto || 'Sin dato'}</span>
            </p>
          ))}
        </div>
      ) : (
        <div className="ay-ubigeo__row">
          {nivel(
            'departamento',
            'Departamento',
            DEPARTAMENTOS,
            valor.departamento,
            elegirDepartamento,
            'address-level1',
            'Elige un departamento',
            null,
            'provincia',
          )}
          {nivel(
            'provincia',
            'Provincia',
            opcionesProv,
            valor.provincia,
            elegirProvincia,
            'address-level2',
            'Elige una provincia',
            valor.departamento ? null : 'Elige primero el departamento.',
            'distrito',
          )}
          {nivel(
            'distrito',
            'Distrito',
            opcionesDist,
            valor.distrito,
            elegirDistrito,
            'address-level3',
            'Elige un distrito',
            valor.provincia ? null : 'Elige primero la provincia.',
          )}
        </div>
      )}

      {/* seleccionable y nunca antes de tiempo: aparece con la selección completa */}
      {showCode && completo && (
        <p className="ay-ubigeo__code">
          Ubigeo <code>{valor.distrito}</code>
        </p>
      )}

      <p className="ay-visually-hidden" role="status" aria-live="polite">
        {aviso}
      </p>
    </fieldset>
  )
})

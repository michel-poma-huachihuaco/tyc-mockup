import { forwardRef, useEffect, useId, useMemo, useRef, useState } from 'react'
import type { HTMLAttributes, KeyboardEvent as EventoTeclado } from 'react'
import { cx } from '../../utiles.js'
import {
  acotar,
  claveDia,
  diasDeLaSemana,
  fechaLarga,
  fueraDeRango,
  mismoMes,
  nombreAccesibleDelDia,
  nombreDelMes,
  posicionEnSemana,
  primeroDeMes,
  sinHora,
  sumarDias,
  sumarMeses,
} from './_fechas.js'
import { IconoAnterior, IconoSiguiente } from './_iconos.js'
import { enfocarTrasPintar as enfocarDespues } from './_internos.js'

/** Cómo se pinta un día según la selección de quien usa la rejilla. */
export interface EstadoDia {
  elegido: boolean
  enTramo: boolean
  extremo?: 'inicio' | 'fin'
}

export interface PropsRejilla extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'onSelect'> {
  mes: Date
  meses: 1 | 2
  onMes: (primero: Date) => void
  locale: string
  etiqueta?: string
  tamano: 'md' | 'lg'
  min?: Date
  max?: Date
  deshabilitada?: (d: Date) => boolean
  estado: (d: Date) => EstadoDia
  onElegir: (d: Date) => void
  onApuntar?: (d: Date | null) => void
  /** El día que recibe el foco móvil si no hay otro: el elegido, o hoy. */
  activoPreferido?: Date
  /** Al pasar a `true`, el foco va al día activo: se usa al abrir la superficie de un picker. */
  enfocar?: boolean
  claseExtra?: string
}

/**
 * La rejilla de Calendar, compartida con Date Picker, Date Range Picker y Date-Time
 * Picker. No sabe de modos de selección: pinta lo que `estado` le dice y avisa con
 * `onElegir`. El foco móvil, el teclado y los anuncios sí son suyos, porque son
 * idénticos en los cuatro.
 */
export const RejillaCalendario = forwardRef<HTMLDivElement, PropsRejilla>(function RejillaCalendario(
  {
    mes: mesProp,
    meses,
    onMes,
    locale,
    etiqueta,
    tamano,
    min,
    max,
    deshabilitada,
    estado,
    onElegir,
    onApuntar,
    activoPreferido,
    enfocar = false,
    claseExtra,
    children,
    ...resto
  },
  ref,
) {
  const base = useId()
  const mes = primeroDeMes(mesProp)
  const visibles = useMemo(
    () => Array.from({ length: meses }, (_, i) => sumarMeses(mes, i)),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [claveDia(mes), meses],
  )
  const ultimoVisible = visibles[visibles.length - 1] ?? mes
  const hoy = sinHora(new Date())
  const raiz = useRef<HTMLDivElement | null>(null)
  const enfocarTrasPintar = useRef(false)

  const esDeshabilitado = (d: Date) => fueraDeRango(d, min, max) || !!deshabilitada?.(d)
  const esVisible = (d: Date) => visibles.some((v) => mismoMes(v, d))

  const [activo, setActivo] = useState<Date>(() => sinHora(activoPreferido ?? hoy))

  /** El primer día seleccionable de los meses visibles, o null si no hay ninguno. */
  const primerHabilitado = (): Date | null => {
    for (const v of visibles) {
      const dias = new Date(v.getFullYear(), v.getMonth() + 1, 0).getDate()
      for (let d = 1; d <= dias; d++) {
        const f = new Date(v.getFullYear(), v.getMonth(), d)
        if (!esDeshabilitado(f)) return f
      }
    }
    return null
  }

  // El activo efectivo siempre está en un mes visible y es seleccionable. Si el mes
  // cambió por los botones, se conserva el número de día y, si el destino no lo tiene
  // —el 31 hacia febrero—, se ajusta al último día del mes.
  const activoEfectivo = useMemo((): Date | null => {
    let candidato = activo
    if (!esVisible(candidato)) {
      const preferido = activoPreferido && esVisible(activoPreferido) ? sinHora(activoPreferido) : null
      if (preferido) candidato = preferido
      else if (esVisible(hoy)) candidato = hoy
      else {
        const ultimo = new Date(mes.getFullYear(), mes.getMonth() + 1, 0).getDate()
        candidato = new Date(mes.getFullYear(), mes.getMonth(), Math.min(activo.getDate(), ultimo))
      }
    }
    if (!esDeshabilitado(candidato)) return candidato
    return primerHabilitado()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [claveDia(activo), claveDia(mes), meses, min && claveDia(min), max && claveDia(max), deshabilitada, activoPreferido && claveDia(activoPreferido)])

  // Abrir la superficie del picker lleva el foco al día activo: el elegido, o hoy. Se
  // enfoca después del pintado, cuando la superficie ya no está `hidden`.
  useEffect(() => {
    if (!enfocar) return
    if (activoPreferido) setActivo(sinHora(activoPreferido))
    enfocarDespues(() => raiz.current?.querySelector<HTMLButtonElement>('.ay-calendar__day[tabindex="0"]'))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enfocar])

  useEffect(() => {
    if (!enfocarTrasPintar.current || !activoEfectivo) return
    enfocarTrasPintar.current = false
    raiz.current
      ?.querySelector<HTMLButtonElement>(`[data-dia="${claveDia(activoEfectivo)}"]`)
      ?.focus()
  })

  /** Busca un día seleccionable en una dirección, sin salir del rango permitido. */
  const buscar = (desde: Date, paso: number): Date | null => {
    let d = desde
    for (let i = 0; i < 400; i++) {
      if (fueraDeRango(d, min, max)) return null
      if (!esDeshabilitado(d)) return d
      d = sumarDias(d, paso)
    }
    return null
  }

  const irA = (destino: Date | null) => {
    if (!destino || !activoEfectivo || claveDia(destino) === claveDia(activoEfectivo)) return
    setActivo(destino)
    onApuntar?.(destino)
    enfocarTrasPintar.current = true
    // Al salir de los meses visibles se cambia de mes, en lugar de dejar el foco en un
    // botón que no se ve.
    if (claveDia(destino) < claveDia(mes)) onMes(primeroDeMes(destino))
    else if (!esVisible(destino) && claveDia(destino) > claveDia(ultimoVisible))
      onMes(sumarMeses(primeroDeMes(destino), -(meses - 1)))
  }

  const alTeclear = (e: EventoTeclado<HTMLTableElement>) => {
    if (!activoEfectivo) return
    const a = activoEfectivo
    const enSemana = posicionEnSemana(a, locale)
    let destino: Date | null | undefined
    switch (e.key) {
      case 'ArrowLeft':
        destino = buscar(sumarDias(a, -1), -1)
        break
      case 'ArrowRight':
        destino = buscar(sumarDias(a, 1), 1)
        break
      case 'ArrowUp':
        destino = buscar(sumarDias(a, -7), -7)
        break
      case 'ArrowDown':
        destino = buscar(sumarDias(a, 7), 7)
        break
      // Inicio y Fin recorren la semana, que es la fila que se está leyendo.
      case 'Home':
        destino = buscar(sumarDias(a, -enSemana), 1)
        break
      case 'End':
        destino = buscar(sumarDias(a, 6 - enSemana), -1)
        break
      // Página arriba y abajo cambian de mes; con Mayús, de año.
      case 'PageUp':
      case 'PageDown': {
        const salto = (e.key === 'PageUp' ? -1 : 1) * (e.shiftKey ? 12 : 1)
        const objetivo = acotar(sumarMeses(a, salto), min, max)
        destino = buscar(objetivo, 1) ?? buscar(objetivo, -1)
        break
      }
      case 'Enter':
      case ' ':
        e.preventDefault()
        if (!esDeshabilitado(a)) onElegir(a)
        return
      default:
        return
    }
    e.preventDefault()
    irA(destino ?? null)
  }

  const nombres = useMemo(() => diasDeLaSemana(locale), [locale])
  const titulos = visibles.map((v) => nombreDelMes(v, locale))

  /** Si el rango permitido deja el mes entero sin días, se explica en vez de pintar una rejilla inerte. */
  const motivoMesVacio = (v: Date): string | null => {
    const dias = new Date(v.getFullYear(), v.getMonth() + 1, 0).getDate()
    for (let d = 1; d <= dias; d++) if (!esDeshabilitado(new Date(v.getFullYear(), v.getMonth(), d))) return null
    const ultimo = new Date(v.getFullYear(), v.getMonth(), dias)
    if (min && claveDia(min) > claveDia(ultimo))
      return `No hay fechas disponibles en ${nombreDelMes(v, locale)}. La primera fecha permitida es el ${fechaLarga(min, locale)}.`
    if (max && claveDia(max) < claveDia(v))
      return `No hay fechas disponibles en ${nombreDelMes(v, locale)}. La última fecha permitida es el ${fechaLarga(max, locale)}.`
    return `No hay fechas disponibles en ${nombreDelMes(v, locale)}. Elige otro mes.`
  }

  const anterior = () => onMes(sumarMeses(mes, -1))
  const siguiente = () => onMes(sumarMeses(mes, 1))

  const unMes = (v: Date, i: number) => {
    const idTitulo = `${base}-titulo-${i}`
    const idVacio = `${base}-vacio-${i}`
    const vacio = motivoMesVacio(v)
    const conAnterior = i === 0
    const conSiguiente = i === visibles.length - 1
    return (
      <div
        key={claveDia(v)}
        className={cx('ay-calendar', tamano === 'lg' && 'ay-calendar--lg', meses === 1 && claseExtra)}
        {...(meses === 1 ? resto : {})}
        ref={meses === 1 ? asignarRaiz : undefined}
      >
        <div className="ay-calendar__head">
          {conAnterior ? (
            <button
              type="button"
              className="ay-iconbtn ay-iconbtn--ghost ay-iconbtn--md"
              aria-label="Mes anterior"
              onClick={anterior}
            >
              <IconoAnterior className="ay-iconbtn__glyph" />
            </button>
          ) : (
            <span className="ay-calendar__spacer" aria-hidden="true" />
          )}
          <h3 className="ay-calendar__title" id={idTitulo}>
            {titulos[i]}
          </h3>
          {conSiguiente ? (
            <button
              type="button"
              className="ay-iconbtn ay-iconbtn--ghost ay-iconbtn--md"
              aria-label="Mes siguiente"
              onClick={siguiente}
            >
              <IconoSiguiente className="ay-iconbtn__glyph" />
            </button>
          ) : (
            <span className="ay-calendar__spacer" aria-hidden="true" />
          )}
        </div>

        {/* table con role grid: el marcado tabular es lo que permite al lector decir «martes 14» */}
        <table
          className="ay-calendar__grid"
          role="grid"
          aria-labelledby={etiqueta ? undefined : idTitulo}
          aria-label={etiqueta ? `${etiqueta}, ${titulos[i]}` : undefined}
          aria-describedby={vacio ? idVacio : undefined}
          onKeyDown={alTeclear}
          // Espacio activa el botón al soltarse en algunos navegadores: ya se eligió al pulsar.
          onKeyUp={(e) => {
            if (e.key === ' ') e.preventDefault()
          }}
          onMouseLeave={onApuntar ? () => onApuntar(null) : undefined}
        >
          <thead>
            <tr>
              {nombres.map((n) => (
                <th key={n.completo} scope="col">
                  {/* «L» leída en voz alta no significa nada: el nombre completo va en abbr */}
                  <abbr title={n.completo}>{n.corto}</abbr>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {semanasDe(v).map((semana, s) => (
              <tr key={s}>
                {semana.map((d) => {
                  if (!mismoMes(d, v)) {
                    // Los días de otros meses son texto, no botones muertos.
                    return (
                      <td key={claveDia(d)} role="gridcell">
                        <span className="ay-calendar__out" aria-hidden="true">
                          {d.getDate()}
                        </span>
                      </td>
                    )
                  }
                  const e = estado(d)
                  const esHoy = claveDia(d) === claveDia(hoy)
                  const esActivo = !!activoEfectivo && claveDia(d) === claveDia(activoEfectivo)
                  const nombre = [
                    nombreAccesibleDelDia(d, locale),
                    esHoy && 'hoy',
                    e.extremo === 'inicio' && 'inicio del intervalo',
                    e.extremo === 'fin' && 'fin del intervalo',
                  ]
                    .filter(Boolean)
                    .join(', ')
                  return (
                    <td key={claveDia(d)} role="gridcell" aria-selected={e.elegido}>
                      <button
                        type="button"
                        className={cx(
                          'ay-calendar__day',
                          e.elegido && 'ay-calendar__day--selected',
                          e.enTramo && 'ay-calendar__day--inrange',
                          e.extremo === 'inicio' && 'ay-calendar__day--start',
                          e.extremo === 'fin' && 'ay-calendar__day--end',
                          esHoy && 'ay-calendar__day--today',
                        )}
                        data-dia={claveDia(d)}
                        // un solo día en el orden de tabulación: sin foco móvil, Tab recorrería 42 botones
                        tabIndex={esActivo ? 0 : -1}
                        aria-label={nombre}
                        disabled={esDeshabilitado(d)}
                        onClick={() => {
                          setActivo(d)
                          onElegir(d)
                        }}
                        onMouseEnter={onApuntar ? () => onApuntar(d) : undefined}
                      >
                        {d.getDate()}
                      </button>
                    </td>
                  )
                })}
              </tr>
            ))}
          </tbody>
        </table>
        {vacio && (
          <p className="ay-calendar__empty" id={idVacio}>
            {vacio}
          </p>
        )}
        {meses === 1 && <Anuncio texto={titulos[0] ?? ''} />}
        {meses === 1 && children}
      </div>
    )
  }

  function asignarRaiz(el: HTMLDivElement | null) {
    raiz.current = el
    if (typeof ref === 'function') ref(el)
    else if (ref) ref.current = el
  }

  function semanasDe(v: Date) {
    return semanasDelMesCache(v, locale)
  }

  if (meses === 1) return unMes(mes, 0)

  return (
    <div {...resto} ref={asignarRaiz} className={cx('ay-calendar__months', claseExtra)}>
      {visibles.map(unMes)}
      <Anuncio texto={titulos.join(' y ')} />
      {children}
    </div>
  )
})

/** Sin esto, mover el foco fuera del mes parece que no hace nada. */
function Anuncio({ texto }: { texto: string }) {
  return (
    <p className="ay-visually-hidden" aria-live="polite">
      {texto}
    </p>
  )
}

const cache = new Map<string, Date[][]>()
function semanasDelMesCache(v: Date, locale: string): Date[][] {
  const clave = `${claveDia(v)}|${locale}`
  let semanas = cache.get(clave)
  if (!semanas) {
    semanas = calcularSemanas(v, locale)
    if (cache.size > 48) cache.clear()
    cache.set(clave, semanas)
  }
  return semanas
}

function calcularSemanas(v: Date, locale: string): Date[][] {
  const inicio = sumarDias(v, -posicionEnSemana(v, locale))
  return Array.from({ length: 6 }, (_, s) => Array.from({ length: 7 }, (_, d) => sumarDias(inicio, s * 7 + d)))
}

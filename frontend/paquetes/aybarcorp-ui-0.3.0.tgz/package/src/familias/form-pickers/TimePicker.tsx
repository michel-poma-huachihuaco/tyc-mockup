import { forwardRef, useId, useMemo, useRef, useState } from 'react'
import type { HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import { unir } from './_fechas.js'
import { horaDe, horaHablada, horasDeLaLista, masCercana, mostrarHora, normalizarHora } from './_horas.js'
import { IconoReloj } from './_iconos.js'
import { useCerrarAlSalir, useEspejo, useSuperficieEnCapa, useTextoDe } from './_internos.js'
import { ListaHoras } from './_ListaHoras.js'

export type TimeFormat = '24h' | '12h'
export type TimePickerSize = 'md' | 'lg'

export interface PropsTimePicker extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'onSelect'> {
  /** Etiqueta del campo; obligatoria. Nombra el dato: «Hora de la visita». */
  label: string
  /** Hora en formato `HH:mm` de 24 horas, se muestre como se muestre. `null` es vacío. */
  value?: string | null
  /** Cambio de hora; siempre llega en `HH:mm` de 24 horas. */
  onValueChange?: (v: string | null) => void
  /** Minutos entre las horas de la lista. Una hora escrita fuera de ese paso se acepta:
   *  la lista no es una restricción. */
  step?: number
  /** Primera hora permitida (`HH:mm`). Las anteriores no aparecen en la lista y, si se
   *  escriben, se explica el horario. */
  minTime?: string
  /** Última hora permitida (`HH:mm`). */
  maxTime?: string
  /** Formato mostrado. En `12h` la franja va en el texto, «9:30 a.m.»: confundir las 9:00
   *  con las 21:00 manda a alguien doce horas tarde a la unidad 402. */
  format?: TimeFormat
  /** Agrupa la lista en franjas con cabecera: «Mañana», «Tarde», «Noche». */
  groups?: boolean
  /** Mensaje de validación externo; sustituye a los de formato y horario del campo. */
  error?: string
  /** Altura del campo: `md` por omisión, `lg` en pantallas de cita. */
  size?: TimePickerSize
  /** Deshabilita el campo y el disparador a la vez. */
  disabled?: boolean
}

/**
 * Hora con el formato local, escrita o elegida de una lista de horas válidas. El campo
 * acepta escritura —«930» es las 09:30— y la lista es un listbox con foco virtual: el
 * foco real se queda en el campo para corregir un dígito sin volver a él.
 */
export const TimePicker = forwardRef<HTMLDivElement, PropsTimePicker>(function TimePicker(
  {
    label,
    value = null,
    onValueChange,
    step = 30,
    minTime,
    maxTime,
    format = '24h',
    groups = false,
    error,
    size = 'md',
    disabled = false,
    onBlur,
    ...resto
  },
  ref,
) {
  const id = useId()
  const idAyuda = `${id}-help`
  const idError = `${id}-error`
  const idLista = `${id}-list`

  const valorProp = typeof value === 'string' ? normalizarHora(value) : null
  const [hora, setHora] = useEspejo<string | null>(valorProp === 'invalida' ? null : valorProp)
  const [texto, setTexto] = useTextoDe(`${hora}|${format}`, () => (hora ? mostrarHora(hora, format) : ''))
  const [errorLocal, setErrorLocal] = useState<string | null>(null)
  const [abierto, setAbierto] = useState(false)
  const [activo, setActivo] = useState(-1)

  const horas = useMemo(() => horasDeLaLista(step, minTime, maxTime), [step, minTime, maxTime])
  const { raiz, alSalir } = useCerrarAlSalir(abierto, () => setAbierto(false))
  const caja = useRef<HTMLDivElement>(null)
  const lista = useRef<HTMLUListElement>(null)
  // La lista se ancla a la caja del campo, no a toda la ficha: va justo debajo de ella.
  useSuperficieEnCapa(abierto, lista, caja)

  const fijar = (h: string | null) => {
    setHora(h)
    setErrorLocal(null)
    setTexto(h ? mostrarHora(h, format) : '')
    onValueChange?.(h) // en 24 horas aunque se muestre en 12
  }

  const validar = () => {
    const r = normalizarHora(texto)
    // El error de formato y el de horario son mensajes distintos: «Hora no válida» a las
    // 22:00 esconde que el problema es que la oficina cierra a las 19:00.
    if (r === 'invalida') return setErrorLocal('Usa el formato hh:mm')
    if (r === null) return fijar(null)
    if (minTime && r < minTime) return setErrorLocal(`El horario empieza a las ${mostrarHora(minTime, format)}`)
    if (maxTime && r > maxTime) return setErrorLocal(`El horario acaba a las ${mostrarHora(maxTime, format)}`)
    fijar(r)
  }

  const abrir = () => {
    const referencia = (() => {
      const escrita = normalizarHora(texto)
      return typeof escrita === 'string' ? escrita : (hora ?? horaDe(new Date()))
    })()
    setActivo(masCercana(horas, referencia))
    setAbierto(true)
  }

  const elegir = (h: string) => {
    fijar(h)
    setAbierto(false)
  }

  const mensaje = error ?? errorLocal
  const opcionActiva = abierto && activo >= 0 ? `${idLista}-opt-${activo}` : undefined

  return (
    <div
      {...resto}
      ref={(el) => {
        raiz.current = el
        if (typeof ref === 'function') ref(el)
        else if (ref) ref.current = el
      }}
      className="ay-field"
      onBlur={(e) => {
        onBlur?.(e)
        alSalir(e)
      }}
    >
      <label className="ay-label" htmlFor={id}>
        {label}
      </label>
      <p className="ay-help" id={idAyuda}>
        hh:mm
      </p>

      <div ref={caja} className={cx('ay-timepicker', `ay-timepicker--${size}`)} aria-invalid={mensaje ? true : undefined}>
        {/* editable: recorrer 48 horas con lector es inaceptable */}
        <input
          className="ay-timepicker__field"
          id={id}
          type="text"
          inputMode="numeric"
          role="combobox"
          aria-expanded={abierto}
          aria-controls={idLista}
          aria-autocomplete="list"
          aria-activedescendant={opcionActiva}
          aria-describedby={unir(idAyuda, mensaje && idError)}
          aria-invalid={mensaje ? true : undefined}
          placeholder="hh:mm"
          disabled={disabled}
          value={texto}
          onChange={(e) => setTexto(e.target.value)}
          onBlur={() => {
            validar()
            setAbierto(false)
          }}
          onKeyDown={(e) => {
            if (e.key === 'ArrowDown') {
              e.preventDefault()
              if (!abierto) abrir()
              else setActivo((i) => Math.min(horas.length - 1, i + 1))
            } else if (e.key === 'ArrowUp' && abierto) {
              e.preventDefault()
              setActivo((i) => Math.max(0, i - 1))
            } else if (e.key === 'Enter') {
              e.preventDefault()
              const h = abierto ? horas[activo] : undefined
              if (h) elegir(h)
              else {
                validar()
                setAbierto(false)
              }
            } else if (e.key === 'Escape' && abierto) {
              // cierra la lista; el foco ya está en el campo y ahí se queda
              e.preventDefault()
              setAbierto(false)
            }
          }}
        />
        <button
          type="button"
          className="ay-timepicker__trigger"
          tabIndex={-1}
          aria-label="Mostrar las horas"
          disabled={disabled}
          onMouseDown={(e) => e.preventDefault()}
          onClick={() => (abierto ? setAbierto(false) : abrir())}
        >
          <IconoReloj />
        </button>
      </div>

      <ListaHoras
        id={idLista}
        horas={horas}
        valor={hora}
        activo={activo}
        formato={format}
        conFranjas={groups}
        oculta={!abierto}
        onElegir={elegir}
        refLista={lista}
        foco="virtual"
      />

      {/* «nueve y media de la mañana», no «09:30» */}
      <p className="ay-visually-hidden" aria-live="polite">
        {hora ? horaHablada(hora) : ''}
      </p>

      {mensaje && (
        <p className="ay-error" id={idError}>
          {mensaje}
        </p>
      )}
    </div>
  )
})

import { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react'
import type { RefObject } from 'react'
import { anclarEnCapaSuperior } from '../surfaces/_capa.js'

/**
 * Estado que refleja una prop y que el propio control también puede cambiar.
 *
 * Sirve a los dos usos: quien pasa `value` y lo actualiza en `onValueChange` ve siempre
 * su valor (cada cambio de la prop vuelve a sincronizar el estado), y quien no lo
 * actualiza —o no pasa nada— tiene igualmente un control que responde a lo que se
 * escribe. `clave` decide cuándo la prop cambió de verdad: dos `Date` con el mismo día
 * creadas en cada render no son un cambio.
 */
export function useEspejo<T>(
  prop: T,
  clave: (v: T) => unknown = (v) => v,
): [T, (siguiente: T) => void] {
  const [valor, setValor] = useState<T>(prop)
  const claveProp = clave(prop)
  const [anterior, setAnterior] = useState(claveProp)
  // Se ajusta durante el render, no en un efecto: así no hay un pintado intermedio con
  // el valor viejo. Es el patrón de React para derivar estado de una prop que cambia.
  if (!Object.is(anterior, claveProp)) {
    setAnterior(claveProp)
    setValor(prop)
  }
  return [valor, setValor]
}

/** Clave estable de una fecha, de un par de fechas o de una lista de fechas. */
export function claveDeFechas(v: unknown): string {
  if (v instanceof Date) return String(+v)
  if (Array.isArray(v)) return v.map(claveDeFechas).join('|')
  if (v === null || v === undefined) return String(v)
  return String(v)
}

/** Clave estable de un objeto plano y pequeño (el valor de Ubigeo Select). */
export const claveDeObjeto = (v: unknown): string => JSON.stringify(v ?? null)

/**
 * Cierra una superficie cuando el foco sale del conjunto (campo, disparador y
 * superficie). No mueve el foco: quien tabuló fuera ya eligió dónde ir.
 */
export function useCerrarAlSalir(abierto: boolean, cerrar: () => void) {
  const raiz = useRef<HTMLElement | null>(null)
  const cerrarRef = useRef(cerrar)
  cerrarRef.current = cerrar
  const alSalir = useCallback(
    (e: { relatedTarget: EventTarget | null }) => {
      if (!abierto) return
      const destino = e.relatedTarget
      if (destino instanceof Node && raiz.current?.contains(destino)) return
      cerrarRef.current()
    },
    [abierto],
  )
  useEffect(() => {
    if (!abierto) return
    const fuera = (e: PointerEvent) => {
      if (e.target instanceof Node && raiz.current && !raiz.current.contains(e.target)) cerrarRef.current()
    }
    document.addEventListener('pointerdown', fuera)
    return () => document.removeEventListener('pointerdown', fuera)
  }, [abierto])
  return { raiz, alSalir }
}

/**
 * Abierta, la superficie (el calendario, la lista de horas) sube a la capa superior bajo
 * su campo, separada por space.1 como en la hoja: allí no la tapa una Navbar o un Banner
 * pegajoso, ni la recorta el overflow de una tarjeta o de un Modal, ni la desplaza el
 * transform de una tarjeta inclinada. Va antes de que el foco entre en ella, que se mueve
 * tras pintar. Sin la API sigue anclada con la hoja.
 */
export function useSuperficieEnCapa(
  abierta: boolean,
  superficie: RefObject<HTMLElement | null>,
  ancla: RefObject<HTMLElement | null>,
): void {
  useLayoutEffect(() => {
    if (!abierta || !superficie.current || !ancla.current) return
    return anclarEnCapaSuperior(superficie.current, ancla.current, { separacion: '--aybar-space-1' })
  }, [abierta, superficie, ancla])
}

/** Ejecuta tras el siguiente pintado, o en la siguiente vuelta si no hay pintado (jsdom). */
export function trasPintar(fn: () => void) {
  if (typeof requestAnimationFrame === 'function') requestAnimationFrame(fn)
  else setTimeout(fn, 0)
}

/** Mueve el foco tras el render, cuando el elemento ya existe. */
export function enfocarTrasPintar(obtener: () => HTMLElement | null | undefined) {
  trasPintar(() => obtener()?.focus())
}

/** Desplaza una opción a la vista si el entorno lo permite (jsdom no lo implementa). */
export function aLaVista(el: Element | null | undefined) {
  if (el && typeof (el as HTMLElement).scrollIntoView === 'function') {
    ;(el as HTMLElement).scrollIntoView({ block: 'nearest' })
  }
}

/** Quita tildes y pasa a minúsculas para filtrar «Junin» y encontrar «Junín». */
export const sinTildes = (texto: string): string =>
  texto.normalize('NFD').replace(/\p{Diacritic}/gu, '').toLowerCase()

/**
 * El texto de un campo que refleja un valor: se reescribe cuando el valor cambia (y se
 * muestra completo, «14/02/2026» aunque se escribiera «14-2-26»), pero no mientras se
 * teclea ni cuando lo escrito no pasó la validación, que se conserva para corregirlo.
 */
export function useTextoDe(clave: string, formatear: () => string): [string, (t: string) => void] {
  const [texto, setTexto] = useState(formatear)
  const [anterior, setAnterior] = useState(clave)
  if (anterior !== clave) {
    setAnterior(clave)
    setTexto(formatear())
  }
  return [texto, setTexto]
}

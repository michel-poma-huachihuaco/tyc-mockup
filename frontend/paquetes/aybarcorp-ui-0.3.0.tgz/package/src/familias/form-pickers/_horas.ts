/**
 * Horas de Time Picker y Date-Time Picker. El dato es siempre `HH:mm` de 24 horas; el
 * formato de 12 horas es solo presentación. Mezclar dato y presentación es la fuente de
 * la mitad de los errores de hora.
 */

export type FormatoHora = '24h' | '12h'

const dos = (n: number): string => String(n).padStart(2, '0')

/** `HH:mm` a partir de horas y minutos. */
export const hhmm = (h: number, m: number): string => `${dos(h)}:${dos(m)}`

/** Minutos desde medianoche de un `HH:mm`. */
export const minutosDe = (valor: string): number => {
  const [h = 0, m = 0] = valor.split(':').map(Number)
  return h * 60 + m
}

/**
 * Lee una hora escrita a la carrera: «930», «9:30», «9.30», «9 30» y «9:30 p.m.» son la
 * misma hora. Vacío es `null`; lo que no es una hora es `'invalida'`.
 */
export function normalizarHora(texto: string): string | null | 'invalida' {
  const t = texto.trim().toLowerCase()
  if (!t) return null
  const pm = /p\.?\s?m\.?$/.test(t)
  const am = /a\.?\s?m\.?$/.test(t)
  const sinSufijo = t.replace(/[ap]\.?\s?m\.?$/, '').trim()
  if (!/^\d{1,2}(?:[:.\s]?\d{2})?$/.test(sinSufijo)) return 'invalida'
  const solo = sinSufijo.replace(/\D/g, '')
  let h: number
  let m: number
  if (solo.length <= 2) {
    h = Number(solo)
    m = 0
  } else if (solo.length === 3) {
    h = Number(solo.slice(0, 1))
    m = Number(solo.slice(1))
  } else {
    h = Number(solo.slice(0, 2))
    m = Number(solo.slice(2, 4))
  }
  if ((pm || am) && (h < 1 || h > 12)) return 'invalida'
  if (pm && h < 12) h += 12
  if (am && h === 12) h = 0
  if (h > 23 || m > 59) return 'invalida'
  return hhmm(h, m)
}

/** La hora tal como se muestra: 09:30 o «9:30 a.m.», con la franja en el texto. */
export function mostrarHora(valor: string, formato: FormatoHora): string {
  if (formato === '24h') return valor
  const [h = 0, m = 0] = valor.split(':').map(Number)
  return `${((h + 11) % 12) + 1}:${dos(m)} ${h < 12 ? 'a.m.' : 'p.m.'}`
}

const NOMBRES = ['doce', 'una', 'dos', 'tres', 'cuatro', 'cinco', 'seis', 'siete', 'ocho', 'nueve', 'diez', 'once']

/**
 * La hora dicha como se dice: «nueve y media de la mañana», «doce de la noche». Un
 * lector que lee «09:30» dice «cero nueve dos puntos treinta».
 */
export function horaHablada(valor: string): string {
  const [h = 0, m = 0] = valor.split(':').map(Number)
  const franja =
    h === 12 ? 'del mediodía' : h >= 6 && h < 12 ? 'de la mañana' : h > 12 && h < 21 ? 'de la tarde' : 'de la noche'
  const minutos = m === 0 ? '' : m === 15 ? ' y cuarto' : m === 30 ? ' y media' : ` y ${m}`
  return `${NOMBRES[h % 12] ?? ''}${minutos} ${franja}`
}

/** «a las nueve y media de la mañana», «a la una de la tarde». */
export const aLaHora = (valor: string): string =>
  `${Number(valor.split(':')[0]) % 12 === 1 ? 'a la' : 'a las'} ${horaHablada(valor)}`

/**
 * Las horas de la lista. Lo que cae fuera del horario no se pinta apagado: no aparece,
 * para no obligar a recorrer con flechas opciones que no se pueden elegir.
 */
export function horasDeLaLista(paso: number, minima?: string, maxima?: string): string[] {
  const salto = Number.isFinite(paso) && paso > 0 ? paso : 30
  const out: string[] = []
  for (let m = 0; m < 24 * 60; m += salto) {
    const valor = hhmm(Math.floor(m / 60), m % 60)
    if (minima && valor < minima) continue
    if (maxima && valor > maxima) continue
    out.push(valor)
  }
  return out
}

export const franjaDe = (valor: string): string => (valor < '13:00' ? 'Mañana' : valor < '21:00' ? 'Tarde' : 'Noche')

/** La hora de la lista más cercana a una dada: es la que se activa al abrir. */
export function masCercana(horas: string[], objetivo: string): number {
  if (horas.length === 0) return -1
  const meta = minutosDe(objetivo)
  let mejor = 0
  horas.forEach((h, i) => {
    if (Math.abs(minutosDe(h) - meta) < Math.abs(minutosDe(horas[mejor] ?? h) - meta)) mejor = i
  })
  return mejor
}

/** `HH:mm` de una `Date`. */
export const horaDe = (d: Date): string => hhmm(d.getHours(), d.getMinutes())

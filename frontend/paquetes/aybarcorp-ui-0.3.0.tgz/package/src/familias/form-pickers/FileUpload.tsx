import { forwardRef, useId, useRef, useState } from 'react'
import type { HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import { unir } from './_fechas.js'
import { admitido, formatosLegibles, partirNombre, pesoLegible } from './_archivos.js'
import { IconoCerrar, IconoSubir } from './_iconos.js'

export type UploadFileStatus = 'pending' | 'uploading' | 'done' | 'error'

/** Un archivo de la lista, con su estado de subida. */
export interface UploadFile {
  id: string
  name: string
  /** Peso en bytes. */
  size: number
  status: UploadFileStatus
  /** Porcentaje 0–100 mientras `status` es `uploading`. */
  progress?: number
  /** Motivo concreto del fallo: «Supera los 10 MB», no «Archivo no válido». */
  error?: string
}

export interface PropsFileUpload extends Omit<HTMLAttributes<HTMLDivElement>, 'className'> {
  /** Etiqueta del campo; obligatoria. Nombra el documento: «Documentación del contrato». */
  label: string
  /** Formatos admitidos, como el `accept` nativo: «.pdf,.jpg,.jpeg». */
  accept?: string
  /** Permite varios archivos, que se acumulan en la lista. Sin ella, uno nuevo sustituye al anterior. */
  multiple?: boolean
  /** Tamaño máximo por archivo, en bytes. Un archivo mayor se rechaza con el límite concreto. */
  maxSize?: number
  /** Número máximo de archivos. Al alcanzarlo, el disparador se deshabilita y lo explica. */
  maxFiles?: number
  /** Archivos con su estado y progreso. La lista la lleva quien sube: el componente no sube nada. */
  files?: UploadFile[]
  /** Archivos añadidos, ya filtrados: vacíos, de formato no admitido, demasiado grandes o
   *  repetidos no llegan aquí, se explican junto al campo. */
  onFilesAdd?: (files: File[]) => void
  /** Archivo quitado (o subida cancelada). El foco pasa al siguiente o al disparador. */
  onFileRemove?: (id: string) => void
  /** Reintento de una subida fallida. Un archivo con error se queda en la lista. */
  onFileRetry?: (id: string) => void
  /** Requisitos visibles antes de elegir: «PDF o JPG, hasta 10 MB por archivo, máximo 5 archivos». */
  requirements?: string
  /** Error del campo completo, no de un archivo. */
  error?: string
  /** Deshabilita el disparador. */
  disabled?: boolean
}

interface Rechazo {
  mensaje: string
  /** Un duplicado se puede reemplazar en lugar de acumular dos copias. */
  reemplazar?: { id: string; archivo: File }
}

/**
 * Adjuntar archivos con su progreso, sus errores y la posibilidad de quitarlos. El
 * `input type="file"` es el control real —el que usan el lector, el teclado y el
 * dictado— y el botón visible solo lo activa.
 */
export const FileUpload = forwardRef<HTMLDivElement, PropsFileUpload>(function FileUpload(
  {
    label,
    accept,
    multiple = false,
    maxSize,
    maxFiles,
    files = [],
    onFilesAdd,
    onFileRemove,
    onFileRetry,
    requirements,
    error,
    disabled = false,
    ...resto
  },
  ref,
) {
  const id = useId()
  const idRequisitos = `${id}-req`
  const idError = `${id}-error`
  const idLleno = `${id}-full`
  const [rechazos, setRechazos] = useState<Rechazo[]>([])
  const lista = useRef<HTMLUListElement>(null)
  const entrada = useRef<HTMLInputElement>(null)

  const archivos = Array.isArray(files) ? files : []
  const lleno = multiple && !!maxFiles && archivos.length >= maxFiles
  const inactivo = disabled || lleno

  const elegir = (nuevos: File[]) => {
    const motivos: Rechazo[] = []
    const validos: File[] = []
    for (const f of nuevos) {
      if (f.size === 0) motivos.push({ mensaje: `${f.name}: el archivo está vacío` })
      else if (!admitido(f, accept)) motivos.push({ mensaje: `${f.name}: solo se admiten ${formatosLegibles(accept)}` })
      // el límite concreto, no «archivo no válido»
      else if (maxSize && f.size > maxSize) motivos.push({ mensaje: `${f.name}: supera los ${pesoLegible(maxSize)}` })
      else {
        const repetido = multiple ? archivos.find((x) => x.name === f.name) : undefined
        if (repetido) motivos.push({ mensaje: `${f.name}: ya está en la lista`, reemplazar: { id: repetido.id, archivo: f } })
        else validos.push(f)
      }
    }
    let aceptados = validos
    if (!multiple) {
      aceptados = validos.slice(0, 1)
      // de un archivo: el nuevo sustituye al anterior
      if (aceptados.length) for (const anterior of archivos) onFileRemove?.(anterior.id)
    } else if (maxFiles) {
      const caben = Math.max(0, maxFiles - archivos.length)
      const fuera = validos.length - caben
      if (fuera > 0) {
        aceptados = validos.slice(0, caben)
        motivos.push({
          mensaje: `${fuera === 1 ? 'No se añadió 1 archivo' : `No se añadieron ${fuera} archivos`}: el máximo es ${maxFiles}.`,
        })
      }
    }
    setRechazos(motivos)
    if (aceptados.length) onFilesAdd?.(aceptados)
  }

  const quitar = (idArchivo: string, i: number) => {
    // El foco va al siguiente archivo, o al disparador si era el último: si no, cae al
    // cuerpo del documento y la persona reaparece al principio de la página.
    const botones = lista.current?.querySelectorAll<HTMLElement>('[data-file-remove]')
    const siguiente = botones?.[i + 1] ?? botones?.[i - 1]
    onFileRemove?.(idArchivo)
    ;(siguiente ?? entrada.current)?.focus()
  }

  const subiendo = archivos.some((f) => f.status === 'uploading')
  const completados = archivos.filter((f) => f.status === 'done').map((f) => `${f.name} subido`)

  return (
    <div {...resto} ref={ref} className="ay-field">
      {/* el input es el control real: sustituirlo por un div rompe el selector del sistema */}
      <label className="ay-label" htmlFor={id}>
        {label}
      </label>
      {/* los requisitos, antes de elegir: descubrirlos al fallar obliga a repetir */}
      {requirements && (
        <p className="ay-help" id={idRequisitos}>
          {requirements}
        </p>
      )}

      <input
        ref={entrada}
        className="ay-upload__input ay-visually-hidden"
        id={id}
        type="file"
        accept={accept}
        multiple={multiple}
        disabled={inactivo}
        aria-describedby={unir(requirements && idRequisitos, lleno && idLleno, error && idError)}
        aria-invalid={error ? true : undefined}
        onChange={(e) => {
          elegir(Array.from(e.target.files ?? []))
          e.target.value = '' // permite volver a elegir el mismo archivo tras quitarlo
        }}
      />
      <label
        className={cx('ay-btn', 'ay-btn--secondary', 'ay-btn--md', inactivo && 'ay-btn--disabled')}
        htmlFor={id}
        aria-disabled={inactivo || undefined}
        title={lleno ? `Máximo ${maxFiles} archivos` : undefined}
      >
        <IconoSubir />
        {multiple ? 'Elegir archivos' : 'Elegir archivo'}
      </label>
      {lleno && (
        <p className="ay-help" id={idLleno}>
          Has alcanzado el máximo de {maxFiles} archivos. Quita uno para añadir otro.
        </p>
      )}

      {/* lista real: el lector anuncia cuántos archivos hay */}
      {archivos.length > 0 && (
        <ul className="ay-upload__list" ref={lista} aria-busy={subiendo || undefined}>
          {archivos.map((f, i) => {
            const [base, extension] = partirNombre(f.name)
            const progreso = Math.max(0, Math.min(100, Math.round(f.progress ?? 0)))
            return (
              <li
                key={f.id}
                className={cx('ay-upload__item', f.status === 'error' && 'ay-upload__item--error')}
                onKeyDown={(e) => {
                  if (e.key === 'Delete') {
                    e.preventDefault()
                    quitar(f.id, i)
                  }
                }}
              >
                {/* truncado por el centro: se conserva la extensión */}
                <span className="ay-upload__name" title={f.name}>
                  <span className="ay-upload__base">{base}</span>
                  <span className="ay-upload__ext">{extension}</span>
                </span>
                <span className="ay-upload__size">{pesoLegible(f.size)}</span>

                {f.status === 'uploading' && (
                  // el nombre en la etiqueta: con cuatro barras, un «60%» suelto no dice de cuál
                  <progress className="ay-progress" value={progreso} max={100} aria-label={`Subiendo ${f.name}`}>
                    {progreso}%
                  </progress>
                )}
                {f.status === 'done' && <span className="ay-upload__done">Subido</span>}
                {f.status === 'error' && (
                  <>
                    <span className="ay-upload__error">{f.error ?? 'No se pudo subir el archivo.'}</span>
                    {/* el archivo que falla se queda: perderlo obliga a buscarlo otra vez */}
                    {onFileRetry && (
                      <button
                        type="button"
                        className="ay-btn ay-btn--ghost ay-btn--sm"
                        aria-label={`Reintentar la subida de ${f.name}`}
                        onClick={() => onFileRetry(f.id)}
                      >
                        Reintentar
                      </button>
                    )}
                  </>
                )}

                <button
                  type="button"
                  className="ay-iconbtn ay-iconbtn--ghost ay-iconbtn--sm"
                  data-file-remove=""
                  aria-label={f.status === 'uploading' ? `Cancelar la subida de ${f.name}` : `Quitar ${f.name}`}
                  onClick={() => quitar(f.id, i)}
                >
                  <IconoCerrar className="ay-iconbtn__glyph" />
                </button>
              </li>
            )
          })}
        </ul>
      )}

      {rechazos.length > 0 && (
        <ul className="ay-upload__rejected" role="alert">
          {rechazos.map((r) => (
            <li key={r.mensaje}>
              {r.mensaje}
              {r.reemplazar && (
                <>
                  {' '}
                  <button
                    type="button"
                    className="ay-btn ay-btn--ghost ay-btn--sm"
                    onClick={() => {
                      const { id: anterior, archivo } = r.reemplazar!
                      onFileRemove?.(anterior)
                      onFilesAdd?.([archivo])
                      setRechazos((todos) => todos.filter((x) => x !== r))
                    }}
                  >
                    Reemplazar
                  </button>
                </>
              )}
            </li>
          ))}
        </ul>
      )}

      {/* una vez por archivo, no en cada porcentaje */}
      <p className="ay-visually-hidden" aria-live="polite">
        {completados.join('. ')}
      </p>

      {error && (
        <p className="ay-error" id={idError}>
          {error}
        </p>
      )}
    </div>
  )
})

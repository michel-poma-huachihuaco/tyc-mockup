import { Fragment, useEffect, useRef } from 'react'
import type { RefObject } from 'react'
import { aLaVista } from './_internos.js'
import { franjaDe, mostrarHora } from './_horas.js'
import type { FormatoHora } from './_horas.js'

export interface PropsListaHoras {
  id: string
  horas: string[]
  valor: string | null
  /** Índice de la opción activa; -1 si no hay ninguna. */
  activo: number
  formato: FormatoHora
  conFranjas: boolean
  oculta?: boolean
  onElegir: (hora: string) => void
  /**
   * `virtual`: el foco se queda en el campo y la opción activa se señala con
   * aria-activedescendant, como en Combobox, para no cortar la escritura.
   * `real`: las opciones reciben el foco; es la lista de la superficie combinada de
   * Date-Time Picker, que es un diálogo.
   */
  foco: 'virtual' | 'real'
  onActivo?: (i: number) => void
  /** La lista, para quien la ancla en la capa superior (Time Picker). */
  refLista?: RefObject<HTMLUListElement | null>
}

/** La lista de horas: un listbox con la hora elegida en aria-selected. */
export function ListaHoras({ id, horas, valor, activo, formato, conFranjas, oculta, onElegir, foco, onActivo, refLista }: PropsListaHoras) {
  const lista = useRef<HTMLUListElement>(null)
  const enfocar = useRef(false)

  // Desplazada a la hora activa: abrir una lista de 48 horas en las 00:00 no ayuda.
  useEffect(() => {
    if (oculta || activo < 0) return
    const opcion = lista.current?.ownerDocument.getElementById(`${id}-opt-${activo}`)
    aLaVista(opcion)
    if (foco === 'real' && enfocar.current) {
      enfocar.current = false
      opcion?.focus()
    }
  }, [activo, oculta, id, foco])

  const mover = (i: number) => {
    enfocar.current = true
    onActivo?.(Math.max(0, Math.min(horas.length - 1, i)))
  }

  return (
    <ul
      ref={(nodo) => {
        lista.current = nodo
        if (refLista) refLista.current = nodo
      }}
      className="ay-timepicker__list"
      id={id}
      role="listbox"
      aria-label="Horas disponibles"
      hidden={oculta}
      onKeyDown={
        foco === 'real'
          ? (e) => {
              if (e.key === 'ArrowDown') mover(activo + 1)
              else if (e.key === 'ArrowUp') mover(activo - 1)
              else if (e.key === 'Home') mover(0)
              else if (e.key === 'End') mover(horas.length - 1)
              else if (e.key === 'Enter' || e.key === ' ') {
                const h = horas[activo]
                if (h) onElegir(h)
              } else return
              e.preventDefault()
            }
          : undefined
      }
    >
      {horas.map((h, i) => (
        <Fragment key={h}>
          {conFranjas && (i === 0 || franjaDe(h) !== franjaDe(horas[i - 1] ?? h)) && (
            // la cabecera de franja es presentación, no una opción
            <li className="ay-timepicker__group" role="presentation">
              {franjaDe(h)}
            </li>
          )}
          <li
            id={`${id}-opt-${i}`}
            role="option"
            aria-selected={valor === h}
            className="ay-timepicker__option"
            data-active={i === activo ? '' : undefined}
            tabIndex={foco === 'real' ? (i === Math.max(activo, 0) ? 0 : -1) : undefined}
            onMouseDown={(e) => {
              // el foco no se mueve del campo: la lista no corta la escritura
              if (foco === 'virtual') e.preventDefault()
            }}
            onClick={() => onElegir(h)}
          >
            {mostrarHora(h, formato)}
          </li>
        </Fragment>
      ))}
    </ul>
  )
}

/** Utilidades de File Upload y Dropzone, que son dos disparadores del mismo campo. */

/** «2,4 MB», «640 KB»: con coma decimal, como se escribe en español. */
export function pesoLegible(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes < 0) return ''
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`
  return `${(bytes / 1024 / 1024).toFixed(1).replace(/\.0$/, '').replace('.', ',')} MB`
}

/** ¿El archivo cumple `accept`? Admite extensiones (`.pdf`), tipos (`image/png`) y comodines (`image/*`). */
export function admitido(archivo: { name: string; type: string }, accept?: string): boolean {
  if (!accept) return true
  const reglas = accept
    .split(',')
    .map((r) => r.trim().toLowerCase())
    .filter(Boolean)
  const nombre = archivo.name.toLowerCase()
  const tipo = archivo.type.toLowerCase()
  return reglas.some((r) =>
    r.startsWith('.') ? nombre.endsWith(r) : r.endsWith('/*') ? tipo.startsWith(r.slice(0, -1)) : tipo === r,
  )
}

/** «.pdf,.jpg,.jpeg» → «PDF y JPG»: lo admitido, dicho como lo diría una persona. */
export function formatosLegibles(accept?: string): string {
  if (!accept) return ''
  const nombres = [
    ...new Set(
      accept
        .split(',')
        .map((r) => r.trim().replace(/^\./, '').replace(/\/\*$/, '').replace(/^.*\//, '').toUpperCase())
        .map((r) => (r === 'JPEG' ? 'JPG' : r))
        .filter(Boolean),
    ),
  ]
  if (nombres.length <= 1) return nombres.join('')
  return `${nombres.slice(0, -1).join(', ')} y ${nombres[nombres.length - 1]}`
}

/** Separa nombre y extensión para truncar por el centro y conservar la extensión. */
export function partirNombre(nombre: string): [string, string] {
  const punto = nombre.lastIndexOf('.')
  if (punto <= 0 || punto === nombre.length - 1) return [nombre, '']
  return [nombre.slice(0, punto), nombre.slice(punto)]
}

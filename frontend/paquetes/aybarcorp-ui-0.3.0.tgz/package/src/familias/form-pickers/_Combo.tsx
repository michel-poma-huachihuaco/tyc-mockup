import { forwardRef, useEffect, useLayoutEffect, useRef, useState } from 'react'
import { cx } from '../../utiles.js'
import { anclarEnCapaSuperior } from '../surfaces/_capa.js'
import { aLaVista, sinTildes } from './_internos.js'
import type { OpcionUbigeo } from './_peru.js'

export interface PropsCombo {
  id: string
  opciones: OpcionUbigeo[]
  valor: string
  onCambio: (codigo: string) => void
  /** «distritos»: para el recuento anunciado, «3 distritos de 43». */
  plural: string
  placeholder: string
  disabled?: boolean
  describedBy?: string
  autoComplete?: string
  tamano: 'sm' | 'md' | 'lg'
  ocupado?: boolean
  onEnter?: () => void
}

/**
 * Un nivel de Ubigeo Select con búsqueda, con el marcado canónico de Combobox. El foco
 * no sale del campo: la opción activa se señala con aria-activedescendant.
 */
export const ComboNivel = forwardRef<HTMLInputElement, PropsCombo>(function ComboNivel(
  { id, opciones, valor, onCambio, plural, placeholder, disabled, describedBy, autoComplete, tamano, ocupado, onEnter },
  ref,
) {
  const elegida = opciones.find((o) => o.codigo === valor)
  const [consulta, setConsulta] = useState<string | null>(null)
  const [abierto, setAbierto] = useState(false)
  const [activo, setActivo] = useState(0)
  const lista = useRef<HTMLUListElement>(null)
  const caja = useRef<HTMLDivElement>(null)
  const idLista = `${id}-list`

  const texto = consulta ?? elegida?.nombre ?? (valor && !elegida ? valor : '')
  const filtro = sinTildes(consulta ?? '')
  const visibles = filtro ? opciones.filter((o) => sinTildes(o.nombre).includes(filtro)) : opciones

  // Abierta, la lista sube a la capa superior junto al campo, con su mismo ancho: allí no
  // la tapa nada pegajoso ni la recorta un ancestro. Sin la API sigue anclada con la hoja.
  useLayoutEffect(() => {
    if (!abierto || !lista.current || !caja.current) return
    return anclarEnCapaSuperior(lista.current, caja.current, { separacion: '--aybar-space-1', ancho: 'igual' })
  }, [abierto])

  useEffect(() => {
    if (!abierto) return
    aLaVista(lista.current?.ownerDocument.getElementById(`${id}-opt-${activo}`))
  }, [abierto, activo, id])

  const elegir = (o: OpcionUbigeo) => {
    onCambio(o.codigo)
    setConsulta(null)
    setAbierto(false)
  }

  return (
    <>
      <div ref={caja} className={cx('ay-combo', `ay-combo--${tamano}`)}>
        <input
          ref={ref}
          className="ay-combo__field"
          id={id}
          type="text"
          role="combobox"
          aria-expanded={abierto}
          aria-controls={idLista}
          aria-autocomplete="list"
          aria-activedescendant={abierto && visibles[activo] ? `${id}-opt-${activo}` : undefined}
          aria-describedby={describedBy}
          aria-busy={ocupado || undefined}
          autoComplete={autoComplete}
          placeholder={placeholder}
          disabled={disabled}
          value={texto}
          onChange={(e) => {
            setConsulta(e.target.value)
            setActivo(0)
            setAbierto(true)
          }}
          onBlur={() => {
            // al salir sin elegir, se restaura el valor anterior
            setConsulta(null)
            setAbierto(false)
          }}
          onKeyDown={(e) => {
            if (e.key === 'ArrowDown') {
              e.preventDefault()
              if (!abierto) setAbierto(true)
              else setActivo((i) => Math.min(visibles.length - 1, i + 1))
            } else if (e.key === 'ArrowUp') {
              e.preventDefault()
              setActivo((i) => Math.max(0, i - 1))
            } else if (e.key === 'Enter') {
              const o = abierto ? visibles[activo] : undefined
              e.preventDefault()
              if (o) elegir(o)
              else onEnter?.()
            } else if (e.key === 'Escape' && abierto) {
              // cierra la lista sin cambiar la selección
              e.preventDefault()
              setConsulta(null)
              setAbierto(false)
            }
          }}
        />
        <button
          type="button"
          className="ay-combo__trigger"
          tabIndex={-1}
          aria-label={`Mostrar los ${plural}`}
          disabled={disabled}
          onMouseDown={(e) => e.preventDefault()}
          onClick={() => setAbierto((a) => !a)}
        >
          ⌄
        </button>
      </div>
      <ul className="ay-combo__list" id={idLista} role="listbox" aria-label={plural} hidden={!abierto} ref={lista}>
        {visibles.map((o, i) => (
          <li
            key={o.codigo}
            id={`${id}-opt-${i}`}
            role="option"
            aria-selected={o.codigo === valor}
            className="ay-combo__option"
            data-active={i === activo ? '' : undefined}
            onMouseDown={(e) => e.preventDefault()}
            onClick={() => elegir(o)}
          >
            {o.nombre}
            <span className="ay-combo__desc">Ubigeo {o.codigo}</span>
          </li>
        ))}
        {visibles.length === 0 && (
          <li className="ay-combo__empty" role="presentation">
            Sin coincidencias
          </li>
        )}
      </ul>
      <p className="ay-visually-hidden" aria-live="polite">
        {abierto ? `${visibles.length} ${plural} de ${opciones.length}` : ''}
      </p>
    </>
  )
})

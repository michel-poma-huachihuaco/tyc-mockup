import { forwardRef, useId, useRef, useState } from 'react'
import type { HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import {
  claveDia,
  comoFecha,
  diasDelIntervalo,
  enMinuscula,
  fechaCorta,
  fueraDeRango,
  mismoDia,
  patronDeFecha,
  primeroDeMes,
  sinHora,
  unir,
  validarFecha,
} from './_fechas.js'
import { IconoCalendario } from './_iconos.js'
import { claveDeFechas, useCerrarAlSalir, useEspejo, useSuperficieEnCapa, useTextoDe } from './_internos.js'
import { RejillaCalendario } from './_Rejilla.js'
import type { EstadoDia } from './_Rejilla.js'

export type DateRangePickerSize = 'md' | 'lg'
/** Los dos extremos. Cualquiera puede faltar mientras se elige. */
export type DateRangeValue = [Date | null, Date | null]
/** Periodo predefinido: «Este mes», «Últimos 30 días», «Este trimestre». */
export interface DateRangeShortcut {
  label: string
  range: [Date, Date]
}

export interface PropsDateRangePicker extends Omit<HTMLAttributes<HTMLFieldSetElement>, 'className' | 'onSelect'> {
  /** Nombre del intervalo; obligatorio. Es la leyenda del grupo: «Vigencia del contrato». */
  label: string
  /** Extremos `[desde, hasta]`. Sin `value`, el componente lleva su propio intervalo y
   *  empieza vacío, `[null, null]`. */
  value?: [Date | null, Date | null]
  /** Cambio de intervalo. Un intervalo escrito o elegido al revés llega ya ordenado. */
  onValueChange?: (v: [Date | null, Date | null]) => void
  /** Primera fecha permitida. */
  minDate?: Date
  /** Última fecha permitida. */
  maxDate?: Date
  /** Máximo de días del intervalo, contando los dos extremos. Superarlo se avisa con el
   *  límite; el intervalo no se recorta en silencio. */
  maxSpan?: number
  /** Permite dejar el fin sin definir; el campo vacío dice «Sin fecha de fin». */
  allowOpenEnded?: boolean
  /** Periodos predefinidos junto al calendario. Los imposibles dentro del rango
   *  permitido se deshabilitan y dicen por qué. */
  shortcuts?: Array<{ label: string; range: [Date, Date] }>
  /** Muestra los días del intervalo («31 días») y los añade a la descripción del grupo. */
  showDuration?: boolean
  /** Formato de los campos y del calendario. */
  locale?: string
  /** Mensaje de validación externo; se muestra en el campo «Desde». */
  error?: string
  /** Altura de los campos: `md` por omisión y `lg` en pantallas de informe. */
  size?: DateRangePickerSize
}

/**
 * Intervalo de fechas con los dos extremos validados juntos: dos campos con etiqueta
 * propia dentro de un grupo, y un calendario de dos meses en modo intervalo.
 */
export const DateRangePicker = forwardRef<HTMLFieldSetElement, PropsDateRangePicker>(function DateRangePicker(
  {
    label,
    value,
    onValueChange,
    minDate,
    maxDate,
    maxSpan,
    allowOpenEnded = false,
    shortcuts,
    showDuration = false,
    locale = 'es-PE',
    error,
    size = 'md',
    onBlur,
    ...resto
  },
  ref,
) {
  const id = useId()
  const min = comoFecha(minDate)
  const max = comoFecha(maxDate)
  const patron = patronDeFecha(locale)

  const propPar: [Date | null, Date | null] = [
    value?.[0] ? sinHora(comoFecha(value[0]) ?? new Date(Number.NaN)) : null,
    value?.[1] ? sinHora(comoFecha(value[1]) ?? new Date(Number.NaN)) : null,
  ]
  const [par, setPar] = useEspejo<[Date | null, Date | null]>(
    [valida(propPar[0]), valida(propPar[1])],
    claveDeFechas,
  )
  const [desde, hasta] = par

  const [textoDesde, setTextoDesde] = useTextoDe(`${claveDeFechas(desde)}|${locale}`, () =>
    desde ? fechaCorta(desde, locale) : '',
  )
  const [textoHasta, setTextoHasta] = useTextoDe(`${claveDeFechas(hasta)}|${locale}`, () =>
    hasta ? fechaCorta(hasta, locale) : '',
  )
  const [errores, setErrores] = useState<{ desde?: string; hasta?: string }>({})
  const [aviso, setAviso] = useState('')
  const [abierto, setAbierto] = useState(false)
  const [mes, setMes] = useState(() => primeroDeMes(desde ?? new Date()))
  const [apuntado, setApuntado] = useState<Date | null>(null)
  const [enfocarEn, setEnfocarEn] = useState<Date | undefined>(undefined)
  const origen = useRef<HTMLElement | null>(null)
  const disparador = useRef<HTMLButtonElement>(null)
  const superficie = useRef<HTMLDivElement>(null)

  const cerrar = (devolverFoco: boolean) => {
    setAbierto(false)
    setApuntado(null)
    if (devolverFoco) (origen.current ?? disparador.current)?.focus()
  }
  const { raiz, alSalir } = useCerrarAlSalir(abierto, () => cerrar(false))
  useSuperficieEnCapa(abierto, superficie, raiz)

  // Abrir en el mes del extremo que se está eligiendo: abrir siempre en hoy obliga a
  // recorrer con flechas los meses que separan hoy de la fecha que se corrige.
  const abrirEn = (d: Date | null, quien: HTMLElement | null) => {
    origen.current = quien
    setMes(primeroDeMes(d ?? new Date()))
    setEnfocarEn(d ?? undefined)
    setAbierto(true)
  }

  // Un intervalo que supera el máximo se avisa en el campo «Hasta», que es el que falla.
  const excedido = !!maxSpan && !!desde && !!hasta && diasDelIntervalo(desde, hasta) > maxSpan
  const errorDesde = error ?? errores.desde
  const errorHasta = errores.hasta ?? (excedido ? `El periodo no puede superar ${maxSpan} días` : undefined)

  const emitir = (siguiente: [Date | null, Date | null]) => {
    setPar(siguiente)
    onValueChange?.(siguiente)
  }

  /** El extremo que elige el calendario: inicio, o fin si ya hay inicio. */
  const fijar = (d: Date) => {
    // Sin inicio, o con el intervalo completo: empieza uno nuevo.
    if (!desde || (desde && hasta)) {
      setErrores({})
      emitir([d, null])
      return
    }
    // Invertido: se ordena en silencio. Rechazarlo es fricción sin motivo.
    const [a, b] = claveDia(d) < claveDia(desde) ? [d, desde] : [desde, d]
    if (maxSpan && diasDelIntervalo(a, b) > maxSpan) {
      setErrores({ hasta: `El periodo no puede superar ${maxSpan} días` })
      return
    }
    setErrores({})
    emitir([a, b])
    cerrar(true)
  }

  const validarDesde = () => {
    const r = validarFecha(textoDesde, locale, min, max)
    if (r.error !== undefined) return setErrores((e) => ({ ...e, desde: r.error }))
    setErrores((e) => ({ ...e, desde: undefined }))
    const d = r.fecha
    if (mismoDia(d, desde) || (!d && !desde)) {
      if (d) setTextoDesde(fechaCorta(d, locale))
      return
    }
    // Inicio posterior al fin: el fin se limpia y se pide de nuevo, y se dice.
    if (d && hasta && claveDia(d) > claveDia(hasta)) {
      setAviso('La fecha de fin se ha borrado: era anterior al nuevo inicio.')
      return emitir([d, null])
    }
    emitir([d, hasta])
  }

  const validarHasta = () => {
    const r = validarFecha(textoHasta, locale, min, max)
    if (r.error !== undefined) return setErrores((e) => ({ ...e, hasta: r.error }))
    const d = r.fecha
    if (mismoDia(d, hasta) || (!d && !hasta)) {
      setErrores((e) => ({ ...e, hasta: undefined }))
      if (d) setTextoHasta(fechaCorta(d, locale))
      return
    }
    // Escrito al revés —«30/04» en Desde y «01/04» en Hasta—: se quería abril, se ordena.
    const [a, b] = d && desde && claveDia(d) < claveDia(desde) ? [d, desde] : [desde, d]
    if (maxSpan && a && b && diasDelIntervalo(a, b) > maxSpan) {
      return setErrores((e) => ({ ...e, hasta: `El periodo no puede superar ${maxSpan} días` }))
    }
    setErrores((e) => ({ ...e, hasta: undefined }))
    emitir([a, b])
  }

  const duracion = desde && hasta ? diasDelIntervalo(desde, hasta) : null
  const idDuracion = `${id}-dur`
  const conDuracion = showDuration && duracion !== null

  const estado = (d: Date): EstadoDia => {
    const k = claveDia(d)
    const a = desde
    const b = hasta ?? (desde ? apuntado : null)
    if (!a) return { elegido: false, enTramo: false }
    if (!b) return { elegido: mismoDia(a, d), enTramo: false, extremo: mismoDia(a, d) ? 'inicio' : undefined }
    const [ini, fin] = claveDia(a) <= claveDia(b) ? [a, b] : [b, a]
    const esIni = k === claveDia(ini)
    const esFin = k === claveDia(fin) && !!hasta
    return {
      elegido: esIni || esFin,
      enTramo: k > claveDia(ini) && k < claveDia(fin),
      extremo: esIni ? 'inicio' : esFin ? 'fin' : undefined,
    }
  }

  const campo = (
    extremo: 'desde' | 'hasta',
    etiqueta: string,
    texto: string,
    setTexto: (t: string) => void,
    validar: () => void,
    mensaje: string | undefined,
    describir?: string,
  ) => {
    const idCampo = `${id}-${extremo}`
    const idError = `${idCampo}-error`
    return (
      <div className="ay-field">
        <label className="ay-label ay-label--sm" htmlFor={idCampo}>
          {etiqueta}
        </label>
        <input
          className="ay-daterange__field"
          id={idCampo}
          type="text"
          inputMode="numeric"
          placeholder={extremo === 'hasta' && allowOpenEnded ? 'Sin fecha de fin' : patron}
          value={texto}
          // el error va solo en el campo que falla: marcar los dos obliga a adivinar
          aria-invalid={mensaje ? true : undefined}
          aria-describedby={unir(mensaje && idError, describir)}
          onChange={(e) => setTexto(e.target.value)}
          onBlur={validar}
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              e.preventDefault()
              validar()
            } else if (e.key === 'ArrowDown') {
              e.preventDefault()
              abrirEn(extremo === 'desde' ? desde : (hasta ?? desde), e.currentTarget)
            }
          }}
        />
        {mensaje && (
          <p className="ay-error" id={idError}>
            {mensaje}
          </p>
        )}
      </div>
    )
  }

  return (
    <fieldset
      {...resto}
      ref={(el) => {
        raiz.current = el
        if (typeof ref === 'function') ref(el)
        else if (ref) ref.current = el
      }}
      className={cx('ay-daterange', `ay-daterange--${size}`)}
      // «31 días» entra en la descripción del grupo: se oye sin restar dos fechas de memoria
      aria-describedby={conDuracion ? idDuracion : undefined}
      onBlur={(e) => {
        onBlur?.(e)
        alSalir(e)
      }}
    >
      <legend className="ay-label">{label}</legend>

      <div className="ay-daterange__fields">
        {campo('desde', 'Desde', textoDesde, setTextoDesde, validarDesde, errorDesde)}
        <span className="ay-daterange__sep" aria-hidden="true">
          –
        </span>
        {campo('hasta', 'Hasta', textoHasta, setTextoHasta, validarHasta, errorHasta, conDuracion ? idDuracion : undefined)}
        <button
          ref={disparador}
          type="button"
          className="ay-daterange__trigger"
          aria-label="Abrir el calendario"
          aria-haspopup="dialog"
          aria-expanded={abierto}
          aria-controls={`${id}-cal`}
          onClick={(e) => (abierto ? cerrar(false) : abrirEn(desde, e.currentTarget))}
        >
          <IconoCalendario />
        </button>
      </div>

      {conDuracion && (
        <p className="ay-daterange__duration" id={idDuracion}>
          {duracion} {duracion === 1 ? 'día' : 'días'}
        </p>
      )}
      {allowOpenEnded && desde && !hasta && <p className="ay-daterange__duration">Sin fecha de fin</p>}

      <div
        ref={superficie}
        className="ay-daterange__surface"
        id={`${id}-cal`}
        role="dialog"
        aria-label={`Elegir ${enMinuscula(label)}`}
        hidden={!abierto}
        onKeyDown={(e) => {
          if (e.key === 'Escape') {
            e.preventDefault()
            e.stopPropagation()
            cerrar(true)
          }
        }}
      >
        <RejillaCalendario
          mes={mes}
          meses={2}
          onMes={setMes}
          locale={locale}
          etiqueta={label}
          tamano="md"
          min={min}
          max={max}
          estado={estado}
          onElegir={fijar}
          onApuntar={desde && !hasta ? setApuntado : undefined}
          activoPreferido={enfocarEn}
          enfocar={abierto}
        />
        {shortcuts && shortcuts.length > 0 && (
          <div className="ay-daterange__shortcuts">
            {shortcuts.map((s, i) => {
              const a = comoFecha(s.range?.[0])
              const b = comoFecha(s.range?.[1])
              // Atajo imposible dentro del rango permitido: se deshabilita y lo explica.
              const fuera = !a || !b || fueraDeRango(a, min, max) || fueraDeRango(b, min, max)
              const idMotivo = `${id}-atajo-${i}`
              return (
                <span key={s.label} className="ay-daterange__shortcut">
                  <button
                    type="button"
                    className="ay-btn ay-btn--ghost ay-btn--sm"
                    aria-disabled={fuera || undefined}
                    aria-describedby={fuera ? idMotivo : undefined}
                    title={fuera ? 'Fuera del periodo permitido' : undefined}
                    onClick={() => {
                      if (fuera || !a || !b) return
                      const [x, y] = claveDia(a) <= claveDia(b) ? [a, b] : [b, a]
                      setErrores({})
                      emitir([sinHora(x), sinHora(y)])
                      cerrar(true)
                    }}
                  >
                    {s.label}
                  </button>
                  {fuera && (
                    <span className="ay-visually-hidden" id={idMotivo}>
                      Fuera del periodo permitido
                    </span>
                  )}
                </span>
              )
            })}
          </div>
        )}
      </div>

      {/* mientras falta un extremo, el estado se dice; el tramo intermedio no se anuncia */}
      <p className="ay-visually-hidden" aria-live="polite">
        {desde && !hasta && !allowOpenEnded ? 'Elige la fecha de fin' : aviso}
      </p>
    </fieldset>
  )
})

const valida = (d: Date | null): Date | null => (d && !Number.isNaN(+d) ? d : null)

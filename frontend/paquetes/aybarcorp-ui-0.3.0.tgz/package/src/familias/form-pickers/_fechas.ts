/**
 * Cálculo de fechas de la familia de pickers, sin librerías: Date e Intl nativos.
 *
 * Todo se hace sobre fechas sin hora (`sinHora`): con la hora dentro, el cambio de
 * horario de verano hace que sumar un día a las 00:00 caiga en el mismo día a las 23:00
 * y que el calendario repita o salte una fecha.
 */

const DIA_MS = 86_400_000

/** La fecha a medianoche local: el valor que se guarda y se compara. */
export const sinHora = (d: Date): Date => new Date(d.getFullYear(), d.getMonth(), d.getDate())

/** Clave numérica aaaammdd: compara días sin tocar horas ni zonas. */
export const claveDia = (d: Date): number => d.getFullYear() * 10_000 + d.getMonth() * 100 + d.getDate()

export const mismoDia = (a: Date | null | undefined, b: Date | null | undefined): boolean =>
  !!a && !!b && claveDia(a) === claveDia(b)

export const mismoMes = (a: Date, b: Date): boolean =>
  a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth()

export const primeroDeMes = (d: Date): Date => new Date(d.getFullYear(), d.getMonth(), 1)

/**
 * Acepta una `Date` o una cadena ISO local (`2026-02-14`, `2026-02-16T09:30`). La cadena
 * existe porque el catálogo de ejemplos es JSON y no puede llevar una `Date`; se
 * interpreta como fecha local, nunca como UTC, para que no retroceda un día.
 */
export function comoFecha(valor: unknown): Date | undefined {
  if (valor instanceof Date) return Number.isNaN(+valor) ? undefined : valor
  if (typeof valor !== 'string' || !valor.trim()) return undefined
  const m = /^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2})(?::(\d{2}))?)?$/.exec(valor.trim())
  if (m) {
    const [, y, mes, d, h = '0', min = '0', s = '0'] = m
    return new Date(Number(y), Number(mes) - 1, Number(d), Number(h), Number(min), Number(s))
  }
  const libre = new Date(valor)
  return Number.isNaN(+libre) ? undefined : libre
}

/** Suma días sobre el calendario, no sobre milisegundos. */
export function sumarDias(d: Date, dias: number): Date {
  return new Date(d.getFullYear(), d.getMonth(), d.getDate() + dias)
}

/**
 * Suma meses conservando el día; si el destino no lo tiene —el 31 hacia febrero— se
 * ajusta al último día de ese mes en lugar de desbordar al mes siguiente.
 */
export function sumarMeses(d: Date, meses: number): Date {
  const destino = new Date(d.getFullYear(), d.getMonth() + meses, 1)
  const ultimo = new Date(destino.getFullYear(), destino.getMonth() + 1, 0).getDate()
  return new Date(destino.getFullYear(), destino.getMonth(), Math.min(d.getDate(), ultimo))
}

/** Días de un intervalo contando los dos extremos: un solo día dura «1 día». */
export function diasDelIntervalo(a: Date, b: Date): number {
  return Math.round((+sinHora(b) - +sinHora(a)) / DIA_MS) + 1
}

/** Lunes en español y domingo en inglés: el criterio del sistema de diseño. */
export const empiezaEnDomingo = (locale: string): boolean => /^en\b/i.test(locale)

/** Índice 0–6 de una fecha dentro de su semana, según el primer día del locale. */
export const posicionEnSemana = (d: Date, locale: string): number =>
  empiezaEnDomingo(locale) ? d.getDay() : (d.getDay() + 6) % 7

/** Seis semanas fijas: la altura del calendario no cambia entre meses. */
export function semanasDelMes(mes: Date, locale: string): Date[][] {
  const primero = primeroDeMes(mes)
  const inicio = sumarDias(primero, -posicionEnSemana(primero, locale))
  return Array.from({ length: 6 }, (_, s) =>
    Array.from({ length: 7 }, (_, d) => sumarDias(inicio, s * 7 + d)),
  )
}

/** Nombres completo y abreviado de los siete días, en el orden de la semana del locale. */
export function diasDeLaSemana(locale: string): { completo: string; corto: string }[] {
  const domingo = new Date(2026, 1, 1) // un domingo cualquiera
  const desde = empiezaEnDomingo(locale) ? 0 : 1
  return Array.from({ length: 7 }, (_, i) => {
    const d = sumarDias(domingo, desde + i)
    return {
      completo: new Intl.DateTimeFormat(locale, { weekday: 'long' }).format(d),
      corto: new Intl.DateTimeFormat(locale, { weekday: 'narrow' }).format(d).toUpperCase(),
    }
  })
}

/** «febrero de 2026»: el mes y el año completos. */
export const nombreDelMes = (d: Date, locale: string): string =>
  d.toLocaleDateString(locale, { month: 'long', year: 'numeric' })

/** «14 de febrero de 2026». */
export const fechaLarga = (d: Date, locale: string): string =>
  d.toLocaleDateString(locale, { day: 'numeric', month: 'long', year: 'numeric' })

/** «14 de febrero de 2026, sábado»: el número solo no sitúa. */
export function nombreAccesibleDelDia(d: Date, locale: string): string {
  const dia = new Intl.DateTimeFormat(locale, { weekday: 'long' }).format(d)
  return `${fechaLarga(d, locale)}, ${dia}`
}

/** El formato corto que se escribe en el campo: 14/02/2026. */
export const fechaCorta = (d: Date, locale: string): string =>
  d.toLocaleDateString(locale, { day: '2-digit', month: '2-digit', year: 'numeric' })

/** El orden de las partes según el locale: día-mes-año o mes-día-año. */
export const mesPrimero = (locale: string): boolean => {
  const partes = new Intl.DateTimeFormat(locale, { day: '2-digit', month: '2-digit', year: 'numeric' })
    .formatToParts(new Date(2026, 1, 14))
    .filter((p) => p.type !== 'literal')
    .map((p) => p.type)
  return partes[0] === 'month'
}

/** El formato esperado, que cambia junto con el placeholder: dd/mm/aaaa o mm/dd/yyyy. */
export const patronDeFecha = (locale: string): string => {
  const ingles = /^en\b/i.test(locale)
  const anio = ingles ? 'yyyy' : 'aaaa'
  return mesPrimero(locale) ? `mm/dd/${anio}` : `dd/mm/${anio}`
}

/** Año de dos cifras: ventana declarada; 71–99 son del siglo XX y 00–70 del XXI. */
const anioCompleto = (y: number): number => (y < 100 ? (y > 70 ? 1900 + y : 2000 + y) : y)

/**
 * Lee lo escrito. Barra, guion y punto valen igual como separador; un campo vacío es
 * `null` —nunca la fecha de hoy— y lo que no es una fecha real es `'invalida'`.
 */
export function parsearFecha(texto: string, locale: string): Date | null | 'invalida' {
  const limpio = texto.trim()
  if (!limpio) return null
  const partes = limpio.split(/\s*[/.\-]\s*/)
  if (partes.length !== 3 || partes.some((p) => !/^\d{1,4}$/.test(p))) return 'invalida'
  const [a, b, c] = partes.map(Number) as [number, number, number]
  const [d, m] = mesPrimero(locale) ? [b, a] : [a, b]
  const y = anioCompleto(c)
  const fecha = new Date(y, m - 1, d)
  return fecha.getFullYear() === y && fecha.getMonth() === m - 1 && fecha.getDate() === d
    ? fecha
    : 'invalida'
}

/** Restringe una fecha al intervalo permitido. */
export function acotar(d: Date, min?: Date, max?: Date): Date {
  if (min && claveDia(d) < claveDia(min)) return sinHora(min)
  if (max && claveDia(d) > claveDia(max)) return sinHora(max)
  return d
}

export const fueraDeRango = (d: Date, min?: Date, max?: Date): boolean =>
  (!!min && claveDia(d) < claveDia(min)) || (!!max && claveDia(d) > claveDia(max))

/** Une clases descartando falsy; ids de aria-describedby con la misma regla. */
export const unir = (...partes: (string | false | null | undefined)[]): string | undefined =>
  partes.filter(Boolean).join(' ') || undefined

/** Resultado de validar lo escrito: la fecha (o null si se vació) o el mensaje concreto. */
export type ResultadoFecha = { fecha: Date | null; error?: undefined } | { fecha?: undefined; error: string }

/**
 * Valida lo escrito en un campo de fecha. El error de formato y el de rango son
 * mensajes distintos: «Usa el formato dd/mm/aaaa» no es lo mismo que «Elige una fecha
 * posterior al 28 de febrero de 2026», y el segundo dice cuál es el rango.
 */
export function validarFecha(
  texto: string,
  locale: string,
  min?: Date,
  max?: Date,
  deshabilitada?: (d: Date) => boolean,
): ResultadoFecha {
  const r = parsearFecha(texto, locale)
  if (r === 'invalida') return { error: `Usa el formato ${patronDeFecha(locale)}` }
  if (r === null) return { fecha: null }
  if (min && claveDia(r) < claveDia(min))
    return { error: `Elige una fecha posterior al ${fechaLarga(sumarDias(min, -1), locale)}` }
  if (max && claveDia(r) > claveDia(max))
    return { error: `Elige una fecha anterior al ${fechaLarga(sumarDias(max, 1), locale)}` }
  if (deshabilitada?.(r)) return { error: 'Esa fecha no está disponible. Elige otra.' }
  return { fecha: r }
}

/** «Fecha de entrega prevista» → «fecha de entrega prevista», para «Elegir la …». */
export const enMinuscula = (texto: string): string =>
  texto ? texto.charAt(0).toLocaleLowerCase() + texto.slice(1) : texto

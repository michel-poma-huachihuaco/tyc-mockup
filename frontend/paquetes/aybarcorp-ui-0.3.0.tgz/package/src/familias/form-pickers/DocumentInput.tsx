import { forwardRef, useId, useRef, useState } from 'react'
import type { FieldsetHTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import { unir } from './_fechas.js'
import { useEspejo } from './_internos.js'
import { REGLAS_DOCUMENTO, limpiarDocumento } from './_peru.js'

export type DocType = 'dni' | 'ruc' | 'ce' | 'pasaporte'
export type DocumentInputSize = 'sm' | 'md' | 'lg'

export interface PropsDocumentInput extends Omit<FieldsetHTMLAttributes<HTMLFieldSetElement>, 'className'> {
  /** Tipo de documento, que fija la regla: longitud, teclado y validación. */
  type?: DocType
  /** Cambio de tipo. El número se limpia y se anuncia: la regla nueva no aplica al anterior. */
  onTypeChange?: (t: DocType) => void
  /** Número, sin separadores. */
  value?: string
  /** Cambio del número, ya sin guiones, puntos ni espacios. */
  onValueChange?: (v: string) => void
  /** Tipos ofrecidos. Con uno solo, el selector se oculta (formulario solo de empresa: RUC). */
  allowedTypes?: DocType[]
  /** Resuelve el titular tras un documento válido; `null` si no existe en el padrón. Si
   *  falla, el campo sigue siendo válido por formato y no se bloquea el formulario. */
  onLookup?: (type: DocType, value: string) => Promise<string | null>
  /** Titular resuelto, mostrado bajo el campo como dato, no como aprobación. */
  holderName?: string
  /** Mensaje de error; sobrescribe la validación interna. */
  error?: string
  /** Altura del conjunto: `sm` en tablas y paneles densos, `md` en formularios, `lg` en altas en móvil. */
  size?: DocumentInputSize
  /** Deshabilita el selector y el campo a la vez: media pieza activa se lee como un fallo. */
  disabled?: boolean
  /** Leyenda del grupo. Nombra el uso, no el sistema: «Documento del comprador». */
  label?: string
}

type Consulta = { estado: 'consultando' } | { estado: 'resuelto'; nombre: string } | { estado: 'no-encontrado' } | { estado: 'fallo' }

/**
 * Documento de identidad peruano —DNI, RUC, carné de extranjería o pasaporte— con la
 * regla de su tipo: el RUC valida su dígito verificador en el cliente antes de
 * consultar, y el error dice la regla concreta, nunca «documento inválido».
 */
export const DocumentInput = forwardRef<HTMLFieldSetElement, PropsDocumentInput>(function DocumentInput(
  {
    type = 'dni',
    onTypeChange,
    value = '',
    onValueChange,
    allowedTypes = ['dni', 'ruc', 'ce', 'pasaporte'],
    onLookup,
    holderName,
    error,
    size = 'md',
    disabled = false,
    label = 'Documento del comprador',
    ...resto
  },
  ref,
) {
  const id = useId()
  const idTipo = `${id}-tipo`
  const idNumero = `${id}-num`
  const idAyuda = `${id}-ayuda`
  const idError = `${id}-error`
  const idTitular = `${id}-titular`

  const permitidos = allowedTypes.length > 0 ? allowedTypes : (['dni'] as DocType[])
  const [tipoInterno, setTipo] = useEspejo<DocType>(type)
  const tipo = permitidos.includes(tipoInterno) ? tipoInterno : (permitidos[0] as DocType)
  const regla = REGLAS_DOCUMENTO[tipo]

  const valorProp = typeof value === 'string' ? value : String(value ?? '')
  const [numero, setNumero] = useEspejo<string>(limpiarDocumento(valorProp, regla.numerico))
  // Lo que se ve mientras se escribe: el campo acepta cualquier tecla —con dictado, una
  // tecla que no hace nada parece un campo roto— y descarta lo que sobra al salir.
  const [borrador, setBorrador] = useState(valorProp)
  const [propAnterior, setPropAnterior] = useState(valorProp)
  if (propAnterior !== valorProp) {
    setPropAnterior(valorProp)
    if (limpiarDocumento(borrador, regla.numerico) !== limpiarDocumento(valorProp, regla.numerico)) setBorrador(valorProp)
  }

  const [tocado, setTocado] = useState(false)
  const [aviso, setAviso] = useState('')
  const [consulta, setConsulta] = useState<Consulta | null>(null)
  const turno = useRef(0)
  const consultado = useRef('')

  const cambiarNumero = (crudo: string) => {
    setBorrador(crudo)
    const limpio = limpiarDocumento(crudo, regla.numerico)
    if (limpio !== numero) {
      setNumero(limpio)
      setConsulta(null)
      onValueChange?.(limpio)
    }
  }

  const salir = () => {
    setTocado(true)
    // Sin forzar mayúsculas al escribir; se normaliza al salir.
    const final = regla.numerico ? numero : numero.toUpperCase()
    setBorrador(final)
    if (final !== numero) {
      setNumero(final)
      onValueChange?.(final)
    }
    if (!final || regla.validar(final) || !onLookup || consultado.current === `${tipo}:${final}`) return
    consultado.current = `${tipo}:${final}`
    const mio = ++turno.current
    setConsulta({ estado: 'consultando' })
    onLookup(tipo, final).then(
      (nombre) => {
        if (mio !== turno.current) return
        setConsulta(nombre ? { estado: 'resuelto', nombre } : { estado: 'no-encontrado' })
      },
      () => {
        if (mio !== turno.current) return
        // Un padrón caído no bloquea el formulario: el formato ya es válido.
        setConsulta({ estado: 'fallo' })
      },
    )
  }

  const cambiarTipo = (t: DocType) => {
    setTipo(t)
    onTypeChange?.(t)
    turno.current++
    consultado.current = ''
    setConsulta(null)
    setTocado(false)
    const habia = numero.length > 0
    setNumero('')
    setBorrador('')
    if (habia) onValueChange?.('') // la regla cambió: el número anterior ya no aplica
    setAviso(`Tipo cambiado a ${REGLAS_DOCUMENTO[t].etiqueta}.${habia ? ' El número se ha borrado.' : ''}`)
  }

  // Solo al salir del campo: marcar en rojo un DNI de tres dígitos que se está tecleando
  // es acusar de un fallo que no se ha cometido.
  const errorVisible = error ?? (tocado && numero ? regla.validar(numero) : null)

  const titular = (() => {
    if (holderName) return `${regla.padron}: ${holderName}`
    if (!consulta) return aviso
    if (consulta.estado === 'consultando') return 'Consultando el titular…'
    if (consulta.estado === 'resuelto') return `${regla.padron}: ${consulta.nombre}`
    if (consulta.estado === 'no-encontrado')
      return `No figura en el padrón de ${regla.padron}. Puedes continuar; el registro quedará marcado para revisión.`
    return 'No hemos podido verificar el documento. Puedes continuar: el formato es válido.'
  })()

  return (
    <fieldset
      {...resto}
      ref={ref}
      className={cx('ay-doc', `ay-doc--${size}`)}
      disabled={disabled}
      aria-busy={consulta?.estado === 'consultando' || undefined}
    >
      {/* fieldset con legend: el tipo y el número son un solo dato, no dos controles */}
      <legend className="ay-label">{label}</legend>

      <div className="ay-doc__group" data-invalid={errorVisible ? '' : undefined}>
        {permitidos.length > 1 && (
          <>
            <label className="ay-visually-hidden" htmlFor={idTipo}>
              Tipo de documento
            </label>
            <select
              id={idTipo}
              className="ay-doc__type"
              value={tipo}
              onChange={(e) => cambiarTipo(e.target.value as DocType)}
            >
              {permitidos.map((t) => (
                <option key={t} value={t}>
                  {REGLAS_DOCUMENTO[t].etiqueta}
                </option>
              ))}
            </select>
          </>
        )}

        <label className="ay-visually-hidden" htmlFor={idNumero}>
          {permitidos.length > 1 ? 'Número de documento' : `Número de ${regla.etiqueta}`}
        </label>
        <input
          id={idNumero}
          className="ay-doc__number"
          type="text"
          inputMode={regla.numerico ? 'numeric' : 'text'}
          // a propósito: no hay token estándar para un documento nacional, y el historial
          // de otro campo numérico induce a guardar el documento de otra persona
          autoComplete="off"
          maxLength={regla.maxLength}
          value={borrador}
          aria-describedby={unir(idAyuda, errorVisible && idError, idTitular)}
          aria-invalid={errorVisible ? true : undefined}
          onChange={(e) => cambiarNumero(e.target.value)}
          onPaste={(e) => {
            // Al pegar se limpian guiones, puntos y espacios antes de validar.
            e.preventDefault()
            const campo = e.currentTarget
            const inicio = campo.selectionStart ?? borrador.length
            const fin = campo.selectionEnd ?? borrador.length
            const pegado = limpiarDocumento(e.clipboardData.getData('text'), regla.numerico)
            cambiarNumero(limpiarDocumento(borrador.slice(0, inicio) + pegado + borrador.slice(fin), regla.numerico).slice(0, regla.maxLength))
          }}
          onBlur={salir}
          onKeyDown={(e) => {
            // Escape cancela la consulta en curso sin vaciar el campo.
            if (e.key === 'Escape' && consulta?.estado === 'consultando') {
              e.preventDefault()
              turno.current++
              consultado.current = ''
              setConsulta(null)
              setAviso('Consulta del titular cancelada.')
            }
          }}
        />
      </div>

      {/* el formato existe antes de escribir: aprenderlo tras fallar es un mal trato */}
      <p id={idAyuda} className="ay-helper">
        {regla.ayuda}
      </p>
      {errorVisible && (
        <p id={idError} className="ay-error-msg" role="alert">
          {errorVisible}
        </p>
      )}
      {/* polite: la respuesta llega sin sacar del sitio a quien sigue escribiendo */}
      <p id={idTitular} className="ay-doc__holder" role="status" aria-live="polite">
        {titular}
      </p>
    </fieldset>
  )
})

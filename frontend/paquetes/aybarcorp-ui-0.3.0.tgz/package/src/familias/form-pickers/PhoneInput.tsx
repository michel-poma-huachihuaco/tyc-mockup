import { forwardRef, useId, useState } from 'react'
import type { HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import { unir } from './_fechas.js'
import { IconoCopiar } from './_iconos.js'
import { trasPintar, useEspejo } from './_internos.js'
import { PREFIJOS, agruparTelefono, normalizarTelefono, reconocerTelefono, validarTelefono } from './_peru.js'

export type PhoneKind = 'mobile' | 'landline' | 'any'
export type PhoneInputSize = 'sm' | 'md' | 'lg'

export interface PropsPhoneInput extends Omit<HTMLAttributes<HTMLDivElement>, 'className'> {
  /** Número nacional, sin prefijo ni separadores: pegable tal cual en WhatsApp. */
  value?: string
  /** Cambio del número, ya limpio. Un «+51» pegado se quita, no se marca en rojo. */
  onValueChange?: (v: string) => void
  /** País del prefijo. `PE` fuerza el formato peruano; otro país deja de forzarlo. */
  country?: string
  /** Formato forzado. `any` lo deduce del primer dígito: 9 es móvil, lo demás es fijo. */
  kind?: PhoneKind
  /** Marca el número como canal de WhatsApp, solo si es móvil. No se afirma un canal que
   *  quien integra no ha comprobado. */
  whatsapp?: boolean
  /** Modo consulta, con las acciones de copiar el número y de abrir el chat. */
  readOnly?: boolean
  /** Mensaje de error; sobrescribe la validación interna. */
  error?: string
  /** Altura del conjunto: `sm` en tablas, `md` en formularios, `lg` en altas en móvil. */
  size?: PhoneInputSize
  /** Deshabilita prefijo y campo a la vez. */
  disabled?: boolean
  /** Etiqueta del campo. Nombra el canal cuando es WhatsApp: «WhatsApp del comprador».
   *  El prefijo se añade una sola vez, oculto, al final de la etiqueta. */
  label?: string
}

/**
 * Teléfono peruano en el formato en que se va a usar: el prefijo +51 como afijo, el
 * número agrupado 3-3-3 solo a la vista y guardado sin separadores, y móvil o fijo
 * reconocidos sin obligar a saber cuál es cuál.
 */
export const PhoneInput = forwardRef<HTMLDivElement, PropsPhoneInput>(function PhoneInput(
  {
    value = '',
    onValueChange,
    country = 'PE',
    kind = 'any',
    whatsapp = false,
    readOnly = false,
    error,
    size = 'md',
    disabled = false,
    label = 'Teléfono',
    ...resto
  },
  ref,
) {
  const id = useId()
  const idAyuda = `${id}-ayuda`
  const idTipo = `${id}-tipo`
  const idError = `${id}-error`
  const pais = country.toUpperCase()
  const peru = pais === 'PE'
  const prefijo = PREFIJOS[pais] ?? ''

  const limpiar = (v: string) => normalizarTelefono(v, prefijo || '+51')
  const agrupar = (v: string) => (peru ? agruparTelefono(v) : v)

  const valorProp = limpiar(typeof value === 'string' ? value : String(value ?? ''))
  const [numero, setNumero] = useEspejo<string>(valorProp)
  // Mientras se escribe se muestra lo tecleado; la agrupación es visual y se aplica al
  // salir, para que el retroceso borre un dígito y no un espacio de un grupo.
  const [borrador, setBorrador] = useState<string | null>(null)
  const [tocado, setTocado] = useState(false)
  const [copiado, setCopiado] = useState('')

  const fijar = (crudo: string) => {
    setBorrador(crudo)
    const limpio = limpiar(crudo)
    if (limpio !== numero) {
      setNumero(limpio)
      onValueChange?.(limpio)
    }
  }

  const { tipo, nota } = peru ? reconocerTelefono(numero) : { tipo: null, nota: '' }
  const errorVisible = error ?? (tocado && peru ? validarTelefono(numero, kind) : null)
  // texto además del color: el verde por sí solo no distingue el canal
  const marcaWhatsapp = whatsapp && tipo === 'mobile'
  const ayuda = !peru
    ? 'Escribe el número nacional, sin el prefijo.'
    : kind === 'landline'
      ? 'Código de área y número: ocho dígitos en total.'
      : 'Nueve dígitos, empieza por 9.'
  const completo = `${prefijo}${numero}`

  return (
    <div {...resto} ref={ref} className={cx('ay-field', 'ay-phone-field', `ay-phone-field--${size}`)}>
      {/* el prefijo va en la etiqueta: se anuncia una vez, no en cada pasada */}
      <label className="ay-label" htmlFor={id}>
        {label}
        {prefijo && <span className="ay-visually-hidden">, prefijo {prefijo}</span>}
      </label>

      <div className="ay-phone" data-invalid={errorVisible ? '' : undefined} data-disabled={disabled ? '' : undefined}>
        {/* eco visual de lo que ya dice la etiqueta */}
        {prefijo && (
          <span className="ay-phone__cc" aria-hidden="true">
            {prefijo}
          </span>
        )}
        <input
          id={id}
          className="ay-phone__number"
          type="tel"
          inputMode="numeric"
          autoComplete="tel-national"
          maxLength={peru ? 11 : 20}
          readOnly={readOnly}
          disabled={disabled}
          placeholder={readOnly && !numero ? 'Sin teléfono registrado' : undefined}
          value={borrador ?? agrupar(numero)}
          aria-describedby={unir(idAyuda, errorVisible && idError, idTipo)}
          aria-invalid={errorVisible ? true : undefined}
          onChange={(e) => fijar(e.target.value)}
          onPaste={(e) => {
            // Al pegar se quitan espacios, guiones, paréntesis y el prefijo repetido.
            e.preventDefault()
            const campo = e.currentTarget
            const actual = borrador ?? agrupar(numero)
            const inicio = campo.selectionStart ?? actual.length
            const fin = campo.selectionEnd ?? actual.length
            const pegado = limpiar(e.clipboardData.getData('text'))
            fijar(limpiar(actual.slice(0, inicio)) + pegado + limpiar(actual.slice(fin)))
          }}
          onKeyDown={(e) => {
            // El retroceso borra un dígito, no el espacio de un grupo.
            const campo = e.currentTarget
            const pos = campo.selectionStart ?? 0
            const texto = campo.value
            if (e.key === 'Backspace' && pos === campo.selectionEnd && pos > 1 && texto[pos - 1] === ' ') {
              e.preventDefault()
              const siguiente = texto.slice(0, pos - 2) + texto.slice(pos)
              fijar(siguiente)
              trasPintar(() => campo.setSelectionRange(pos - 2, pos - 2))
            }
          }}
          onBlur={() => {
            setTocado(true)
            setBorrador(null)
          }}
        />
        {nota && <span className="ay-phone__kind">{nota}</span>}
      </div>

      {readOnly && numero && (
        <div className="ay-phone__actions">
          <button
            type="button"
            className="ay-iconbtn ay-iconbtn--ghost ay-iconbtn--sm"
            aria-label={`Copiar el número ${prefijo} ${agrupar(numero)}`}
            onClick={() => {
              void navigator.clipboard?.writeText(completo).then(
                () => setCopiado('Número copiado.'),
                () => setCopiado('No se pudo copiar el número.'),
              )
            }}
          >
            <IconoCopiar className="ay-iconbtn__glyph" />
          </button>
          {marcaWhatsapp && (
            <a
              className="ay-link"
              href={`https://wa.me/${completo.replace(/\D/g, '')}`}
              target="_blank"
              rel="noopener noreferrer"
            >
              Abrir el chat de WhatsApp
              <span className="ay-visually-hidden"> (se abre fuera de la aplicación)</span>
              <span aria-hidden="true"> ↗</span>
            </a>
          )}
        </div>
      )}

      <p id={idAyuda} className="ay-helper">
        {ayuda}
      </p>
      {errorVisible && (
        <p id={idError} className="ay-error-msg" role="alert">
          {errorVisible}
        </p>
      )}
      <p id={idTipo} className="ay-phone__hint" role="status" aria-live="polite">
        {copiado || (marcaWhatsapp ? `${nota} · WhatsApp` : nota)}
      </p>
    </div>
  )
})

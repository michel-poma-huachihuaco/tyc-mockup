import { forwardRef, useEffect, useId, useRef, useState } from 'react'
import type { HTMLAttributes, KeyboardEvent, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { TabItem } from './TabItem.js'
import type { TamanoNavegacion } from './_internos.js'

export type VarianteTabs = 'underline' | 'pill' | 'vertical'
export type ModoActivacionTabs = 'automatic' | 'manual'

/** Una pestaña de Tabs: el subconjunto de Tab Item que se declara como dato. */
export interface ItemTabs {
  /** Identificador; es el valor de `value`, `defaultValue` y `onValueChange`. */
  value: string
  /** Etiqueta de una o dos palabras, sin la palabra «pestaña» ni numeración. */
  label: string
  /** Recuento, en un Badge tras la etiqueta y dentro del nombre accesible. */
  count?: number
  /** Icono decorativo inicial. */
  icon?: ReactNode
  /** Pestaña no seleccionable; las flechas la omiten. El motivo se explica fuera, en un Tooltip. */
  disabled?: boolean
}

export interface PropsTabs extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'defaultValue'> {
  /** Pestaña activa en modo controlado. Si se omite, Tabs lleva su propio estado a partir
   *  de `defaultValue`. */
  value?: string
  /** Notifica el cambio de pestaña, en modo controlado y no controlado. */
  onValueChange?: (value: string) => void
  /** Pestaña activa inicial en modo no controlado. Sin ella, la primera habilitada. */
  defaultValue?: string
  /** Pestañas: `value`, `label`, `count`, `icon` y `disabled`. */
  items?: ItemTabs[]
  /** Presentación: `underline` es la del sistema; `pill`, para grupos pequeños dentro de
   *  una card; `vertical`, lista lateral cuando hay más de seis secciones. */
  variant?: VarianteTabs
  /** Altura de la pestaña: `md` en cabeceras de página, `sm` dentro de cards y paneles. */
  size?: TamanoNavegacion
  /** Si las flechas cambian el panel (`automatic`) o solo mueven el foco y la pestaña se
   *  activa con Enter o Espacio (`manual`). Manual cuando cambiar de pestaña dispara una
   *  carga: recorrer cuatro pestañas no debe lanzar cuatro peticiones. */
  activationMode?: ModoActivacionTabs
}

/**
 * Alterna entre vistas hermanas del mismo objeto sin cambiar de página. El tablist es una
 * sola parada de tabulación (foco móvil) y las flechas recorren las pestañas con retorno
 * circular. `children` es el contenido del panel activo; los paneles inactivos existen y
 * se ocultan con `hidden`, para que cada `aria-controls` apunte a algo real. El nombre del
 * tablist llega por `aria-label` o `aria-labelledby`.
 */
export const Tabs = forwardRef<HTMLDivElement, PropsTabs>(function Tabs(
  {
    value,
    onValueChange,
    defaultValue,
    items = [],
    variant = 'underline',
    size = 'md',
    activationMode = 'automatic',
    'aria-label': etiqueta,
    'aria-labelledby': etiquetadoPor,
    children,
    ...resto
  },
  ref,
) {
  const base = useId()
  const idTab = (v: string) => `${base}-tab-${v}`
  const idPanel = (v: string) => `${base}-panel-${v}`
  const listaRef = useRef<HTMLDivElement>(null)
  const [interna, setInterna] = useState(defaultValue)
  const [anuncio, setAnuncio] = useState('')

  const habilitadas = items.filter((item) => !item.disabled)
  const solicitada = value ?? interna
  const valida = habilitadas.some((item) => item.value === solicitada)
  const activa = valida ? solicitada : habilitadas[0]?.value

  const seleccionar = (siguiente: string) => {
    if (value === undefined) setInterna(siguiente)
    if (siguiente !== activa) onValueChange?.(siguiente)
  }

  // La pestaña pedida desapareció (cambio de datos) o está deshabilitada (llegó por la
  // URL): se activa la primera disponible y se dice, para que el cambio no sea mudo.
  useEffect(() => {
    if (solicitada === undefined || valida || activa === undefined) return
    if (value === undefined) setInterna(activa)
    onValueChange?.(activa)
    const nombre = items.find((item) => item.value === activa)?.label ?? activa
    setAnuncio(`La pestaña pedida no está disponible; se muestra «${nombre}».`)
    // Solo cuando cambia lo pedido o lo disponible, no en cada render.
  }, [solicitada, valida, activa])

  // Con desbordamiento, la activa siempre a la vista. Se ajusta el scroll de la lista y
  // no se usa scrollIntoView, que también desplazaría la página entera.
  useEffect(() => {
    const lista = listaRef.current
    if (!lista || activa === undefined || variant === 'vertical') return
    const pestana = lista.ownerDocument.getElementById(idTab(activa))
    if (!pestana || lista.scrollWidth <= lista.clientWidth) return
    const inicio = pestana.offsetLeft
    const fin = inicio + pestana.offsetWidth
    if (inicio < lista.scrollLeft) lista.scrollLeft = inicio
    else if (fin > lista.scrollLeft + lista.clientWidth) lista.scrollLeft = fin - lista.clientWidth
  }, [activa, variant])

  const navegar = (evento: KeyboardEvent<HTMLDivElement>) => {
    if (habilitadas.length === 0) return
    const vertical = variant === 'vertical'
    const rtl = !vertical && evento.currentTarget.ownerDocument.defaultView
      ?.getComputedStyle(evento.currentTarget).direction === 'rtl'
    const siguiente = vertical ? 'ArrowDown' : rtl ? 'ArrowLeft' : 'ArrowRight'
    const anterior = vertical ? 'ArrowUp' : rtl ? 'ArrowRight' : 'ArrowLeft'
    // En modo manual el foco y la selección van por separado: se avanza desde la
    // pestaña enfocada, no desde la activa.
    const enfocada = habilitadas.findIndex((item) => idTab(item.value) === (evento.target as HTMLElement).id)
    const origen = enfocada >= 0 ? enfocada : habilitadas.findIndex((item) => item.value === activa)
    const total = habilitadas.length
    let destino: ItemTabs | undefined
    if (evento.key === siguiente) destino = habilitadas[(origen + 1) % total]
    else if (evento.key === anterior) destino = habilitadas[(origen - 1 + total) % total]
    else if (evento.key === 'Home') destino = habilitadas[0]
    else if (evento.key === 'End') destino = habilitadas[total - 1]
    if (!destino) return
    evento.preventDefault()
    evento.currentTarget.ownerDocument.getElementById(idTab(destino.value))?.focus()
    if (activationMode === 'automatic') seleccionar(destino.value)
  }

  return (
    <div {...resto} ref={ref} className={cx('ay-tabs', `ay-tabs--${variant}`, `ay-tabs--${size}`)}>
      <div
        ref={listaRef}
        className={cx('ay-tabs__list', variant === 'pill' && 'ay-tablist--pill')}
        role="tablist"
        aria-label={etiqueta}
        aria-labelledby={etiquetadoPor}
        aria-orientation={variant === 'vertical' ? 'vertical' : undefined}
        onKeyDown={navegar}
      >
        {items.map((item) => (
          <TabItem
            key={item.value}
            id={idTab(item.value)}
            value={item.value}
            label={item.label}
            icon={item.icon}
            count={item.count}
            disabled={item.disabled}
            selected={item.value === activa}
            panelId={idPanel(item.value)}
            onSelect={seleccionar}
          />
        ))}
      </div>
      {items.map((item) =>
        item.value === activa ? (
          <div
            key={item.value}
            className="ay-tabs__panel"
            role="tabpanel"
            id={idPanel(item.value)}
            aria-labelledby={idTab(item.value)}
            // Enfocable: si no, el segundo Tab desde la pestaña se salta el panel entero.
            tabIndex={children == null ? undefined : 0}
          >
            {children}
          </div>
        ) : (
          <div
            key={item.value}
            className="ay-tabs__panel"
            role="tabpanel"
            id={idPanel(item.value)}
            aria-labelledby={idTab(item.value)}
            hidden
          />
        ),
      )}
      <span className="ay-visually-hidden" role="status">
        {anuncio}
      </span>
    </div>
  )
})

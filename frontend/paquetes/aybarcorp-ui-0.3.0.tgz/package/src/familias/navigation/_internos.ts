/**
 * Piezas internas de la familia Navigation. No se exportan desde el índice salvo
 * `TamanoNavegacion`, que es API: es el tipo de `size` en todos los componentes de la
 * familia que lo tienen.
 */
import { useLayoutEffect, useMemo, useRef, useSyncExternalStore } from 'react'
import type { Ref, RefCallback, RefObject } from 'react'

/** Los dos tamaños de la familia: `md` por omisión, `sm` para paneles y densidad alta. */
export type TamanoNavegacion = 'sm' | 'md'

/** Une la ref que llega por `forwardRef` con la que el componente necesita para sí. */
export function combinarRefs<T>(...refs: (Ref<T> | undefined)[]): RefCallback<T> {
  return (nodo) => {
    for (const ref of refs) {
      if (typeof ref === 'function') ref(nodo)
      else if (ref) (ref as { current: T | null }).current = nodo
    }
  }
}

/** `combinarRefs` estable entre renders: React no vuelve a llamar a las refs si no cambian. */
export function useRefCombinada<T>(...refs: (Ref<T> | undefined)[]): RefCallback<T> {
  return useMemo(() => combinarRefs(...refs), refs)
}

/**
 * Por qué el breakpoint se resuelve en JavaScript y no con una media query.
 *
 * Una media query no admite `var()`: `@media (max-width: var(--aybar-breakpoint-md))`
 * es inválida. Escribir el valor a mano en la hoja sería el literal que el sistema
 * prohíbe, y una segunda verdad que se desincroniza en cuanto el manual mueva el
 * breakpoint. Aquí el valor se lee del token en tiempo de ejecución y el componente
 * recibe una clase; la hoja solo dice qué cambia, nunca a partir de qué ancho.
 *
 * Sin DOM —render en servidor, pruebas sin `matchMedia`— la respuesta es «no»: el
 * marcado de escritorio es el que lleva todo el contenido, y el cliente corrige en
 * cuanto hidrata.
 */
const consultas = new Map<string, MediaQueryList>()

function consultaDe(token: string): MediaQueryList | null {
  if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') return null
  const guardada = consultas.get(token)
  if (guardada) return guardada
  const valor = window.getComputedStyle(document.documentElement).getPropertyValue(token).trim()
  // Sin la hoja de tokens cargada no hay breakpoint que medir: no se cachea el fallo,
  // para que el primer render después de cargarla sí lo encuentre.
  if (!valor) return null
  const consulta = window.matchMedia(`(max-width: ${valor})`)
  consultas.set(token, consulta)
  return consulta
}

/** `true` cuando el viewport es igual o más estrecho que el breakpoint del token. */
export function useBajoBreakpoint(token = '--aybar-breakpoint-md'): boolean {
  return useSyncExternalStore(
    (avisar) => {
      const consulta = consultaDe(token)
      consulta?.addEventListener('change', avisar)
      return () => consulta?.removeEventListener('change', avisar)
    },
    () => consultaDe(token)?.matches ?? false,
    () => false,
  )
}

/**
 * Devuelve el foco al disparador cuando una región se cierra con el foco dentro.
 *
 * Es efecto de layout y no de pasivo a propósito: corre después de que React ponga
 * `hidden` y antes de que el navegador haga la corrección de foco de los elementos que
 * dejan de mostrarse. En ese hueco `activeElement` todavía dice dónde estaba el usuario;
 * un efecto pasivo llega tarde y lo encuentra ya en el `body`.
 */
export function useDevolverFoco(
  abierto: boolean,
  region: RefObject<HTMLElement | null>,
  disparador: RefObject<HTMLElement | null>,
): void {
  const anterior = useRef(abierto)
  useLayoutEffect(() => {
    if (anterior.current && !abierto) {
      const nodo = region.current
      const activo = nodo?.ownerDocument.activeElement
      if (nodo && activo && nodo.contains(activo)) disparador.current?.focus()
    }
    anterior.current = abierto
  }, [abierto, region, disparador])
}

/**
 * `true` desde el primer cambio de `valor` respecto del que tenía al montarse.
 *
 * Una región plegable solo anima la apertura y el cierre que el usuario provoca, no su
 * primer pintado: `@starting-style` también actúa al cargar, y una sección abierta por
 * omisión crecería delante del usuario cada vez que la vista se monta. La hoja anima solo
 * las regiones con el modificador `--animable`, que se pone aquí, en el mismo render que
 * cambia `hidden`; una vez puesto, no se quita.
 */
export function useHaCambiado(valor: unknown): boolean {
  const inicial = useRef(valor)
  const cambiado = useRef(false)
  if (!Object.is(valor, inicial.current)) cambiado.current = true
  return cambiado.current
}

/** El fragmento de la URL sin `#`, o cadena vacía sin DOM. */
export function hashActual(): string {
  if (typeof window === 'undefined') return ''
  const crudo = window.location.hash.slice(1)
  try {
    return decodeURIComponent(crudo)
  } catch {
    return crudo
  }
}

/** Preferencia de movimiento reducido del sistema; sin `matchMedia`, se respeta como activa. */
export function prefiereMenosMovimiento(vista: Window | null | undefined): boolean {
  if (!vista || typeof vista.matchMedia !== 'function') return true
  return vista.matchMedia('(prefers-reduced-motion: reduce)').matches
}

/** Desplaza hasta el nodo respetando `prefers-reduced-motion`. */
export function desplazarHasta(nodo: HTMLElement | null, suave = true): void {
  if (!nodo || typeof nodo.scrollIntoView !== 'function') return
  const reducir = prefiereMenosMovimiento(nodo.ownerDocument.defaultView)
  nodo.scrollIntoView({ behavior: suave && !reducir ? 'smooth' : 'auto', block: 'start' })
}

// ── Cambio de página ─────────────────────────────────────────────────────────

/** Dónde guarda el documento la página que ya anunció. */
const PAGINA = Symbol.for('aybar.pagina')

/**
 * Registra `titulo` como la página que muestra el documento y dice si llegar a ella es una
 * navegación dentro de la aplicación: había otra página antes y era otra. La primera del
 * documento es la carga y no se lleva el foco —el primer Tab tiene que llegar a Skip
 * Link—; repetir la que ya está tampoco es navegar: StrictMode monta dos veces en
 * desarrollo, y un Suspense o un remonte vuelven a montar la misma cabecera.
 *
 * Por título y no con una bandera: la bandera del módulo contaba el segundo pase de
 * StrictMode como un cambio de página. Y en el documento, con Symbol.for, como el estado
 * de apariencia: el anfitrión y cada remoto cargan su propia copia de este paquete, y las
 * de React y Angular tienen que coincidir en cuál fue la primera página.
 */
export function esCambioDePagina(documento: Document, titulo: string): boolean {
  const registro = documento as Document & { [PAGINA]?: string }
  const anterior = registro[PAGINA]
  registro[PAGINA] = titulo
  return anterior !== undefined && anterior !== titulo
}

/** Campo donde una tecla imprimible escribe: ahí un atajo de una letra no se intercepta. */
export function esCampoDeTexto(nodo: Element | null): boolean {
  if (!nodo) return false
  if ((nodo as HTMLElement).isContentEditable) return true
  const etiqueta = nodo.tagName
  if (etiqueta === 'TEXTAREA' || etiqueta === 'SELECT') return true
  if (etiqueta !== 'INPUT') return false
  const tipo = (nodo as HTMLInputElement).type
  return !['button', 'checkbox', 'radio', 'submit', 'reset', 'range', 'color', 'file', 'image'].includes(tipo)
}

/** Elemento que el navegador ya sabe enfocar sin `tabindex`. */
export function esEnfocableDeNacimiento(nodo: HTMLElement): boolean {
  if (nodo.isContentEditable) return true
  const etiqueta = nodo.tagName
  if (etiqueta === 'A' || etiqueta === 'AREA') return nodo.hasAttribute('href')
  return ['BUTTON', 'INPUT', 'SELECT', 'TEXTAREA', 'IFRAME', 'SUMMARY'].includes(etiqueta)
}

/** «1 elemento», «4 elementos»: el recuento que se lee en el nombre accesible. */
export function textoRecuento(cuenta: number): string {
  return `${cuenta} ${cuenta === 1 ? 'elemento' : 'elementos'}`
}

/** El contador visible: por encima de 99 se abrevia, el exacto va al nombre accesible. */
export function textoContador(cuenta: number): string {
  return cuenta > 99 ? '99+' : String(cuenta)
}

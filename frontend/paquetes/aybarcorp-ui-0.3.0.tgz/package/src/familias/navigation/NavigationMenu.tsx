import { forwardRef, useEffect, useId, useLayoutEffect, useRef, useState } from 'react'
import type { HTMLAttributes, KeyboardEvent } from 'react'
import { cx } from '../../utiles.js'
import { anclarEnCapaSuperior } from '../surfaces/_capa.js'
import { IconoChevronAbajo } from './_iconos.js'
import { useBajoBreakpoint, useRefCombinada } from './_internos.js'

export type AnchoNavigationMenu = 'auto' | 'full'

/** Un enlace del panel: una sección concreta, «Promociones», «Reservas». */
export interface EnlaceNavigationMenu {
  /** Destino. */
  href: string
  /** Nombre de la sección. */
  label: string
  /** Página actual: `aria-current="page"`. */
  current?: boolean
}

/** Un grupo del panel, con encabezado real para saltar entre bloques con el lector. */
export interface GrupoNavigationMenu {
  /** Título del grupo. */
  label: string
  /** Enlaces del grupo. Una sección sin permiso no aparece. */
  links: EnlaceNavigationMenu[]
}

/** Un área de primer nivel. Con `groups` despliega un panel; sin ellos es un enlace directo. */
export interface AreaNavigationMenu {
  /** Identificador; es lo que se compara con `currentArea`. */
  id: string
  /** Sustantivo amplio: «Comercial», «Administración». */
  label: string
  /** Destino del área cuando no tiene subsecciones. */
  href?: string
  /** Grupos de enlaces del panel. */
  groups?: GrupoNavigationMenu[]
}

export interface PropsNavigationMenu extends Omit<HTMLAttributes<HTMLElement>, 'className'> {
  /** Áreas y su contenido. */
  areas?: AreaNavigationMenu[]
  /** Área que contiene la página actual: su disparador lleva `aria-current`. */
  currentArea?: string
  /** Ancho del panel: automático, o a ancho completo alineado con la página. */
  width?: AnchoNavigationMenu
  /** Nombre accesible del nav. */
  label?: string
}

/**
 * Navegación de dos niveles desde la barra superior. Es navegación, no un menú de
 * comandos: un nav con enlaces, sin `role="menu"` ni flechas forzadas. Cada área con
 * subsecciones es un `button` con `aria-expanded` que abre su panel al activarlo —nunca
 * al enfocar ni con hover—; solo hay un panel abierto, Escape lo cierra devolviendo el
 * foco al disparador, y salir con Tab, hacer scroll o pulsar fuera también lo cierran.
 * Por debajo del breakpoint `md` se oculta: la aplicación delega en un Drawer con Accordion.
 */
export const NavigationMenu = forwardRef<HTMLElement, PropsNavigationMenu>(function NavigationMenu(
  { areas = [], currentArea, width = 'auto', label = 'Principal', ...resto },
  ref,
) {
  const base = useId()
  const movil = useBajoBreakpoint()
  const raizRef = useRef<HTMLElement>(null)
  const refRaiz = useRefCombinada(ref, raizRef)
  const disparadores = useRef(new Map<string, HTMLButtonElement | null>())
  const [abierta, setAbierta] = useState<string | null>(null)

  const idPanel = (id: string) => `${base}-panel-${id}`

  // El panel abierto sube a la capa superior bajo su disparador o, a ancho completo,
  // centrado bajo la barra: allí no lo tapa nada pegajoso que haya debajo de la Navbar (un
  // Banner fijo) ni lo recorta el overflow de la cabecera. Sin la API sigue anclado con la hoja.
  useLayoutEffect(() => {
    if (abierta === null) return
    const raiz = raizRef.current
    const panel = raiz?.ownerDocument.getElementById(`${base}-panel-${abierta}`)
    const ancla = width === 'full' ? raiz : panel?.parentElement
    if (!panel || !ancla) return
    return anclarEnCapaSuperior(
      panel,
      ancla,
      width === 'full'
        ? { separacion: '--aybar-space-2', alineacion: 'centro', ancho: 'igual' }
        : { separacion: '--aybar-space-2' },
    )
  }, [abierta, width, base])

  useEffect(() => {
    if (abierta === null) return
    const raiz = raizRef.current
    const doc = raiz?.ownerDocument
    const vista = doc?.defaultView
    if (!raiz || !doc || !vista) return
    const alTeclear = (evento: globalThis.KeyboardEvent) => {
      if (evento.key !== 'Escape') return
      setAbierta(null)
      disparadores.current.get(abierta)?.focus()
    }
    const alScroll = () => setAbierta(null)
    const fuera = (evento: Event) => {
      if (!raiz.contains(evento.target as Node)) setAbierta(null)
    }
    doc.addEventListener('keydown', alTeclear)
    doc.addEventListener('pointerdown', fuera)
    vista.addEventListener('scroll', alScroll, true)
    return () => {
      doc.removeEventListener('keydown', alTeclear)
      doc.removeEventListener('pointerdown', fuera)
      vista.removeEventListener('scroll', alScroll, true)
    }
  }, [abierta])

  // Flecha abajo desde el disparador entra en el panel abierto.
  const alTeclearDisparador = (evento: KeyboardEvent<HTMLButtonElement>, id: string) => {
    if (evento.key !== 'ArrowDown' || abierta !== id) return
    const primero = evento.currentTarget.ownerDocument.getElementById(idPanel(id))?.querySelector<HTMLElement>('a[href]')
    if (!primero) return
    evento.preventDefault()
    primero.focus()
  }

  return (
    <nav
      {...resto}
      ref={refRaiz}
      className={cx('ay-navmenu', `ay-navmenu--${width}`, movil && 'ay-navmenu--movil')}
      aria-label={label}
    >
      <ul className="ay-navmenu__bar">
        {areas.map((area) => {
          const actual = currentArea === area.id
          if (!area.groups?.length) {
            return (
              <li key={area.id}>
                <a className="ay-navmenu__link" href={area.href} aria-current={actual ? 'page' : undefined}>
                  {area.label}
                </a>
              </li>
            )
          }
          const abiertaEsta = abierta === area.id
          return (
            <li
              key={area.id}
              onBlur={(evento) => {
                // Tab fuera del área cierra su panel; el foco sigue su camino.
                if (abiertaEsta && !evento.currentTarget.contains(evento.relatedTarget as Node | null)) {
                  setAbierta(null)
                }
              }}
            >
              <button
                ref={(nodo) => {
                  disparadores.current.set(area.id, nodo)
                }}
                type="button"
                className="ay-navmenu__trigger"
                aria-expanded={abiertaEsta}
                aria-controls={idPanel(area.id)}
                aria-current={actual ? true : undefined}
                onClick={() => setAbierta(abiertaEsta ? null : area.id)}
                onKeyDown={(evento) => alTeclearDisparador(evento, area.id)}
              >
                {area.label}
                <IconoChevronAbajo tamano={14} />
              </button>
              {abiertaEsta && (
                <div className="ay-navmenu__panel" id={idPanel(area.id)}>
                  {area.groups.map((grupo, i) => {
                    const idGrupo = `${base}-${area.id}-g${i}`
                    return (
                      <div key={`${i}-${grupo.label}`} className="ay-navmenu__group">
                        <h3 className="ay-navmenu__grouptitle" id={idGrupo}>
                          {grupo.label}
                        </h3>
                        <ul aria-labelledby={idGrupo}>
                          {grupo.links.map((enlace) => (
                            <li key={enlace.href}>
                              <a href={enlace.href} aria-current={enlace.current ? 'page' : undefined}>
                                {enlace.label}
                              </a>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )
                  })}
                </div>
              )}
            </li>
          )
        })}
      </ul>
    </nav>
  )
})

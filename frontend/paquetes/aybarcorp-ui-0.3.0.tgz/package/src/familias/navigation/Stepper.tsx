import { forwardRef, useEffect, useRef, useState } from 'react'
import type { HTMLAttributes, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { IconoCheck } from './_iconos.js'
import { useBajoBreakpoint } from './_internos.js'
import type { TamanoNavegacion } from './_internos.js'

export type OrientacionStepper = 'horizontal' | 'vertical'

/** Un paso del proceso. */
export interface PasoStepper {
  /** Identificador estable del paso. */
  id: string
  /** Sustantivo corto: «Datos de la unidad», «Comprador». Un paso opcional lo dice aquí. */
  label: string
  /** Una frase con lo que se pide en el paso. En un paso con error, qué falta. */
  description?: string
  /** `error`: el paso se marca en tono danger y su estado escrito pasa a «con error». */
  status?: 'error'
}

export interface PropsStepper extends Omit<HTMLAttributes<HTMLElement>, 'className'> {
  /** Pasos, en orden. Con más de cinco, se agrupan en fases. */
  steps?: PasoStepper[]
  /** Índice del paso actual, desde 0. Los anteriores están completados. */
  current?: number
  /** Hace navegables los pasos completados: solo esos son botones. Los pendientes no,
   *  porque un control que no hace nada confunde. */
  onStepClick?: (index: number) => void
  /** Disposición. El horizontal pasa a la variante compacta por debajo del breakpoint `md`. */
  orientation?: OrientacionStepper
  /** Tamaño: `sm` reduce el círculo y no muestra descripciones, salvo la de un paso con
   *  error, que dice qué falta. */
  size?: TamanoNavegacion
  /** Nombre accesible del nav. */
  label?: string
}

const estadoDe = (i: number, actual: number, paso: PasoStepper) =>
  paso.status === 'error' ? 'con error' : i < actual ? 'completado' : i === actual ? 'en curso' : 'pendiente'

/**
 * Indicador de progreso de un proceso en pasos: un `ol`, porque el orden es la
 * información principal, con `aria-current="step"` en el actual y el estado de cada paso
 * escrito en su nombre accesible —«paso 2 de 3, completado»—. No es un widget: las flechas
 * no hacen nada. Al cambiar de paso, el cambio se anuncia; llevar el foco al encabezado
 * del contenido nuevo es cosa del formulario que aporta ese contenido.
 */
export const Stepper = forwardRef<HTMLElement, PropsStepper>(function Stepper(
  { steps = [], current = 0, onStepClick, orientation = 'horizontal', size = 'md', label = 'Progreso del proceso', ...resto },
  ref,
) {
  const movil = useBajoBreakpoint()
  const compacto = movil && orientation === 'horizontal'
  const [anuncio, setAnuncio] = useState('')
  const anterior = useRef(current)

  useEffect(() => {
    if (anterior.current === current) return
    anterior.current = current
    const paso = steps[current]
    if (paso) setAnuncio(`Paso ${current + 1} de ${steps.length}: ${paso.label}`)
  }, [current])

  const pasoActual = steps[current]

  return (
    <nav {...resto} ref={ref} aria-label={label}>
      {compacto && pasoActual ? (
        // Variante compacta, por debajo del breakpoint `md`: «Paso 2 de 5: Comprador» con
        // la barra. Sustituye a la lista, no la duplica.
        <div className={cx('ay-stepper', 'ay-stepper--compacto', `ay-stepper--${size}`)} aria-current="step">
          <p className="ay-stepper__compact-text">
            Paso {current + 1} de {steps.length}: {pasoActual.label}
            {pasoActual.status === 'error' && <span className="ay-visually-hidden">, con error</span>}
          </p>
          {pasoActual.status === 'error' && pasoActual.description && (
            <p className="ay-step__desc">{pasoActual.description}</p>
          )}
          <progress className="ay-stepper__bar" max={steps.length} value={current + 1} aria-hidden="true" />
        </div>
      ) : (
        <ol
          className={cx(
            'ay-stepper',
            `ay-stepper--${orientation}`,
            `ay-stepper--${size}`,
          )}
        >
          {steps.map((paso, i) => {
            const completado = i < current
            const conError = paso.status === 'error'
            const navegable = onStepClick != null && completado
            let marca: ReactNode = i + 1
            if (conError) marca = '!'
            else if (completado) marca = <IconoCheck tamano={size === 'sm' ? 12 : 14} />
            const contenido = (
              <>
                <span className="ay-step__dot" aria-hidden="true">
                  {marca}
                </span>
                <span className="ay-step__label">
                  {paso.label}
                  {/* El estado se escribe: el círculo relleno no llega a quien no lo ve. */}
                  <span className="ay-visually-hidden">
                    , paso {i + 1} de {steps.length}, {estadoDe(i, current, paso)}
                  </span>
                  {/* `sm` no lleva descripción, salvo la de un paso con error: dice qué falta. */}
                  {paso.description && (size !== 'sm' || conError) && (
                    <span className="ay-step__desc">{paso.description}</span>
                  )}
                </span>
              </>
            )
            return (
              <li
                key={paso.id}
                className={cx(
                  'ay-step',
                  completado && !conError && 'ay-step--done',
                  i === current && 'ay-step--current',
                  conError && 'ay-step--error',
                )}
                aria-current={i === current ? 'step' : undefined}
              >
                {navegable ? (
                  <button type="button" className="ay-step__btn" onClick={() => onStepClick?.(i)}>
                    {contenido}
                  </button>
                ) : (
                  contenido
                )}
              </li>
            )
          })}
        </ol>
      )}
      <p className="ay-visually-hidden" aria-live="polite">
        {anuncio}
      </p>
    </nav>
  )
})

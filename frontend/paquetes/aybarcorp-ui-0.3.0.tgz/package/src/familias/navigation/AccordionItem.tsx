import { createContext, forwardRef, useContext, useEffect, useId, useRef, useState } from 'react'
import type { HTMLAttributes, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { IconoChevronAbajo } from './_iconos.js'
import { desplazarHasta, hashActual, useDevolverFoco, useHaCambiado, useRefCombinada } from './_internos.js'

export type NivelEncabezado = 'h2' | 'h3' | 'h4'

/** Lo que Accordion comparte con sus elementos. Interno: no se exporta desde el índice. */
export interface ContextoAccordionValor {
  abiertas: string[]
  alternar: (valor: string) => void
  abrir: (valor: string) => void
}

export const ContextoAccordion = createContext<ContextoAccordionValor | null>(null)

export interface PropsAccordionItem
  extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'title' | 'onToggle'> {
  /** Identificador dentro del Accordion. También sirve de ancla: con `#<value>` en la URL
   *  la sección se abre al cargar y el foco va a su cabecera. */
  value: string
  /** Título de la cabecera: dice qué contiene la sección, sin «Más información». */
  title: ReactNode
  /** Recuento o estado corto, antes del indicador. */
  meta?: ReactNode
  /** Icono decorativo antes del título. */
  icon?: ReactNode
  /** Impide abrir. Se expresa con `aria-disabled`: la cabecera sigue enfocable y su motivo
   *  —escrito en el título o en `meta`— se puede leer. */
  disabled?: boolean
  /** Nivel del encabezado que envuelve al botón. Responde a la jerarquía de la página, no
   *  al tamaño del texto: la lista de encabezados del lector sirve de índice. */
  headingLevel?: NivelEncabezado
  /** Estado abierto controlado. Sin él, lo aporta Accordion o, fuera de él, el propio
   *  elemento lleva su estado. */
  open?: boolean
  /** Se llama con `value` al pulsar la cabecera de un elemento habilitado. */
  onToggle?: (value: string) => void
  /** Contenido de la región. */
  children: ReactNode
}

/**
 * Pieza de Accordion: un `button` dentro de un encabezado real, con `aria-expanded` y
 * `aria-controls` hacia una región `role="region"`. La región cerrada lleva `hidden` —con
 * altura cero seguiría siendo enfocable— y la animación usa `grid-template-rows`, no un
 * `max-height` inventado. Si se cierra con el foco dentro, el foco vuelve a la cabecera.
 */
export const AccordionItem = forwardRef<HTMLDivElement, PropsAccordionItem>(function AccordionItem(
  { value, title, meta, icon, disabled = false, headingLevel = 'h3', open, onToggle, children, id, ...resto },
  ref,
) {
  const contexto = useContext(ContextoAccordion)
  const base = useId()
  const idBoton = `${base}-btn`
  const idRegion = `${base}-region`
  const raizRef = useRef<HTMLDivElement>(null)
  const botonRef = useRef<HTMLButtonElement>(null)
  const regionRef = useRef<HTMLDivElement>(null)
  const [interno, setInterno] = useState(false)
  const refRaiz = useRefCombinada(ref, raizRef)

  const abierto = open ?? (contexto ? contexto.abiertas.includes(value) : interno)

  const alternar = () => {
    if (disabled) return
    if (open === undefined) {
      if (contexto) contexto.alternar(value)
      else setInterno(!abierto)
    }
    onToggle?.(value)
  }

  useDevolverFoco(abierto, regionRef, botonRef)
  const animable = useHaCambiado(abierto)

  // Los manejadores nativos leen el estado de aquí: su cierre no se rehace en cada render.
  const ultimo = useRef({ abierto, disabled, open, contexto, onToggle })
  ultimo.current = { abierto, disabled, open, contexto, onToggle }

  // Enlace profundo: `#<value>` o el id del elemento —al cargar o al navegar dentro de la
  // página— abre la sección, la trae a la vista y deja el foco en su cabecera.
  useEffect(() => {
    const vista = raizRef.current?.ownerDocument.defaultView
    const alAncla = () => {
      const destino = hashActual()
      if (!destino || (destino !== value && destino !== id)) return
      const actual = ultimo.current
      if (!actual.abierto && !actual.disabled) {
        if (actual.open === undefined) {
          if (actual.contexto) actual.contexto.abrir(value)
          else setInterno(true)
        }
        actual.onToggle?.(value)
      }
      botonRef.current?.focus({ preventScroll: true })
      desplazarHasta(raizRef.current)
    }
    alAncla()
    vista?.addEventListener('hashchange', alAncla)
    return () => vista?.removeEventListener('hashchange', alAncla)
  }, [value, id])

  const Encabezado = headingLevel

  return (
    <div {...resto} id={id} ref={refRaiz} className="ay-accordion__item">
      <Encabezado className="ay-accordion__heading">
        <button
          ref={botonRef}
          type="button"
          className="ay-accordion__trigger"
          id={idBoton}
          aria-expanded={abierto}
          aria-controls={idRegion}
          aria-disabled={disabled || undefined}
          onClick={alternar}
        >
          {icon != null && (
            <span className="ay-accordion__icon" aria-hidden="true">
              {icon}
            </span>
          )}
          <span className="ay-accordion__title">{title}</span>
          {meta != null && <span className="ay-accordion__meta">{meta}</span>}
          <IconoChevronAbajo className="ay-accordion__chevron" tamano={18} />
        </button>
      </Encabezado>
      <div
        ref={regionRef}
        className={cx('ay-accordion__region', animable && 'ay-accordion__region--animable')}
        id={idRegion}
        role="region"
        aria-labelledby={idBoton}
        hidden={!abierto}
      >
        <div className="ay-accordion__content">{children}</div>
      </div>
    </div>
  )
})

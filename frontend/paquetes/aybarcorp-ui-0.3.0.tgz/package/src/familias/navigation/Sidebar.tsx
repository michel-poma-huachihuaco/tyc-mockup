import { forwardRef, useEffect, useId, useRef, useState } from 'react'
import type { HTMLAttributes, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { IconoChevronAbajo, IconoChevronDerecha, IconoChevronIzquierda } from './_iconos.js'
import { esCampoDeTexto, useBajoBreakpoint, useDevolverFoco, useHaCambiado, useRefCombinada } from './_internos.js'

/** Un elemento de la columna. */
export interface ItemSidebar {
  /** Destino. */
  href: string
  /** Sustantivo corto. En la versión expandida envuelve en dos líneas, no se trunca; en
   *  la colapsada sigue siendo el nombre accesible del enlace. */
  label: string
  /** Icono decorativo. En la versión colapsada es lo único visible. */
  icon?: ReactNode
  /** Recuento o estado al final del elemento. Un texto o un número se pinta como Badge. */
  badge?: ReactNode
  /** Página actual: `aria-current="page"`. */
  current?: boolean
  /** Subniveles: un único nivel de anidación, plegable. Si alguno es el actual, se abre al
   *  cargar. */
  items?: ItemSidebar[]
}

/** Un grupo de elementos con su título opcional. */
export interface GrupoSidebar {
  /** Título del grupo, que nombra el ámbito: «Comercial», «Administración». */
  label?: string
  /** Elementos del grupo. */
  items: ItemSidebar[]
  /** La cabecera del grupo es un botón con `aria-expanded` que lo pliega y despliega. */
  collapsible?: boolean
  /** Estado inicial de un grupo plegable; si contiene la página actual, se abre igual. */
  defaultOpen?: boolean
}

export interface PropsSidebar extends Omit<HTMLAttributes<HTMLElement>, 'className'> {
  /** Grupos y elementos. Una sección sin permiso no se incluye: no se muestra deshabilitada. */
  groups?: GrupoSidebar[]
  /** Estado colapsado (rail de solo iconos) en modo controlado. Sin él, la columna empieza
   *  expandida y lleva su propio estado. */
  collapsed?: boolean
  /** Cambio de colapso. Con `collapsed` controlado, el control de colapso —y su atajo, la
   *  tecla `[` fuera de un campo de texto— solo existen si se pasa este callback. */
  onCollapsedChange?: (c: boolean) => void
  /** Contenido del pie: ayuda, configuración y cuenta, sin repetir el Navbar. */
  footer?: ReactNode
  /** Nombre accesible del nav. */
  label?: string
}

/**
 * Columna de navegación de muchas secciones, anclada al borde inicial. Es navegación, no
 * un widget: Tab recorre los enlaces en orden y las flechas no se capturan. Colapsada, se
 * reduce a un rail de iconos que conserva el nombre accesible de cada enlace y lo muestra
 * en un tooltip al apuntar o enfocar; la tecla `[` la pliega y despliega. Por debajo del breakpoint `md` se oculta: la
 * aplicación delega en un Drawer, que sí es modal.
 */
export const Sidebar = forwardRef<HTMLElement, PropsSidebar>(function Sidebar(
  { groups = [], collapsed, onCollapsedChange, footer, label = 'Secciones', ...resto },
  ref,
) {
  const base = useId()
  const movil = useBajoBreakpoint()
  const [interno, setInterno] = useState(false)
  const colapsada = collapsed ?? interno
  const conControl = collapsed === undefined || onCollapsedChange != null

  const raizRef = useRef<HTMLElement>(null)
  const refRaiz = useRefCombinada(ref, raizRef)

  const alternarColumna = () => {
    const siguiente = !colapsada
    if (collapsed === undefined) setInterno(siguiente)
    onCollapsedChange?.(siguiente)
  }
  const alternarRef = useRef(alternarColumna)
  alternarRef.current = alternarColumna

  // Atajo de colapso: `[` alterna la columna sin ratón, salvo con el foco en un campo de
  // texto, donde la tecla escribe. En móvil no hay columna que plegar: la sustituye el Drawer.
  useEffect(() => {
    const doc = raizRef.current?.ownerDocument
    if (!conControl || movil || !doc) return
    const alTeclear = (evento: KeyboardEvent) => {
      if (evento.key !== '[' || evento.ctrlKey || evento.metaKey || evento.altKey || evento.defaultPrevented) return
      if (esCampoDeTexto(doc.activeElement)) return
      evento.preventDefault()
      alternarRef.current()
    }
    doc.addEventListener('keydown', alTeclear)
    return () => doc.removeEventListener('keydown', alTeclear)
  }, [conControl, movil])

  return (
    <nav
      {...resto}
      ref={refRaiz}
      className={cx('ay-sidebar', colapsada && 'ay-sidebar--collapsed', movil && 'ay-sidebar--movil')}
      aria-label={label}
    >
      {groups.map((grupo, i) => (
        <Grupo key={`${i}-${grupo.label ?? ''}`} grupo={grupo} id={`${base}-g${i}`} colapsada={colapsada} />
      ))}
      <div className="ay-sidebar__footer">
        {footer}
        {conControl && (
          <button
            type="button"
            className="ay-iconbtn ay-iconbtn--ghost ay-iconbtn--md ay-sidebar__collapse"
            // Dice qué hace y en qué estado deja la columna.
            aria-label={colapsada ? 'Expandir la navegación' : 'Contraer la navegación'}
            aria-keyshortcuts="["
            onClick={alternarColumna}
          >
            {colapsada ? (
              <IconoChevronDerecha className="ay-iconbtn__glyph" />
            ) : (
              <IconoChevronIzquierda className="ay-iconbtn__glyph" />
            )}
          </button>
        )}
      </div>
    </nav>
  )
})

const contieneActual = (item: ItemSidebar): boolean =>
  !!item.current || !!item.items?.some((hijo) => hijo.current)

function Grupo({ grupo, id, colapsada }: { grupo: GrupoSidebar; id: string; colapsada: boolean }) {
  const plegable = !!grupo.collapsible && !!grupo.label
  // El grupo que contiene la página actual se abre al cargar: si no, el usuario aterriza
  // sin ninguna pista de dónde cuelga.
  const [abierto, setAbierto] = useState(() => (grupo.defaultOpen ?? true) || grupo.items.some(contieneActual))
  const botonRef = useRef<HTMLButtonElement>(null)
  const regionRef = useRef<HTMLDivElement>(null)
  const mostrarTitulo = !!grupo.label && !colapsada
  // En el rail los títulos no se ven, y con ellos su pliegue: se muestran todos los iconos.
  const desplegado = abierto || colapsada
  useDevolverFoco(desplegado, regionRef, botonRef)
  const animable = useHaCambiado(desplegado)

  const lista = (
    <ul aria-labelledby={mostrarTitulo ? `${id}-titulo` : undefined}>
      {grupo.items.map((item, i) => (
        <Elemento key={`${i}-${item.href}`} item={item} id={`${id}-e${i}`} colapsada={colapsada} />
      ))}
    </ul>
  )

  return (
    <div className="ay-sidebar__group">
      {mostrarTitulo &&
        (plegable ? (
          <h2 className="ay-sidebar__grouptitle" id={`${id}-titulo`}>
            <button
              ref={botonRef}
              type="button"
              className="ay-sidebar__grouptoggle"
              aria-expanded={abierto}
              aria-controls={`${id}-lista`}
              onClick={() => setAbierto(!abierto)}
            >
              <span>{grupo.label}</span>
              <IconoChevronAbajo className="ay-sidebar__chevron" tamano={14} />
            </button>
          </h2>
        ) : (
          <h2 className="ay-sidebar__grouptitle" id={`${id}-titulo`}>
            {grupo.label}
          </h2>
        ))}
      {plegable ? (
        <div
          ref={regionRef}
          className={cx('ay-sidebar__region', animable && 'ay-sidebar__region--animable')}
          id={`${id}-lista`}
          hidden={!desplegado}
        >
          {lista}
        </div>
      ) : (
        lista
      )}
    </div>
  )
}

function Insignia({ contenido }: { contenido: ReactNode }) {
  if (contenido == null) return null
  return (
    <span className="ay-sidebar__badge">
      {typeof contenido === 'string' || typeof contenido === 'number' ? (
        <span className="ay-badge ay-badge--neutral ay-badge--sm">{contenido}</span>
      ) : (
        contenido
      )}
    </span>
  )
}

function Elemento({ item, id, colapsada }: { item: ItemSidebar; id: string; colapsada: boolean }) {
  const [abierto, setAbierto] = useState(() => !!item.items?.some((hijo) => hijo.current))
  const botonRef = useRef<HTMLButtonElement>(null)
  const regionRef = useRef<HTMLDivElement>(null)
  const conHijos = !!item.items?.length && !colapsada
  useDevolverFoco(abierto && conHijos, regionRef, botonRef)
  const animable = useHaCambiado(abierto)

  const enlace = (
    <a
      href={item.href}
      className="ay-sidebar__item"
      aria-current={item.current ? 'page' : undefined}
      // Colapsada, el nombre accesible se conserva: un icono no nombra nada.
      aria-label={colapsada ? item.label : undefined}
    >
      {item.icon != null ? (
        <span className="ay-sidebar__icon" aria-hidden="true">
          {item.icon}
        </span>
      ) : (
        colapsada && (
          <span className="ay-sidebar__mono" aria-hidden="true">
            {item.label.slice(0, 1).toUpperCase()}
          </span>
        )
      )}
      {!colapsada && <span className="ay-sidebar__label">{item.label}</span>}
      <Insignia contenido={item.badge} />
      {colapsada && (
        <span className="ay-sidebar__tip" aria-hidden="true">
          {item.label}
        </span>
      )}
    </a>
  )

  if (!conHijos) return <li>{enlace}</li>

  return (
    <li>
      <div className={cx('ay-sidebar__parent', contieneActual(item) && 'ay-sidebar__parent--current')}>
        {enlace}
        <button
          ref={botonRef}
          type="button"
          className="ay-sidebar__expand"
          aria-expanded={abierto}
          aria-controls={`${id}-sub`}
          aria-label={`Subsecciones de ${item.label}`}
          onClick={() => setAbierto(!abierto)}
        >
          <IconoChevronAbajo className="ay-sidebar__chevron" tamano={14} />
        </button>
      </div>
      <div
        ref={regionRef}
        className={cx('ay-sidebar__region', animable && 'ay-sidebar__region--animable')}
        id={`${id}-sub`}
        hidden={!abierto}
      >
        <ul className="ay-sidebar__sublist">
          {item.items?.map((hijo, i) => (
            <li key={`${i}-${hijo.href}`}>
              <a
                href={hijo.href}
                className="ay-sidebar__item ay-sidebar__item--sub"
                aria-current={hijo.current ? 'page' : undefined}
              >
                <span className="ay-sidebar__label">{hijo.label}</span>
                <Insignia contenido={hijo.badge} />
              </a>
            </li>
          ))}
        </ul>
      </div>
    </li>
  )
}

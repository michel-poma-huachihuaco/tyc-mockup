import { forwardRef } from 'react'
import type { ButtonHTMLAttributes, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { textoContador, textoRecuento } from './_internos.js'

export interface PropsTabItem
  extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'className' | 'value' | 'onSelect' | 'type'> {
  /** Identificador de la pestaña. Es lo que recibe `onSelect` y, sin `id`, forma el id
   *  del botón (`tab-<value>`) al que apunta el `aria-labelledby` del panel. */
  value: string
  /** Etiqueta: un sustantivo corto, «Unidades», «Documentos». Es el nombre accesible;
   *  sin números dentro, el recuento va en `count`. */
  label: ReactNode
  /** Icono decorativo antes de la etiqueta. Se marca `aria-hidden`: el glifo repite lo
   *  que la palabra ya dice y anunciarlo antepone un elemento vacío a cada pestaña. */
  icon?: ReactNode
  /** Contador tras la etiqueta. Por encima de 99 se ve «99+», y el valor exacto entra
   *  siempre en el nombre accesible: «Reservas, 4 elementos», no una cifra suelta. */
  count?: number
  /** Desactiva la selección. Se expresa con `aria-disabled` y no con `disabled` para que
   *  la pestaña siga en el árbol de accesibilidad y su motivo se pueda leer. */
  disabled?: boolean
  /** Si es la pestaña activa: `aria-selected`, indicador visible y `tabIndex` 0. Lo aporta
   *  Tabs, no se fija a mano. */
  selected?: boolean
  /** Se llama con `value` al pulsar una pestaña habilitada. Lo aporta Tabs. */
  onSelect?: (value: string) => void
  /** Id del panel que gobierna, para `aria-controls`. Lo aporta Tabs: `role="tab"`,
   *  `aria-selected` y `aria-controls` van los tres juntos. */
  panelId?: string
}

/**
 * Una pestaña individual de Tabs. Nunca va suelta: es Tabs quien decide cuál está
 * seleccionada, mueve el foco con las flechas y asocia cada pestaña con su panel. Como
 * enlace entre páginas es Link dentro de un nav, y como filtro, Segmented Control.
 */
export const TabItem = forwardRef<HTMLButtonElement, PropsTabItem>(function TabItem(
  { value, label, icon, count, disabled = false, selected, onSelect, panelId, id, onClick, ...resto },
  ref,
) {
  const seleccionada = selected === true
  return (
    <button
      {...resto}
      ref={ref}
      type="button"
      role="tab"
      id={id ?? `tab-${value}`}
      aria-selected={seleccionada}
      aria-controls={panelId}
      aria-disabled={disabled || undefined}
      // Foco móvil: solo la seleccionada está en el orden de tabulación, así Tab salta al
      // panel en lugar de recorrer cada pestaña.
      tabIndex={seleccionada ? 0 : -1}
      className={cx('ay-tab', seleccionada && 'ay-tab--selected')}
      onClick={(evento) => {
        onClick?.(evento)
        if (!disabled && !evento.defaultPrevented) onSelect?.(value)
      }}
    >
      {icon != null && (
        <span className="ay-tab__icon" aria-hidden="true">
          {icon}
        </span>
      )}
      <span className="ay-tab__label">{label}</span>
      {count != null && (
        <>
          <span className="ay-badge ay-badge--neutral ay-badge--sm ay-badge--count" aria-hidden="true">
            {textoContador(count)}
          </span>
          <span className="ay-visually-hidden">, {textoRecuento(count)}</span>
        </>
      )}
    </button>
  )
})

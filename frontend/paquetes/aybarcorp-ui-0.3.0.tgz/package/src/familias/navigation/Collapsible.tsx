import { forwardRef, useEffect, useId, useRef, useState } from 'react'
import type { HTMLAttributes, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { IconoChevronAbajo } from './_iconos.js'
import { desplazarHasta, hashActual, useDevolverFoco, useHaCambiado, useRefCombinada } from './_internos.js'
import type { TamanoNavegacion } from './_internos.js'

export interface PropsCollapsible extends Omit<HTMLAttributes<HTMLDivElement>, 'className'> {
  /** Estado abierto en modo controlado. Si se omite, el componente lleva su propio estado
   *  a partir de `defaultOpen`. */
  open?: boolean
  /** Estado inicial en modo no controlado. */
  defaultOpen?: boolean
  /** Notifica el cambio de estado, en modo controlado y no controlado. */
  onOpenChange?: (open: boolean) => void
  /** Contenido del disparador: dice qué se despliega, «Ver el desglose del importe», no
   *  «Ver más». Como función recibe el estado, para la variante de texto alterno; el botón
   *  es el mismo elemento, así que cambiar el texto no reanuncia el foco. */
  trigger: ReactNode | ((open: boolean) => ReactNode)
  /** Tamaño del disparador. */
  size?: TamanoNavegacion
  /** Contenido de la región. */
  children: ReactNode
}

/**
 * Muestra y oculta una región con un disparador, sin pertenecer a un grupo. El disparador
 * es un `button` con `aria-expanded` y `aria-controls`; la región cerrada lleva `hidden`
 * —una región de altura cero sigue siendo enfocable— y no lleva `role="region"`: no es una
 * sección del documento. Con `id` en la raíz, `#<id>` en la URL la abre al cargar.
 * Dentro de un formulario, un campo inválido de la región la abre: los campos ocultos se
 * siguen enviando y la validación los tiene en cuenta.
 */
export const Collapsible = forwardRef<HTMLDivElement, PropsCollapsible>(function Collapsible(
  { open, defaultOpen = false, onOpenChange, trigger, size = 'md', children, id, ...resto },
  ref,
) {
  const idRegion = useId()
  const raizRef = useRef<HTMLDivElement>(null)
  const refRaiz = useRefCombinada(ref, raizRef)
  const botonRef = useRef<HTMLButtonElement>(null)
  const regionRef = useRef<HTMLDivElement>(null)
  const [interno, setInterno] = useState(defaultOpen)
  const abierto = open ?? interno

  // Los manejadores nativos leen el estado de aquí: su cierre no se rehace en cada render.
  const ultimo = useRef({ abierto, open, onOpenChange })
  ultimo.current = { abierto, open, onOpenChange }

  const fijar = (siguiente: boolean) => {
    const actual = ultimo.current
    if (siguiente === actual.abierto) return
    if (actual.open === undefined) setInterno(siguiente)
    actual.onOpenChange?.(siguiente)
  }

  useDevolverFoco(abierto, regionRef, botonRef)
  const animable = useHaCambiado(abierto)

  useEffect(() => {
    // Enlace profundo: `#<id>` en la URL, al cargar o al navegar dentro de la página,
    // abre la región y la trae a la vista.
    const vista = raizRef.current?.ownerDocument.defaultView
    const alAncla = () => {
      if (!id || hashActual() !== id) return
      fijar(true)
      desplazarHasta(raizRef.current)
    }
    alAncla()
    vista?.addEventListener('hashchange', alAncla)
    // `invalid` no burbujea: se escucha en captura desde la región.
    const region = regionRef.current
    const alInvalido = () => fijar(true)
    region?.addEventListener('invalid', alInvalido, true)
    return () => {
      vista?.removeEventListener('hashchange', alAncla)
      region?.removeEventListener('invalid', alInvalido, true)
    }
  }, [id])

  return (
    <div {...resto} id={id} ref={refRaiz} className={cx('ay-collapsible', `ay-collapsible--${size}`)}>
      <button
        ref={botonRef}
        type="button"
        className="ay-collapsible__trigger"
        aria-expanded={abierto}
        aria-controls={idRegion}
        onClick={() => fijar(!abierto)}
      >
        {typeof trigger === 'function' ? trigger(abierto) : trigger}
        <IconoChevronAbajo className="ay-collapsible__chevron" />
      </button>
      <div
        ref={regionRef}
        className={cx('ay-collapsible__region', animable && 'ay-collapsible__region--animable')}
        id={idRegion}
        hidden={!abierto}
      >
        <div className="ay-collapsible__content">{children}</div>
      </div>
    </div>
  )
})

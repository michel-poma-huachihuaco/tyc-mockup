import { forwardRef, useEffect, useRef, useState } from 'react'
import type { HTMLAttributes, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { IconoMenu } from './_iconos.js'
import { esCampoDeTexto, useBajoBreakpoint } from './_internos.js'
import type { TamanoNavegacion } from './_internos.js'

/** Un enlace de la navegación principal. */
export interface ItemNavbar {
  /** Destino. */
  href: string
  /** Sustantivo corto: «Promociones», «Reservas». */
  label: string
  /** Sección actual: `aria-current="page"`; el subrayado solo lo refuerza. */
  current?: boolean
}

export interface PropsNavbar extends Omit<HTMLAttributes<HTMLElement>, 'className'> {
  /** Logotipo enlazado al inicio. Un texto se envuelve en un enlace a `/` con ese texto
   *  como nombre —el del producto, nunca «logo»—; un nodo se pinta tal cual. */
  brand?: ReactNode
  /** Navegación principal: como máximo seis enlaces de primer nivel; a partir de ahí,
   *  Sidebar. Una sección sin permiso no se muestra, en lugar de mostrarse deshabilitada. */
  items?: ItemNavbar[]
  /** Búsqueda global. La tecla `/` lleva el foco al primer campo de este bloque desde
   *  cualquier parte, salvo si el foco ya está en otro campo de texto. */
  search?: ReactNode
  /** Acciones de la derecha: notificaciones, ayuda y menú de cuenta. */
  actions?: ReactNode
  /** Altura de la barra; `sm` para densidad compacta. */
  size?: TamanoNavegacion
  /** Abre el Drawer de navegación. Si se pasa, por debajo del breakpoint `md` la
   *  navegación se sustituye por su disparador, con `aria-controls="nav-drawer"`. */
  onMenuClick?: () => void
}

/**
 * Barra superior de la aplicación: un `header` con un `nav` «Principal» dentro. Es
 * pegajosa, no fija: ocupa su espacio y no tapa contenido al hacer scroll. Debe ir
 * precedida de SkipLink, para que quien usa teclado no recorra la navegación en cada
 * página.
 */
export const Navbar = forwardRef<HTMLElement, PropsNavbar>(function Navbar(
  { brand, items = [], search, actions, size = 'md', onMenuClick, ...resto },
  ref,
) {
  const movil = useBajoBreakpoint()
  const busquedaRef = useRef<HTMLDivElement>(null)
  // El Drawer devuelve el foco a su disparador al cerrarse: esa vuelta es la señal de que
  // la navegación ya no está desplegada.
  const [menuAbierto, setMenuAbierto] = useState(false)
  const conBusqueda = search != null

  useEffect(() => {
    const doc = busquedaRef.current?.ownerDocument
    if (!conBusqueda || !doc) return
    const alTeclear = (evento: KeyboardEvent) => {
      if (evento.key !== '/' || evento.ctrlKey || evento.metaKey || evento.altKey || evento.defaultPrevented) return
      if (esCampoDeTexto(doc.activeElement)) return
      const campo = busquedaRef.current?.querySelector<HTMLElement>(
        'input:not([type="hidden"]), textarea, [role="searchbox"], [role="combobox"], [contenteditable="true"]',
      )
      if (!campo) return
      evento.preventDefault()
      campo.focus()
    }
    doc.addEventListener('keydown', alTeclear)
    return () => doc.removeEventListener('keydown', alTeclear)
  }, [conBusqueda])

  const conMenu = onMenuClick != null

  return (
    <header
      {...resto}
      ref={ref}
      className={cx('ay-navbar', `ay-navbar--${size}`, movil && conMenu && 'ay-navbar--movil')}
    >
      <div className="ay-navbar__inner">
        {typeof brand === 'string' || typeof brand === 'number' ? (
          <a className="ay-navbar__brand" href="/">
            {brand}
          </a>
        ) : (
          brand
        )}

        {items.length > 0 && (
          // aria-label distingue este nav de los demás de la página.
          <nav className="ay-navbar__nav" aria-label="Principal">
            {items.map((item) => (
              <a key={item.href} href={item.href} aria-current={item.current ? 'page' : undefined}>
                {item.label}
              </a>
            ))}
          </nav>
        )}

        {conBusqueda && (
          <div ref={busquedaRef} className="ay-navbar__search">
            {search}
          </div>
        )}
        {actions != null && <div className="ay-navbar__actions">{actions}</div>}

        {conMenu && (
          <button
            type="button"
            className="ay-iconbtn ay-iconbtn--ghost ay-iconbtn--md ay-navbar__menu"
            aria-label="Abrir la navegación"
            aria-expanded={menuAbierto}
            aria-controls="nav-drawer"
            onClick={() => {
              setMenuAbierto(true)
              onMenuClick?.()
            }}
            onFocus={() => {
              if (menuAbierto) setMenuAbierto(false)
            }}
          >
            <IconoMenu className="ay-iconbtn__glyph" />
          </button>
        )}
      </div>
    </header>
  )
})

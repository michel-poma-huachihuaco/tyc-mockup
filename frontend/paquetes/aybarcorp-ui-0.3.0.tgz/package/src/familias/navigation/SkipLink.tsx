import type { MouseEvent } from 'react'
import { cx } from '../../utiles.js'
import { esEnfocableDeNacimiento, prefiereMenosMovimiento } from './_internos.js'

/** Un destino del atajo. */
export interface DestinoSkipLink {
  /** Id del elemento destino: un ancla real del documento. */
  id: string
  /** Rótulo que empieza por el verbo y nombra el destino: «Saltar al contenido». */
  label: string
}

/**
 * Por qué no extiende los atributos de un elemento: SkipLink no tiene raíz propia. Son de
 * uno a cuatro enlaces hermanos, primeros hijos del `body`; un contenedor alrededor no
 * aporta nada y un atributo repartido entre todos ellos —un `id`— sería un error.
 */
export interface PropsSkipLink {
  /** Destinos, en el orden en que aparecen en la página, no por importancia. De dos a
   *  cuatro cuando la página los justifica: contenido, navegación, búsqueda, pie. */
  targets?: DestinoSkipLink[]
  /** Visible siempre en lugar de al recibir el foco, por preferencia declarada del usuario
   *  o en modo de alto contraste. */
  persistent?: boolean
  /** Se dispara tras mover el foco al destino, para instrumentar el uso. */
  onSkip?: (id: string) => void
  /** Margen de anclaje del destino (`scroll-margin-block-start`), para que la cabecera
   *  pegajosa no lo tape tras el salto. */
  scrollMargin?: string
  /** Desplaza con animación; se ignora bajo `prefers-reduced-motion`. */
  smooth?: boolean
  /** Destino cuando `targets` llega vacío: el atajo se mantiene en todas las plantillas. */
  fallbackTargetId?: string
}

/**
 * Atajo para saltarse la cabecera y el índice y llegar al contenido en una pulsación.
 * Va como primer elemento del `body`, en todas las plantillas. Fuera del lienzo por
 * posicionamiento —nunca `display: none`, que lo sacaría del orden de foco— y por encima
 * de la cabecera pegajosa al recibir el foco. Al activarlo mueve el foco al destino
 * (con `tabindex="-1"` si no es enfocable) y después lo desplaza: si solo se desplazara,
 * el siguiente Tab volvería a la cabecera que se acaba de saltar.
 */
export function SkipLink({
  targets = [{ id: 'contenido', label: 'Saltar al contenido' }],
  persistent = false,
  onSkip,
  scrollMargin = 'var(--aybar-shell-top)',
  smooth = true,
  fallbackTargetId = 'contenido',
}: PropsSkipLink) {
  const destinos = targets.length > 0 ? targets : [{ id: fallbackTargetId, label: 'Saltar al contenido' }]

  const saltar = (evento: MouseEvent<HTMLAnchorElement>, id: string) => {
    const doc = evento.currentTarget.ownerDocument
    const destino = doc.getElementById(id)
    // Sin destino, el enlace se comporta como un ancla normal.
    if (!destino) return
    evento.preventDefault()
    // Un main sin tabindex no puede recibir el foco por programa.
    if (!destino.hasAttribute('tabindex') && !esEnfocableDeNacimiento(destino)) destino.setAttribute('tabindex', '-1')
    if (scrollMargin) destino.style.scrollMarginBlockStart = scrollMargin
    // El foco antes que el desplazamiento.
    destino.focus({ preventScroll: true })
    if (typeof destino.scrollIntoView === 'function') {
      const animar = smooth && !prefiereMenosMovimiento(doc.defaultView)
      destino.scrollIntoView({ behavior: animar ? 'smooth' : 'auto', block: 'start' })
    }
    onSkip?.(id)
  }

  return (
    <>
      {destinos.map((destino, i) => (
        <a
          key={destino.id}
          className={cx('ay-skip', persistent && 'ay-skip--persistent')}
          href={`#${destino.id}`}
          // Persistentes y en grupo, se apilan en columna en vez de taparse entre sí.
          style={
            persistent && i > 0
              ? {
                  insetBlockStart: `calc(var(--aybar-space-3) + ${i} * (var(--aybar-control-height-md) + var(--aybar-space-2)))`,
                }
              : undefined
          }
          onClick={(evento) => saltar(evento, destino.id)}
        >
          {destino.label}
        </a>
      ))}
    </>
  )
}

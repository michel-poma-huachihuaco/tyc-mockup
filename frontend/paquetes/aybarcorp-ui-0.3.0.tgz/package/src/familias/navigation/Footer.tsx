import { forwardRef, useId } from 'react'
import type { HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import type { TamanoNavegacion } from './_internos.js'

/** Un enlace del pie, con texto descriptivo: «Política de privacidad», no «Aquí». */
export interface EnlaceFooter {
  /** Destino. */
  href: string
  /** Nombre oficial del documento o la sección. */
  label: string
}

/** Un grupo de enlaces: legales, soporte, recursos. */
export interface GrupoFooter {
  /** Título del grupo. */
  label: string
  /** Enlaces del grupo. */
  links: EnlaceFooter[]
}

export interface PropsFooter extends Omit<HTMLAttributes<HTMLElement>, 'className'> {
  /** Grupos de enlaces. La declaración de accesibilidad va siempre aquí: es donde se busca
   *  por convención. */
  groups?: GrupoFooter[]
  /** Aviso de copyright, con el año y la razón social completa. */
  copyright?: string
  /** Versión y entorno con el formato del paquete, «v1.0.0 · producción». Es texto
   *  seleccionable, para copiarlo al abrir una incidencia. */
  version?: string
  /** Padding vertical. */
  size?: TamanoNavegacion
  /** Nombre accesible del nav de los grupos, distinto del de la navegación principal. */
  label?: string
}

/**
 * Pie del documento: el `footer` que da el landmark contentinfo, uno por página. Los
 * grupos de enlaces van en un único nav con nombre propio, cada uno con su encabezado;
 * el copyright y la versión, en la última fila. Se imprime: la información legal importa.
 */
export const Footer = forwardRef<HTMLElement, PropsFooter>(function Footer(
  { groups = [], copyright, version, size = 'sm', label = 'Pie de página', ...resto },
  ref,
) {
  const base = useId()
  return (
    <footer {...resto} ref={ref} className={cx('ay-footer', `ay-footer--${size}`)}>
      <div className="ay-footer__inner">
        {groups.length > 0 && (
          <nav className="ay-footer__nav" aria-label={label}>
            {groups.map((grupo, i) => (
              <div key={`${i}-${grupo.label}`} className="ay-footer__group">
                <h2 className="ay-footer__grouptitle" id={`${base}-g${i}`}>
                  {grupo.label}
                </h2>
                <ul aria-labelledby={`${base}-g${i}`}>
                  {grupo.links.map((enlace) => (
                    <li key={enlace.href}>
                      <a href={enlace.href}>{enlace.label}</a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </nav>
        )}
        {(copyright || version) && (
          <div className="ay-footer__meta">
            {copyright && <p>{copyright}</p>}
            {version && <p className="ay-footer__version">{version}</p>}
          </div>
        )}
      </div>
    </footer>
  )
})

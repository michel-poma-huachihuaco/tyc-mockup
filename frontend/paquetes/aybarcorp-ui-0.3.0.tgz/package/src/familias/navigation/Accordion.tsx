import { forwardRef, useState } from 'react'
import type { HTMLAttributes, KeyboardEvent, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { AccordionItem, ContextoAccordion } from './AccordionItem.js'
import type { ContextoAccordionValor } from './AccordionItem.js'

export type TipoAccordion = 'single' | 'multiple'
export type VarianteAccordion = 'plain' | 'card'

/** Una sección de Accordion declarada como dato. */
export interface SeccionAccordion {
  /** Identificador de la sección; es lo que viaja en `value`. */
  id: string
  /** Título de la sección, en una línea. */
  title: string
  /** Metadato objetivo —recuento, importe o estado— alineado al final de la cabecera. */
  meta?: ReactNode
  /** Contenido de la región. */
  content: ReactNode
  /** Cabecera no activable. */
  disabled?: boolean
}

export interface PropsAccordion extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'defaultValue'> {
  /** Secciones: `id`, `title`, `meta`, `content` y `disabled`. También admite elementos
   *  AccordionItem como hijos, que comparten el mismo estado. */
  items?: SeccionAccordion[]
  /** Secciones abiertas, en modo controlado. Sin él, Accordion lleva su propio estado y
   *  empieza con todas cerradas, que es un estado válido: los títulos siguen visibles. */
  value?: string[]
  /** Notifica el cambio de secciones abiertas. */
  onValueChange?: (value: string[]) => void
  /** `single` cierra la anterior al abrir otra, para contenido largo; `multiple` permite
   *  varias abiertas a la vez. */
  type?: TipoAccordion
  /** Presentación: `card` pone cada sección sobre su propia superficie con borde. */
  variant?: VarianteAccordion
  /** En modo `single`, permite cerrar la única abierta. */
  collapsible?: boolean
}

/**
 * Varias secciones plegables para abrir solo la que hace falta, sin ocultar qué secciones
 * existen. Cada cabecera es una parada de Tab; además, las flechas arriba y abajo mueven
 * entre cabeceras sin abrirlas, con Inicio y Fin para la primera y la última.
 */
export const Accordion = forwardRef<HTMLDivElement, PropsAccordion>(function Accordion(
  {
    items = [],
    value,
    onValueChange,
    type = 'multiple',
    variant = 'plain',
    collapsible = true,
    children,
    onKeyDown,
    ...resto
  },
  ref,
) {
  const [interno, setInterno] = useState<string[]>([])
  const abiertas = value ?? interno

  const fijar = (siguiente: string[]) => {
    if (value === undefined) setInterno(siguiente)
    onValueChange?.(siguiente)
  }

  const contexto: ContextoAccordionValor = {
    abiertas,
    alternar: (id) => {
      const abierta = abiertas.includes(id)
      if (type === 'single') {
        // Sin `collapsible`, la única abierta no se cierra: no hay cambio que notificar.
        if (abierta && !collapsible) return
        fijar(abierta ? [] : [id])
      } else {
        fijar(abierta ? abiertas.filter((v) => v !== id) : [...abiertas, id])
      }
    },
    abrir: (id) => {
      if (abiertas.includes(id)) return
      fijar(type === 'single' ? [id] : [...abiertas, id])
    },
  }

  // Flechas opcionales según APG: mueven entre cabeceras de este acordeón, sin abrir.
  const navegar = (evento: KeyboardEvent<HTMLDivElement>) => {
    onKeyDown?.(evento)
    if (evento.defaultPrevented) return
    const raiz = evento.currentTarget
    const objetivo = evento.target as HTMLElement
    if (!objetivo.classList.contains('ay-accordion__trigger') || objetivo.closest('.ay-accordion') !== raiz) return
    const cabeceras = Array.from(raiz.querySelectorAll<HTMLElement>('.ay-accordion__trigger')).filter(
      (cabecera) => cabecera.closest('.ay-accordion') === raiz,
    )
    const i = cabeceras.indexOf(objetivo)
    const total = cabeceras.length
    let destino: HTMLElement | undefined
    if (evento.key === 'ArrowDown') destino = cabeceras[(i + 1) % total]
    else if (evento.key === 'ArrowUp') destino = cabeceras[(i - 1 + total) % total]
    else if (evento.key === 'Home') destino = cabeceras[0]
    else if (evento.key === 'End') destino = cabeceras[total - 1]
    if (!destino) return
    evento.preventDefault()
    destino.focus()
  }

  return (
    <div {...resto} ref={ref} className={cx('ay-accordion', `ay-accordion--${variant}`)} onKeyDown={navegar}>
      <ContextoAccordion.Provider value={contexto}>
        {items.map((seccion) => (
          <AccordionItem
            key={seccion.id}
            value={seccion.id}
            title={seccion.title}
            meta={seccion.meta}
            disabled={seccion.disabled}
          >
            {seccion.content}
          </AccordionItem>
        ))}
        {children}
      </ContextoAccordion.Provider>
    </div>
  )
})

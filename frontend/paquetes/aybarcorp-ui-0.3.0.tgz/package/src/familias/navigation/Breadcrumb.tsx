import { Fragment, forwardRef, useEffect, useId, useLayoutEffect, useRef, useState } from 'react'
import type { HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import { anclarEnCapaSuperior } from '../surfaces/_capa.js'

export type SeparadorBreadcrumb = 'chevron' | 'slash'

/** Un nivel de la ruta. Sin `href` se pinta como texto: la página actual, o un nivel
 *  sobre el que el usuario no tiene permiso. */
export interface ItemBreadcrumb {
  /** Nombre real de la entidad, no el de la sección genérica. */
  label: string
  /** Destino del nivel. */
  href?: string
}

export interface PropsBreadcrumb extends Omit<HTMLAttributes<HTMLElement>, 'className'> {
  /** Niveles en orden jerárquico. El último es la página actual: lleva `aria-current` y
   *  nunca es un enlace. Un nivel intermedio sin `href` es uno sin permiso y se muestra
   *  como texto plano, no como enlace apagado. */
  items?: ItemBreadcrumb[]
  /** Por encima de este número de niveles, los intermedios se colapsan tras un botón que
   *  dice cuántos esconde; quedan visibles el primero y los dos últimos. */
  maxVisible?: number
  /** Separador entre niveles. Es decorativo: lo genera la hoja, nunca el lector. */
  separator?: SeparadorBreadcrumb
  /** Nombre accesible del nav, para distinguirlo del nav principal y del de pie. */
  label?: string
}

/**
 * Ruta jerárquica hasta la página actual. Es una lista de enlaces, no un widget: Tab
 * recorre los niveles y las flechas no hacen nada. Con muchos niveles, los intermedios
 * pasan a un desplegable de enlaces —siguen siendo enlaces, no comandos de menú—.
 */
export const Breadcrumb = forwardRef<HTMLElement, PropsBreadcrumb>(function Breadcrumb(
  { items = [], maxVisible = 4, separator = 'chevron', label = 'Ruta de navegación', ...resto },
  ref,
) {
  const base = useId()
  const [abierto, setAbierto] = useState(false)
  const masRef = useRef<HTMLLIElement>(null)
  const botonRef = useRef<HTMLButtonElement>(null)
  const menuRef = useRef<HTMLUListElement>(null)

  // Colapsar solo tiene sentido si queda al menos un intermedio que esconder.
  const colapsar = items.length > Math.max(maxVisible, 3)
  const intermedios = colapsar ? items.slice(1, -2) : []
  const visibles = colapsar ? [...items.slice(0, 1), ...items.slice(-2)] : items
  const ultimo = visibles.length - 1

  // Abierta, la lista de niveles sube a la capa superior bajo el botón: allí no la tapa una
  // cabecera pegajosa ni la recorta el overflow de la barra. Sin la API sigue con la hoja.
  useLayoutEffect(() => {
    if (!abierto || !menuRef.current || !masRef.current) return
    return anclarEnCapaSuperior(menuRef.current, masRef.current, { separacion: '--aybar-space-2' })
  }, [abierto])

  useEffect(() => {
    if (!abierto) return
    const doc = masRef.current?.ownerDocument
    if (!doc) return
    const fuera = (evento: Event) => {
      if (!masRef.current?.contains(evento.target as Node)) setAbierto(false)
    }
    doc.addEventListener('pointerdown', fuera)
    return () => doc.removeEventListener('pointerdown', fuera)
  }, [abierto])

  const nombreBoton =
    intermedios.length === 1 ? 'Mostrar 1 nivel intermedio' : `Mostrar ${intermedios.length} niveles intermedios`

  return (
    <nav {...resto} ref={ref} className={cx('ay-crumbs', `ay-crumbs--${separator}`)} aria-label={label}>
      <ol className="ay-crumbs__list">
        {visibles.map((nivel, i) => (
          <Fragment key={`${i}-${nivel.label}`}>
            {colapsar && i === 1 && (
              <li
                ref={masRef}
                className="ay-crumbs__more"
                onKeyDown={(evento) => {
                  if (evento.key !== 'Escape' || !abierto) return
                  evento.preventDefault()
                  setAbierto(false)
                  botonRef.current?.focus()
                }}
                onBlur={(evento) => {
                  if (!evento.currentTarget.contains(evento.relatedTarget as Node | null)) setAbierto(false)
                }}
              >
                <button
                  ref={botonRef}
                  type="button"
                  className="ay-crumbs__toggle"
                  aria-expanded={abierto}
                  aria-controls={`${base}-niveles`}
                  aria-label={nombreBoton}
                  onClick={() => setAbierto((a) => !a)}
                >
                  <span aria-hidden="true">…</span>
                </button>
                <ul ref={menuRef} id={`${base}-niveles`} className="ay-crumbs__menu" hidden={!abierto}>
                  {intermedios.map((oculto, j) => (
                    <li key={`${j}-${oculto.label}`}>
                      {oculto.href ? (
                        <a className="ay-link" href={oculto.href}>
                          {oculto.label}
                        </a>
                      ) : (
                        <span className="ay-crumbs__text">{oculto.label}</span>
                      )}
                    </li>
                  ))}
                </ul>
              </li>
            )}
            <li>
              {i === ultimo ? (
                // La página actual no se enlaza: enlazar a la propia página confunde.
                <span aria-current="page">{nivel.label}</span>
              ) : nivel.href ? (
                <a className="ay-link" href={nivel.href}>
                  {nivel.label}
                </a>
              ) : (
                <span className="ay-crumbs__text">{nivel.label}</span>
              )}
            </li>
          </Fragment>
        ))}
      </ol>
    </nav>
  )
})

/**
 * Glifos de la familia Navigation. Todos son decorativos —`aria-hidden` y fuera del
 * orden de foco—: el estado lo comunican `aria-expanded`, `aria-current` y el texto, no
 * la forma de una flecha. Usan `currentColor` para heredar el color del control y que el
 * tema oscuro no necesite una regla propia.
 */

interface PropsGlifo {
  className?: string
  tamano?: number
}

function Glifo({ className, tamano, trazo }: PropsGlifo & { trazo: string }) {
  return (
    <svg
      className={className}
      aria-hidden="true"
      focusable="false"
      width={tamano}
      height={tamano}
      viewBox="0 0 16 16"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.6}
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d={trazo} />
    </svg>
  )
}

export const IconoChevronAbajo = (p: PropsGlifo) => <Glifo {...p} tamano={p.tamano ?? 16} trazo="M4 6l4 4 4-4" />
export const IconoChevronIzquierda = (p: PropsGlifo) => <Glifo {...p} tamano={p.tamano ?? 16} trazo="M10 4L6 8l4 4" />
export const IconoChevronDerecha = (p: PropsGlifo) => <Glifo {...p} tamano={p.tamano ?? 16} trazo="M6 4l4 4-4 4" />
export const IconoMenu = (p: PropsGlifo) => <Glifo {...p} tamano={p.tamano ?? 20} trazo="M2.5 4h11M2.5 8h11M2.5 12h11" />
export const IconoCheck = (p: PropsGlifo) => <Glifo {...p} tamano={p.tamano ?? 16} trazo="M3.5 8.5l3 3 6-7" />

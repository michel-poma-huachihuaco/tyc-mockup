import { forwardRef, useEffect, useRef } from 'react'
import type { HTMLAttributes, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { esCambioDePagina } from './_internos.js'
import type { TamanoNavegacion } from './_internos.js'

export interface PropsHeader extends Omit<HTMLAttributes<HTMLElement>, 'className' | 'title'> {
  /** Nombre de la página; se renderiza como el único h1 y da el título del documento.
   *  No repite el nombre de la pestaña activa. */
  title: string
  /** Ruta hasta la página (Breadcrumb). Va antes del h1 en el DOM. */
  breadcrumb?: ReactNode
  /** Estado e identificadores junto al título; el estado es un Badge con su palabra
   *  escrita, el color solo lo acompaña. */
  meta?: ReactNode
  /** Frase de contexto con el dato que no cabe en el título. No es un encabezado. */
  description?: string
  /** Acciones de la página, con una primaria, que nombran el objeto: «Nueva unidad», no
   *  «Nuevo». Dos visibles como máximo; el resto, en un Dropdown Menu. */
  actions?: ReactNode
  /** Pestañas ancladas al pie, sin separación con el encabezado. */
  tabs?: ReactNode
  /** Padding vertical. */
  size?: TamanoNavegacion
  /** Muestra el Skeleton en título y metadatos y deshabilita las acciones. */
  loading?: boolean
}

/**
 * Cabecera de una página concreta: ruta, título como único h1, metadatos, descripción,
 * acciones y pestañas. Vive bajo Navbar y encima del contenido. El h1 coincide con el
 * título del documento para que la pestaña del navegador y la página digan lo mismo.
 */
export const Header = forwardRef<HTMLElement, PropsHeader>(function Header(
  { title, breadcrumb, meta, description, actions, tabs, size = 'md', loading = false, ...resto },
  ref,
) {
  const h1 = useRef<HTMLHeadingElement>(null)

  // El documento dice lo mismo que la página.
  useEffect(() => {
    if (title && !loading) document.title = `${title} · Aybar`
  }, [title, loading])

  // Al cambiar de página dentro de la aplicación, el foco pasa al h1 para que se anuncie.
  // En la carga de la página no: el primer Tab saltaría SkipLink y la navegación. Tampoco
  // cuando el efecto se repite con la misma página (StrictMode, un remonte).
  useEffect(() => {
    const titulo = h1.current
    if (loading || !title || !titulo) return
    if (esCambioDePagina(titulo.ownerDocument, title)) titulo.focus()
  }, [title, loading])

  return (
    <header
      {...resto}
      ref={ref}
      className={cx('ay-pageheader', `ay-pageheader--${size}`)}
      aria-busy={loading || undefined}
    >
      {breadcrumb}
      <div className="ay-pageheader__row">
        <div className="ay-pageheader__main">
          {loading ? (
            <div className="ay-pageheader__loading" aria-hidden="true">
              <span className="ay-skel ay-skel--text ay-pageheader__skel" />
              {meta != null && <span className="ay-skel ay-skel--text ay-pageheader__skel-meta" />}
            </div>
          ) : (
            <h1 ref={h1} className="ay-pageheader__title" tabIndex={-1}>
              {title}
              {/* Un texto suelto se fundiría con el título en el mismo hueco flexible: se
                  envuelve para que el estado guarde su separación. Un Badge ya es elemento. */}
              {typeof meta === 'string' || typeof meta === 'number' ? (
                <span className="ay-pageheader__meta">{meta}</span>
              ) : (
                meta
              )}
            </h1>
          )}
          {description && <p className="ay-pageheader__desc">{description}</p>}
        </div>
        {actions != null &&
          (loading ? (
            // Un fieldset deshabilitado deshabilita de forma nativa todos sus controles.
            <fieldset className="ay-pageheader__actions" disabled>
              {actions}
            </fieldset>
          ) : (
            <div className="ay-pageheader__actions">{actions}</div>
          ))}
      </div>
      {tabs != null && <div className="ay-pageheader__tabs">{tabs}</div>}
      {/* La región ya existe vacía: una región que nace con su texto no se anuncia de forma fiable. */}
      <p className="ay-visually-hidden" aria-live="polite">
        {loading ? 'Cargando la página' : ''}
      </p>
    </header>
  )
})

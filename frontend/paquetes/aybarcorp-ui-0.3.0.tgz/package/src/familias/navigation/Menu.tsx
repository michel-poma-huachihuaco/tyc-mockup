import { Fragment, forwardRef, useEffect, useId, useLayoutEffect, useRef, useState } from 'react'
import type { FocusEvent, HTMLAttributes, KeyboardEvent } from 'react'
import { areaVisible, cx } from '../../utiles.js'
import { anclarEnCapaSuperior, pixelesDeToken } from '../surfaces/_capa.js'
import { IconoChevronDerecha } from './_iconos.js'
import { useRefCombinada } from './_internos.js'
import type { TamanoNavegacion } from './_internos.js'

/** Un comando del menú. */
export interface ItemMenu {
  /** Identificador estable. */
  id: string
  /** Comando en infinitivo: «Duplicar», «Exportar». El destructivo nombra el objeto. */
  label: string
  /** Atajo de teclado, con el modificador del sistema. Entra en el nombre accesible. */
  shortcut?: string
  /** Si se define, el comando alterna algo: `menuitemcheckbox` con `aria-checked`. */
  checked?: boolean
  /** Comando destructivo: tono danger; conviene `separatorBefore`. */
  danger?: boolean
  /** Recorrible con las flechas pero no activable: quitarlo del recorrido oculta que existe. */
  disabled?: boolean
  /** Separador antes del comando, para agrupar comandos relacionados. */
  separatorBefore?: boolean
  /** Submenú: un solo nivel. La flecha derecha lo abre y entra; la izquierda lo cierra. */
  items?: ItemMenu[]
  /** Acción del comando. */
  onSelect?: () => void
}

export interface PropsMenu extends Omit<HTMLAttributes<HTMLDivElement>, 'className'> {
  /** Comandos: `label`, `shortcut`, `checked`, `disabled`, `items` y `onSelect`. Sin
   *  comandos el menú no se abre: no se renderiza nada. */
  items?: ItemMenu[]
  /** Nombre accesible del menú. */
  label: string
  /** Altura de los elementos: `sm` para barras densas. */
  size?: TamanoNavegacion
  /** Se llama tras activar un comando, con Escape y al salir con Tab. Después el foco
   *  vuelve al elemento que lo tenía cuando el menú lo recibió: el disparador. */
  onClose?: () => void
  /** Búsqueda por letra: la tecla salta al primer comando que empieza por ella, y
   *  pulsaciones seguidas de la misma letra recorren las coincidencias. */
  typeahead?: boolean
}

const ESPERA_TECLEO = 600

/**
 * Lista de comandos con el modelo de teclado que exige `role="menu"`: flechas con ciclo,
 * Inicio, Fin, búsqueda por letra, Enter o Espacio y Escape. El foco es real y se mueve
 * con foco móvil (un solo comando en el orden de tabulación); no se mezcla con
 * `aria-activedescendant`. Al recibir el foco el contenedor, lo pasa al comando activo:
 * así lo usan Dropdown Menu y Context Menu. No es para navegar entre páginas.
 */
export const Menu = forwardRef<HTMLDivElement, PropsMenu>(function Menu(
  { items = [], label, size = 'md', onClose, typeahead = true, onKeyDown, onFocus, ...resto },
  ref,
) {
  const base = useId()
  const raizRef = useRef<HTMLDivElement>(null)
  const refRaiz = useRefCombinada(ref, raizRef)
  const botones = useRef<(HTMLButtonElement | null)[]>([])
  const subBotones = useRef<(HTMLButtonElement | null)[]>([])
  const origen = useRef<HTMLElement | null>(null)
  const tecleo = useRef({ texto: '', hasta: 0 })
  const [activo, setActivo] = useState(0)
  const [submenu, setSubmenu] = useState<string | null>(null)
  const [activoSub, setActivoSub] = useState(0)
  const [voltear, setVoltear] = useState(false)

  const padre = items.find((item) => item.id === submenu)
  const hijos = padre?.items ?? []

  // Al abrir un submenú, el foco entra en su primer comando.
  useEffect(() => {
    if (submenu !== null) subBotones.current[0]?.focus()
  }, [submenu])

  // El submenú abierto sube a la capa superior junto a su ítem padre, con el primer comando
  // a su altura (sube lo que mide su relleno): allí no lo recorta el overflow del menú ni el
  // de un ancestro. Antes del volteo, que lo mide, y del foco, que entra en él. Sin la API
  // sigue anclado con la hoja.
  useLayoutEffect(() => {
    if (submenu === null) return
    const nodo = raizRef.current?.querySelector<HTMLElement>(`[data-submenu="${submenu}"]`)
    const padre = nodo?.parentElement
    if (!nodo || !padre) return
    return anclarEnCapaSuperior(nodo, padre, {
      lado: 'lado',
      separacion: '--aybar-space-1',
      desplazamiento: -pixelesDeToken(nodo.ownerDocument, '--aybar-space-1'),
    })
  }, [submenu])

  // Submenú que no cabe: se abre al otro lado, pero solo si allí sí cabe. Volteado y aun
  // así sin sitio quedaría cortado por el borde de inicio, donde la página no tiene
  // scroll que lo alcance; sin voltear, el exceso queda del lado que sí se desplaza.
  useLayoutEffect(() => {
    if (submenu === null) return setVoltear(false)
    const nodo = raizRef.current?.querySelector<HTMLElement>(`[data-submenu="${submenu}"]`)
    const vista = nodo?.ownerDocument.defaultView
    if (!nodo || !vista) return
    const { ancho } = areaVisible(nodo.ownerDocument)
    const caja = nodo.getBoundingClientRect()
    const padre = (nodo.parentElement ?? nodo).getBoundingClientRect()
    // Las dos posiciones posibles, con el mismo hueco que tenga ahora (volteado o no).
    const hueco = Math.max(0, caja.left - padre.right, padre.left - caja.right)
    const aLaDerecha = { izquierda: padre.right + hueco, derecha: padre.right + hueco + caja.width }
    const aLaIzquierda = { izquierda: padre.left - hueco - caja.width, derecha: padre.left - hueco }
    // En LTR el submenú abre a la derecha del ítem; en RTL, a la izquierda.
    const rtl = vista.getComputedStyle(nodo).direction === 'rtl'
    const [propia, opuesta] = rtl ? [aLaIzquierda, aLaDerecha] : [aLaDerecha, aLaIzquierda]
    const cabe = (lado: { izquierda: number; derecha: number }) => lado.izquierda >= 0 && lado.derecha <= ancho
    setVoltear(!cabe(propia) && cabe(opuesta))
  }, [submenu])

  if (items.length === 0) return null

  const enfocar = (i: number) => {
    setActivo(i)
    botones.current[i]?.focus()
  }
  const enfocarSub = (i: number) => {
    setActivoSub(i)
    subBotones.current[i]?.focus()
  }

  const cerrar = (devolverFoco = true) => {
    setSubmenu(null)
    onClose?.()
    if (devolverFoco && origen.current?.isConnected) origen.current.focus()
  }

  const activar = (item: ItemMenu, i: number) => {
    if (item.disabled) return
    if (item.items?.length) {
      setActivo(i)
      setActivoSub(0)
      setSubmenu(item.id)
      return
    }
    item.onSelect?.()
    cerrar()
  }

  /** Índice del siguiente comando que empieza por lo tecleado, a partir del activo. */
  const buscar = (lista: ItemMenu[], desde: number, tecla: string): number => {
    const ahora = Date.now()
    const previo = tecleo.current
    const texto = ahora < previo.hasta ? previo.texto + tecla : tecla
    tecleo.current = { texto, hasta: ahora + ESPERA_TECLEO }
    // La misma letra repetida recorre las coincidencias; varias letras afinan la búsqueda.
    const repetida = texto.split('').every((c) => c === tecla)
    const prefijo = repetida ? tecla : texto
    const inicio = repetida || texto.length === 1 ? desde + 1 : desde
    for (let n = 0; n < lista.length; n++) {
      const i = (inicio + n) % lista.length
      if (lista[i]?.label.toLowerCase().startsWith(prefijo)) return i
    }
    return -1
  }

  const mover = (evento: KeyboardEvent, lista: ItemMenu[], actual: number, ir: (i: number) => void): boolean => {
    const ultimo = lista.length - 1
    // Ciclo en los extremos; los deshabilitados se recorren igual.
    if (evento.key === 'ArrowDown') ir(actual === ultimo ? 0 : actual + 1)
    else if (evento.key === 'ArrowUp') ir(actual === 0 ? ultimo : actual - 1)
    else if (evento.key === 'Home') ir(0)
    else if (evento.key === 'End') ir(ultimo)
    else if (
      typeahead &&
      evento.key.length === 1 &&
      evento.key !== ' ' &&
      !evento.ctrlKey &&
      !evento.metaKey &&
      !evento.altKey
    ) {
      const i = buscar(lista, actual, evento.key.toLowerCase())
      if (i >= 0) ir(i)
    } else return false
    return true
  }

  const alTeclear = (evento: KeyboardEvent<HTMLDivElement>) => {
    onKeyDown?.(evento)
    if (evento.defaultPrevented) return
    const enSubmenu = submenu !== null && !!(evento.target as HTMLElement).closest('[data-submenu]')

    if (evento.key === 'Tab') {
      // Tab sale del menú y sigue por la página: no se devuelve el foco atrás.
      cerrar(false)
      return
    }
    if (enSubmenu) {
      if (evento.key === 'ArrowLeft' || evento.key === 'Escape') {
        evento.preventDefault()
        setSubmenu(null)
        botones.current[activo]?.focus()
        return
      }
      if (mover(evento, hijos, activoSub, enfocarSub)) evento.preventDefault()
      return
    }
    if (evento.key === 'Escape') {
      evento.preventDefault()
      cerrar()
      return
    }
    if (evento.key === 'ArrowRight') {
      const item = items[activo]
      if (item?.items?.length && !item.disabled) {
        evento.preventDefault()
        activar(item, activo)
      }
      return
    }
    if (mover(evento, items, activo, enfocar)) evento.preventDefault()
  }

  const alEnfocar = (evento: FocusEvent<HTMLDivElement>) => {
    onFocus?.(evento)
    // El contenedor recibe el foco desde fuera: se recuerda quién lo tenía y se pasa al
    // comando activo.
    if (evento.target === evento.currentTarget) {
      const previo = evento.relatedTarget as HTMLElement | null
      if (previo && !evento.currentTarget.contains(previo)) origen.current = previo
      botones.current[activo]?.focus()
    } else if (!evento.currentTarget.contains(evento.relatedTarget as Node | null)) {
      const previo = evento.relatedTarget as HTMLElement | null
      if (previo) origen.current = previo
    }
  }

  return (
    <div
      {...resto}
      ref={refRaiz}
      className={cx('ay-menu', `ay-menu--${size}`)}
      role="menu"
      aria-label={label}
      tabIndex={-1}
      onKeyDown={alTeclear}
      onFocus={alEnfocar}
    >
      {items.map((item, i) => {
        const conSub = !!item.items?.length
        const abierto = submenu === item.id
        const boton = (
          <BotonMenu
            item={item}
            refBoton={(nodo) => {
              botones.current[i] = nodo
            }}
            activo={i === activo}
            conSub={conSub}
            abierto={abierto}
            controla={abierto ? `${base}-sub-${item.id}` : undefined}
            alActivar={() => activar(item, i)}
          />
        )
        return (
          <Fragment key={item.id}>
            {item.separatorBefore && <div role="separator" className="ay-menu__sep" />}
            {conSub ? (
              <div role="none" className="ay-menu__subwrap">
                {boton}
                {abierto && (
                  <div
                    className={cx('ay-menu', `ay-menu--${size}`, 'ay-menu--sub', voltear && 'ay-menu--sub-flip')}
                    role="menu"
                    id={`${base}-sub-${item.id}`}
                    aria-label={item.label}
                    data-submenu={item.id}
                  >
                    {hijos.map((hijo, j) => (
                      <Fragment key={hijo.id}>
                        {hijo.separatorBefore && <div role="separator" className="ay-menu__sep" />}
                        <BotonMenu
                          item={hijo}
                          refBoton={(nodo) => {
                            subBotones.current[j] = nodo
                          }}
                          activo={j === activoSub}
                          conSub={false}
                          abierto={false}
                          alActivar={() => {
                            if (hijo.disabled) return
                            hijo.onSelect?.()
                            cerrar()
                          }}
                        />
                      </Fragment>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              boton
            )}
          </Fragment>
        )
      })}
    </div>
  )
})

interface PropsBotonMenu {
  item: ItemMenu
  refBoton: (nodo: HTMLButtonElement | null) => void
  activo: boolean
  conSub: boolean
  abierto: boolean
  controla?: string
  alActivar: () => void
}

function BotonMenu({ item, refBoton, activo, conSub, abierto, controla, alActivar }: PropsBotonMenu) {
  const conEstado = item.checked !== undefined
  return (
    <button
      ref={refBoton}
      type="button"
      // Los que alternan declaran su rol y su estado: el icono de marca no se anuncia.
      role={conEstado ? 'menuitemcheckbox' : 'menuitem'}
      aria-checked={conEstado ? item.checked : undefined}
      aria-haspopup={conSub ? 'menu' : undefined}
      aria-expanded={conSub ? abierto : undefined}
      aria-controls={controla}
      aria-disabled={item.disabled || undefined}
      tabIndex={activo ? 0 : -1}
      data-active={activo || undefined}
      className={cx('ay-menu__item', item.danger && 'ay-menu__item--danger')}
      onClick={alActivar}
    >
      <span className="ay-menu__label">{item.label}</span>
      {item.shortcut && (
        // El atajo entra en el nombre accesible, separado de la etiqueta por una pausa.
        <>
          <span className="ay-visually-hidden">, </span>
          <span className="ay-menu__shortcut">{item.shortcut}</span>
        </>
      )}
      {conSub && <IconoChevronDerecha className="ay-menu__chevron" tamano={14} />}
    </button>
  )
}

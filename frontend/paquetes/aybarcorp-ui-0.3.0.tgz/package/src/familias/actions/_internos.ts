/**
 * Piezas internas de la familia Actions. No se exportan desde el índice: no son API.
 */
import { createContext } from 'react'
import type { ButtonSize } from './Button.js'

/**
 * Tamaño que un `ButtonGroup` impone a sus miembros. La ficha lo pide así —«size se
 * propaga por contexto a los miembros»— porque un grupo unido con alturas distintas deja
 * escalones en el borde compartido. `undefined` fuera de un grupo: cada control usa el
 * suyo.
 */
export const ContextoTamanoGrupo = createContext<ButtonSize | undefined>(undefined)

/** Retardo de apertura del Tooltip con puntero, el de la ficha de Tooltip (300 ms). */
export const RETARDO_TOOLTIP = 300

/**
 * Margen de tolerancia antes de cerrar el Tooltip al salir el puntero: quien mueve el
 * ratón con poca precisión tiene que poder cruzar el hueco hasta el tooltip sin que
 * desaparezca justo antes de leerlo.
 */
export const TOLERANCIA_TOOLTIP = 120

// ── Capa superior ─────────────────────────────────────────────────────────────
// El tooltip propio de Icon Button sube a la capa superior con la misma mecánica que el
// de Surfaces: `_capa.ts`, que no depende de ninguna familia.
export { mostrarEnCapaSuperior } from '../surfaces/_capa.js'

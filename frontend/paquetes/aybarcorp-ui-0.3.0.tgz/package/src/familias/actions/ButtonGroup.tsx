import { Children, forwardRef } from 'react'
import type { HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import type { ButtonSize } from './Button.js'
import { ContextoTamanoGrupo } from './_internos.js'

/** Eje de un ButtonGroup. */
export type ButtonGroupDirection = 'horizontal' | 'vertical'
/** Bordes compartidos (`joined`) o separación con el gap del sistema (`spaced`). */
export type ButtonGroupAttachment = 'joined' | 'spaced'

export interface PropsButtonGroup extends Omit<HTMLAttributes<HTMLDivElement>, 'className'> {
  /** Eje. `vertical` en paneles estrechos y menús laterales, donde los miembros ocupan
   *  el ancho del grupo. */
  direction?: ButtonGroupDirection
  /** `joined` comparte bordes y redondea solo los extremos exteriores; promete
   *  alternativas equivalentes, así que todos los miembros llevan la misma variante.
   *  `spaced` deja el gap control.gap entre miembros y admite mezclar jerarquías. */
  attachment?: ButtonGroupAttachment
  /** Tamaño que se propaga por contexto a los miembros: en un grupo todos miden lo mismo. */
  size?: ButtonSize
  /** Nombre accesible del grupo (`role="group"`). Obligatorio si no hay un título visible
   *  al lado: el borde compartido no existe en el árbol de accesibilidad. No sustituye al
   *  nombre de cada miembro, que conserva el suyo. */
  label?: string
}

/**
 * Presenta de dos a cuatro acciones relacionadas como una sola unidad visual. No es un
 * control por sí mismo: cada miembro es una parada de tabulación con su propio nombre y
 * las flechas no hacen nada —si hicieran falta, sería Toolbar o Segmented Control—.
 * Un miembro sin permiso no se renderiza; si solo queda uno, se pinta suelto, sin grupo.
 */
export const ButtonGroup = forwardRef<HTMLDivElement, PropsButtonGroup>(function ButtonGroup(
  { direction = 'horizontal', attachment = 'joined', size = 'md', label, children, ...rest },
  ref,
) {
  // `Children.toArray` descarta null y false: lo que filtra un `{permiso && <Button/>}`.
  const miembros = Children.toArray(children)
  if (miembros.length === 0) return null
  return (
    <ContextoTamanoGrupo.Provider value={size}>
      {miembros.length === 1 ? (
        miembros[0]
      ) : (
        <div
          {...rest}
          ref={ref}
          role="group"
          aria-label={label}
          className={cx('ay-btngroup', `ay-btngroup--${direction}`, `ay-btngroup--${attachment}`)}
        >
          {children}
        </div>
      )}
    </ContextoTamanoGrupo.Provider>
  )
})

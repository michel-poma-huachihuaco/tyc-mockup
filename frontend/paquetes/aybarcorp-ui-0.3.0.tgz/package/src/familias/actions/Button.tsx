import { forwardRef, useContext } from 'react'
import type { ButtonHTMLAttributes, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { GiroDeCarga } from './_iconos.js'
import { ContextoTamanoGrupo } from './_internos.js'

/** Jerarquía visual e intención de un botón. */
export type ButtonVariant = 'primary' | 'secondary' | 'accent' | 'ghost' | 'danger'
/** Tamaño de control de la familia Actions: altura y padding desde control.height y control.padding. */
export type ButtonSize = 'sm' | 'md' | 'lg'
/** Tipo nativo del botón dentro de un formulario. */
export type ButtonType = 'button' | 'submit' | 'reset'

export interface PropsButton extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'className'> {
  /** Jerarquía visual e intención. `primary` es la acción principal, una por vista;
   *  `secondary` la alternativa de igual jerarquía, con borde; `accent` el destacado de
   *  marca, nunca junto a primary; `ghost` la terciaria de barras y tablas; `danger` la
   *  acción destructiva confirmada, siempre con la copia del riesgo. */
  variant?: ButtonVariant
  /** Altura y padding desde los tokens de densidad: `sm` en toolbars y celdas de tabla,
   *  `md` en formularios, `lg` en el CTA de página y en móvil. Dentro de un ButtonGroup
   *  manda el tamaño del grupo: todos los miembros miden lo mismo. */
  size?: ButtonSize
  /** Explícito para no enviar formularios por accidente: `button` por omisión y no
   *  `submit`, que es lo que haría el elemento nativo. */
  type?: ButtonType
  /** Desactiva la activación y saca el botón del orden de tabulación. */
  disabled?: boolean
  /** Implica disabled y expone `aria-busy`: bloquea el segundo envío. Un spinner ocupa el
   *  lugar del icono inicial y la etiqueta no cambia, para no reanunciar el nombre. */
  loading?: boolean
  /** Ocupa el ancho del contenedor: pies de formulario en móvil. Solo en este modo la
   *  etiqueta envuelve; en el resto una etiqueta que no cabe obliga a revisar la copia. */
  fullWidth?: boolean
  /** Icono inicial, decorativo: se marca `aria-hidden` y el nombre lo da la etiqueta. */
  leadingIcon?: ReactNode
  /** Icono final, decorativo; reservado a dirección o desplegable. */
  trailingIcon?: ReactNode
}

/**
 * Control de acción canónico: guardar, enviar, abrir un overlay, confirmar. Si la
 * interacción navega a otra URL es Link; si solo hay icono, IconButton; si el estado
 * persiste al soltar, ToggleButton. Es un `button` nativo: rol, foco y activación con
 * Enter y Space vienen dados, sin ARIA redundante.
 */
export const Button = forwardRef<HTMLButtonElement, PropsButton>(function Button(
  {
    variant = 'primary',
    size = 'md',
    type = 'button',
    disabled = false,
    loading = false,
    fullWidth = false,
    leadingIcon,
    trailingIcon,
    children,
    ...rest
  },
  ref,
) {
  const tamanoGrupo = useContext(ContextoTamanoGrupo)
  const tamano = tamanoGrupo ?? size
  return (
    <button
      {...rest}
      ref={ref}
      type={type}
      // `loading` implica disabled: un botón ocupado que acepta un segundo clic envía la
      // operación dos veces, y `onClick` no se dispara en ninguno de los dos estados.
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      className={cx('ay-btn', `ay-btn--${variant}`, `ay-btn--${tamano}`, fullWidth && 'ay-btn--full')}
    >
      {loading ? (
        <GiroDeCarga tamano="sm" clase="ay-btn__spinner" />
      ) : (
        hayNodo(leadingIcon) && (
          <span className="ay-btn__icon" aria-hidden="true">
            {leadingIcon}
          </span>
        )
      )}
      <span className="ay-btn__label">{children}</span>
      {hayNodo(trailingIcon) && (
        <span className="ay-btn__icon" aria-hidden="true">
          {trailingIcon}
        </span>
      )}
    </button>
  )
})

/** Un slot de icono vacío no se pinta: dejaría un hueco del ancho del gap. */
function hayNodo(nodo: ReactNode): boolean {
  return nodo !== undefined && nodo !== null && nodo !== false && nodo !== ''
}

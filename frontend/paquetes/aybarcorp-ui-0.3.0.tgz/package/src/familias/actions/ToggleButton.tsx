import { forwardRef, useContext, useState } from 'react'
import type { ButtonHTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import type { ButtonSize } from './Button.js'
import { ContextoTamanoGrupo } from './_internos.js'

/** Apariencia de un ToggleButton. */
export type ToggleButtonVariant = 'label' | 'icon' | 'ghost'

export interface PropsToggleButton extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'className' | 'type'> {
  /** Estado controlado; se refleja en `aria-pressed`. Si se omite, el control lleva su
   *  propio estado a partir de `defaultPressed`. */
  pressed?: boolean
  /** Notifica el cambio con el valor nuevo, en modo controlado y no controlado. En modo
   *  controlado el control no cambia hasta que `pressed` cambie: si aplicar el filtro
   *  falla, basta con no actualizarlo para que vuelva a su estado anterior. */
  onPressedChange?: (pressed: boolean) => void
  /** Estado inicial en modo no controlado. */
  defaultPressed?: boolean
  /** Nombre accesible; obligatorio en la variante `icon`, donde no hay texto visible. Nombra
   *  la capacidad y no cambia con el estado: «Solo disponibles», nunca «Quitar filtro». */
  label?: string
  /** `label` con texto, para filtros y modos con nombre; `icon` solo icono, con `label`
   *  como `aria-label`; `ghost` en toolbars densas, sin fondo hasta presionarse. */
  variant?: ToggleButtonVariant
  /** Altura y padding, igual que en Button. Dentro de un ButtonGroup manda el del grupo. */
  size?: ButtonSize
  /** Desactiva la activación. Conserva la pista de presionado: la información sigue siendo
   *  relevante aunque no se pueda cambiar. */
  disabled?: boolean
}

/**
 * Activa y desactiva un estado binario que se aplica de inmediato y queda visible en el
 * propio control: filtros activos, formato de texto, modos de una herramienta. Es un
 * `button` con `aria-pressed`, no un `role="switch"`: una preferencia con lectura
 * encendido/apagado es Switch, y un estado que se confirma al guardar es Checkbox. La
 * etiqueta no cambia entre estados; el fondo lleno, el peso y el relleno del icono sí.
 */
export const ToggleButton = forwardRef<HTMLButtonElement, PropsToggleButton>(function ToggleButton(
  {
    pressed,
    onPressedChange,
    defaultPressed = false,
    label,
    variant = 'label',
    size = 'md',
    disabled = false,
    onClick,
    children,
    'aria-label': ariaLabel,
    ...rest
  },
  ref,
) {
  const tamanoGrupo = useContext(ContextoTamanoGrupo)
  const tamano = tamanoGrupo ?? size
  const [interno, setInterno] = useState(defaultPressed)
  const presionado = pressed ?? interno

  return (
    <button
      {...rest}
      ref={ref}
      type="button"
      disabled={disabled}
      aria-pressed={presionado}
      aria-label={variant === 'icon' ? label : ariaLabel}
      className={cx('ay-toggle', `ay-toggle--${variant}`, `ay-toggle--${tamano}`)}
      onClick={(evento) => {
        onClick?.(evento)
        if (evento.defaultPrevented) return
        // Estado «loading» de la ficha: mientras el toggle aplica un cambio remoto lleva
        // `aria-busy` y no admite reentrada; un segundo clic no lanza otra llamada.
        if (rest['aria-busy'] === true || rest['aria-busy'] === 'true') return
        // No controlado si `pressed` no llegó por props: el propio clic lleva el estado.
        if (pressed === undefined) setInterno(!presionado)
        onPressedChange?.(!presionado)
      }}
    >
      {children}
    </button>
  )
})

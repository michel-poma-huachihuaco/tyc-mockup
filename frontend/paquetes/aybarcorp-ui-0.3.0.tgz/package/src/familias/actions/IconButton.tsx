import {
  forwardRef,
  useCallback,
  useContext,
  useEffect,
  useId,
  useImperativeHandle,
  useLayoutEffect,
  useRef,
  useState,
} from 'react'
import type { ButtonHTMLAttributes, ReactNode } from 'react'
import { areaVisible, cx } from '../../utiles.js'
import type { ButtonSize } from './Button.js'
import { GiroDeCarga } from './_iconos.js'
import { ContextoTamanoGrupo, mostrarEnCapaSuperior, RETARDO_TOOLTIP, TOLERANCIA_TOOLTIP } from './_internos.js'

/** Apariencia de un IconButton. `accent` no existe aquí: en toolbars satura. */
export type IconButtonVariant = 'primary' | 'secondary' | 'ghost' | 'danger'

export interface PropsIconButton
  extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'className' | 'aria-label' | 'type' | 'children'> {
  /** Glifo. Obligatorio. Se marca `aria-hidden`: el nombre viene del `aria-label`, no del SVG. */
  icon: ReactNode
  /** Nombre accesible, obligatorio; se aplica como `aria-label`. Se redacta como acción
   *  con su objeto —«Eliminar unidad 402», no «Eliminar»— y nunca queda vacío. */
  label: string
  /** Apariencia. `ghost` es la de densidad de datos (tablas y toolbars), sin fondo hasta
   *  hover; `secondary` lleva borde para separarse de una superficie blanca; `danger`
   *  solo con confirmación posterior o deshacer disponible. */
  variant?: IconButtonVariant
  /** Lado del cuadrado, igual a control.height, y tamaño del glifo: 16 en `sm`, 20 en
   *  `md` y 24 en `lg`. Dentro de un ButtonGroup manda el tamaño del grupo. */
  size?: ButtonSize
  /** Implica disabled y expone `aria-busy`; el spinner sustituye al glifo y el nombre
   *  accesible no cambia. */
  loading?: boolean
  /** Desactiva la activación y saca el botón del orden de tabulación. */
  disabled?: boolean
  /** Texto del Tooltip; por omisión reutiliza `label`. Aparece con el foco de teclado de
   *  inmediato y con el puntero tras el retardo, y Escape lo cierra sin mover el foco.
   *  Es refuerzo visual: no sustituye al nombre accesible. Una cadena vacía lo suprime. */
  tooltip?: string
}

interface Posicion {
  top: number
  left: number
  lado: 'top' | 'bottom'
}

/**
 * Acción cuyo significado cabe en un icono reconocible, donde no hay espacio para
 * etiqueta: toolbars, cabeceras de card, filas de tabla y overlays. Si el icono admite
 * más de una lectura, o la acción es la principal de la vista, es Button con etiqueta.
 * A partir de tres por fila, se agrupan en un Dropdown Menu «Más acciones».
 */
export const IconButton = forwardRef<HTMLButtonElement, PropsIconButton>(function IconButton(
  {
    icon,
    label,
    variant = 'ghost',
    size = 'md',
    loading = false,
    disabled = false,
    tooltip = label,
    onPointerEnter,
    onPointerLeave,
    onFocus,
    onBlur,
    'aria-describedby': describedBy,
    ...rest
  },
  ref,
) {
  const tamanoGrupo = useContext(ContextoTamanoGrupo)
  const tamano = tamanoGrupo ?? size
  const inerte = disabled || loading

  const boton = useRef<HTMLButtonElement | null>(null)
  const burbuja = useRef<HTMLSpanElement | null>(null)
  const temporizador = useRef<ReturnType<typeof setTimeout> | undefined>(undefined)
  const idTooltip = useId()
  const [abierto, setAbierto] = useState(false)
  const [posicion, setPosicion] = useState<Posicion | null>(null)
  useImperativeHandle(ref, () => boton.current as HTMLButtonElement)

  const cerrar = useCallback(() => {
    clearTimeout(temporizador.current)
    setAbierto(false)
    setPosicion(null)
  }, [])
  const programar = (accion: () => void, retardo: number) => {
    clearTimeout(temporizador.current)
    temporizador.current = setTimeout(accion, retardo)
  }

  useEffect(() => () => clearTimeout(temporizador.current), [])

  // Escape cierra el tooltip esté donde esté el foco, sin moverlo: quien lo descarta
  // sigue en mitad de lo que hacía. Un desplazamiento lo cierra porque su posición es fija.
  useEffect(() => {
    if (!abierto) return
    const alTeclear = (evento: KeyboardEvent) => {
      if (evento.key === 'Escape') cerrar()
    }
    document.addEventListener('keydown', alTeclear)
    window.addEventListener('scroll', cerrar, true)
    return () => {
      document.removeEventListener('keydown', alTeclear)
      window.removeEventListener('scroll', cerrar, true)
    }
  }, [abierto, cerrar])

  // Se mide antes de pintar: arriba si cabe, abajo si no, y nunca fuera del área útil.
  // En la capa superior o, sin ella, con `position: fixed`: un contenedor con overflow no
  // lo recorta.
  useLayoutEffect(() => {
    if (!abierto) return
    const disparador = boton.current
    const tip = burbuja.current
    if (!disparador || !tip) return
    // A la capa superior antes de medir: allí no lo recorta el overflow ni lo desplaza el
    // transform de un ancestro. Sin la API sigue con su `position: fixed`.
    mostrarEnCapaSuperior(tip)
    const caja = disparador.getBoundingClientRect()
    // El margen de bloque del tooltip es la separación con el botón: la burbuja ocupa
    // su alto más dos márgenes.
    const hueco = Number.parseFloat(getComputedStyle(tip).marginTop) || 0
    const alto = tip.offsetHeight
    const ancho = tip.offsetWidth
    // El área útil es la de la página sin las barras de scroll: con innerWidth, un botón
    // pegado al borde derecho dejaba la burbuja encima de la barra y la página con scroll
    // horizontal.
    const area = areaVisible()
    const arriba = caja.top - alto - 2 * hueco >= 0
    const izquierda = Math.max(hueco, Math.min(caja.left + caja.width / 2 - ancho / 2, area.ancho - ancho - hueco))
    // Si tampoco cabe abajo (un botón en una ventana muy baja), se recorta dentro del área
    // útil: mejor tapar parte del botón que dejar el texto fuera de la ventana.
    const top = arriba ? caja.top - alto - 2 * hueco : Math.max(0, Math.min(caja.bottom, area.alto - alto - 2 * hueco))
    setPosicion({ top, left: izquierda, lado: arriba ? 'top' : 'bottom' })
  }, [abierto, tooltip])

  const visible = abierto && !inerte && tooltip !== ''
  // Si el tooltip repite el nombre, describir con él haría oír dos veces lo mismo.
  const describe = visible && tooltip !== label
  const descripcion = [describedBy, describe ? idTooltip : undefined].filter(Boolean).join(' ') || undefined

  return (
    <button
      {...rest}
      ref={boton}
      type="button"
      aria-label={label}
      aria-busy={loading || undefined}
      aria-describedby={descripcion}
      disabled={inerte}
      className={cx('ay-iconbtn', `ay-iconbtn--${variant}`, `ay-iconbtn--${tamano}`)}
      onPointerEnter={(evento) => {
        onPointerEnter?.(evento)
        // Volver desde el tooltip (que es descendiente) no reinicia el retardo.
        if (abierto) clearTimeout(temporizador.current)
        else programar(() => setAbierto(true), RETARDO_TOOLTIP)
      }}
      onPointerLeave={(evento) => {
        onPointerLeave?.(evento)
        programar(cerrar, TOLERANCIA_TOOLTIP)
      }}
      onFocus={(evento) => {
        onFocus?.(evento)
        // Con teclado aparece de inmediato; el foco de un clic ya lo programó el puntero.
        if (enfoqueDeTeclado(evento.currentTarget)) {
          clearTimeout(temporizador.current)
          setAbierto(true)
        }
      }}
      onBlur={(evento) => {
        onBlur?.(evento)
        cerrar()
      }}
    >
      {loading ? (
        <GiroDeCarga tamano="sm" clase="ay-iconbtn__glyph" />
      ) : (
        <span className="ay-iconbtn__glyph" aria-hidden="true">
          {icon}
        </span>
      )}
      {visible && (
        <span
          ref={burbuja}
          id={idTooltip}
          role="tooltip"
          className={cx('ay-tooltip', `ay-tooltip--${posicion?.lado ?? 'top'}`)}
          style={posicion ? { top: posicion.top, left: posicion.left } : { visibility: 'hidden' }}
          // El tooltip vive dentro del botón: un clic sobre su texto no es una activación.
          onClick={(evento) => {
            evento.preventDefault()
            evento.stopPropagation()
          }}
        >
          {tooltip}
        </span>
      )}
    </button>
  )
})

/** `:focus-visible` distingue el foco de teclado del de un clic; sin soporte, se asume teclado. */
function enfoqueDeTeclado(elemento: HTMLElement): boolean {
  try {
    return elemento.matches(':focus-visible')
  } catch {
    return true
  }
}

import {
  forwardRef,
  useCallback,
  useEffect,
  useId,
  useImperativeHandle,
  useLayoutEffect,
  useRef,
  useState,
} from 'react'
import type { HTMLAttributes, KeyboardEvent } from 'react'
import { areaVisible, cx } from '../../utiles.js'
import { anclarEnCapaSuperior } from '../surfaces/_capa.js'
import { Button } from './Button.js'
import type { ButtonSize } from './Button.js'
import { ButtonGroup } from './ButtonGroup.js'
import { GiroDeCarga, IconoChevronAbajo } from './_iconos.js'

/** Apariencia del conjunto de un SplitButton. */
export type SplitButtonVariant = 'primary' | 'secondary'
/** Qué mitad de un SplitButton está ejecutando: ninguna, la principal o la del menú. */
export type SplitButtonLoading = false | 'main' | 'menu'

/** Una variante del menú de un SplitButton. */
export interface SplitButtonItem {
  /** Identificador estable: es lo que recuerda `rememberLast`. */
  id: string
  /** Rótulo, escrito como variante de la acción principal: «Guardar y cerrar». */
  label: string
  /** Ejecuta la variante. */
  onSelect: () => void
  /** Marca la opción peligrosa. Vive en el menú, nunca en la mitad principal. */
  danger?: boolean
}

export interface PropsSplitButton extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'children'> {
  /** Rótulo de la acción principal. Nombra la acción dominante, no la categoría:
   *  «Guardar», no «Opciones de guardado». */
  label: string
  /** Ejecuta la acción principal, la que se pulsa sin abrir nada. */
  onAction: () => void
  /** Variantes del menú, de dos a tres. Con una sola el componente se degrada a un
   *  ButtonGroup spaced con los dos botones a la vista; sin ninguna, a un Button. */
  items?: SplitButtonItem[]
  /** Nombre accesible del disparador y del menú; repite la acción: «Más opciones de
   *  guardado», nunca «Más». Si falta se deriva del rótulo. */
  menuLabel?: string
  /** Apariencia del conjunto: `primary` para la acción dominante de la vista, una por
   *  pantalla; `secondary` para una acción frecuente que no es la principal. */
  variant?: SplitButtonVariant
  /** Altura de las dos mitades; el disparador es siempre cuadrado. */
  size?: ButtonSize
  /** Qué mitad está ejecutando. Esa mitad muestra su carga y las dos quedan inertes,
   *  para que una segunda pulsación no dispare la acción dos veces; el conjunto expone
   *  `aria-busy`. */
  loading?: SplitButtonLoading
  /** Deshabilita las dos mitades a la vez: una mitad activa junto a otra apagada se lee
   *  como un fallo de la interfaz. */
  disabled?: boolean
  /** La mitad principal adopta la última variante elegida y lo dice en su rótulo. Si esa
   *  variante deja de estar en `items`, vuelve a la acción por omisión. */
  rememberLast?: boolean
}

/**
 * La acción más probable, pulsable de una vez, con sus variantes en un menú adjunto.
 * Son dos botones y dos paradas de tabulación: se puede ejecutar la principal sin abrir
 * el menú. El disparador declara `aria-haspopup="menu"` y `aria-expanded`; las opciones
 * son `menuitem` —cada una ejecuta, ninguna selecciona un valor—, y la que ya hace la
 * mitad principal lo dice en su nombre accesible. Flecha abajo y arriba abren el menú
 * desde el disparador y lo recorren con retorno circular; Inicio y Fin van a los
 * extremos; Escape lo cierra y devuelve el foco al disparador; Tab lo cierra y sigue.
 */
export const SplitButton = forwardRef<HTMLDivElement, PropsSplitButton>(function SplitButton(
  {
    label,
    onAction,
    items = [],
    menuLabel,
    variant = 'primary',
    size = 'md',
    loading = false,
    disabled = false,
    rememberLast = false,
    ...rest
  },
  ref,
) {
  const [abierto, setAbierto] = useState(false)
  const [activo, setActivo] = useState(0)
  const [ultima, setUltima] = useState<string | null>(null)
  const [volteo, setVolteo] = useState({ arriba: false, inicio: false })
  const raiz = useRef<HTMLDivElement | null>(null)
  const disparador = useRef<HTMLButtonElement | null>(null)
  const menu = useRef<HTMLDivElement | null>(null)
  const opciones = useRef<(HTMLButtonElement | null)[]>([])
  const idMenu = useId()
  useImperativeHandle(ref, () => raiz.current as HTMLDivElement)

  // Las dos mitades se apagan juntas: media pieza activa se lee como un fallo.
  const inerte = disabled || loading !== false
  // Si la variante recordada desaparece, se vuelve a la de por omisión en lugar de dejar
  // la mitad principal apuntando a algo que ya no existe.
  const principal = rememberLast ? (items.find((it) => it.id === ultima) ?? null) : null
  const rotulo = principal?.label ?? label
  const nombreMenu = menuLabel ?? `Más opciones de ${label.toLowerCase()}`

  const cerrar = useCallback((devolverFoco: boolean) => {
    setAbierto(false)
    setVolteo({ arriba: false, inicio: false })
    // El foco vuelve al disparador: mandarlo al principio obligaría a recorrer la página
    // entera para seguir donde se estaba.
    if (devolverFoco) disparador.current?.focus()
  }, [])

  const abrir = (indice: number) => {
    setActivo(indice)
    setAbierto(true)
  }

  // Abrir o mover el activo lleva el foco a esa opción (foco itinerante).
  useEffect(() => {
    if (abierto) opciones.current[activo]?.focus()
  }, [abierto, activo])

  // Un menú abierto mientras el conjunto pasa a inerte se cierra con él.
  useEffect(() => {
    if (inerte && abierto) cerrar(false)
  }, [inerte, abierto, cerrar])

  // Un clic fuera del conjunto cierra el menú sin robar el foco a donde fue.
  useEffect(() => {
    if (!abierto) return
    const alPulsar = (evento: PointerEvent) => {
      if (raiz.current && !raiz.current.contains(evento.target as Node)) cerrar(false)
    }
    document.addEventListener('pointerdown', alPulsar)
    return () => document.removeEventListener('pointerdown', alPulsar)
  }, [abierto, cerrar])

  // Abierto, el menú sube a la capa superior junto al conjunto, alineado a su borde final y
  // como poco de su ancho: allí no lo tapa una Navbar o un Banner pegajoso, ni lo recorta el
  // overflow de una tarjeta. Antes del volteo, que lo mide, y del foco, que entra en una
  // opción. Sin la API sigue anclado con la hoja.
  useLayoutEffect(() => {
    if (!abierto || !raiz.current || !menu.current) return
    return anclarEnCapaSuperior(menu.current, raiz.current, {
      alineacion: 'fin',
      separacion: '--aybar-space-1',
      ancho: 'minimo',
    })
  }, [abierto])

  // El menú se alinea al borde final y voltea al de inicio si no cabe; cerca del borde
  // inferior de la ventana se abre hacia arriba, conservando el orden de las opciones.
  useLayoutEffect(() => {
    if (!abierto || !raiz.current || !menu.current) return
    const conjunto = raiz.current.getBoundingClientRect()
    const caja = menu.current.getBoundingClientRect()
    // El área útil, sin las barras de scroll: con innerWidth el menú pegado al borde
    // derecho quedaba encima de la barra vertical.
    const { ancho, alto } = areaVisible()
    setVolteo({
      arriba: conjunto.bottom + caja.height > alto && conjunto.top - caja.height >= 0,
      inicio: caja.left < 0 || caja.right > ancho,
    })
  }, [abierto])

  const elegir = (item: SplitButtonItem) => {
    setUltima(item.id)
    item.onSelect?.()
    cerrar(true)
  }

  const navegar = (evento: KeyboardEvent<HTMLElement>) => {
    const ultimo = items.length - 1
    switch (evento.key) {
      case 'ArrowDown':
        evento.preventDefault()
        if (!abierto) abrir(0)
        else setActivo((i) => (i === ultimo ? 0 : i + 1))
        break
      case 'ArrowUp':
        evento.preventDefault()
        if (!abierto) abrir(ultimo)
        else setActivo((i) => (i === 0 ? ultimo : i - 1))
        break
      case 'Home':
        if (!abierto) break
        evento.preventDefault()
        setActivo(0)
        break
      case 'End':
        if (!abierto) break
        evento.preventDefault()
        setActivo(ultimo)
        break
      case 'Escape':
        // Cerrado, Escape es del overlay que contenga el conjunto.
        if (!abierto) break
        evento.preventDefault()
        evento.stopPropagation()
        cerrar(true)
        break
      case 'Tab':
        // Se cierra y el foco sigue su curso al siguiente control de la página.
        if (abierto) cerrar(false)
        break
    }
  }

  // ── Degradaciones de la ficha ─────────────────────────────────────────────
  // Un menú de un solo elemento es una pulsación de más: Button Group spaced con las
  // dos acciones a la vista. Sin variantes, es una acción sola: Button.
  if (items.length === 0) {
    return (
      <Button variant={variant} size={size} loading={loading === 'main'} disabled={disabled} onClick={() => onAction?.()}>
        {label}
      </Button>
    )
  }
  const unica = items.length === 1 ? items[0] : undefined
  if (unica) {
    return (
      <ButtonGroup {...rest} ref={raiz} attachment="spaced" size={size} label={nombreMenu} aria-busy={loading !== false || undefined}>
        <Button variant={variant} loading={loading === 'main'} disabled={inerte && loading !== 'main'} onClick={() => onAction?.()}>
          {label}
        </Button>
        <Button
          variant={unica.danger ? 'danger' : 'secondary'}
          loading={loading === 'menu'}
          disabled={inerte && loading !== 'menu'}
          onClick={() => unica.onSelect?.()}
        >
          {unica.label}
        </Button>
      </ButtonGroup>
    )
  }

  return (
    <div
      {...rest}
      ref={raiz}
      className={cx('ay-split', `ay-split--${variant}`, `ay-split--${size}`)}
      aria-busy={loading !== false || undefined}
    >
      <button
        type="button"
        className="ay-split__main"
        disabled={inerte}
        onClick={() => {
          // Con el menú abierto, se cierra y se ejecuta sin pedir confirmación extra.
          if (abierto) cerrar(false)
          if (principal) principal.onSelect?.()
          else onAction?.()
        }}
      >
        {loading === 'main' && <GiroDeCarga tamano="sm" />}
        <span className="ay-split__label">{rotulo}</span>
      </button>

      <button
        ref={disparador}
        type="button"
        className="ay-split__toggle"
        aria-label={nombreMenu}
        aria-haspopup="menu"
        aria-expanded={abierto}
        aria-controls={idMenu}
        disabled={inerte}
        onClick={() => (abierto ? cerrar(false) : abrir(0))}
        onKeyDown={navegar}
      >
        {loading === 'menu' ? <GiroDeCarga tamano="sm" /> : <IconoChevronAbajo />}
      </button>

      <div
        ref={menu}
        id={idMenu}
        role="menu"
        aria-label={nombreMenu}
        hidden={!abierto}
        className={cx('ay-split__menu', volteo.arriba && 'ay-split__menu--up', volteo.inicio && 'ay-split__menu--start')}
        onKeyDown={navegar}
      >
        {items.map((item, indice) => (
          <button
            key={item.id}
            ref={(elemento) => {
              opciones.current[indice] = elemento
            }}
            type="button"
            role="menuitem"
            tabIndex={indice === activo ? 0 : -1}
            className={cx('ay-split__item', item.danger && 'ay-split__item--danger')}
            onClick={() => elegir(item)}
          >
            {item.label}
            {/* Cuál hace ya la mitad principal se dice en el nombre, no con un estado
                aria-checked que se quedaría clavado en la primera opción. */}
            {(principal ? item.id === principal.id : item.label === label) && (
              <span className="ay-visually-hidden"> — lo que hace el botón</span>
            )}
          </button>
        ))}
      </div>
    </div>
  )
})

import { forwardRef } from 'react'
import type { AnchorHTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import { IconoDescarga, IconoExterno } from './_iconos.js'

/** Tratamiento visual de un enlace. */
export type LinkVariant = 'inline' | 'standalone' | 'inverse' | 'quiet'

export interface PropsLink extends Omit<AnchorHTMLAttributes<HTMLAnchorElement>, 'className' | 'download'> {
  /** Tratamiento visual. `inline` va dentro de un párrafo con subrayado permanente,
   *  porque el color solo no señala el enlace; `standalone` va fuera de texto corrido y
   *  subraya al hover; `inverse` es para superficie de marca y conserva el subrayado;
   *  `quiet` es para listas densas donde el subrayado permanente sería ruido. */
  variant?: LinkVariant
  /** Abre en pestaña nueva: añade `target="_blank"`, suma `noopener noreferrer` al `rel`
   *  que traiga el enlace sin pisarlo, y lo anuncia con el icono de dirección y con un
   *  texto que oye el lector de pantalla. */
  external?: boolean
  /** Descarga en lugar de navegar. `true` descarga con el nombre del servidor; una cadena
   *  propone el nombre del archivo. Se anuncia igual que el destino externo, y el texto
   *  del enlace indica formato y peso cuando el archivo es grande. */
  download?: boolean | string
}

/** Lo que una pestaña nueva exige en `rel`: sin `noopener`, la página abierta controla
 *  a esta por `window.opener`; sin `noreferrer`, se lleva la URL de origen. */
const REL_EXTERNO = ['noopener', 'noreferrer']

/**
 * El `rel` de un enlace externo: el del consumidor, más lo que falte de `REL_EXTERNO`.
 * Se combina y no se reemplaza porque un `rel` propio dice algo que el enlace necesita
 * —`external`, `nofollow`, `license`— y pisarlo lo borraría en silencio.
 */
function relExterno(rel: string | undefined): string {
  const valores = (rel ?? '').split(/\s+/).filter(Boolean)
  const presentes = new Set(valores.map((v) => v.toLowerCase()))
  return [...valores, ...REL_EXTERNO.filter((v) => !presentes.has(v))].join(' ')
}

/**
 * Navega a otra URL, ancla o documento: es el único control de Actions que cambia de
 * ubicación en lugar de producir un efecto. Es siempre un `a` nativo —un `div` con
 * `onClick` no se anuncia como enlace ni deja «abrir en pestaña nueva»—. Sin `href` no
 * es un enlace: con `aria-disabled="true"` el destino se retira, queda `role="link"`
 * para que siga anunciándose y deja de ser navegable.
 */
export const Link = forwardRef<HTMLAnchorElement, PropsLink>(function Link(
  { variant = 'inline', external = false, download = false, href, target, rel, role, children, ...rest },
  ref,
) {
  const deshabilitado = rest['aria-disabled'] === true || rest['aria-disabled'] === 'true'
  // Sin destino no hay nada que descargar: un enlace deshabilitado tampoco lo anuncia.
  const descarga = deshabilitado || download === false ? undefined : download === true ? '' : download
  return (
    <a
      {...rest}
      ref={ref}
      href={deshabilitado ? undefined : href}
      role={deshabilitado ? 'link' : role}
      target={external ? '_blank' : target}
      rel={external ? relExterno(rel) : rel}
      download={descarga}
      // `inline` es el enlace base: la definición canónica no le añade modificador.
      className={cx('ay-link', variant !== 'inline' && `ay-link--${variant}`)}
    >
      {children}
      {/* La señal de pestaña nueva o descarga es para quien ve y para quien oye: el
          icono va aria-hidden y el texto oculto es lo que anuncia el lector. */}
      {external ? <IconoExterno /> : descarga !== undefined && <IconoDescarga />}
      {external && <span className="ay-visually-hidden"> (abre en una pestaña nueva)</span>}
      {descarga !== undefined && <span className="ay-visually-hidden"> (descarga)</span>}
    </a>
  )
})

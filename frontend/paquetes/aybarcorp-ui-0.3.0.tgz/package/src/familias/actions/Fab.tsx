import { forwardRef } from 'react'
import type { ButtonHTMLAttributes, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { GiroDeCarga } from './_iconos.js'

/** Par de color de un FAB. */
export type FabIntent = 'accent' | 'primary'
/** Diámetro de un FAB: 48 en `md`, 56 en `lg`. */
export type FabSize = 'md' | 'lg'

export interface PropsFab
  extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'className' | 'aria-label' | 'type' | 'children'> {
  /** Glifo. Obligatorio, inequívoco y decorativo: se marca `aria-hidden`. */
  icon: ReactNode
  /** Nombre accesible, obligatorio: en la variante circular es el `aria-label` y nombra la
   *  acción completa («Registrar nueva unidad»); en la extendida es texto visible, de dos
   *  palabras como máximo, y hace de nombre sin repetirse en `aria-label`. */
  label: string
  /** Muestra la etiqueta junto al icono, para cuando el glifo solo no comunica la acción. */
  extended?: boolean
  /** Par de color. `accent` es la mandarina de marca con texto petróleo, la presentación
   *  por defecto; `primary` cuando el acento ya está ocupado en la vista. */
  intent?: FabIntent
  /** Diámetro: `lg` (56) es el tamaño por defecto en móvil; `md` (48) en tablet o listas
   *  compactas. */
  size?: FabSize
  /** Implica disabled y expone `aria-busy`; el spinner sustituye al icono. */
  loading?: boolean
}

/**
 * Acción constructiva principal de una vista en móvil, flotando sobre el contenido con
 * inset lógico y safe-area. Un único FAB por vista, nunca para una acción destructiva, y
 * al final del contenido principal en el DOM para no interrumpir la lectura. Sin
 * permiso para crear se oculta en lugar de mostrarse deshabilitado; en desktop la acción
 * pasa al Header como Button primary.
 */
export const Fab = forwardRef<HTMLButtonElement, PropsFab>(function Fab(
  { icon, label, extended = false, intent = 'accent', size = 'lg', loading = false, disabled, ...rest },
  ref,
) {
  return (
    <button
      {...rest}
      ref={ref}
      type="button"
      aria-label={extended ? undefined : label}
      aria-busy={loading || undefined}
      disabled={disabled || loading}
      className={cx('ay-fab', `ay-fab--${intent}`, `ay-fab--${size}`, extended && 'ay-fab--extended')}
    >
      {loading ? (
        <GiroDeCarga tamano="md" clase="ay-fab__icon" />
      ) : (
        <span className="ay-fab__icon" aria-hidden="true">
          {icon}
        </span>
      )}
      {extended && <span className="ay-fab__label">{label}</span>}
    </button>
  )
})

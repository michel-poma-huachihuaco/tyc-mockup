/**
 * Glifos propios de la familia Actions. No se exportan desde el índice: no son API.
 *
 * Todos son decorativos y llevan `aria-hidden`: el nombre accesible lo da siempre la
 * etiqueta o el `aria-label` del control, nunca el SVG. El tamaño lo pone la hoja
 * (`--button-glyph`), no el SVG, para que siga a la densidad.
 */
import { cx } from '../../utiles.js'

/**
 * Marcado canónico de Spinner (familia Feedback) dentro de un control: el arco con
 * `aria-hidden` y SIN texto oculto. Dentro de un botón, el estado lo anuncia el
 * `aria-busy` del botón y la etiqueta no cambia: un «Cargando» oculto aquí entraría en el
 * nombre accesible del botón y lo reanunciaría. Se pinta en esta familia en lugar de
 * importar el Spinner de Feedback para que Actions no dependa de otra familia.
 */
export function GiroDeCarga({ tamano, clase }: { tamano: 'sm' | 'md'; clase?: string }) {
  return (
    <svg
      className={cx('ay-spinner', `ay-spinner--${tamano}`, 'ay-spinner--on-color', clase)}
      viewBox="0 0 24 24"
      aria-hidden="true"
      focusable="false"
    >
      <circle className="ay-spinner__track" cx="12" cy="12" r="9" />
      <circle className="ay-spinner__arc" cx="12" cy="12" r="9" />
    </svg>
  )
}

/** Chevron del disparador de Split Button. */
export function IconoChevronAbajo() {
  return (
    <svg className="ay-split__chevron" width="16" height="16" viewBox="0 0 16 16" aria-hidden="true" focusable="false">
      <path d="M4 6l4 4 4-4" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

/** Flecha de destino externo de Link: indica pestaña nueva. */
export function IconoExterno() {
  return (
    <svg className="ay-link__icon" width="12" height="12" viewBox="0 0 12 12" aria-hidden="true" focusable="false">
      <path
        d="M5 2.5H2.5v7h7V7M7 1.5h3.5V5M10.5 1.5 5.5 6.5"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

/** Flecha de descarga de Link. */
export function IconoDescarga() {
  return (
    <svg className="ay-link__icon" width="12" height="12" viewBox="0 0 12 12" aria-hidden="true" focusable="false">
      <path
        d="M6 1.5v6M3.5 5 6 7.5 8.5 5M2 10.5h8"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

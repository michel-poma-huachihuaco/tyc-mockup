import { forwardRef, useEffect, useMemo, useRef, useState } from 'react'
import type { CSSProperties, HTMLAttributes, KeyboardEvent as EventoTeclado } from 'react'
import { cx } from '../../utiles.js'
import { IconoChevron, SpinnerPequeno } from './_iconos.js'
import { normalizar, useControlable } from './_internos.js'

/** Nodo del árbol: una torre, un piso, una unidad. */
export interface TreeNode {
  id: string
  /** Nombre de la entidad, no de su tipo: «Torre A», no «Nodo torre». */
  label: string
  /** Metadato corto, alineado al final: «12 unidades», «118 m²». */
  meta?: string
  children?: TreeNode[]
  /** Rama con carga diferida aún sin abrir: tiene hijos aunque `children` venga vacío. */
  hasChildren?: boolean
}

export type TreeViewMode = 'navigation' | 'multi' | 'read-only'
export type TreeViewSize = 'sm' | 'md'

export interface PropsTreeView extends Omit<HTMLAttributes<HTMLUListElement>, 'className'> {
  /** Raíces del árbol. Sin nodos se muestra el estado vacío (los `children` del
   *  componente, que deben explicar la causa). */
  nodes?: TreeNode[]
  /** Ramas abiertas. Si se omite, el árbol lleva las suyas (empieza plegado). */
  expandedIds?: string[]
  /** Cambio de ramas abiertas. */
  onExpandedChange?: (ids: string[]) => void
  /** Nodos elegidos. Si se omite, el árbol lleva su propia selección. */
  selectedIds?: string[]
  /** Cambio de selección: en `navigation`, el nodo activado con Enter o clic; en `multi`,
   *  las casillas marcadas (una rama marca a todos sus descendientes cargados). */
  onSelectedChange?: (ids: string[]) => void
  /** Qué hace la selección: `navigation` elige un nodo y la vista cambia; `multi` usa
   *  casillas con estado mixto; `read-only` muestra la jerarquía sin selección. */
  mode?: TreeViewMode
  /** Carga diferida de una rama al abrirla por primera vez. Si falla, solo esa rama marca
   *  el error con su reintento; el resto del árbol sigue usable. */
  loadChildren?: (id: string) => Promise<TreeNode[]>
  /** Filtra: deja solo las ramas con coincidencias, abiertas hasta ellas, y anuncia
   *  cuántas encontró. */
  filter?: string
  /** Muestra el metadato de cada nodo (el recuento de descendientes). */
  showCount?: boolean
  /** Altura de fila. También en `sm` llega al objetivo táctil mínimo. */
  size?: TreeViewSize
}

type EstadoCasilla = boolean | 'mixed'

interface NodoPlano {
  id: string
  label: string
  meta?: string
  level: number
  parentId?: string
  esRama: boolean
  abierta: boolean
  posinset: number
  setsize: number
  nodo: TreeNode
  /** Pseudonodo «Reintentar» bajo una rama que no cargó. */
  reintentoDe?: string
}

const SUFIJO_REINTENTO = '::reintentar'

/**
 * La jerarquía de una promoción —torre, piso, unidad— que se recorre, se pliega y se
 * selecciona sin perder de vista dónde está cada cosa. Es un solo punto de tabulación con
 * roving tabindex: la flecha derecha abre y baja, la izquierda cierra y sube, como en un
 * explorador de archivos. Cada nodo declara `aria-level` y `aria-expanded`, y la selección
 * parcial de una rama es `aria-checked="mixed"`.
 */
export const TreeView = forwardRef<HTMLUListElement, PropsTreeView>(function TreeView(
  {
    nodes = [],
    expandedIds,
    onExpandedChange,
    selectedIds,
    onSelectedChange,
    mode = 'navigation',
    loadChildren,
    filter,
    showCount = false,
    size = 'md',
    'aria-label': etiqueta = 'Unidades',
    children,
    onKeyDown,
    ...resto
  },
  ref,
) {
  const raices = nodes ?? []
  const [abiertasLista, cambiarAbiertas] = useControlable<string[]>(expandedIds, [], onExpandedChange)
  const [elegidasLista, cambiarElegidas] = useControlable<string[]>(selectedIds, [], onSelectedChange)
  const [cargados, setCargados] = useState<Record<string, TreeNode[]>>({})
  const [errores, setErrores] = useState<Record<string, string>>({})
  const [cargando, setCargando] = useState<string | null>(null)
  const [aviso, setAviso] = useState('')
  const [activoId, setActivoId] = useState<string | null>(null)
  const elementos = useRef(new Map<string, HTMLLIElement>())
  const enfocar = useRef(false)

  const abiertas = useMemo(() => new Set(abiertasLista), [abiertasLista])
  const elegidas = useMemo(() => new Set(elegidasLista), [elegidasLista])
  const consulta = filter ? normalizar(filter) : ''

  const hijosDe = (n: TreeNode): TreeNode[] | undefined => (n.children?.length ? n.children : cargados[n.id])
  const esRamaNodo = (n: TreeNode) => Boolean(hijosDe(n)?.length) || Boolean(n.hasChildren)

  // Coincidencias del filtro por subárbol (el propio nodo incluido).
  const coincidencias = useMemo(() => {
    const mapa = new Map<string, number>()
    if (!consulta) return mapa
    const contar = (n: TreeNode): number => {
      const propias = normalizar(n.label).includes(consulta) ? 1 : 0
      const total = (hijosDe(n) ?? []).reduce((suma, h) => suma + contar(h), propias)
      mapa.set(n.id, total)
      return total
    }
    raices.forEach(contar)
    return mapa
    // eslint-disable-next-line react-hooks/exhaustive-deps -- hijosDe depende de `cargados`
  }, [raices, consulta, cargados])

  // Solo los nodos visibles entran en el recorrido: lo plegado no se navega.
  const visibles = useMemo(() => {
    const plano: NodoPlano[] = []
    const recorrer = (lista: TreeNode[], nivel: number, padre?: string) => {
      const incluidos = consulta ? lista.filter((n) => (coincidencias.get(n.id) ?? 0) > 0) : lista
      incluidos.forEach((n, i) => {
        const hijos = hijosDe(n)
        const esRama = esRamaNodo(n)
        const propias = consulta && normalizar(n.label).includes(consulta) ? 1 : 0
        const debajo = consulta ? (coincidencias.get(n.id) ?? 0) - propias : 0
        // Con filtro, las ramas se abren hasta las coincidencias.
        const abierta = esRama && (debajo > 0 || abiertas.has(n.id))
        const meta = errores[n.id]
          ? 'no cargó'
          : cargando === n.id
            ? 'cargando…'
            : consulta && debajo > 0
              ? `${debajo} ${debajo === 1 ? 'coincidencia' : 'coincidencias'}`
              : n.meta
        plano.push({
          id: n.id,
          label: n.label,
          meta,
          level: nivel,
          parentId: padre,
          esRama,
          abierta,
          posinset: i + 1,
          setsize: incluidos.length,
          nodo: n,
        })
        if (!abierta) return
        if (errores[n.id]) {
          plano.push({
            id: `${n.id}${SUFIJO_REINTENTO}`,
            label: 'Reintentar',
            level: nivel + 1,
            parentId: n.id,
            esRama: false,
            abierta: false,
            posinset: 1,
            setsize: 1,
            nodo: n,
            reintentoDe: n.id,
          })
        } else if (hijos?.length) {
          recorrer(hijos, nivel + 1, n.id)
        }
      })
    }
    recorrer(raices, 1)
    return plano
    // eslint-disable-next-line react-hooks/exhaustive-deps -- hijosDe depende de `cargados`
  }, [raices, abiertas, consulta, coincidencias, cargados, errores, cargando])

  const indiceActivo = Math.max(
    0,
    visibles.findIndex((v) => v.id === activoId) >= 0
      ? visibles.findIndex((v) => v.id === activoId)
      : visibles.findIndex((v) => elegidas.has(v.id)),
  )
  const activo = visibles[indiceActivo]

  // El foco sigue a la celda activa solo cuando el movimiento lo pidió el teclado.
  useEffect(() => {
    if (!enfocar.current || !activo) return
    enfocar.current = false
    elementos.current.get(activo.id)?.focus()
  })

  // El filtro dice cuántas coincidencias encontró: un árbol que encoge sin explicación se
  // lee como datos perdidos.
  const filtroPrevio = useRef(filter)
  useEffect(() => {
    if (filtroPrevio.current === filter) return
    filtroPrevio.current = filter
    if (!filter) return setAviso('Se muestra el árbol completo')
    let total = 0
    for (const n of raices) total += coincidencias.get(n.id) ?? 0
    setAviso(
      total === 0
        ? `Sin coincidencias para «${filter}»`
        : `${total} ${total === 1 ? 'coincidencia' : 'coincidencias'} para «${filter}»`,
    )
  }, [filter, raices, coincidencias])

  const descendientes = (n: TreeNode): TreeNode[] => {
    const lista: TreeNode[] = []
    const bajar = (m: TreeNode) => (hijosDe(m) ?? []).forEach((h) => (lista.push(h), bajar(h)))
    bajar(n)
    return lista
  }

  // «Algunos descendientes elegidos» es un tercer estado real, no un a medio camino visual.
  const estadoCasilla = (n: TreeNode): EstadoCasilla => {
    const hojas = descendientes(n).filter((d) => !esRamaNodo(d))
    if (hojas.length === 0) return elegidas.has(n.id)
    const marcadas = hojas.filter((h) => elegidas.has(h.id)).length
    if (marcadas === hojas.length) return true
    return marcadas === 0 ? false : 'mixed'
  }

  const alternar = (n: TreeNode) => {
    const todos = [n, ...descendientes(n)].map((d) => d.id)
    const siguiente = new Set(elegidas)
    if (estadoCasilla(n) === true) todos.forEach((id) => siguiente.delete(id))
    else {
      todos.forEach((id) => siguiente.add(id))
      // No se finge que lo no cargado ya está elegido: se dice que entrará al abrirlo.
      if (n.hasChildren && !hijosDe(n)?.length) {
        setAviso(`Se incluirá el contenido de ${n.label} al abrirla`)
      }
    }
    cambiarElegidas([...siguiente])
  }

  const cargar = async (n: TreeNode) => {
    if (!loadChildren) return
    setCargando(n.id)
    setErrores(({ [n.id]: _, ...resto }) => resto)
    setAviso(`Cargando ${n.label}…`)
    try {
      const hijos = await loadChildren(n.id)
      setCargados((previos) => ({ ...previos, [n.id]: hijos ?? [] }))
      setAviso(`${hijos?.length ?? 0} elementos en ${n.label}.`)
    } catch {
      // El error es de esta rama; el resto del árbol sigue usable. El foco no se mueve.
      setErrores((previos) => ({ ...previos, [n.id]: 'no cargó' }))
      setAviso(`No hemos podido cargar el contenido de ${n.label}.`)
    } finally {
      setCargando(null)
    }
  }

  const abrir = (n: NodoPlano) => {
    const nuevas = new Set(abiertas)
    nuevas.add(n.id)
    // Una cadena de hijos únicos se abre de una vez: abrir cuatro veces para llegar a un
    // único descendiente es trabajo sin información.
    let cadena = hijosDe(n.nodo)
    while (cadena?.length === 1 && cadena[0] && esRamaNodo(cadena[0])) {
      nuevas.add(cadena[0].id)
      cadena = hijosDe(cadena[0])
    }
    cambiarAbiertas([...nuevas])
    if (n.nodo.hasChildren && !hijosDe(n.nodo)?.length) void cargar(n.nodo)
  }
  const cerrar = (n: NodoPlano) => cambiarAbiertas(abiertasLista.filter((id) => id !== n.id))
  const conmutar = (n: NodoPlano) => (n.abierta ? cerrar(n) : abrir(n))

  const activar = (n: NodoPlano) => {
    if (n.reintentoDe) return void cargar(n.nodo)
    if (mode === 'navigation') cambiarElegidas([n.id])
    else if (mode === 'multi') alternar(n.nodo)
    else if (n.esRama) conmutar(n)
  }

  const mover = (id: string | undefined) => {
    if (!id) return
    enfocar.current = true
    setActivoId(id)
  }

  const navegar = (evento: EventoTeclado<HTMLUListElement>) => {
    onKeyDown?.(evento)
    if (evento.defaultPrevented || !activo) return
    const ultimo = visibles.length - 1
    switch (evento.key) {
      case 'ArrowDown':
        evento.preventDefault()
        mover(visibles[Math.min(indiceActivo + 1, ultimo)]?.id)
        break
      case 'ArrowUp':
        evento.preventDefault()
        mover(visibles[Math.max(indiceActivo - 1, 0)]?.id)
        break
      case 'ArrowRight':
        evento.preventDefault()
        if (!activo.esRama) return
        if (activo.abierta) mover(visibles[Math.min(indiceActivo + 1, ultimo)]?.id)
        else abrir(activo)
        break
      case 'ArrowLeft':
        evento.preventDefault()
        if (activo.esRama && activo.abierta && !consulta) cerrar(activo)
        else if (activo.parentId) mover(activo.parentId)
        break
      case 'Home':
        evento.preventDefault()
        mover(visibles[0]?.id)
        break
      case 'End':
        evento.preventDefault()
        mover(visibles[ultimo]?.id)
        break
      case ' ':
        if (mode !== 'multi' || activo.reintentoDe) return
        evento.preventDefault()
        alternar(activo.nodo)
        break
      case 'Enter':
        evento.preventDefault()
        activar(activo)
        break
      default: {
        // Escribir una letra salta al siguiente nodo visible que empieza por ella.
        if (evento.key.length !== 1 || evento.ctrlKey || evento.metaKey || evento.altKey) return
        const letra = normalizar(evento.key)
        const orden = [...visibles.slice(indiceActivo + 1), ...visibles.slice(0, indiceActivo + 1)]
        const destino = orden.find((v) => !v.reintentoDe && normalizar(v.label).startsWith(letra))
        if (destino) {
          evento.preventDefault()
          mover(destino.id)
        }
      }
    }
  }

  const avisos = (
    <p className="ay-visually-hidden" role="status" aria-live="polite">
      {aviso}
    </p>
  )

  if (visibles.length === 0) {
    return (
      <>
        <div className={cx('ay-tree', `ay-tree--${size}`, 'ay-tree--empty')}>
          <p className="ay-tree__empty">
            {consulta ? `Sin coincidencias para «${filter}»` : (children ?? 'No hay elementos que mostrar.')}
          </p>
        </div>
        {avisos}
      </>
    )
  }

  return (
    <>
      <ul
        {...resto}
        ref={ref}
        role="tree"
        aria-label={etiqueta}
        aria-multiselectable={mode === 'multi' || undefined}
        className={cx('ay-tree', `ay-tree--${size}`)}
        onKeyDown={navegar}
      >
        {visibles.map((n, i) => {
          const casilla = mode === 'multi' && !n.reintentoDe ? estadoCasilla(n.nodo) : undefined
          const elegido = mode === 'multi' ? casilla === true : elegidas.has(n.id)
          return (
            <li
              key={n.id}
              ref={(nodo) => {
                if (nodo) elementos.current.set(n.id, nodo)
                else elementos.current.delete(n.id)
              }}
              role="treeitem"
              aria-level={n.level}
              aria-setsize={n.setsize}
              aria-posinset={n.posinset}
              aria-expanded={n.esRama ? n.abierta : undefined}
              aria-selected={mode === 'navigation' && !n.reintentoDe ? elegidas.has(n.id) : undefined}
              aria-checked={casilla}
              aria-busy={cargando === n.id || undefined}
              tabIndex={i === indiceActivo ? 0 : -1}
              className={cx(elegido && 'is-selected', errores[n.id] && 'is-error', n.reintentoDe && 'ay-tree__retry')}
              style={{ '--nivel': n.level } as CSSProperties}
              onClick={(evento) => {
                evento.stopPropagation()
                setActivoId(n.id)
                activar(n)
              }}
            >
              <span className="ay-tree__row">
                {n.esRama ? (
                  <span
                    className="ay-tree__twisty"
                    aria-hidden="true"
                    onClick={(evento) => {
                      evento.stopPropagation()
                      setActivoId(n.id)
                      conmutar(n)
                    }}
                  >
                    {cargando === n.id ? <SpinnerPequeno /> : <IconoChevron direccion="derecha" />}
                  </span>
                ) : (
                  <span className="ay-tree__twisty ay-tree__twisty--leaf" aria-hidden="true" />
                )}
                {casilla !== undefined && (
                  <span className="ay-tree__check" data-estado={String(casilla)} aria-hidden="true" />
                )}
                <span className="ay-tree__label" title={n.label}>
                  {n.label}
                </span>
                {(showCount || errores[n.id] || cargando === n.id || consulta) && n.meta && (
                  <span className="ay-tree__meta">{n.meta}</span>
                )}
              </span>
            </li>
          )
        })}
      </ul>
      {avisos}
    </>
  )
})

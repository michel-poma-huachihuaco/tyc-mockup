import { Children, forwardRef, useMemo } from 'react'
import type { HTMLAttributes, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { IconoChevron } from './_iconos.js'
import { ContextoFila, useControlable } from './_internos.js'

export type TableRowStatus = 'default' | 'warning' | 'danger'

export interface PropsTableRow extends Omit<HTMLAttributes<HTMLTableRowElement>, 'className' | 'id'> {
  /** Identificador estable del registro. Da el id de la fila de detalle
   *  (`row-<id>-detail`), que es el destino de `aria-controls` del disparador. */
  id: string
  /** Nombre del registro para los controles: «la unidad 402». El checkbox dice
   *  «Seleccionar la unidad 402» y el disparador «Ver el detalle de la unidad 402». */
  rowLabel: string
  /** Estado de selección. Se refleja en `aria-selected` del `tr`, nunca en las celdas.
   *  Si se omite y hay `onSelectedChange`, la fila lleva su propio estado. */
  selected?: boolean
  /** Cambio de selección. Con él (o con `selected`) la fila pinta su celda de checkbox. */
  onSelectedChange?: (selected: boolean) => void
  /** Estado de expansión. Si se omite, la fila lo lleva por su cuenta. */
  expanded?: boolean
  /** Cambio de expansión. */
  onExpandedChange?: (expanded: boolean) => void
  /** Contenido del detalle: una fila adicional con `colspan` que crece con su contenido.
   *  Sin detalle, el disparador de expansión no se muestra. */
  detail?: ReactNode
  /** Destino cuando la fila navega. El enlace real va en la celda que identifica el
   *  registro (la Table Cell con `header`), no en toda la fila. */
  href?: string
  /** Marca lateral de estado. No es la única pista: el estado se escribe en una celda. */
  status?: TableRowStatus
  /** Fila guardando: `aria-busy` en el `tr` y sus controles deshabilitados, que son los que
   *  impiden pulsar dos veces (aria-busy solo difiere anuncios). */
  busy?: boolean
  /** Columnas que ocupa la fila de detalle. Si se omite, se cuentan las celdas de la fila. */
  colSpan?: number
}

/**
 * Un registro como fila, con sus estados de selección, expansión y guardado. Es la pieza
 * de Table y de Data Grid; suelta fuera de una tabla no tiene sentido.
 */
export const TableRow = forwardRef<HTMLTableRowElement, PropsTableRow>(function TableRow(
  {
    id,
    rowLabel,
    selected,
    onSelectedChange,
    expanded,
    onExpandedChange,
    detail,
    href,
    status = 'default',
    busy = false,
    colSpan,
    children,
    ...resto
  },
  ref,
) {
  const seleccionable = selected !== undefined || onSelectedChange !== undefined
  const expandible = detail !== undefined && detail !== null && detail !== false
  const [estaSeleccionada, cambiarSeleccion] = useControlable(selected, false, onSelectedChange)
  const [estaExpandida, cambiarExpansion] = useControlable(expanded, false, onExpandedChange)
  const idDetalle = `row-${id}-detail`
  const contexto = useMemo(() => ({ href }), [href])
  const columnas = colSpan ?? Children.count(children) + (seleccionable ? 1 : 0) + (expandible ? 1 : 0)

  return (
    <ContextoFila.Provider value={contexto}>
      <tr
        {...resto}
        ref={ref}
        className={cx(
          'ay-tr',
          estaSeleccionada && 'ay-tr--selected',
          status !== 'default' && `ay-tr--${status}`,
          href && 'ay-tr--link',
        )}
        aria-selected={seleccionable ? estaSeleccionada : undefined}
        aria-busy={busy || undefined}
      >
        {seleccionable && (
          <td className="ay-td ay-td--check">
            <input
              type="checkbox"
              className="ay-tr__check"
              checked={estaSeleccionada}
              disabled={busy}
              aria-label={`Seleccionar ${rowLabel}`}
              onChange={(evento) => cambiarSeleccion(evento.currentTarget.checked)}
            />
          </td>
        )}

        {children}

        {expandible && (
          <td className="ay-td ay-td--actions">
            <button
              type="button"
              className="ay-iconbtn ay-iconbtn--ghost ay-iconbtn--sm"
              aria-expanded={estaExpandida}
              aria-controls={idDetalle}
              aria-label={estaExpandida ? `Ocultar el detalle de ${rowLabel}` : `Ver el detalle de ${rowLabel}`}
              disabled={busy}
              onClick={() => cambiarExpansion(!estaExpandida)}
            >
              <IconoChevron direccion={estaExpandida ? 'arriba' : 'abajo'} />
            </button>
          </td>
        )}
      </tr>

      {expandible && (
        // El id es estable aunque esté plegada: es el destino de aria-controls.
        <tr id={idDetalle} className="ay-tr__detail" hidden={!estaExpandida}>
          <td colSpan={columnas}>{detail}</td>
        </tr>
      )}
    </ContextoFila.Provider>
  )
})

import { forwardRef, useMemo } from 'react'
import type { ForwardedRef, HTMLAttributes, ReactElement, ReactNode, Ref } from 'react'
import { cx } from '../../utiles.js'
import { IconoOrden } from './_iconos.js'
import { comparar, textoDeCelda, useControlable } from './_internos.js'
import { ariaSortDe } from './SortControl.js'

export type TableAlign = 'start' | 'end'
export type SortDirection = 'asc' | 'desc'

/** Orden activo de una tabla: la columna y el sentido. */
export interface TableSort {
  key: string
  dir: SortDirection
}

/** Una fila de Table: cualquier registro con un `id` estable. */
export interface TableRowData {
  id: string
}

/** Columna de Table. */
export interface TableColumn<T> {
  /** Campo del registro que pinta la columna. */
  key: keyof T & string
  /** Nombre del dato; la unidad va entre paréntesis: «Superficie (m²)». */
  header: string
  /** `end` para números, importes y fechas: se alinean al final con cifras tabulares. */
  align?: TableAlign
  /** Ancho declarado en rem o en porcentaje; nunca al azar del contenido. */
  width?: string
  /** Pinta el control de orden en la cabecera. */
  sortable?: boolean
  /** Contenido propio de la celda (un Badge, un enlace). Sin él se pinta el valor o un guion. */
  render?: (row: T) => ReactNode
}

export interface PropsTable<T extends TableRowData = TableRowData>
  extends Omit<HTMLAttributes<HTMLDivElement>, 'className'> {
  /** Columnas en orden: `key`, `header`, `align`, `width`, `sortable` y `render`. La
   *  primera identifica el registro y se pinta como `th scope="row"`. */
  columns?: TableColumn<T>[]
  /** Registros. Cada uno con un `id` estable. */
  rows?: T[]
  /** Nombre accesible de la tabla; obligatorio. Va en el `caption` y nombra la región de
   *  desplazamiento. Puede quedar oculto visualmente, pero no ausente. */
  caption: string
  /** Muestra el caption o lo deja solo para lectores de pantalla. */
  captionVisible?: boolean
  /** Orden activo. Si se omite, la tabla ordena sus filas por su cuenta al pulsar una cabecera. */
  sort?: TableSort
  /** Cambio de orden. Con `sort` controlado, el consumidor reordena (o pide al servidor). */
  onSortChange?: (sort: TableSort) => void
  /** La cabecera queda fija al desplazarse en vertical. */
  stickyHeader?: boolean
  /** Filas rayadas, para seguir la línea en tablas anchas. */
  striped?: boolean
  /** Contenido cuando no hay filas: un Empty State en una celda con `colspan` que ocupa la
   *  fila entera, conservando la cabecera. También sirve para las filas de Skeleton. */
  emptyState?: ReactNode
}

function TablaInterna<T extends TableRowData>(
  {
    columns = [],
    rows = [],
    caption,
    captionVisible = false,
    sort,
    onSortChange,
    stickyHeader = false,
    striped = false,
    emptyState,
    ...resto
  }: PropsTable<T>,
  ref: ForwardedRef<HTMLDivElement>,
) {
  const columnas = columns ?? []
  const registros = rows ?? []
  // Sin `sort` controlado, la tabla lleva su orden y reordena sola; controlado, el
  // consumidor decide (puede que el orden venga del servidor).
  const [orden, cambiarOrden] = useControlable<TableSort | undefined>(
    sort,
    undefined,
    onSortChange as ((orden: TableSort | undefined) => void) | undefined,
  )
  const controlado = sort !== undefined && sort !== null

  const visibles = useMemo(() => {
    if (controlado || !orden) return registros
    const copia = [...registros]
    copia.sort((a, b) => {
      const resultado = comparar(a[orden.key as keyof T], b[orden.key as keyof T])
      return orden.dir === 'asc' ? resultado : -resultado
    })
    return copia
  }, [registros, orden, controlado])

  return (
    <div className="ay-table__scroll" tabIndex={0} role="region" aria-label={caption} {...resto} ref={ref}>
      <table className={cx('ay-table', striped && 'ay-table--striped', stickyHeader && 'ay-table--sticky')}>
        <caption className={captionVisible ? 'ay-table__caption' : 'ay-visually-hidden'}>{caption}</caption>
        <thead>
          <tr>
            {columnas.map((c) => {
              const dir = orden?.key === c.key ? orden.dir : undefined
              return (
                <th
                  key={c.key}
                  scope="col"
                  style={c.width ? { inlineSize: c.width } : undefined}
                  className={c.align === 'end' ? 'ay-td--num' : undefined}
                  aria-sort={ariaSortDe(dir)}
                >
                  {c.sortable ? (
                    <button
                      type="button"
                      className={cx('ay-th__sort', c.align === 'end' && 'ay-th__sort--end')}
                      onClick={() =>
                        cambiarOrden({ key: c.key, dir: orden?.key === c.key && orden.dir === 'asc' ? 'desc' : 'asc' })
                      }
                    >
                      {c.header}
                      <IconoOrden dir={dir} className={cx('ay-sort__arrow', dir === undefined && 'ay-sort__arrow--idle')} />
                    </button>
                  ) : (
                    c.header
                  )}
                </th>
              )
            })}
          </tr>
        </thead>
        <tbody>
          {visibles.length === 0 ? (
            <tr className="ay-table__empty">
              <td colSpan={Math.max(columnas.length, 1)}>{emptyState}</td>
            </tr>
          ) : (
            visibles.map((r) => (
              <tr key={r.id}>
                {columnas.map((c, i) => {
                  const contenido = c.render ? c.render(r) : textoDeCelda(r[c.key])
                  const clase = c.align === 'end' ? 'ay-td--num' : undefined
                  return i === 0 ? (
                    <th key={c.key} scope="row" className={clase}>
                      {contenido}
                    </th>
                  ) : (
                    <td key={c.key} className={clase}>
                      {contenido}
                    </td>
                  )
                })}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  )
}

/**
 * Presenta registros en filas y columnas para compararlos campo a campo. Marcado nativo
 * (`table`, `thead`, `th` con `scope`) con un `caption` como nombre, `aria-sort` en el `th`
 * ordenado y un contenedor de desplazamiento alcanzable por teclado. Las flechas no hacen
 * nada aquí: la navegación por celdas es de Data Grid.
 */
export const Table = forwardRef(TablaInterna) as <T extends TableRowData = TableRowData>(
  props: PropsTable<T> & { ref?: Ref<HTMLDivElement> },
) => ReactElement | null

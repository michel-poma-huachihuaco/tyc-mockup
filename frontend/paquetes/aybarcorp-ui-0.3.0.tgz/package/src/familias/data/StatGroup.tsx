import { forwardRef } from 'react'
import type { HTMLAttributes, Ref } from 'react'
import { cx } from '../../utiles.js'
import { IconoVariacion } from './_iconos.js'

export type StatDeltaDir = 'up' | 'down' | 'flat'
export type StatGroupSize = 'sm' | 'md' | 'lg'

/** Variación de una cifra respecto al periodo anterior, escrita con su signo y su palabra. */
export interface StatDelta {
  /** Texto de la variación: «+12 % más», «−3 % menos», «sin cambio». */
  value: string
  dir: StatDeltaDir
}

/** Una cifra del grupo. `value: null` es un dato ausente y se escribe «Sin dato». */
export interface StatItem {
  id: string
  /** Qué mide y su unidad: «Importe reservado (S/)». */
  label: string
  value: string | null
  delta?: StatDelta
}

export interface PropsStatGroup extends Omit<HTMLAttributes<HTMLElement>, 'className'> {
  /** Cifras del grupo, máximo cinco: a partir de ahí no se leen juntas y conviene una tabla. */
  items?: StatItem[]
  /** Periodo comparado. Se escribe una vez para todo el grupo, bajo la caja. */
  period?: string
  /** Muestra los esqueletos con la misma altura que las cifras. El grupo espera a tener
   *  todas antes de pintar: una fila con dos cifras y un esqueleto invita a comparar lo
   *  que aún no está. */
  loading?: boolean
  /** Escala de la cifra: `sm` en la cabecera de una tabla o una card, `lg` en el panel de
   *  inicio. Si una cifra es demasiado larga, todo el grupo baja un escalón. */
  size?: StatGroupSize
  /** Filete de un píxel entre celdas, nunca en los extremos. */
  divider?: boolean
  /** Si subir es bueno. Con `false` (incidencias, vencidos) el color se invierte, para que
   *  verde no signifique cosas opuestas en el mismo panel; la palabra lo aclara igual. */
  positiveIsGood?: boolean
}

/** Cifras de este largo rompen la fila en la escala md: el grupo entero baja un escalón. */
const LARGO_MAXIMO = 11
const ESCALON_MENOR: Record<StatGroupSize, StatGroupSize> = { lg: 'md', md: 'sm', sm: 'sm' }

/**
 * De tres a cinco cifras que se leen juntas, con la misma escala y la misma línea de base.
 * Es una lista de descripciones —rótulo como término, cifra como definición— para que el
 * lector anuncie «Unidades disponibles, 36» y no dos textos sueltos.
 */
export const StatGroup = forwardRef<HTMLElement, PropsStatGroup>(function StatGroup(
  { items = [], period, loading = false, size = 'md', divider = true, positiveIsGood = true, ...resto },
  ref,
) {
  const cifras = (items ?? []).slice(0, 5)
  const largo = cifras.some((s) => (s.value ?? '').length > LARGO_MAXIMO)
  const escala = largo ? ESCALON_MENOR[size] : size
  const clases = cx('ay-stats', `ay-stats--${escala}`, divider && 'has-divider')

  // Si subir es malo, verde significaría lo contrario que en el resto del panel.
  const tono = (dir: StatDeltaDir) => (dir === 'flat' ? 'flat' : (dir === 'up') === positiveIsGood ? 'good' : 'bad')

  return (
    <>
      {loading ? (
        <div {...resto} ref={ref as Ref<HTMLDivElement>} className={clases} aria-busy="true">
          {Array.from({ length: cifras.length || 3 }, (_, i) => (
            <div key={i} className="ay-stats__cell">
              <div className="ay-skel ay-skel--text ay-stats__skel ay-stats__skel--label" aria-hidden="true" />
              <div className="ay-skel ay-skel--text ay-stats__skel ay-stats__skel--value" aria-hidden="true" />
            </div>
          ))}
        </div>
      ) : (
        <dl {...resto} ref={ref as Ref<HTMLDListElement>} className={clases}>
          {cifras.map((s) => (
            <div key={s.id} className="ay-stats__cell">
              <dt className="ay-stats__label">{s.label}</dt>
              {/* «Sin dato», no una celda vacía ni un cero: la falta de información no es una cifra. */}
              <dd className={cx('ay-stats__value', s.value === null && 'ay-stats__value--empty')}>
                {s.value ?? 'Sin dato'}
              </dd>
              {s.delta && (
                <dd className={cx('ay-stats__delta', `ay-stats__delta--${tono(s.delta.dir)}`)}>
                  {s.delta.dir !== 'flat' && <IconoVariacion dir={s.delta.dir} className="ay-stats__arrow" />}
                  {s.delta.value}
                </dd>
              )}
            </div>
          ))}
        </dl>
      )}
      {period && !loading && <p className="ay-stats__period">{period}</p>}
      <p className="ay-visually-hidden" aria-live="polite">
        {loading ? 'Cargando las cifras' : ''}
      </p>
    </>
  )
})

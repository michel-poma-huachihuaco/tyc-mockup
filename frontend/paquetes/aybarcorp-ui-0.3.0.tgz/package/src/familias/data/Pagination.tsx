import { forwardRef, useEffect, useRef, useState } from 'react'
import type { HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import { IconoChevron } from './_iconos.js'
import { useControlable } from './_internos.js'

export type PaginationVariant = 'numbered' | 'simple' | 'compact'

export interface PropsPagination extends Omit<HTMLAttributes<HTMLElement>, 'className'> {
  /** Página actual, base 1. Si se omite, el componente lleva su propia página desde la 1. */
  page?: number
  /** Número total de páginas. Con menos de dos, el componente no se muestra. */
  pageCount: number
  /** Cambio de página. El foco se queda en el control pulsado y el cambio se anuncia. */
  onPageChange?: (page: number) => void
  /** Elementos por página. Con `total`, da el resumen «41-60 de 248 unidades». */
  pageSize?: number
  /** Opciones del selector de tamaño; cada una se lee «25 por página». */
  pageSizeOptions?: number[]
  /** Cambio de tamaño de página. Con él (y `pageSize`) se pinta el selector, y la página se
   *  recalcula para conservar aproximadamente la posición. */
  onPageSizeChange?: (size: number) => void
  /** Total de elementos, para el resumen. Si se desconoce, no se inventa: sin resumen. */
  total?: number
  /** `numbered` con números y elipsis (máximo siete posiciones), `simple` solo anterior y
   *  siguiente con el resumen, y `compact` con «Página 3 de 13» como texto. */
  variant?: PaginationVariant
  /** Nombre del elemento para el resumen: «unidades», «reservas». */
  itemLabel?: string
}

type Posicion = number | 'hueco'

/**
 * Como máximo siete posiciones: la primera, el entorno de la actual y la última, con
 * elipsis cuando se salta más de una página. Una elipsis que tapa una sola página se
 * sustituye por esa página: no ahorra sitio y obliga a adivinar.
 */
export function posicionesDePagina(pagina: number, total: number): Posicion[] {
  if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1)
  let desde = Math.max(2, pagina - 1)
  let hasta = Math.min(total - 1, pagina + 1)
  if (pagina <= 1) hasta = 3
  if (pagina >= total) desde = total - 2
  const posiciones: Posicion[] = [1]
  if (desde === 3) posiciones.push(2)
  else if (desde > 3) posiciones.push('hueco')
  for (let p = desde; p <= hasta; p++) posiciones.push(p)
  if (hasta === total - 2) posiciones.push(total - 1)
  else if (hasta < total - 2) posiciones.push('hueco')
  posiciones.push(total)
  return posiciones
}

/**
 * Recorre un conjunto de resultados por páginas, indicando en todo momento en qué página
 * se está y cuántas hay. Es un `nav` con nombre «Paginación»; los extremos se deshabilitan
 * en lugar de ocultarse. Con `aria-busy` (página en camino) todos los controles quedan
 * deshabilitados, para que una segunda pulsación no pida otra página antes de que vuelva
 * la primera.
 */
export const Pagination = forwardRef<HTMLElement, PropsPagination>(function Pagination(
  {
    page,
    pageCount,
    onPageChange,
    pageSize,
    pageSizeOptions = [10, 25, 50],
    onPageSizeChange,
    total,
    variant = 'numbered',
    itemLabel = 'elementos',
    'aria-label': etiqueta = 'Paginación',
    ...resto
  },
  ref,
) {
  const [pagina, cambiarPagina] = useControlable(page, 1, onPageChange)
  const [tamanoInterno, setTamanoInterno] = useState(pageSize)
  const tamano = pageSize ?? tamanoInterno
  const [anuncio, setAnuncio] = useState('')
  const ocupado = resto['aria-busy'] === true || resto['aria-busy'] === 'true'
  const previa = useRef<number | null>(null)
  const salto = useRef<string | null>(null)

  // El cambio se anuncia en una live region que ya estaba (vacía) en el DOM: la lista se
  // reemplaza sin recargar y, sin aviso, quien no ve la pantalla no sabe si surtió efecto.
  // Una página fuera de rango por un filtro nuevo salta a la última válida y lo dice.
  useEffect(() => {
    if (pageCount >= 1 && pagina > pageCount) {
      salto.current = `La página ${pagina} ya no existe; se muestra la página ${pageCount} de ${pageCount}`
      previa.current = pagina
      cambiarPagina(pageCount)
      return
    }
    if (previa.current !== null && previa.current !== pagina) {
      setAnuncio(salto.current ?? `Página ${pagina} de ${pageCount}`)
    }
    salto.current = null
    previa.current = pagina
    // eslint-disable-next-line react-hooks/exhaustive-deps -- solo reacciona a la página y al total
  }, [pagina, pageCount])

  if (!(pageCount > 1)) return null

  const ir = (destino: number) => {
    if (destino < 1 || destino > pageCount || destino === pagina) return
    cambiarPagina(destino)
  }

  const desde = tamano ? (pagina - 1) * tamano + 1 : undefined
  const hasta = tamano && total != null ? Math.min(pagina * tamano, total) : undefined
  const resumen =
    total == null ? null : desde != null && hasta != null ? `${desde}-${hasta} de ${total} ${itemLabel}` : `${total} ${itemLabel}`

  return (
    <nav {...resto} ref={ref} aria-label={etiqueta} className={cx('ay-pager', `ay-pager--${variant}`)}>
      {resumen && <p className="ay-pager__summary">{resumen}</p>}
      <button
        type="button"
        className="ay-iconbtn ay-iconbtn--ghost ay-pager__step"
        aria-label="Página anterior"
        disabled={ocupado || pagina <= 1}
        onClick={() => ir(pagina - 1)}
      >
        <IconoChevron direccion="izquierda" />
      </button>

      {variant === 'numbered' &&
        posicionesDePagina(pagina, pageCount).map((p, i) =>
          p === 'hueco' ? (
            // La elipsis es texto decorativo, nunca un botón: no lleva a ninguna página.
            <span key={`hueco-${i}`} className="ay-pager__gap" aria-hidden="true">
              …
            </span>
          ) : (
            <button
              key={p}
              type="button"
              className="ay-pager__page"
              aria-label={`Página ${p}`}
              aria-current={p === pagina ? 'page' : undefined}
              disabled={ocupado}
              onClick={() => ir(p)}
            >
              {p}
            </button>
          ),
        )}

      {variant === 'compact' && (
        <span className="ay-pager__of">
          Página {pagina} de {pageCount}
        </span>
      )}

      <button
        type="button"
        className="ay-iconbtn ay-iconbtn--ghost ay-pager__step"
        aria-label="Página siguiente"
        disabled={ocupado || pagina >= pageCount}
        onClick={() => ir(pagina + 1)}
      >
        <IconoChevron direccion="derecha" />
      </button>

      {onPageSizeChange !== undefined && tamano != null && (
        <label className="ay-pager__size">
          <span className="ay-visually-hidden">Elementos por página</span>
          <span className="ay-selectwrap ay-selectwrap--sm">
            <select
              className="ay-select ay-select--sm"
              value={String(tamano)}
              disabled={ocupado}
              onChange={(evento) => {
                const nuevo = Number(evento.currentTarget.value)
                // Se conserva aproximadamente la posición: el primer elemento visible
                // sigue en pantalla con el tamaño nuevo.
                const primero = (pagina - 1) * tamano + 1
                setTamanoInterno(nuevo)
                onPageSizeChange?.(nuevo)
                const destino = Math.max(1, Math.ceil(primero / nuevo))
                if (destino !== pagina) cambiarPagina(destino)
              }}
            >
              {pageSizeOptions.map((opcion) => (
                <option key={opcion} value={String(opcion)}>
                  {`${opcion} por página`}
                </option>
              ))}
            </select>
            <IconoChevron direccion="abajo" className="ay-select__chevron" />
          </span>
        </label>
      )}

      <p className="ay-visually-hidden" aria-live="polite">
        {anuncio}
      </p>
    </nav>
  )
})

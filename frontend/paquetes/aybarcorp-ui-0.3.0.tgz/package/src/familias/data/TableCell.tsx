import { forwardRef, useContext, useId } from 'react'
import type { ReactNode, TdHTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import { ContextoFila } from './_internos.js'

export type TableCellAlign = 'start' | 'end'

export interface PropsTableCell
  extends Omit<TdHTMLAttributes<HTMLTableCellElement>, 'className' | 'align'> {
  /** Alineación. `end` para números e importes, que se comparan en vertical. */
  align?: TableCellAlign
  /** Cifras tabulares, alineadas al final y sin envolver. La unidad va en la cabecera de
   *  la columna, no repetida en cada celda. */
  numeric?: boolean
  /** Trunca con puntos suspensivos. El recorte es solo visual: el valor entero sigue en la
   *  celda (el lector lo anuncia completo) y en el `title` para quien la ve cortada. */
  truncate?: boolean
  /** Segunda línea con contexto corto, dentro de la misma celda: el lector la anuncia con
   *  el dato y no como si fuera otra columna. */
  secondary?: ReactNode
  /** Elemento inicial: Avatar o icono de tipo. */
  leading?: ReactNode
  /** Elemento final: Badge o acción. */
  trailing?: ReactNode
  /** Celda que identifica la fila: se pinta como `th scope="row"`. Sin ella el lector no
   *  puede decir a qué registro pertenece cada dato. */
  header?: boolean
  /** Contenido cuando el valor falta. 0 es un dato; ausente es guion. */
  empty?: string
  /** Motivo del error de guardado. Marca la celda y se enlaza con `aria-describedby`. */
  error?: string
}

/**
 * Un dato dentro de una fila, con la alineación, el formato y el tratamiento que su tipo
 * exige. Dentro de una Table Row con `href`, la celda `header` lleva el enlace real al
 * detalle: la fila entera nunca se convierte en un control.
 */
export const TableCell = forwardRef<HTMLTableCellElement, PropsTableCell>(function TableCell(
  {
    align = 'start',
    numeric = false,
    truncate = false,
    secondary,
    leading,
    trailing,
    header = false,
    empty = '—',
    error,
    id,
    title,
    children,
    'aria-describedby': describedBy,
    ...resto
  },
  ref,
) {
  const idAuto = useId()
  const fila = useContext(ContextoFila)
  const vacio = children === null || children === undefined || children === '' || children === false
  let contenido: ReactNode = vacio ? empty : children
  // Fila navegable: el enlace ocupa solo la celda del identificador, así las acciones de
  // la fila siguen siendo pulsables y el enlace se anuncia como enlace.
  if (header && fila?.href && !vacio) {
    contenido = (
      <a className="ay-tr__link" href={fila.href}>
        {contenido}
      </a>
    )
  }

  const cuerpo = secondary ? (
    <span className="ay-td__two">
      <span>{contenido}</span>
      <span className="ay-td__secondary">{secondary}</span>
    </span>
  ) : (
    contenido
  )

  const idError = `${id ?? idAuto}-error`
  const props = {
    ...resto,
    id,
    ref,
    className: cx(
      'ay-td',
      (numeric || align === 'end') && 'ay-td--num',
      truncate && 'ay-td--truncate',
      error && 'ay-td--error',
    ),
    // El valor completo queda disponible aunque se vea truncado.
    title: title ?? (truncate && typeof children === 'string' ? children : undefined),
    'aria-describedby': cx(describedBy, error && idError) || undefined,
  }

  const interior = (
    <>
      {leading}
      {cuerpo}
      {trailing}
      {error && (
        <span id={idError} className="ay-visually-hidden">
          {error}
        </span>
      )}
    </>
  )

  return header ? (
    <th scope="row" {...props}>
      {interior}
    </th>
  ) : (
    <td {...props}>{interior}</td>
  )
})

/**
 * Iconos de la familia Data. Todos son decorativos (`aria-hidden`): el sentido de un
 * orden, el estado de una rama o la dirección de una variación lo dicen el texto y los
 * atributos ARIA, nunca la punta de una flecha.
 *
 * El tamaño va en unidades de usuario del `viewBox`; la medida en pantalla la da la
 * hoja (`inline-size` con tokens), no un literal aquí.
 */
import type { ReactNode, SVGProps } from 'react'

type PropsIcono = Omit<SVGProps<SVGSVGElement>, 'children'>

function Svg({ children, ...resto }: PropsIcono & { children: ReactNode }) {
  return (
    <svg
      viewBox="0 0 16 16"
      width={16}
      height={16}
      fill="none"
      stroke="currentColor"
      strokeWidth={1.5}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
      {...resto}
    >
      {children}
    </svg>
  )
}

export type DireccionChevron = 'izquierda' | 'derecha' | 'arriba' | 'abajo'

const TRAZO_CHEVRON: Record<DireccionChevron, string> = {
  izquierda: 'M10 3.5 5.5 8l4.5 4.5',
  derecha: 'M6 3.5 10.5 8 6 12.5',
  arriba: 'M3.5 10 8 5.5l4.5 4.5',
  abajo: 'M3.5 6 8 10.5 12.5 6',
}

export function IconoChevron({ direccion, ...resto }: PropsIcono & { direccion: DireccionChevron }) {
  return (
    <Svg {...resto}>
      <path d={TRAZO_CHEVRON[direccion]} />
    </Svg>
  )
}

export function IconoCerrar(props: PropsIcono) {
  return (
    <Svg {...props}>
      <path d="M4 4l8 8M12 4l-8 8" />
    </Svg>
  )
}

/** Flecha de orden: arriba ascendente, abajo descendente y doble flecha tenue sin ordenar. */
export function IconoOrden({ dir, ...resto }: PropsIcono & { dir?: 'asc' | 'desc' }) {
  return (
    <Svg {...resto}>
      {dir === 'asc' && <path d="M8 13V3M4.5 6.5 8 3l3.5 3.5" />}
      {dir === 'desc' && <path d="M8 3v10M4.5 9.5 8 13l3.5-3.5" />}
      {dir === undefined && <path d="M5.5 6 8 3.5 10.5 6M5.5 10 8 12.5 10.5 10" />}
    </Svg>
  )
}

/** Flecha de una variación en Stat Group. La palabra hace el trabajo; esto solo acompaña. */
export function IconoVariacion({ dir, ...resto }: PropsIcono & { dir: 'up' | 'down' }) {
  return (
    <Svg {...resto}>
      {dir === 'up' ? <path d="M4 10l4-4 4 4" /> : <path d="M4 6l4 4 4-4" />}
    </Svg>
  )
}

/** Spinner con el marcado canónico de Feedback (`.ay-spinner`), pintado aquí sin importarlo. */
export function SpinnerPequeno() {
  return (
    <svg className="ay-spinner ay-spinner--sm" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
      <circle className="ay-spinner__track" cx="12" cy="12" r="9" />
      <circle className="ay-spinner__arc" cx="12" cy="12" r="9" />
    </svg>
  )
}

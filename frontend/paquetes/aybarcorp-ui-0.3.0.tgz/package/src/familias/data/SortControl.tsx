import { forwardRef, useState } from 'react'
import type { ButtonHTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import { IconoOrden } from './_iconos.js'

/** Sentido del orden; `undefined` es el orden natural (la columna no está ordenada). */
export type SortDir = 'asc' | 'desc' | undefined
/** Tipo de dato de la columna: decide cómo se nombra el sentido («de A a Z», «de menor a mayor»…). */
export type SortKind = 'text' | 'number' | 'date'
export type SortAlign = 'start' | 'end'

export interface PropsSortControl
  extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'className' | 'dir' | 'disabled'> {
  /** Nombre de la columna, sin añadir «ordenar por». Es también el texto visible del botón. */
  label: string
  /** Sentido activo. Sin valor, la columna está en el orden natural y el `th` no lleva
   *  `aria-sort` (ausente, nunca `none`). */
  dir?: SortDir
  /** Cambio de orden: recibe el sentido que pide la pulsación. Con `tristate`, tras el
   *  descendente llega `undefined` (vuelta al orden natural). */
  onSortChange: (dir: SortDir) => void
  /** Permite volver al orden natural: ascendente → descendente → sin ordenar. */
  tristate?: boolean
  /** Posición en el orden compuesto (1 manda sobre 2). Se ve como cifra y se dice en el
   *  nombre accesible, que es lo único que indica qué columna manda. */
  position?: number
  /** `end` en columnas numéricas alineadas al final: el indicador va antes del nombre. */
  align?: SortAlign
  /** Desactiva el control, por ejemplo mientras llega del servidor el orden nuevo. */
  disabled?: boolean
  /** Tipo de dato, para nombrar el sentido: «de A a Z» en texto, «de menor a mayor» en
   *  números y «de más reciente a más antigua» en fechas. */
  kind?: SortKind
}

const SENTIDOS: Record<SortKind, [string, string]> = {
  text: ['de A a Z', 'de Z a A'],
  number: ['de menor a mayor', 'de mayor a menor'],
  date: ['de más antigua a más reciente', 'de más reciente a más antigua'],
}

/** El sentido que pedirá la próxima pulsación. */
export function siguienteDir(dir: SortDir, tristate: boolean): SortDir {
  if (dir === 'asc') return 'desc'
  if (dir === 'desc') return tristate ? undefined : 'asc'
  return 'asc'
}

/** Nombre accesible: estado actual y lo que hará la siguiente pulsación. */
export function nombreDeOrden(label: string, dir: SortDir, tristate: boolean, kind: SortKind, position?: number): string {
  const [asc, desc] = SENTIDOS[kind]
  const estado = dir === 'asc' ? `ordenado ${asc}` : dir === 'desc' ? `ordenado ${desc}` : 'sin ordenar'
  const siguiente = siguienteDir(dir, tristate)
  const proximo =
    siguiente === 'asc' ? `ordenar ${asc}` : siguiente === 'desc' ? `ordenar ${desc}` : 'volver al orden natural'
  const prioridad = position != null && dir !== undefined ? `, prioridad ${position}` : ''
  return `${label}${prioridad}, ${estado}, activar para ${proximo}`
}

/** El aviso de la live region tras pulsar: «Ordenado por Unidad, de menor a mayor». */
export function anuncioDeOrden(label: string, dir: SortDir, kind: SortKind): string {
  const [asc, desc] = SENTIDOS[kind]
  if (dir === undefined) return `${label} vuelve al orden natural`
  return `Ordenado por ${label}, ${dir === 'asc' ? asc : desc}`
}

/**
 * El valor de `aria-sort` para el `th`: va en la columna, no en el botón, y en el orden
 * natural se retira (`undefined`) en lugar de quedarse en `none`, que no todos los
 * lectores anuncian y que suena igual que una columna que no se puede ordenar.
 */
export function ariaSortDe(dir: SortDir): 'ascending' | 'descending' | undefined {
  return dir === 'asc' ? 'ascending' : dir === 'desc' ? 'descending' : undefined
}

/**
 * Cambia el orden por una columna y comunica en qué sentido está. Vive dentro del `th`
 * de las columnas ordenables y lo llena entero: el objetivo es la celda, no un icono de
 * doce píxeles. El `aria-sort` lo pone el `th` con `ariaSortDe(dir)`. Cada pulsación se
 * anuncia en una live region, también cuando el orden no cambia nada.
 */
export const SortControl = forwardRef<HTMLButtonElement, PropsSortControl>(function SortControl(
  {
    label,
    dir,
    onSortChange,
    tristate = false,
    position,
    align = 'start',
    disabled = false,
    kind = 'text',
    type = 'button',
    onClick,
    ...resto
  },
  ref,
) {
  const [anuncio, setAnuncio] = useState('')
  return (
    <>
      <button
        {...resto}
        ref={ref}
        type={type}
        disabled={disabled}
        className={cx('ay-sort', align === 'end' && 'ay-sort--end')}
        aria-label={nombreDeOrden(label, dir, tristate, kind, position)}
        onClick={(evento) => {
          onClick?.(evento)
          if (evento.defaultPrevented) return
          const siguiente = siguienteDir(dir, tristate)
          setAnuncio(anuncioDeOrden(label, siguiente, kind))
          onSortChange?.(siguiente)
        }}
      >
        {label}
        <IconoOrden dir={dir} className={cx('ay-sort__arrow', dir === undefined && 'ay-sort__arrow--idle')} />
        {position != null && (
          <span className="ay-sort__pos" aria-hidden="true">
            {position}
          </span>
        )}
      </button>
      <span className="ay-visually-hidden" aria-live="polite">
        {anuncio}
      </span>
    </>
  )
})

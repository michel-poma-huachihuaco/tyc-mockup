import { forwardRef } from 'react'
import type { HTMLAttributes, ReactNode } from 'react'
import { cx } from '../../utiles.js'

export type EmptyStateVariant = 'first-use' | 'no-results' | 'error' | 'no-access'
export type EmptyStateSize = 'compact' | 'full'

export interface PropsEmptyState extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'title'> {
  /** Qué ocurre, en una línea y como hecho, no como disculpa: «Sin unidades en esta
   *  promoción». Se pinta como encabezado real para que quien salta de encabezado en
   *  encabezado encuentre el motivo del vacío. */
  title: string
  /** Motivo y salida, en una o dos frases. En «sin resultados» repite el término buscado. */
  description?: string
  /** Acción primaria: la siguiente acción evidente, nombrada por lo que hace
   *  («Registrar la primera unidad», no «Empezar»). Con permiso de solo lectura no se pasa. */
  action?: ReactNode
  /** Acción alternativa, como limpiar los filtros (diciendo cuántos hay aplicados). */
  secondaryAction?: ReactNode
  /** Icono o ilustración decorativa. Va con `aria-hidden`: toda la información está en el
   *  texto. En el tamaño `compact` se omite. */
  illustration?: ReactNode
  /** Motivo del vacío, que ajusta el tono: primera vez, sin resultados, error de carga o
   *  sin permisos (en ese caso no se revela cuántos registros hay). */
  variant?: EmptyStateVariant
  /** `full` ocupa el área de contenido de la página; `compact` va dentro de una card, un
   *  panel lateral o una celda de tabla, alineado al inicio y sin ilustración. */
  size?: EmptyStateSize
}

/**
 * Explica por qué no hay nada que mostrar y ofrece la siguiente acción, en lugar de dejar
 * una zona vacía que parezca un error. No sustituye a Skeleton: mientras los datos cargan
 * no se muestra. El bloque es `role="status"` y el foco no se mueve al aparecer, porque el
 * usuario suele venir de escribir en el buscador.
 */
export const EmptyState = forwardRef<HTMLDivElement, PropsEmptyState>(function EmptyState(
  {
    title,
    description,
    action,
    secondaryAction,
    illustration,
    variant = 'first-use',
    size = 'full',
    ...resto
  },
  ref,
) {
  const conAcciones = Boolean(action) || Boolean(secondaryAction)
  return (
    <div
      role="status"
      {...resto}
      ref={ref}
      className={cx('ay-empty', `ay-empty--${variant}`, `ay-empty--${size}`)}
    >
      {size === 'full' && illustration != null && illustration !== false && (
        <span className="ay-empty__art" aria-hidden="true">
          {illustration}
        </span>
      )}
      <h3 className="ay-empty__title">{title}</h3>
      {description && <p className="ay-empty__desc">{description}</p>}
      {conAcciones && (
        <div className="ay-empty__actions">
          {action}
          {secondaryAction}
        </div>
      )}
    </div>
  )
})

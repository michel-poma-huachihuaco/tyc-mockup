import { Fragment, forwardRef, useEffect, useId, useMemo, useRef, useState } from 'react'
import type {
  FocusEvent as EventoFoco,
  ForwardedRef,
  HTMLAttributes,
  KeyboardEvent as EventoTeclado,
  ReactElement,
  ReactNode,
  Ref,
} from 'react'
import { cx } from '../../utiles.js'
import { IconoChevron } from './_iconos.js'
import { comparar, textoDeCelda, useControlable } from './_internos.js'
import { SortControl, ariaSortDe } from './SortControl.js'
import type { TableSort } from './Table.js'

/** Columna de Data Grid. */
export interface GridColumn<T> {
  /** Campo del registro que pinta la columna. */
  key: string
  /** Nombre del dato con su unidad entre paréntesis: «Precio (S/)». */
  header: string
  /** `end` para cifras: alineadas al final con numeración tabular. */
  align?: 'start' | 'end'
  /** Ancho declarado (rem o porcentaje). */
  width?: string
  /** Pinta Sort Control en la cabecera. */
  sortable?: boolean
  /** La celda entra en edición con Enter; se declara con `aria-readonly="false"`. */
  editable?: boolean
  /** Contenido propio de la celda. Sin él se pinta el valor o un guion. */
  renderCell?: (row: T) => ReactNode
}

export interface PropsDataGrid<T = Record<string, unknown>> extends Omit<HTMLAttributes<HTMLDivElement>, 'className'> {
  /** Columnas: `key`, `header`, `align`, `width`, `sortable`, `editable` y `renderCell`. La
   *  primera identifica la fila (`rowheader`). */
  columns?: GridColumn<T>[]
  /** Registros. */
  rows?: T[]
  /** Identificador estable de fila: de él dependen la selección, la edición y el detalle. */
  getRowId: (row: T) => string
  /** Nombre accesible de la rejilla; obligatorio. */
  caption: string
  /** Filas seleccionadas. Con ella (o con `onSelectionChange`) aparece la columna de
   *  casillas; si se omite, la rejilla lleva su propia selección. */
  selection?: Set<string>
  /** Cambio de selección. El recuento se anuncia aparte, en una live region polite. */
  onSelectionChange?: (selection: Set<string>) => void
  /** Orden activo. Si se omite, la rejilla ordena sus filas por su cuenta. */
  sort?: TableSort
  /** Cambio de orden. */
  onSortChange?: (sort: TableSort) => void
  /** Guardado de una celda editable. Si la promesa falla, el valor introducido se conserva,
   *  la celda marca el error y el foco vuelve a ella. */
  onCellEdit?: (rowId: string, key: string, value: string) => Promise<void>
  /** Detalle de la fila expandida: una fila con `colspan` bajo la del registro. Con él
   *  aparece la columna del disparador de expansión. */
  expandedRow?: (row: T) => ReactNode
  /** Muestra filas de Skeleton con la altura real, para que la rejilla no salte. */
  loading?: boolean
  /** Contenido sin filas: un Empty State con la acción siguiente, conservando la cabecera. */
  emptyState?: ReactNode
  /** Total real de registros cuando las filas son una parte (paginadas o virtualizadas):
   *  da `aria-rowcount` y el «4 de 248 seleccionadas». */
  totalRows?: number
}

interface Activa {
  f: number
  c: number
}

const SEPARADOR = '\u001f'
const SALTO_DE_PAGINA = 10

function RejillaInterna<T>(
  {
    columns = [],
    rows = [],
    getRowId,
    caption,
    selection,
    onSelectionChange,
    sort,
    onSortChange,
    onCellEdit,
    expandedRow,
    loading = false,
    emptyState,
    totalRows,
    ...resto
  }: PropsDataGrid<T>,
  ref: ForwardedRef<HTMLDivElement>,
) {
  const idBase = useId()
  const idPista = `${idBase}-pista`
  const columnas = columns ?? []
  const registros = rows ?? []
  const valorDe = (fila: T, clave: string) => (fila as Record<string, unknown>)[clave]
  const idDe = (fila: T, i: number) =>
    typeof getRowId === 'function' ? getRowId(fila) : String(valorDe(fila, 'id') ?? i)

  // Selección: controlada si llega `selection`; si no, interna.
  const conSeleccion = selection != null || onSelectionChange !== undefined
  const [seleccionInterna, setSeleccionInterna] = useState<Set<string>>(() => new Set())
  const seleccion = selection != null ? new Set(selection) : seleccionInterna
  const cambiarSeleccion = (nueva: Set<string>) => {
    if (selection == null) setSeleccionInterna(nueva)
    onSelectionChange?.(nueva)
  }

  const [orden, cambiarOrden] = useControlable<TableSort | undefined>(
    sort,
    undefined,
    onSortChange as ((orden: TableSort | undefined) => void) | undefined,
  )
  const ordenControlado = sort != null
  const visibles = useMemo(() => {
    if (ordenControlado || !orden) return registros
    return [...registros].sort((a, b) => {
      const resultado = comparar(valorDe(a, orden.key), valorDe(b, orden.key))
      return orden.dir === 'asc' ? resultado : -resultado
    })
    // eslint-disable-next-line react-hooks/exhaustive-deps -- valorDe es puro
  }, [registros, orden, ordenControlado])

  const conDetalle = typeof expandedRow === 'function'
  const [expandidas, setExpandidas] = useState<Set<string>>(() => new Set())
  const desplazamiento = conSeleccion ? 1 : 0
  const totalColumnas = desplazamiento + columnas.length + (conDetalle ? 1 : 0)
  const filasNavegables = loading ? 0 : visibles.length

  // Foco móvil: una sola celda con tabIndex 0; Tab sale de la rejilla en un paso.
  const [activaCruda, setActiva] = useState<Activa>({ f: filasNavegables > 0 ? 1 : 0, c: 0 })
  const activa: Activa = {
    f: Math.min(Math.max(activaCruda.f, 0), filasNavegables),
    c: Math.min(Math.max(activaCruda.c, 0), Math.max(totalColumnas - 1, 0)),
  }
  const [editando, setEditando] = useState<string | null>(null)
  const [guardando, setGuardando] = useState<Record<string, string>>({})
  const [errores, setErrores] = useState<Record<string, { valor: string; mensaje: string }>>({})
  const [aviso, setAviso] = useState('')
  const tabla = useRef<HTMLTableElement>(null)
  const casillaTodas = useRef<HTMLInputElement>(null)
  const enfocar = useRef(false)

  useEffect(() => {
    if (!enfocar.current) return
    enfocar.current = false
    tabla.current?.querySelector<HTMLElement>(`[data-celda="${activa.f}-${activa.c}"]`)?.focus()
  })

  const idsVisibles = visibles.map(idDe)
  const marcadasVisibles = idsVisibles.filter((id) => seleccion.has(id)).length
  const todas = idsVisibles.length > 0 && marcadasVisibles === idsVisibles.length
  const parcial = marcadasVisibles > 0 && !todas
  // Parcial: la casilla de la cabecera es indeterminada, no falsa ni verdadera.
  useEffect(() => {
    if (casillaTodas.current) casillaTodas.current.indeterminate = parcial
  }, [parcial])

  const total = totalRows ?? registros.length
  const fueraDelFiltro = [...seleccion].filter((id) => !idsVisibles.includes(id)).length
  const textoSeleccion = seleccion.size
    ? `${seleccion.size} de ${total} seleccionadas` +
      (fueraDelFiltro ? `, ${fueraDelFiltro} fuera del filtro actual` : '')
    : ''

  const claveDe = (idFila: string, clave: string) => `${idFila}${SEPARADOR}${clave}`
  const moverA = (f: number, c: number) => {
    enfocar.current = true
    setActiva({
      f: Math.min(Math.max(f, 0), filasNavegables),
      c: Math.min(Math.max(c, 0), Math.max(totalColumnas - 1, 0)),
    })
  }
  const columnaEn = (c: number) => columnas[c - desplazamiento]

  const alternarFila = (id: string, marcar?: boolean) => {
    const nueva = new Set(seleccion)
    const debe = marcar ?? !nueva.has(id)
    if (debe) nueva.add(id)
    else nueva.delete(id)
    cambiarSeleccion(nueva)
  }
  const alternarTodas = () => {
    const nueva = new Set(seleccion)
    if (todas) idsVisibles.forEach((id) => nueva.delete(id))
    else idsVisibles.forEach((id) => nueva.add(id))
    cambiarSeleccion(nueva)
  }

  const confirmar = async (idFila: string, columna: GridColumn<T>, valor: string, devolverFoco: boolean) => {
    const clave = claveDe(idFila, columna.key)
    setEditando(null)
    enfocar.current = devolverFoco
    setGuardando((previos) => ({ ...previos, [clave]: valor }))
    setErrores(({ [clave]: _descartado, ...resto }) => resto)
    try {
      await onCellEdit?.(idFila, columna.key, valor)
      setAviso(`${columna.header}: cambio guardado`)
    } catch (error) {
      // El valor introducido se conserva y el foco vuelve a la celda: devolverlo al principio
      // obligaría a recorrer otra vez cien filas para encontrar la que hay que corregir.
      const mensaje = error instanceof Error && error.message ? error.message : 'No se ha podido guardar el cambio'
      setErrores((previos) => ({ ...previos, [clave]: { valor, mensaje } }))
      setAviso(`${columna.header}: ${mensaje}. El valor introducido se conserva.`)
      enfocar.current = true
    } finally {
      setGuardando(({ [clave]: _descartado, ...resto }) => resto)
    }
  }

  const pulsarControl = (f: number, c: number) => {
    const celda = tabla.current?.querySelector<HTMLElement>(`[data-celda="${f}-${c}"]`)
    celda?.querySelector<HTMLElement>('button, input[type="checkbox"], a[href]')?.click()
  }

  const alPulsar = (evento: EventoTeclado<HTMLTableElement>) => {
    if (editando) return
    const objetivo = evento.target as HTMLElement
    const enControl = objetivo.matches('input, button, select, textarea, a[href]')
    const { f, c } = activa
    const ctrl = evento.ctrlKey || evento.metaKey
    switch (evento.key) {
      case 'ArrowDown':
      case 'ArrowUp': {
        evento.preventDefault()
        const destino = f + (evento.key === 'ArrowDown' ? 1 : -1)
        // Mayús con flechas extiende la selección de filas.
        if (evento.shiftKey && conSeleccion && f > 0 && destino > 0 && destino <= filasNavegables) {
          const nueva = new Set(seleccion)
          nueva.add(idsVisibles[f - 1] as string)
          nueva.add(idsVisibles[destino - 1] as string)
          cambiarSeleccion(nueva)
        }
        moverA(destino, c)
        break
      }
      case 'ArrowRight':
        evento.preventDefault()
        moverA(f, c + 1)
        break
      case 'ArrowLeft':
        evento.preventDefault()
        moverA(f, c - 1)
        break
      case 'Home':
        evento.preventDefault()
        moverA(ctrl ? 0 : f, 0)
        break
      case 'End':
        evento.preventDefault()
        moverA(ctrl ? filasNavegables : f, totalColumnas - 1)
        break
      case 'PageDown':
        evento.preventDefault()
        moverA(f + SALTO_DE_PAGINA, c)
        break
      case 'PageUp':
        evento.preventDefault()
        moverA(f - SALTO_DE_PAGINA, c)
        break
      case ' ':
        if (enControl) return // la casilla o el botón ya reaccionan solos
        evento.preventDefault()
        if (f === 0) pulsarControl(f, c)
        else if (conSeleccion) alternarFila(idsVisibles[f - 1] as string)
        break
      case 'Enter': {
        if (enControl) return
        evento.preventDefault()
        const columna = columnaEn(c)
        const fila = visibles[f - 1]
        if (f > 0 && fila && columna?.editable && onCellEdit !== undefined) {
          setEditando(claveDe(idDe(fila, f - 1), columna.key))
        } else {
          pulsarControl(f, c)
        }
        break
      }
    }
  }

  const alEnfocar = (f: number, c: number) => (evento: EventoFoco<HTMLElement>) => {
    if (evento.currentTarget.contains(evento.target)) {
      if (activa.f !== f || activa.c !== c) setActiva({ f, c })
    }
  }
  const propsCelda = (f: number, c: number) => ({
    'data-celda': `${f}-${c}`,
    tabIndex: activa.f === f && activa.c === c ? 0 : -1,
    onFocus: alEnfocar(f, c),
  })

  return (
    <>
      <div className="ay-grid__scroll" role="region" tabIndex={0} aria-label={caption} {...resto} ref={ref}>
        <table
          ref={tabla}
          className="ay-grid"
          role="grid"
          aria-label={caption}
          // El tamaño real, no el del DOM: importa al paginar o virtualizar.
          aria-rowcount={total + 1}
          aria-colcount={totalColumnas}
          aria-multiselectable={conSeleccion || undefined}
          aria-busy={loading || undefined}
          onKeyDown={alPulsar}
        >
          <thead>
            <tr role="row" aria-rowindex={1}>
              {conSeleccion && (
                <th role="columnheader" scope="col" className="ay-grid__check" {...propsCelda(0, 0)}>
                  <input
                    ref={casillaTodas}
                    type="checkbox"
                    tabIndex={-1}
                    checked={todas}
                    disabled={loading || idsVisibles.length === 0}
                    aria-label="Seleccionar todas las filas visibles"
                    onChange={alternarTodas}
                  />
                </th>
              )}
              {columnas.map((columna, i) => {
                const dir = orden?.key === columna.key ? orden.dir : undefined
                return (
                  <th
                    key={columna.key}
                    role="columnheader"
                    scope="col"
                    style={columna.width ? { inlineSize: columna.width } : undefined}
                    className={columna.align === 'end' ? 'ay-td--num' : undefined}
                    aria-sort={ariaSortDe(dir)}
                    {...propsCelda(0, i + desplazamiento)}
                  >
                    {columna.sortable ? (
                      <SortControl
                        label={columna.header}
                        dir={dir}
                        kind={columna.align === 'end' ? 'number' : 'text'}
                        align={columna.align ?? 'start'}
                        tabIndex={-1}
                        disabled={loading}
                        onSortChange={(nuevo) => {
                          if (nuevo) cambiarOrden({ key: columna.key, dir: nuevo })
                        }}
                      />
                    ) : (
                      columna.header
                    )}
                  </th>
                )
              })}
              {conDetalle && (
                <th role="columnheader" scope="col" className="ay-td--actions" {...propsCelda(0, totalColumnas - 1)}>
                  <span className="ay-visually-hidden">Detalle</span>
                </th>
              )}
            </tr>
          </thead>

          <tbody>
            {loading ? (
              Array.from({ length: Math.max(registros.length, 5) }, (_, i) => (
                <tr key={`esqueleto-${i}`} className="ay-grid__skeleton" aria-hidden="true">
                  {Array.from({ length: Math.max(totalColumnas, 1) }, (__, j) => (
                    <td key={j}>
                      <div className="ay-skel ay-skel--text" />
                    </td>
                  ))}
                </tr>
              ))
            ) : visibles.length === 0 ? (
              <tr role="row" aria-rowindex={2}>
                <td role="gridcell" colSpan={Math.max(totalColumnas, 1)} className="ay-grid__empty">
                  {emptyState}
                </td>
              </tr>
            ) : (
              visibles.map((fila, indice) => {
                const f = indice + 1
                const id = idsVisibles[indice] as string
                const nombreFila = columnas[0] ? textoDeCelda(valorDe(fila, columnas[0].key)) : id
                const seleccionada = seleccion.has(id)
                const abierta = expandidas.has(id)
                const idDetalle = `${idBase}-detalle-${indice}`
                return (
                  <Fragment key={id}>
                  <tr
                    role="row"
                    aria-rowindex={f + 1}
                    // aria-selected en la fila, nunca en cada celda.
                    aria-selected={conSeleccion ? seleccionada : undefined}
                  >
                    {conSeleccion && (
                      <td role="gridcell" className="ay-grid__check" {...propsCelda(f, 0)}>
                        <input
                          type="checkbox"
                          tabIndex={-1}
                          checked={seleccionada}
                          aria-label={`Seleccionar ${nombreFila}`}
                          onChange={(evento) => alternarFila(id, evento.currentTarget.checked)}
                        />
                      </td>
                    )}
                    {columnas.map((columna, i) => {
                      const c = i + desplazamiento
                      const clave = claveDe(id, columna.key)
                      const error = errores[clave]
                      const pendiente = guardando[clave]
                      const idError = `${idBase}-error-${indice}-${i}`
                      const enEdicion = editando === clave
                      const contenido = enEdicion ? (
                        <EditorDeCelda
                          inicial={error?.valor ?? textoCrudo(valorDe(fila, columna.key))}
                          etiqueta={`${columna.header}, ${nombreFila}`}
                          alConfirmar={(valor, devolverFoco) => void confirmar(id, columna, valor, devolverFoco)}
                          alCancelar={() => {
                            enfocar.current = true
                            setEditando(null)
                          }}
                        />
                      ) : pendiente !== undefined ? (
                        pendiente
                      ) : error ? (
                        error.valor
                      ) : columna.renderCell ? (
                        columna.renderCell(fila)
                      ) : (
                        textoDeCelda(valorDe(fila, columna.key))
                      )
                      const props = {
                        ...propsCelda(f, c),
                        'aria-readonly': columna.editable ? false : undefined,
                        'aria-describedby': columna.editable ? cx(idPista, error && idError) : undefined,
                        'aria-busy': pendiente !== undefined || undefined,
                        className:
                          cx(
                            columna.align === 'end' && 'ay-td--num',
                            error && 'ay-grid__cell--error',
                            pendiente !== undefined && 'ay-grid__cell--saving',
                            enEdicion && 'ay-grid__cell--editing',
                          ) || undefined,
                      }
                      const mensaje = error && (
                        <span id={idError} className="ay-visually-hidden">
                          {error.mensaje}
                        </span>
                      )
                      return i === 0 ? (
                        <th key={columna.key} role="rowheader" scope="row" {...props}>
                          {contenido}
                          {mensaje}
                        </th>
                      ) : (
                        <td key={columna.key} role="gridcell" {...props}>
                          {contenido}
                          {mensaje}
                        </td>
                      )
                    })}
                    {conDetalle && (
                      <td role="gridcell" className="ay-td--actions" {...propsCelda(f, totalColumnas - 1)}>
                        <button
                          type="button"
                          tabIndex={-1}
                          className="ay-iconbtn ay-iconbtn--ghost ay-iconbtn--sm"
                          aria-expanded={abierta}
                          aria-controls={idDetalle}
                          aria-label={`${abierta ? 'Ocultar' : 'Ver'} el detalle de ${nombreFila}`}
                          onClick={() =>
                            setExpandidas((previas) => {
                              const nuevas = new Set(previas)
                              if (nuevas.has(id)) nuevas.delete(id)
                              else nuevas.add(id)
                              return nuevas
                            })
                          }
                        >
                          <IconoChevron direccion={abierta ? 'arriba' : 'abajo'} />
                        </button>
                      </td>
                    )}
                  </tr>
                  {conDetalle && (
                    <tr id={idDetalle} role="row" className="ay-tr__detail" hidden={!abierta}>
                      <td role="gridcell" colSpan={totalColumnas}>
                        {abierta ? expandedRow?.(fila) : null}
                      </td>
                    </tr>
                  )}
                  </Fragment>
                )
              })
            )}
          </tbody>
        </table>
      </div>

      <p id={idPista} className="ay-visually-hidden">
        Pulsa Enter para editar la celda
      </p>
      <p className="ay-visually-hidden" aria-live="polite">
        {loading ? 'Cargando las filas' : textoSeleccion}
      </p>
      <p className="ay-visually-hidden" role="status">
        {aviso}
      </p>
    </>
  )
}

function textoCrudo(valor: unknown): string {
  return valor === null || valor === undefined ? '' : String(valor)
}

/** Campo de edición dentro de la celda. Enter confirma, Escape cancela; salir confirma. */
function EditorDeCelda({
  inicial,
  etiqueta,
  alConfirmar,
  alCancelar,
}: {
  inicial: string
  etiqueta: string
  alConfirmar: (valor: string, devolverFoco: boolean) => void
  alCancelar: () => void
}) {
  const campo = useRef<HTMLInputElement>(null)
  const resuelto = useRef(false)
  useEffect(() => {
    campo.current?.focus()
    campo.current?.select()
  }, [])
  return (
    <input
      ref={campo}
      className="ay-grid__editor"
      defaultValue={inicial}
      aria-label={etiqueta}
      onKeyDown={(evento) => {
        // Dentro del editor las flechas mueven el cursor del texto, no la celda activa.
        evento.stopPropagation()
        if (evento.key === 'Enter') {
          evento.preventDefault()
          resuelto.current = true
          alConfirmar(evento.currentTarget.value, true)
        } else if (evento.key === 'Escape') {
          evento.preventDefault()
          resuelto.current = true
          alCancelar()
        }
      }}
      onBlur={(evento) => {
        if (resuelto.current) return
        resuelto.current = true
        alConfirmar(evento.currentTarget.value, false)
      }}
    />
  )
}

/**
 * Rejilla para trabajar sobre registros: seleccionar, ordenar, editar en celda y recorrer
 * con el teclado celda a celda. Es `role="grid"` con una sola parada de tabulación: las
 * flechas mueven la celda activa, Inicio y Fin van a los extremos de la fila (con Control,
 * de la rejilla), Space alterna la fila y Enter entra en edición. Si solo se leen datos,
 * Table pesa mucho menos.
 */
export const DataGrid = forwardRef(RejillaInterna) as <T = Record<string, unknown>>(
  props: PropsDataGrid<T> & { ref?: Ref<HTMLDivElement> },
) => ReactElement | null

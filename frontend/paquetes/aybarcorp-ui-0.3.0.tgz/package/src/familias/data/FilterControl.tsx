import { forwardRef, useEffect, useId, useLayoutEffect, useRef, useState } from 'react'
import type { HTMLAttributes, KeyboardEvent as EventoTeclado, Ref } from 'react'
import { cx } from '../../utiles.js'
import { anclarEnCapaSuperior } from '../surfaces/_capa.js'
import { IconoCerrar, IconoChevron, SpinnerPequeno } from './_iconos.js'
import { normalizar, useAnuncioAgrupado } from './_internos.js'

export type FilterType = 'multi' | 'single' | 'range' | 'boolean'
export type FilterApplyMode = 'immediate' | 'explicit'
export type FilterSize = 'sm' | 'md'

/** Una opción del filtro, con su recuento opcional. */
export interface FilterOption {
  value: string
  label: string
  /** Registros que quedarían con esta opción: va en la etiqueta, «Disponible (128)». */
  count?: number
}

/** Valor aplicado según el tipo: varios valores, uno, un rango o un booleano. */
export type FilterValue = string[] | string | [number, number] | boolean

export interface PropsFilterControl
  extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'defaultValue'> {
  /** Nombre del atributo: «Estado», «Promoción». El disparador muestra «Estado: 2». */
  label: string
  /** `multi` con casillas (por defecto), `single` con radios, `range` con dos campos y
   *  `boolean`, que alterna sin superficie desplegable. */
  type?: FilterType
  /** Opciones. Sin ninguna posible, el filtro se deshabilita y dice por qué junto al
   *  disparador, en lugar de abrir una superficie vacía. */
  options?: FilterOption[]
  /** Valor aplicado. Si se omite, el filtro lleva su propio estado. Un valor que ya no
   *  existe entre las opciones se conserva visible con aviso, no se descarta en silencio. */
  value?: FilterValue
  /** Cambio de valor. Al quitar el filtro llega `[]` en `multi` y `undefined` en el resto. */
  onValueChange?: (value: FilterValue | undefined) => void
  /** Buscador de opciones dentro de la superficie, para listas de más de diez. */
  searchable?: boolean
  /** `immediate` aplica al elegir; `explicit` aplica al confirmar con «Aplicar», y Escape
   *  cierra sin aplicar. */
  applyMode?: FilterApplyMode
  /** Opciones cargando: Spinner dentro de la superficie. */
  loading?: boolean
  /** `sm` en Table Toolbar; `md` en Filter Panel. */
  size?: FilterSize
  /** Resultados tras aplicar. Se anuncia en una live region polite (agrupado en el modo
   *  inmediato, una vez al confirmar en el explícito). */
  resultCount?: number
}

const esListaDeTexto = (v: unknown): v is string[] => Array.isArray(v) && v.every((x) => typeof x === 'string')
const esRango = (v: unknown): v is [number, number] =>
  Array.isArray(v) && v.length === 2 && v.every((x) => typeof x === 'number')

/**
 * Filtra por un atributo y deja visible el valor aplicado, con una forma clara de quitarlo.
 * El disparador declara `aria-expanded` y `aria-haspopup` y su nombre accesible incluye el
 * valor («Estado, 2 valores aplicados»). Las opciones son casillas o radios reales en un
 * grupo con nombre: no son comandos, así que no hay `role="menu"`.
 */
export const FilterControl = forwardRef<HTMLDivElement, PropsFilterControl>(function FilterControl(
  {
    label,
    type = 'multi',
    options = [],
    value,
    onValueChange,
    searchable = false,
    applyMode = 'immediate',
    loading = false,
    size = 'sm',
    resultCount,
    ...resto
  },
  ref,
) {
  const id = useId()
  const idSuperficie = `${id}-superficie`
  const idNota = `${id}-nota`
  const opciones = options ?? []
  const disparador = useRef<HTMLButtonElement>(null)
  const raiz = useRef<HTMLDivElement | null>(null)
  const superficie = useRef<HTMLDivElement | null>(null)
  const [abierto, setAbierto] = useState(false)
  const [consulta, setConsulta] = useState('')

  // Controlado si llega `value`. El estado interno se mantiene a la par para que, si el
  // consumidor vuelve a `undefined` (filtro quitado desde fuera), el disparador lo refleje.
  const [interno, setInterno] = useState<FilterValue | undefined>(value)
  const valorPrevio = useRef(value)
  useEffect(() => {
    if (valorPrevio.current !== undefined && value === undefined) setInterno(undefined)
    valorPrevio.current = value
  }, [value])
  const actual = value !== undefined ? value : interno
  const [borrador, setBorrador] = useState<FilterValue | undefined>(actual)
  const explicito = applyMode === 'explicit' && type !== 'boolean'
  const enEdicion = explicito && abierto ? borrador : actual

  const aplicar = (nuevo: FilterValue | undefined) => {
    setInterno(nuevo)
    onValueChange?.(nuevo)
  }
  const vacio: FilterValue | undefined = type === 'multi' ? [] : type === 'boolean' ? false : undefined
  const cambiar = (nuevo: FilterValue | undefined) => (explicito ? setBorrador(nuevo) : aplicar(nuevo))

  const aListaDe = (v: FilterValue | undefined): string[] =>
    esListaDeTexto(v) ? v : typeof v === 'string' && v !== '' ? [v] : []
  const aplicados = type === 'multi' || type === 'single' ? aListaDe(actual) : []
  const marcados = aListaDe(enEdicion)
  const rango = type === 'range' && esRango(actual) ? actual : undefined
  const activo = type === 'boolean' ? actual === true : type === 'range' ? rango !== undefined : aplicados.length > 0

  const etiquetaDe = (v: string) => opciones.find((o) => o.value === v)?.label ?? v
  const resumen =
    type === 'range' && rango
      ? `${label}: ${rango[0]}–${rango[1]}`
      : aplicados.length === 0
        ? label
        : aplicados.length === 1
          ? `${label}: ${etiquetaDe(aplicados[0] as string)}`
          : `${label}: ${aplicados.length}`
  const nombre =
    type === 'range'
      ? rango
        ? `${label}, de ${rango[0]} a ${rango[1]}`
        : label
      : aplicados.length === 0
        ? label
        : `${label}, ${aplicados.length} ${aplicados.length === 1 ? 'valor aplicado' : 'valores aplicados'}`

  // Sin opciones posibles (y nada aplicado que quitar): deshabilitado y explicado.
  const sinOpciones = (type === 'multi' || type === 'single') && !loading && opciones.length === 0 && aplicados.length === 0
  // Valores aplicados que ya no están entre las opciones: visibles, con aviso.
  const huerfanos = aplicados.filter((v) => !opciones.some((o) => o.value === v))
  const visibles = consulta
    ? opciones.filter((o) => normalizar(o.label).includes(normalizar(consulta)))
    : opciones

  const anuncio = useAnuncioAgrupado(resultCount == null ? null : `${resultCount} resultados`, explicito ? 0 : 700)

  const abrir = () => {
    setBorrador(actual)
    setAbierto(true)
  }
  const cerrar = (devolverFoco: boolean) => {
    setAbierto(false)
    setConsulta('')
    if (devolverFoco) disparador.current?.focus()
  }
  const limpiar = () => {
    aplicar(vacio)
    setBorrador(vacio)
    // El control pulsado desaparece: el foco vuelve al disparador, que no se mueve.
    disparador.current?.focus()
  }

  // Abierta, la superficie sube a la capa superior bajo el disparador: allí no la tapa una
  // cabecera pegajosa ni la recorta el overflow de la barra de la tabla. Antes de que el foco
  // entre en sus opciones. Sin la API sigue anclada con la hoja.
  useLayoutEffect(() => {
    if (!abierto || !superficie.current || !raiz.current) return
    return anclarEnCapaSuperior(superficie.current, raiz.current, { separacion: '--aybar-space-1' })
  }, [abierto])

  // Un clic fuera cierra la superficie; en el modo explícito, sin aplicar.
  useEffect(() => {
    if (!abierto) return
    const fuera = (evento: PointerEvent) => {
      if (raiz.current && !raiz.current.contains(evento.target as Node)) cerrar(false)
    }
    document.addEventListener('pointerdown', fuera)
    return () => document.removeEventListener('pointerdown', fuera)
  })

  const moverEntreOpciones = (evento: EventoTeclado<HTMLElement>, paso: 1 | -1 | 0) => {
    const campos = Array.from(
      raiz.current?.querySelectorAll<HTMLInputElement>(
        '.ay-filter__surface input[type="checkbox"], .ay-filter__surface input[type="radio"]',
      ) ?? [],
    )
    if (campos.length === 0) return
    evento.preventDefault()
    const actualIndice = campos.indexOf(document.activeElement as HTMLInputElement)
    const siguiente = paso === 0 ? 0 : Math.min(campos.length - 1, Math.max(0, actualIndice + paso))
    campos[siguiente]?.focus()
  }

  const refRaiz = (nodo: HTMLDivElement | null) => {
    raiz.current = nodo
    if (typeof ref === 'function') ref(nodo)
    else if (ref) (ref as { current: HTMLDivElement | null }).current = nodo
  }

  if (type === 'boolean') {
    return (
      <div {...resto} ref={refRaiz as Ref<HTMLDivElement>} className={cx('ay-filter', `ay-filter--${size}`)}>
        <button
          ref={disparador}
          type="button"
          className={cx('ay-filter__trigger', activo && 'ay-filter__trigger--applied')}
          aria-pressed={activo}
          onClick={() => aplicar(!activo)}
          onKeyDown={(evento) => {
            if (evento.key === 'Delete' && activo) limpiar()
          }}
        >
          {label}
        </button>
        <p className="ay-visually-hidden" aria-live="polite">
          {anuncio}
        </p>
      </div>
    )
  }

  return (
    <div {...resto} ref={refRaiz as Ref<HTMLDivElement>} className={cx('ay-filter', `ay-filter--${size}`)}>
      <button
        ref={disparador}
        type="button"
        className={cx('ay-filter__trigger', activo && 'ay-filter__trigger--applied')}
        aria-expanded={abierto}
        aria-haspopup="true"
        aria-controls={idSuperficie}
        aria-label={nombre}
        aria-describedby={sinOpciones ? idNota : undefined}
        disabled={sinOpciones}
        title={sinOpciones ? 'Sin valores disponibles con los filtros actuales' : undefined}
        onClick={() => (abierto ? cerrar(false) : abrir())}
        onKeyDown={(evento) => {
          if (evento.key === 'Delete' && activo) {
            evento.preventDefault()
            limpiar()
          } else if (evento.key === 'Escape' && abierto) {
            evento.preventDefault()
            cerrar(true)
          } else if (evento.key === 'ArrowDown' && abierto) {
            moverEntreOpciones(evento, 0)
          }
        }}
      >
        {resumen}
        <IconoChevron direccion="abajo" className="ay-filter__chevron" />
      </button>

      {activo && (
        <button
          type="button"
          className="ay-iconbtn ay-iconbtn--ghost ay-iconbtn--sm ay-filter__clear"
          aria-label={`Quitar el filtro de ${label.toLowerCase()}`}
          onClick={limpiar}
        >
          <IconoCerrar />
        </button>
      )}

      {sinOpciones && (
        <span id={idNota} className="ay-filter__note">
          Sin valores disponibles con los filtros actuales
        </span>
      )}

      <div
        ref={superficie}
        className="ay-filter__surface"
        id={idSuperficie}
        hidden={!abierto}
        onKeyDown={(evento) => {
          // Las flechas recorren las casillas y los radios sin marcarlos; Space marca.
          // En el buscador y en los campos de rango las flechas son del propio campo.
          const tipo = (evento.target as HTMLElement).getAttribute('type')
          const enOpcion = tipo === 'checkbox' || tipo === 'radio'
          if (evento.key === 'Escape') {
            evento.preventDefault()
            cerrar(true)
          } else if (evento.key === 'ArrowDown' && enOpcion) {
            moverEntreOpciones(evento, 1)
          } else if (evento.key === 'ArrowUp' && enOpcion) {
            moverEntreOpciones(evento, -1)
          }
        }}
      >
        {searchable && type !== 'range' && (
          <div className="ay-search ay-search--sm ay-filter__search">
            <label className="ay-visually-hidden" htmlFor={`${id}-buscar`}>
              {`Buscar en ${label.toLowerCase()}`}
            </label>
            <input
              id={`${id}-buscar`}
              className="ay-search__field"
              type="search"
              value={consulta}
              onChange={(evento) => setConsulta(evento.currentTarget.value)}
            />
          </div>
        )}

        {loading ? (
          <div className="ay-spinner-row" role="status">
            <SpinnerPequeno />
            <span className="ay-spinner__text">Cargando las opciones</span>
          </div>
        ) : type === 'range' ? (
          <fieldset>
            <legend className="ay-visually-hidden">{`Filtrar por ${label.toLowerCase()}`}</legend>
            <CamposDeRango
              id={id}
              valor={esRango(enEdicion) ? enEdicion : undefined}
              alCambiar={(nuevo) => cambiar(nuevo)}
            />
          </fieldset>
        ) : (
          <fieldset>
            <legend className="ay-visually-hidden">{`Filtrar por ${label.toLowerCase()}`}</legend>
            {[...huerfanos.map((v) => ({ value: v, label: v, huerfano: true as const })), ...visibles].map((o) => (
              <label key={o.value} className={cx('ay-filter__option', 'huerfano' in o && 'ay-filter__option--missing')}>
                <input
                  type={type === 'single' ? 'radio' : 'checkbox'}
                  name={type === 'single' ? `${id}-opcion` : undefined}
                  checked={marcados.includes(o.value)}
                  onChange={(evento) => {
                    if (type === 'single') return cambiar(o.value)
                    const conjunto = new Set(marcados)
                    if (evento.currentTarget.checked) conjunto.add(o.value)
                    else conjunto.delete(o.value)
                    cambiar([...conjunto])
                  }}
                />
                {o.label}
                {'huerfano' in o ? (
                  <span className="ay-filter__count">(ya no disponible)</span>
                ) : (
                  o.count != null && <span className="ay-filter__count">({o.count})</span>
                )}
              </label>
            ))}
            {visibles.length === 0 && huerfanos.length === 0 && (
              <p className="ay-filter__empty">
                {consulta ? `Sin opciones para «${consulta}»` : 'Sin opciones disponibles'}
              </p>
            )}
          </fieldset>
        )}

        {explicito && (
          <div className="ay-filter__actions">
            <button type="button" className="ay-btn ay-btn--ghost ay-btn--sm" onClick={limpiar}>
              Limpiar
            </button>
            <button
              type="button"
              className="ay-btn ay-btn--primary ay-btn--sm"
              onClick={() => {
                aplicar(borrador)
                cerrar(true)
              }}
            >
              Aplicar
            </button>
          </div>
        )}
      </div>

      <p className="ay-visually-hidden" aria-live="polite">
        {anuncio}
      </p>
    </div>
  )
})

/** Dos campos «Desde» y «Hasta». El valor solo se emite cuando los dos son números. */
function CamposDeRango({
  id,
  valor,
  alCambiar,
}: {
  id: string
  valor: [number, number] | undefined
  alCambiar: (valor: [number, number] | undefined) => void
}) {
  const [desde, setDesde] = useState(valor ? String(valor[0]) : '')
  const [hasta, setHasta] = useState(valor ? String(valor[1]) : '')
  const emitir = (a: string, b: string) => {
    if (a === '' && b === '') return alCambiar(undefined)
    const numA = Number(a)
    const numB = Number(b)
    if (a !== '' && b !== '' && Number.isFinite(numA) && Number.isFinite(numB)) {
      alCambiar([Math.min(numA, numB), Math.max(numA, numB)])
    }
  }
  return (
    <div className="ay-filter__range">
      <label className="ay-filter__rangefield">
        <span>Desde</span>
        <input
          id={`${id}-desde`}
          type="number"
          inputMode="decimal"
          value={desde}
          onChange={(evento) => {
            setDesde(evento.currentTarget.value)
            emitir(evento.currentTarget.value, hasta)
          }}
        />
      </label>
      <label className="ay-filter__rangefield">
        <span>Hasta</span>
        <input
          id={`${id}-hasta`}
          type="number"
          inputMode="decimal"
          value={hasta}
          onChange={(evento) => {
            setHasta(evento.currentTarget.value)
            emitir(desde, evento.currentTarget.value)
          }}
        />
      </label>
    </div>
  )
}

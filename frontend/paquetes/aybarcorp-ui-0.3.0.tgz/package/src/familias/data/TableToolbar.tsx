import { forwardRef, useEffect, useRef, useState } from 'react'
import type { HTMLAttributes, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { useAnuncioAgrupado } from './_internos.js'

export interface PropsTableToolbar extends Omit<HTMLAttributes<HTMLDivElement>, 'className'> {
  /** Búsqueda: un Search Input que declara su alcance («Buscar unidades»). */
  search?: ReactNode
  /** Controles de filtro (Filter Control), uno por atributo. */
  filters?: ReactNode
  /** Acciones generales: crear, importar, exportar. Sin permiso para crear, no se pasa. */
  actions?: ReactNode
  /** Filas seleccionadas. Con más de cero, la barra de selección sustituye a la normal con
   *  el mismo alto, y el cambio se anuncia; el foco no se mueve a ella. */
  selectionCount?: number
  /** Acciones en lote. Solo existen con selección y nombran el alcance en su etiqueta:
   *  «Exportar 4 unidades», no «Exportar». */
  selectionActions?: ReactNode
  /** Vacía la selección («Quitar la selección»). */
  onClearSelection?: () => void
  /** Resultados tras buscar y filtrar. Se anuncia agrupado, cuando se deja de teclear. */
  resultCount?: number
  /** Nombre de la entidad para el recuento: «12 unidades». */
  itemLabel?: string
}

/**
 * Reúne sobre una tabla la búsqueda, los filtros y las acciones, incluidas las que operan
 * sobre la selección. Es un `toolbar` con nombre; con filas marcadas se convierte en la
 * barra de selección. La live region está siempre en el DOM (vacía al cargar) para que el
 * primer anuncio no se pierda.
 */
export const TableToolbar = forwardRef<HTMLDivElement, PropsTableToolbar>(function TableToolbar(
  {
    search,
    filters,
    actions,
    selectionCount = 0,
    selectionActions,
    onClearSelection,
    resultCount,
    itemLabel = 'elementos',
    'aria-label': etiqueta,
    ...resto
  },
  ref,
) {
  const conSeleccion = selectionCount > 0
  const [anuncio, setAnuncio] = useState('')
  const seleccionPrevia = useRef(selectionCount)

  // Las acciones de la barra se sustituyen por completo al marcar: sin el aviso, quien no
  // la ve seguiría buscando «Exportar» donde ya no está.
  useEffect(() => {
    if (seleccionPrevia.current === selectionCount) return
    seleccionPrevia.current = selectionCount
    setAnuncio(selectionCount > 0 ? `${selectionCount} ${itemLabel} en la selección` : 'Selección vacía')
  }, [selectionCount, itemLabel])

  // El recuento se agrupa: se anuncia cuando deja de cambiar, no en cada pulsación.
  const anuncioRecuento = useAnuncioAgrupado(resultCount == null ? null : `${resultCount} ${itemLabel}`)
  useEffect(() => {
    if (anuncioRecuento) setAnuncio(anuncioRecuento)
  }, [anuncioRecuento])

  return (
    <>
      {conSeleccion ? (
        <div
          {...resto}
          ref={ref}
          role="toolbar"
          aria-label={etiqueta ?? 'Acciones sobre la selección'}
          className={cx('ay-toolbar', 'ay-toolbar--selection')}
        >
          <p className="ay-toolbar__selcount">{selectionCount} seleccionadas</p>
          {selectionActions}
          <button type="button" className="ay-btn ay-btn--ghost ay-btn--sm" onClick={() => onClearSelection?.()}>
            Quitar la selección
          </button>
        </div>
      ) : (
        <div
          {...resto}
          ref={ref}
          role="toolbar"
          aria-label={etiqueta ?? `Acciones sobre ${itemLabel}`}
          className="ay-toolbar"
        >
          {search}
          {filters}
          {resultCount != null && (
            <p className="ay-toolbar__count">
              {resultCount} {itemLabel}
            </p>
          )}
          {actions}
        </div>
      )}
      <p className="ay-visually-hidden" aria-live="polite">
        {anuncio}
      </p>
    </>
  )
})

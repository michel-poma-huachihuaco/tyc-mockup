/**
 * Piezas internas de la familia Data. No se exportan desde el índice: no son API, son
 * el pegamento que comparten Table, Data Grid, Table Row y Tree View.
 */
import { createContext, useCallback, useEffect, useRef, useState } from 'react'

/**
 * Estado controlado o no controlado con una sola firma. Si el consumidor pasa el valor,
 * manda el consumidor; si lo deja en `undefined` (o en `null`, que es como llega un valor
 * ausente desde el catálogo JSON), el componente lleva su propio estado. En los dos casos
 * se notifica el cambio.
 */
export function useControlable<T>(
  controlado: T | undefined | null,
  inicial: T,
  alCambiar?: ((valor: T) => void) | null,
): [T, (valor: T) => void] {
  const [interno, setInterno] = useState<T>(inicial)
  const esControlado = controlado !== undefined && controlado !== null
  const valor = esControlado ? (controlado as T) : interno
  const cambiar = useCallback(
    (nuevo: T) => {
      if (!esControlado) setInterno(nuevo)
      alCambiar?.(nuevo)
    },
    [esControlado, alCambiar],
  )
  return [valor, cambiar]
}

/**
 * Texto para una live region que se agrupa: el anuncio solo se escribe cuando el valor
 * deja de cambiar durante `espera` milisegundos. Anunciar en cada pulsación interrumpe
 * la lectura con cifras que dejan de ser ciertas antes de terminar de oírse.
 * El primer valor no se anuncia: lo que ya estaba al cargar no es un cambio.
 */
export function useAnuncioAgrupado(texto: string | null, espera = 700): string {
  const [anuncio, setAnuncio] = useState('')
  const primero = useRef(true)
  useEffect(() => {
    if (primero.current) {
      primero.current = false
      return
    }
    if (texto === null) return
    const temporizador = setTimeout(() => setAnuncio(texto), espera)
    return () => clearTimeout(temporizador)
  }, [texto, espera])
  return anuncio
}

/** Lo que una Table Row ofrece a sus Table Cell: el destino de la fila navegable. */
export interface ContextoDeFila {
  href?: string
}
export const ContextoFila = createContext<ContextoDeFila | null>(null)

/** Una celda vacía lleva guion: el blanco no se anuncia y parece un fallo de carga. 0 es un dato. */
export function textoDeCelda(valor: unknown): string {
  if (valor === null || valor === undefined || valor === '') return '—'
  return String(valor)
}

/** Comparación para el orden local (sin servidor): números como números y texto según el idioma. */
export function comparar(a: unknown, b: unknown): number {
  const vacioA = a === null || a === undefined || a === ''
  const vacioB = b === null || b === undefined || b === ''
  // Los vacíos van siempre al final, en los dos sentidos: así se mantiene dónde están.
  if (vacioA || vacioB) return vacioA === vacioB ? 0 : vacioA ? 1 : -1
  if (typeof a === 'number' && typeof b === 'number') return a - b
  return String(a).localeCompare(String(b), 'es', { numeric: true, sensitivity: 'base' })
}

/** Normaliza para buscar sin distinguir mayúsculas ni tildes: «Miraflores» encuentra «miraflores». */
export function normalizar(texto: string): string {
  return texto.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase()
}

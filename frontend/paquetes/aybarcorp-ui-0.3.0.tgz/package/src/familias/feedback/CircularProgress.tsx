import { forwardRef } from 'react'
import type { CSSProperties, HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import { porcentaje } from './_internos.js'

export type TamanoCircularProgress = 'sm' | 'md' | 'lg'
export type TonoCircularProgress = 'brand' | 'success' | 'warning' | 'danger'

export interface PropsCircularProgress extends Omit<HTMLAttributes<HTMLDivElement>, 'className'> {
  /** Avance de 0 a 100, redondeado y recortado; `null` lo hace indeterminado, sin
   *  `aria-valuenow`: un 0% que no se mueve hace creer que la operación se colgó. */
  value: number | null
  /** Nombre de la operación, no de la forma: «Subiendo el plano», no «Círculo de
   *  progreso». Obligatorio: es el nombre accesible. */
  label: string
  /** Diámetro: `sm` (`space.5`, sin cifra), `md` (`space.10`) o `lg` (`space.16`, con
   *  cifra y etiqueta debajo). Varios círculos en una lista comparten tamaño para poder
   *  compararse. */
  size?: TamanoCircularProgress
  /** Cifra central. Por defecto en `md` y `lg`; en `sm` no cabe y el valor vive en ARIA
   *  —si sirve para decidir algo, se escribe al lado—. */
  showValue?: boolean
  /** Tono del arco. Un umbral de ocupación no se comunica solo con color: el valor y el
   *  umbral se escriben («85% · por encima del objetivo»). */
  tone?: TonoCircularProgress
}

/**
 * Avance en formato compacto y cuadrado, cuando no hay ancho para una barra. El arco es
 * SVG con `stroke-dasharray`: nítido al escalar y visible en forced-colors. Si hay ancho,
 * Progress Bar se lee mejor; si no hay valor, Spinner.
 */
export const CircularProgress = forwardRef<HTMLDivElement, PropsCircularProgress>(function CircularProgress(
  { value, label, size = 'md', showValue, tone = 'brand', ...resto },
  ref,
) {
  const pct = porcentaje(value)
  const conCifra = showValue ?? size !== 'sm'

  return (
    <div
      {...resto}
      ref={ref}
      className={cx('ay-circ', `ay-circ--${size}`, `ay-circ--${tone}`, pct === null && 'ay-circ--indeterminate')}
      role="progressbar"
      aria-label={label}
      aria-valuenow={pct ?? undefined}
      aria-valuemin={pct === null ? undefined : 0}
      aria-valuemax={pct === null ? undefined : 100}
    >
      <svg viewBox="0 0 36 36" aria-hidden="true">
        <circle className="ay-circ__track" cx="18" cy="18" r="15.5" />
        {/* Con 0 no se pinta el arco: el remate redondeado dejaría un punto. */}
        {pct !== 0 && (
          <circle
            className="ay-circ__fill"
            cx="18"
            cy="18"
            r="15.5"
            style={pct === null ? undefined : ({ '--ay-dash': pct } as CSSProperties)}
          />
        )}
      </svg>
      {conCifra && pct !== null && <span className="ay-circ__value">{pct}%</span>}
    </div>
  )
})

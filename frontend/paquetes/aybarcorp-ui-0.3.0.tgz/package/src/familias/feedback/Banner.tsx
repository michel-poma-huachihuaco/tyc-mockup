import { forwardRef, useId, useRef, useState } from 'react'
import type { HTMLAttributes, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { IconoCerrar, IconoTono } from './_iconos.js'
import { enfocarSiguiente, hayContenido, unirRefs } from './_internos.js'

export type TonoBanner = 'info' | 'warning' | 'danger' | 'brand'
export type TamanoBanner = 'sm' | 'md'

export interface PropsBanner
  extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'children'>,
    Required<Pick<HTMLAttributes<HTMLDivElement>, 'children'>> {
  /** Tono del aviso: `info` para avisos neutros, `warning` para degradaciones de
   *  servicio, `danger` para caídas o pérdidas de datos, `brand` para anuncios de
   *  producto. La severidad va escrita en la frase, no solo en el color. */
  tone?: TonoBanner
  /** Acción de texto —un Link o un Button de texto— con un verbo concreto: «Ver los
   *  detalles». En pantallas estrechas pasa bajo el mensaje. */
  action?: ReactNode
  /** Hace el aviso descartable y se llama al cerrarlo; el foco pasa al contenido
   *  siguiente. No se ofrece mientras la condición sigue activa (solo lectura, caída). */
  onDismiss?: () => void
  /** Identidad del aviso para recordar el descarte entre sesiones. Si el aviso cambia de
   *  contenido, cambia la clave y vuelve a mostrarse. */
  dismissKey?: string
  /** Altura: `md` con padding vertical `space.3`; `sm` con `space.2`, para avisos
   *  persistentes de baja prioridad. */
  size?: TamanoBanner
}

const PREFIJO_CLAVE = 'ay-banner:'

/** `localStorage` puede no existir (SSR) o lanzar (modo privado, cuota): nunca rompe el aviso. */
function leerDescarte(clave: string | undefined): boolean {
  if (!clave || typeof window === 'undefined') return false
  try {
    return window.localStorage.getItem(`${PREFIJO_CLAVE}${clave}`) === '1'
  } catch {
    return false
  }
}

function guardarDescarte(clave: string | undefined): void {
  if (!clave || typeof window === 'undefined') return
  try {
    window.localStorage.setItem(`${PREFIJO_CLAVE}${clave}`, '1')
  } catch {
    // Sin almacenamiento el descarte dura lo que la sesión de la página.
  }
}

/**
 * Aviso de alcance global anclado bajo el Navbar: mantenimiento programado, modo de solo
 * lectura, una incidencia que afecta a todo el producto. Empuja el contenido en lugar de
 * taparlo, se anuncia con `role="status"` y no se imprime. Como máximo uno visible: el
 * de mayor severidad. Si el aviso es de una sección, es Alert.
 */
export const Banner = forwardRef<HTMLDivElement, PropsBanner>(function Banner(
  { tone = 'info', action, onDismiss, dismissKey, size = 'md', children, ...resto },
  ref,
) {
  const raiz = useRef<HTMLDivElement | null>(null)
  const idMensaje = useId()
  // La identidad del aviso decide si un descarte previo sigue valiendo.
  const [descarte, setDescarte] = useState(() => ({ clave: dismissKey, descartado: leerDescarte(dismissKey) }))
  if (descarte.clave !== dismissKey) setDescarte({ clave: dismissKey, descartado: leerDescarte(dismissKey) })
  if (descarte.descartado && descarte.clave === dismissKey) return null

  const cerrar = () => {
    guardarDescarte(dismissKey)
    enfocarSiguiente(raiz.current)
    setDescarte({ clave: dismissKey, descartado: true })
    onDismiss?.()
  }

  return (
    <div
      {...resto}
      ref={unirRefs(ref, raiz)}
      className={cx('ay-banner', `ay-banner--${tone}`, `ay-banner--${size}`)}
      role="status"
      aria-live="polite"
    >
      <div className="ay-banner__inner">
        <IconoTono tono={tone} lado={20} className="ay-banner__icon" />
        <p className="ay-banner__message" id={idMensaje}>
          {children}
        </p>
        {hayContenido(action) && <span className="ay-banner__action">{action}</span>}
        {onDismiss !== undefined && (
          <button
            type="button"
            className="ay-iconbtn ay-iconbtn--ghost ay-iconbtn--sm"
            aria-label="Cerrar el aviso"
            // El nombre dice qué se cierra: el lector lee el aviso como descripción.
            aria-describedby={idMensaje}
            onClick={cerrar}
          >
            <IconoCerrar lado={16} className="ay-iconbtn__glyph" />
          </button>
        )}
      </div>
    </div>
  )
})

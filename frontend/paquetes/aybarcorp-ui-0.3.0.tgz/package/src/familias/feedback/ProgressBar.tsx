import { forwardRef, useEffect, useId, useRef, useState } from 'react'
import type { CSSProperties, HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'
import { porcentaje } from './_internos.js'

export type TamanoProgressBar = 'sm' | 'md'
export type TonoProgressBar = 'brand' | 'success' | 'danger'

export interface PropsProgressBar extends Omit<HTMLAttributes<HTMLDivElement>, 'className'> {
  /** Avance de 0 a 100, redondeado a entero y recortado a ese rango; `null` la hace
   *  indeterminada y entonces no lleva `aria-valuenow`: un valor inventado engaña. El
   *  avance no retrocede: un valor menor se ignora salvo que se reinicie a 0. */
  value: number | null
  /** Nombre de la operación, en gerundio: «Subiendo documentos», no «Progreso».
   *  Obligatorio: es el nombre accesible de la barra. */
  label: string
  /** Detalle bajo la barra: el recuento antes que el tiempo, «3 de 12 archivos». Al
   *  terminar o fallar, es el resultado que se anuncia. */
  detail?: string
  /** Altura: `md` por defecto; `sm` para la barra en línea dentro de una fila. */
  size?: TamanoProgressBar
  /** Tono del tramo. En error el tramo se queda donde estaba y el detalle dice qué
   *  falló: el color no puede ser la única pista. */
  tone?: TonoProgressBar
  /** Oculta la etiqueta visualmente, no del lector: pasa a `aria-label`. */
  hideLabel?: boolean
}

/** Hitos en los que se anuncia el avance: no se anuncia cada actualización. */
const PASO_HITO = 25

/**
 * Avance de una operación larga, con porcentaje conocido o sin él. El porcentaje va
 * escrito además de dibujado. El avance se anuncia en una live region que ya existe
 * vacía: al empezar, en cada cuarto y al terminar, con el detalle como resultado —llegar
 * al 100% no dice si entraron los doce archivos—. Si no hay avance medible, Spinner.
 */
export const ProgressBar = forwardRef<HTMLDivElement, PropsProgressBar>(function ProgressBar(
  { value, label, detail, size = 'md', tone = 'brand', hideLabel = false, ...resto },
  ref,
) {
  const id = useId()
  const pedido = porcentaje(value)

  // El progreso no retrocede: se queda en el máximo alcanzado salvo un reinicio a 0.
  const [maximo, setMaximo] = useState<number | null>(pedido)
  const pct = pedido !== null && maximo !== null && pedido < maximo && pedido !== 0 ? maximo : pedido
  if (pct !== maximo) setMaximo(pct)

  const anuncio = useAnuncioDeAvance(label, pct, tone, detail)

  return (
    <div {...resto} ref={ref} className={cx('ay-progress', `ay-progress--${size}`)}>
      {!hideLabel && (
        <div className="ay-progress__head">
          <span className="ay-progress__label" id={id}>
            {label}
          </span>
          {pct !== null && <span className="ay-progress__value">{pct}%</span>}
        </div>
      )}
      <div
        className={cx(
          'ay-progress__track',
          `ay-progress__track--${tone}`,
          pct === null && 'ay-progress__track--indeterminate',
        )}
        role="progressbar"
        aria-labelledby={hideLabel ? undefined : id}
        aria-label={hideLabel ? label : undefined}
        aria-valuenow={pct ?? undefined}
        aria-valuemin={pct === null ? undefined : 0}
        aria-valuemax={pct === null ? undefined : 100}
      >
        <div
          className="ay-progress__fill"
          style={pct === null ? undefined : ({ '--ay-value': `${pct}%` } as CSSProperties)}
        />
      </div>
      {detail && <p className="ay-progress__detail">{detail}</p>}
      <span className="ay-visually-hidden" aria-live="polite">
        {anuncio}
      </span>
    </div>
  )
})

/**
 * Texto de la live region: cambia al empezar, al cruzar cada hito, al terminar y al
 * fallar. Entre hitos no cambia, y una live region que no cambia no se anuncia.
 */
function useAnuncioDeAvance(
  label: string,
  pct: number | null,
  tone: TonoProgressBar,
  detail: string | undefined,
): string {
  const [anuncio, setAnuncio] = useState('')
  const ultimo = useRef<string | null>(null)
  const tramo =
    tone === 'danger' ? 'error' : pct === null ? 'en-curso' : pct >= 100 ? 'fin' : String(Math.floor(pct / PASO_HITO))

  useEffect(() => {
    if (ultimo.current === tramo) return
    ultimo.current = tramo
    const resultado = detail ? `. ${detail}` : ''
    if (tramo === 'error') setAnuncio(`${label}: se detuvo${pct === null ? '' : ` en ${pct}%`}${resultado}`)
    else if (tramo === 'fin') setAnuncio(`${label}: 100%${resultado}`)
    else setAnuncio(pct === null ? label : `${label}: ${pct}%`)
  }, [tramo, label, pct, detail])

  return anuncio
}

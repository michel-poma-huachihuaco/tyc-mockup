/**
 * Ayudantes internos de la familia Feedback. No se exportan desde el índice: no son API.
 */
import { useSyncExternalStore } from 'react'
import type { ForwardedRef, RefCallback } from 'react'

/** Une la ref que llega por `forwardRef` con la que el componente necesita para sí. */
export function unirRefs<T>(...refs: (ForwardedRef<T> | { current: T | null } | undefined)[]): RefCallback<T> {
  return (nodo) => {
    for (const ref of refs) {
      if (typeof ref === 'function') ref(nodo)
      else if (ref) ref.current = nodo
    }
  }
}

/** Avance de 0 a 100, redondeado y recortado; `null` cuando no se conoce. */
export function porcentaje(valor: number | null | undefined): number | null {
  if (valor === null || valor === undefined || Number.isNaN(valor)) return null
  return Math.min(100, Math.max(0, Math.round(valor)))
}

/** Un `children` que pinta algo: ni `undefined`, ni `null`, ni `false`, ni cadena vacía. */
export function hayContenido(valor: unknown): boolean {
  return valor !== undefined && valor !== null && valor !== false && valor !== ''
}

/** Elementos que reciben foco sin necesitar `tabindex`. */
const ENFOCABLE_NATIVO = 'a[href], button, input, select, textarea, summary, [tabindex]'

/**
 * El primer ancestro con caja propia. Un `display: contents` —el span donde monta
 * `@aybarcorp/ui-elements`, el anfitrión de un componente Angular— no puede recibir el
 * foco aunque tenga `tabindex`, así que se salta.
 */
function ancestroConCaja(desde: Element | null): HTMLElement | null {
  let nodo = desde?.parentElement ?? null
  while (nodo && nodo !== document.body) {
    if (getComputedStyle(nodo).display !== 'contents') return nodo
    nodo = nodo.parentElement
  }
  return nodo
}

/** Lleva el foco a `destino`, dándole `tabindex="-1"` si no lo admite por sí mismo. */
function enfocar(destino: HTMLElement | null): void {
  if (!destino) return
  if (!destino.matches(ENFOCABLE_NATIVO)) destino.setAttribute('tabindex', '-1')
  destino.focus({ preventScroll: true })
}

/** ¿El foco está dentro de `elemento`? Solo entonces tiene sentido moverlo al retirarlo. */
export function contieneFoco(elemento: Element | null): boolean {
  return !!elemento && typeof document !== 'undefined' && elemento.contains(document.activeElement)
}

/**
 * Al descartar un Alert el botón de cerrar desaparece con él. Si el foco se queda ahí,
 * el navegador lo devuelve al `<body>` y quien navega con teclado vuelve al principio
 * del documento; se lleva al contenedor, con `tabindex="-1"`, para que retome donde estaba.
 */
export function enfocarContenedor(elemento: Element | null): void {
  if (!contieneFoco(elemento)) return
  enfocar(ancestroConCaja(elemento))
}

/**
 * Al descartar un Banner el foco pasa al contenido que lo seguía: el hermano siguiente
 * o, si el Banner era el último de su contenedor, el siguiente de algún ancestro.
 */
export function enfocarSiguiente(elemento: Element | null): void {
  if (!contieneFoco(elemento)) return
  let nodo: Element | null = elemento
  while (nodo && !nodo.nextElementSibling) nodo = nodo.parentElement
  enfocar((nodo?.nextElementSibling as HTMLElement | null) ?? ancestroConCaja(elemento))
}

// ── Pestaña en segundo plano ──────────────────────────────────────────────────

function suscribirVisibilidad(avisar: () => void): () => void {
  document.addEventListener('visibilitychange', avisar)
  return () => document.removeEventListener('visibilitychange', avisar)
}

/** `true` mientras la pestaña está en segundo plano: los plazos no corren entonces. */
export function usePestanaOculta(): boolean {
  return useSyncExternalStore(
    suscribirVisibilidad,
    () => document.visibilityState === 'hidden',
    () => false,
  )
}

// ── Plazos que se pausan ──────────────────────────────────────────────────────

/**
 * Programa `alVencer` dentro de `plazo` ms, descontando el tiempo ya corrido cada vez
 * que se pausa. Reanudar no reinicia el plazo entero: la barra de tiempo visible del
 * Snackbar se congela con `animation-play-state` y tiene que coincidir con él.
 */
export class Plazo {
  #restante: number
  #inicio = 0
  #temporizador: ReturnType<typeof setTimeout> | undefined
  readonly #alVencer: () => void

  constructor(plazo: number, alVencer: () => void) {
    this.#restante = plazo
    this.#alVencer = alVencer
  }

  correr(): void {
    if (this.#temporizador !== undefined || this.#restante <= 0) return
    this.#inicio = Date.now()
    this.#temporizador = setTimeout(() => {
      this.#temporizador = undefined
      this.#restante = 0
      this.#alVencer()
    }, this.#restante)
  }

  pausar(): void {
    if (this.#temporizador === undefined) return
    clearTimeout(this.#temporizador)
    this.#temporizador = undefined
    this.#restante = Math.max(0, this.#restante - (Date.now() - this.#inicio))
  }
}

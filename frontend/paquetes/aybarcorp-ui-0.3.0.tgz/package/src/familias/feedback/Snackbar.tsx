import { forwardRef, useEffect, useRef, useState } from 'react'
import type { FocusEvent, HTMLAttributes, KeyboardEvent, MouseEvent } from 'react'
import { IconoCerrar } from './_iconos.js'
import { Plazo } from './_internos.js'

export interface PropsSnackbar extends Omit<HTMLAttributes<HTMLDivElement>, 'className'> {
  /** Acción realizada, en pasado y con su objeto: «Unidad 402 archivada». Con `count`
   *  se escribe en plural sin la cifra («unidades archivadas»): el contador la antepone. */
  message: string
  /** Deshace la acción. Muestra «Deshacer» mientras el plazo no haya caducado; al
   *  caducar la acción desaparece y el mensaje se queda. */
  onUndo?: () => void
  /** Plazo en ms para deshacer, seis segundos como mínimo; `0` lo hace persistente, para
   *  operaciones en lote. Se detiene con el foco o el ratón dentro. */
  duration?: number
  /** Repeticiones agrupadas: la acción repetida se cuenta en el mensaje en lugar de
   *  apilar Snackbars. */
  count?: number
  /** Muestra el plazo como una barra que se vacía, cuando el tiempo importa. */
  showTimer?: boolean
  /** Cierre manual: añade el botón de cerrar y hace que Escape lo descarte sin deshacer. */
  onDismiss?: () => void
}

/** Un deshacer que caduca antes de poder pulsarlo no existe. */
const PLAZO_MINIMO = 6000

/**
 * Confirma una acción ya hecha ofreciendo deshacerla, sin interrumpir: `role="status"`
 * y el foco nunca se mueve aquí. Uno visible a la vez. Si no hay nada que deshacer es
 * Toast; si la acción es irreversible se confirma antes, con Confirmation Dialog.
 */
export const Snackbar = forwardRef<HTMLDivElement, PropsSnackbar>(function Snackbar(
  {
    message,
    onUndo,
    duration = 6000,
    count,
    showTimer = false,
    onDismiss,
    onMouseEnter,
    onMouseLeave,
    onFocus,
    onBlur,
    onKeyDown,
    ...resto
  },
  ref,
) {
  const plazoMs = duration <= 0 ? 0 : Math.max(duration, PLAZO_MINIMO)
  const [caducado, setCaducado] = useState(false)
  const [apuntado, setApuntado] = useState(false)
  const [enfocado, setEnfocado] = useState(false)
  const pausado = apuntado || enfocado

  const plazo = useRef<Plazo | null>(null)
  useEffect(() => {
    setCaducado(false)
    plazo.current = new Plazo(plazoMs, () => setCaducado(true))
    return () => plazo.current?.pausar()
  }, [plazoMs])
  useEffect(() => {
    if (pausado) plazo.current?.pausar()
    else plazo.current?.correr()
  }, [pausado, plazoMs])

  const texto = count !== undefined && count > 1 ? `${count} ${message}` : message
  const descartable = onDismiss !== undefined

  return (
    <div
      {...resto}
      ref={ref}
      className="ay-snackbar"
      role="status"
      aria-live="polite"
      onMouseEnter={(e: MouseEvent<HTMLDivElement>) => {
        setApuntado(true)
        onMouseEnter?.(e)
      }}
      onMouseLeave={(e: MouseEvent<HTMLDivElement>) => {
        setApuntado(false)
        onMouseLeave?.(e)
      }}
      onFocus={(e: FocusEvent<HTMLDivElement>) => {
        setEnfocado(true)
        onFocus?.(e)
      }}
      onBlur={(e: FocusEvent<HTMLDivElement>) => {
        if (!e.currentTarget.contains(e.relatedTarget as Node | null)) setEnfocado(false)
        onBlur?.(e)
      }}
      onKeyDown={(e: KeyboardEvent<HTMLDivElement>) => {
        onKeyDown?.(e)
        if (e.key === 'Escape' && descartable && !e.defaultPrevented) {
          e.stopPropagation()
          onDismiss?.()
        }
      }}
    >
      <p className="ay-snackbar__message">{texto}</p>
      {onUndo !== undefined && !caducado && (
        <button type="button" className="ay-snackbar__action" onClick={() => onUndo?.()}>
          Deshacer
        </button>
      )}
      {showTimer && plazoMs > 0 && !caducado && (
        <span
          className="ay-snackbar__timer"
          aria-hidden="true"
          style={{ animationDuration: `${plazoMs}ms`, animationPlayState: pausado ? 'paused' : 'running' }}
        />
      )}
      {descartable && (
        <button
          type="button"
          className="ay-iconbtn ay-iconbtn--ghost ay-iconbtn--sm"
          aria-label="Cerrar la confirmación"
          onClick={() => onDismiss?.()}
        >
          <IconoCerrar lado={16} className="ay-iconbtn__glyph" />
        </button>
      )}
    </div>
  )
})

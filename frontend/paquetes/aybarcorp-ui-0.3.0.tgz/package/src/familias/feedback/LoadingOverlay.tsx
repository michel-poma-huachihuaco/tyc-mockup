import { forwardRef, useEffect, useRef, useState } from 'react'
import type { HTMLAttributes, KeyboardEvent } from 'react'
import { cx } from '../../utiles.js'
import { ArcoSpinner } from './_iconos.js'
import { contieneFoco, unirRefs } from './_internos.js'
import { ProgressBar } from './ProgressBar.js'

export interface PropsLoadingOverlay
  extends Omit<HTMLAttributes<HTMLElement>, 'className' | 'children' | 'onCancel'>,
    Required<Pick<HTMLAttributes<HTMLElement>, 'children'>> {
  /** Activa el bloqueo: la región queda `aria-busy`, su contenido `inert` —fuera del
   *  orden de tabulación, no solo atenuado— y el velo visible. Para operaciones de menos
   *  de 300 ms no se activa: el destello molesta más que la espera. */
  active?: boolean
  /** Qué se está haciendo, en gerundio y con el objeto: «Recalculando la cartera». Se
   *  anuncia en una live region dentro de la región. Obligatorio. */
  label: string
  /** Avance de 0 a 100: muestra una Progress Bar que se anuncia en hitos. `null` usa
   *  el Spinner. */
  progress?: number | null
  /** Acción de cancelar: añade el botón «Cancelar», que recibe el foco al activarse el
   *  bloqueo, y hace que Escape cancele. No se puede pulsar dos veces. */
  onCancel?: () => void
  /** Muestra el velo. Sin velo queda solo el indicador, cuando el contenido debajo debe
   *  poder leerse. */
  scrim?: boolean
}

/**
 * Bloquea temporalmente una región mientras se completa una operación que invalidaría
 * lo que se ve: recargar una tabla, guardar un formulario largo. Nunca la aplicación
 * entera. Al terminar, el foco vuelve a donde estaba si se había quedado sin sitio. Si
 * la operación falla, el velo se sustituye por un Alert dentro de la región.
 */
export const LoadingOverlay = forwardRef<HTMLElement, PropsLoadingOverlay>(function LoadingOverlay(
  { active = false, label, progress = null, onCancel, scrim = true, children, onKeyDown, ...resto },
  ref,
) {
  const region = useRef<HTMLElement | null>(null)
  const botonCancelar = useRef<HTMLButtonElement | null>(null)
  const previo = useRef<HTMLElement | null>(null)
  // Montar ya activo no es «activarse»: es la carga inicial de la vista, y llevar el foco
  // al botón de cancelar se lo quitaría a quien está en otra parte de la página.
  const estabaActivo = useRef(active)
  const [cancelando, setCancelando] = useState(false)
  const cancelable = onCancel !== undefined

  useEffect(() => {
    if (active && !estabaActivo.current) {
      const enfocado = document.activeElement
      previo.current = enfocado instanceof HTMLElement && enfocado !== document.body ? enfocado : null
      // Con cancelar, el foco va al botón; sin él, el foco no se mueve.
      botonCancelar.current?.focus()
    } else if (!active && estabaActivo.current) {
      setCancelando(false)
      const destino = previo.current
      previo.current = null
      // Solo si el foco se quedó sin sitio: en la región bloqueada o en el body. Si el
      // usuario se fue a otra parte durante la espera, no se le arrastra de vuelta.
      const perdido = document.activeElement === document.body || contieneFoco(region.current)
      if (destino?.isConnected && perdido) destino.focus()
    }
    estabaActivo.current = active
  }, [active])

  const cancelar = () => {
    if (cancelando) return
    setCancelando(true)
    onCancel?.()
  }

  return (
    <section
      {...resto}
      ref={unirRefs(ref, region)}
      className="ay-region"
      aria-busy={active || undefined}
      onKeyDown={(e: KeyboardEvent<HTMLElement>) => {
        onKeyDown?.(e)
        if (active && cancelable && e.key === 'Escape' && !e.defaultPrevented) {
          e.stopPropagation()
          cancelar()
        }
      }}
    >
      <div className="ay-region__content" inert={active || undefined}>
        {children}
      </div>

      {active && (
        <div className={cx('ay-overlay', !scrim && 'ay-overlay--no-scrim')}>
          <div className="ay-overlay__box">
            {progress === null || progress === undefined ? (
              <ArcoSpinner className="ay-spinner ay-spinner--lg" />
            ) : (
              <ProgressBar value={progress} label={label} hideLabel />
            )}
            <p className="ay-overlay__message" aria-live="polite">
              {label}
            </p>
            {cancelable && (
              <button
                ref={botonCancelar}
                type="button"
                className="ay-btn ay-btn--secondary ay-btn--sm"
                aria-busy={cancelando || undefined}
                aria-disabled={cancelando || undefined}
                onClick={cancelar}
              >
                <span className="ay-btn__label">Cancelar</span>
              </button>
            )}
          </div>
        </div>
      )}
    </section>
  )
})

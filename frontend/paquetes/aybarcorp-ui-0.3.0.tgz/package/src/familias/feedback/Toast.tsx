import { forwardRef, useEffect, useRef, useState, useSyncExternalStore } from 'react'
import type { FocusEvent, HTMLAttributes, KeyboardEvent, PointerEvent } from 'react'
import { cx } from '../../utiles.js'
import { IconoCerrar, IconoTono } from './_iconos.js'
import { Plazo, unirRefs, usePestanaOculta } from './_internos.js'

export type TonoToast = 'success' | 'info' | 'warning' | 'danger'
export type PosicionToast = 'bottom-end' | 'bottom-center' | 'top-end'

/** Acción única de un toast. Nombra el destino: «Ver la reserva». */
export interface AccionToast {
  label: string
  onClick: () => void
}

/** Lo que recibe `toast()`. */
export interface ToastOptions {
  /** Una frase en pasado que confirma el hecho; obligatorio. */
  message: string
  /** Carga semántica; por omisión `success`. */
  tone?: TonoToast
  /** Acción única. Con ella el plazo sube a 10 s como mínimo, para que sea alcanzable. */
  action?: AccionToast
  /** Tiempo visible en ms; por omisión 5000. `0` lo hace persistente. */
  duration?: number
}

/** Plazo mínimo cuando hay acción: antes de eso no da tiempo a alcanzarla con teclado. */
const MINIMO_CON_ACCION = 10000
/** Visibles a la vez; el resto espera en cola. */
const VISIBLES = 3

// ── Almacén de toasts ─────────────────────────────────────────────────────────
// Un único almacén de módulo, igual que la región es única en la aplicación: `toast()`
// se llama desde cualquier parte —un manejador, un servicio— sin contexto de React.

interface EntradaToast extends ToastOptions {
  id: string
  /** Repeticiones de la misma acción, colapsadas en un solo toast. */
  veces: number
}

let entradas: readonly EntradaToast[] = []
let siguienteId = 0
const oyentes = new Set<() => void>()
const SIN_TOASTS: readonly EntradaToast[] = []

function publicar(nuevas: readonly EntradaToast[]) {
  entradas = nuevas
  for (const oyente of oyentes) oyente()
}

function suscribir(oyente: () => void) {
  oyentes.add(oyente)
  return () => {
    oyentes.delete(oyente)
  }
}

/**
 * Muestra un toast en la `ToastRegion` montada y devuelve su id. El mismo mensaje con el
 * mismo tono no se apila: se colapsa en el toast que ya estaba, con un contador.
 */
export function toast(options: ToastOptions): string {
  const tono = options.tone ?? 'success'
  const repetido = entradas.find((e) => e.message === options.message && (e.tone ?? 'success') === tono)
  if (repetido) {
    publicar(entradas.map((e) => (e === repetido ? { ...e, ...options, veces: e.veces + 1 } : e)))
    return repetido.id
  }
  siguienteId += 1
  const id = `ay-toast-${siguienteId}`
  publicar([...entradas, { ...options, id, veces: 1 }])
  return id
}

/** Retira el toast con ese id, esté visible o en cola. */
export function dismissToast(id: string): void {
  if (entradas.some((e) => e.id === id)) publicar(entradas.filter((e) => e.id !== id))
}

// ── Un toast ──────────────────────────────────────────────────────────────────

export interface PropsToastItem extends Omit<HTMLAttributes<HTMLDivElement>, 'className'> {
  /** Mensaje: una frase en pasado que confirma el hecho, «Reserva registrada». Sin
   *  «éxito» ni exclamaciones; si necesita más de dos líneas, no es un toast. */
  message: string
  /** Carga semántica. La superficie es siempre la inversa; el tono lo lleva el icono. */
  tone?: TonoToast
  /** Acción única, `{ label, onClick }`. Con ella el toast no se cierra antes de 10 s, y
   *  se retira al usarla: la acción suele llevar a otra vista. */
  action?: AccionToast
  /** Tiempo visible en ms; `0` lo hace persistente. Se pausa al apuntar, al enfocar
   *  dentro y con la pestaña en segundo plano, porque cinco segundos no bastan a todos. */
  duration?: number
  /** Se llama al cerrar: con el botón, con Escape, al vencer el plazo o tras la acción.
   *  `ToastRegion` la conecta con `dismissToast`. */
  onDismiss?: () => void
}

/**
 * Confirmación efímera de una acción completada, que no bloquea ni exige respuesta. No
 * roba el foco y el botón de cerrar está siempre: el autocierre no puede ser la única
 * salida. Normalmente no se monta a mano: lo pinta `ToastRegion` a partir de `toast()`.
 */
export const ToastItem = forwardRef<HTMLDivElement, PropsToastItem>(function ToastItem(
  {
    message,
    tone = 'success',
    action,
    duration = 5000,
    onDismiss,
    onPointerEnter,
    onPointerLeave,
    onFocus,
    onBlur,
    onKeyDown,
    ...resto
  },
  ref,
) {
  const [apuntado, setApuntado] = useState(false)
  const [enfocado, setEnfocado] = useState(false)
  const oculta = usePestanaOculta()
  const pausado = apuntado || enfocado || oculta
  const espera = duration <= 0 ? 0 : action ? Math.max(duration, MINIMO_CON_ACCION) : duration

  // El callback puede cambiar en cada render del padre; el plazo no debe reiniciarse por eso.
  const alCerrar = useRef(onDismiss)
  useEffect(() => {
    alCerrar.current = onDismiss
  })
  const cerrar = () => alCerrar.current?.()

  const plazo = useRef<Plazo | null>(null)
  useEffect(() => {
    plazo.current = new Plazo(espera, () => alCerrar.current?.())
    return () => plazo.current?.pausar()
  }, [espera])
  useEffect(() => {
    if (pausado) plazo.current?.pausar()
    else plazo.current?.correr()
  }, [pausado, espera])

  return (
    <div
      {...resto}
      ref={ref}
      className={cx('ay-toast', `ay-toast--${tone}`)}
      role="status"
      onPointerEnter={(e: PointerEvent<HTMLDivElement>) => {
        setApuntado(true)
        onPointerEnter?.(e)
      }}
      onPointerLeave={(e: PointerEvent<HTMLDivElement>) => {
        setApuntado(false)
        onPointerLeave?.(e)
      }}
      onFocus={(e: FocusEvent<HTMLDivElement>) => {
        setEnfocado(true)
        onFocus?.(e)
      }}
      onBlur={(e: FocusEvent<HTMLDivElement>) => {
        // Pasar de la acción al botón de cerrar no reanuda el plazo: el foco sigue dentro.
        if (!e.currentTarget.contains(e.relatedTarget as Node | null)) setEnfocado(false)
        onBlur?.(e)
      }}
      onKeyDown={(e: KeyboardEvent<HTMLDivElement>) => {
        onKeyDown?.(e)
        if (e.key === 'Escape' && !e.defaultPrevented) {
          e.stopPropagation()
          cerrar()
        }
      }}
    >
      <IconoTono tono={tone} lado={16} className="ay-toast__icon" />
      <p className="ay-toast__msg">{message}</p>
      {action && (
        <button
          type="button"
          className="ay-toast__action"
          onClick={() => {
            if (typeof action.onClick === 'function') action.onClick()
            cerrar()
          }}
        >
          {action.label}
        </button>
      )}
      <button type="button" className="ay-toast__close" aria-label="Cerrar" onClick={cerrar}>
        <IconoCerrar lado={14} />
      </button>
    </div>
  )
})

// ── La región ─────────────────────────────────────────────────────────────────

export interface PropsToastRegion extends Omit<HTMLAttributes<HTMLDivElement>, 'className'> {
  /** Ancla de la región, a `space.6` del borde y respetando el safe-area en móvil, donde
   *  ocupa el ancho disponible menos los márgenes. */
  position?: PosicionToast
}

/**
 * Región única de toasts, con `aria-live="polite"`: los toasts se insertan dentro y se
 * anuncian solos. Se monta una sola vez en el layout raíz. Muestra tres a la vez y deja
 * el resto en cola; F6 lleva el foco al primero visible, y mientras hay toasts abajo el
 * FAB sube lo que mida la región para no quedar tapado.
 */
export const ToastRegion = forwardRef<HTMLDivElement, PropsToastRegion>(function ToastRegion(
  { position = 'bottom-end', ...resto },
  ref,
) {
  const todas = useSyncExternalStore(suscribir, () => entradas, () => SIN_TOASTS)
  const visibles = todas.slice(0, VISIBLES)
  const region = useRef<HTMLDivElement | null>(null)
  const hay = visibles.length > 0

  // F6: a la región, cuando hay algún toast visible.
  useEffect(() => {
    if (!hay) return
    const alPulsar = (e: globalThis.KeyboardEvent) => {
      if (e.key !== 'F6' || e.defaultPrevented) return
      const primero = region.current?.querySelector<HTMLElement>('.ay-toast')
      if (!primero) return
      e.preventDefault()
      primero.focus()
    }
    document.addEventListener('keydown', alPulsar)
    return () => document.removeEventListener('keydown', alPulsar)
  }, [hay])

  // El FAB se desplaza mientras hay toasts abajo: la región no tapa controles fijos.
  useEffect(() => {
    const raiz = document.documentElement
    if (!hay || position === 'top-end' || !region.current) {
      raiz.style.removeProperty('--ay-toasts-alto')
      return
    }
    raiz.style.setProperty('--ay-toasts-alto', `${region.current.offsetHeight}px`)
    return () => {
      raiz.style.removeProperty('--ay-toasts-alto')
    }
  }, [hay, position, todas])

  return (
    <div
      {...resto}
      ref={unirRefs(ref, region)}
      className={cx('ay-toasts', `ay-toasts--${position}`)}
      aria-live="polite"
      aria-atomic="false"
    >
      {visibles.map((t) => (
        <ToastItem
          // La clave cambia con el contador: el toast repetido se vuelve a anunciar y su
          // plazo empieza de nuevo.
          key={`${t.id}:${t.veces}`}
          tabIndex={-1}
          message={t.veces > 1 ? `${t.message} (${t.veces} veces)` : t.message}
          tone={t.tone ?? 'success'}
          action={t.action}
          duration={t.duration ?? 5000}
          onDismiss={() => dismissToast(t.id)}
        />
      ))}
    </div>
  )
})

import { forwardRef, useEffect, useState } from 'react'
import type { SVGAttributes } from 'react'
import { cx } from '../../utiles.js'

export type TamanoSpinner = 'sm' | 'md' | 'lg'

export interface PropsSpinner extends Omit<SVGAttributes<SVGSVGElement>, 'className'> {
  /** Diámetro: `sm` dentro de controles, `md` por defecto, `lg` centrado en una región.
   *  El ciclo es el mismo en los tres. */
  size?: TamanoSpinner
  /** Nombre accesible: dice qué se carga, «Cargando unidades» y no «Cargando», para que
   *  tres zonas que cargan a la vez no den tres anuncios idénticos. */
  label?: string
  /** Muestra el texto junto al arco y lo anuncia con `role="status"`. Para esperas de más
   *  de tres segundos; a partir de diez, se añade aparte el motivo. Solo una región
   *  anuncia la carga aunque haya varios spinners a la vista. */
  showLabel?: boolean
  /** Usa `currentColor` sobre fondos de marca, para mantener el contraste. */
  onColor?: boolean
}

/**
 * Indica que una operación está en curso cuando no se conoce su duración ni su avance.
 * El spinner no es la información: lo que importa es el estado, que anuncia la región que
 * lo contiene. Dentro de un botón, el botón lleva `aria-busy` y su etiqueta no cambia.
 * Si el avance se puede medir, Progress Bar; si el contenido ya tiene forma, Skeleton.
 * Los atributos SVG que recibe van al arco.
 */
export const Spinner = forwardRef<SVGSVGElement, PropsSpinner>(function Spinner(
  { size = 'md', label = 'Cargando', showLabel = false, onColor = false, ...resto },
  ref,
) {
  const arco = (
    <svg
      {...resto}
      ref={ref}
      className={cx('ay-spinner', `ay-spinner--${size}`, onColor && 'ay-spinner--on-color')}
      viewBox="0 0 24 24"
      aria-hidden="true"
    >
      <circle className="ay-spinner__track" cx="12" cy="12" r="9" />
      <circle className="ay-spinner__arc" cx="12" cy="12" r="9" />
    </svg>
  )

  if (!showLabel) {
    return (
      <>
        {arco}
        <span className="ay-visually-hidden">{label}</span>
      </>
    )
  }

  return (
    <div className="ay-spinner-row" role="status" aria-live="polite">
      {arco}
      <span className="ay-spinner__text">{label}…</span>
    </div>
  )
})

/**
 * Evita el destello en esperas muy cortas: devuelve `true` solo cuando `cargando` lleva
 * `retardo` milisegundos activo. Por debajo de 300 ms el spinner no se muestra.
 */
export function useDelayedSpinner(cargando: boolean, retardo = 300): boolean {
  const [visible, setVisible] = useState(false)
  useEffect(() => {
    if (!cargando) {
      setVisible(false)
      return
    }
    const t = setTimeout(() => setVisible(true), retardo)
    return () => clearTimeout(t)
  }, [cargando, retardo])
  return visible
}

/**
 * Glifos internos de la familia Feedback: los del diseño aprobado, en trazo y con
 * `currentColor`, para que en forced-colors el sistema los repinte con su color de texto.
 * Todos son decorativos (`aria-hidden`): el significado lo lleva el texto, nunca el icono.
 */
export type TonoIcono = 'info' | 'success' | 'warning' | 'danger' | 'brand'

interface PropsGlifo {
  /** Lado en unidades de usuario del SVG; el diseño usa 20 en Alert y Banner, 16 en Toast. */
  lado: number
  className?: string
}

/** Icono de tono: refuerza la severidad sin depender del color. `brand` usa el de info. */
export function IconoTono({ tono, lado, className }: PropsGlifo & { tono: TonoIcono }) {
  return (
    <svg className={className} width={lado} height={lado} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      {tono === 'warning' ? (
        <>
          <path d="M12 4.5 21 19.5H3L12 4.5Z" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" />
          <path d="M12 10v4m0 2.5v.5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
        </>
      ) : (
        <>
          <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="1.6" />
          {tono === 'success' && (
            <path d="M8 12.5l2.5 2.5L16 9.5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
          )}
          {tono === 'danger' && <path d="M12 7.5v5m0 3v.5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />}
          {(tono === 'info' || tono === 'brand') && (
            <path d="M12 11v5.5m0-8.5v.5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          )}
        </>
      )}
    </svg>
  )
}

/** Aspa de cerrar. El nombre accesible lo pone el botón que la contiene. */
export function IconoCerrar({ lado, className }: PropsGlifo) {
  return (
    <svg className={className} width={lado} height={lado} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M6 6l12 12M18 6 6 18" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" />
    </svg>
  )
}

/**
 * El arco del Spinner sin su texto. Lo usa `Spinner` y lo usa `LoadingOverlay`, que ya
 * anuncia la operación en su propio mensaje: con el Spinner completo el lector la leería
 * dos veces, una del texto oculto del Spinner y otra del mensaje del velo.
 */
export function ArcoSpinner({ className }: { className: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" aria-hidden="true">
      <circle className="ay-spinner__track" cx="12" cy="12" r="9" />
      <circle className="ay-spinner__arc" cx="12" cy="12" r="9" />
    </svg>
  )
}

import { forwardRef, useRef } from 'react'
import type { HTMLAttributes, ReactNode } from 'react'
import { cx } from '../../utiles.js'
import { IconoCerrar, IconoTono } from './_iconos.js'
import { enfocarContenedor, hayContenido, unirRefs } from './_internos.js'

export type TonoAlert = 'info' | 'success' | 'warning' | 'danger'
export type TamanoAlert = 'sm' | 'md'
export type AnuncioAlert = 'polite' | 'assertive' | 'off'

export interface PropsAlert extends Omit<HTMLAttributes<HTMLDivElement>, 'className' | 'title'> {
  /** Carga semántica. Decide el color, el icono y el rol: `info` y `success` se anuncian
   *  con `role="status"`, que espera a que el lector termine la frase; `warning` y
   *  `danger` con `role="alert"`, que la corta. El tono nunca va solo: el texto tiene que
   *  decir qué pasa, porque un fondo ámbar y uno rojo son el mismo gris para quien no
   *  distingue esos tonos. */
  tone?: TonoAlert
  /** Título del mensaje: nombra la situación en una línea, sin punto final. Es un
   *  párrafo, no un encabezado: un mensaje que aparece y desaparece no altera el esquema
   *  de encabezados de la página. */
  title?: string
  /** Hasta dos acciones, en Button `ghost` `sm`, bajo la descripción. Nombran lo que
   *  hacen: «Reintentar el envío», no «Aceptar». Quedan fuera de la región anunciada para
   *  que no se repitan en cada actualización del mensaje. */
  actions?: ReactNode
  /** Habilita el botón de cerrar y se llama al pulsarlo. Antes de llamarla el foco pasa
   *  al contenedor (con `tabindex="-1"`), porque el botón desaparece con el aviso. Solo
   *  cuando descartar no pierde información. */
  onDismiss?: () => void
  /** Densidad. `sm` deja icono y texto en una sola línea, para cards y paneles estrechos;
   *  ahí va sin título. */
  size?: TamanoAlert
  /** Cómo se anuncia si aparece de forma dinámica. `polite` usa el rol del tono;
   *  `assertive` fuerza `role="alert"` —solo si el aviso bloquea, como un error que impide
   *  el envío—; `off` no pone rol, para el aviso presente desde la carga, que el lector ya
   *  recorre en su sitio. */
  live?: AnuncioAlert
}

/**
 * Mensaje de estado dentro del flujo que persiste mientras la condición exista. Si es
 * efímero y confirma una acción es Toast; si afecta a toda la aplicación, Banner; si
 * valida un campo, Error Message. El rol va en el contenedor del mensaje y no en el que
 * envuelve también las acciones: `role="status"` se lee entero en cada cambio.
 */
export const Alert = forwardRef<HTMLDivElement, PropsAlert>(function Alert(
  { tone = 'info', title, actions, onDismiss, size = 'md', live = 'polite', children, ...resto },
  ref,
) {
  const raiz = useRef<HTMLDivElement | null>(null)
  const urgente = live === 'assertive' || tone === 'warning' || tone === 'danger'
  const rol = live === 'off' ? undefined : urgente ? 'alert' : 'status'

  const cerrar = () => {
    enfocarContenedor(raiz.current)
    onDismiss?.()
  }

  return (
    <div
      {...resto}
      ref={unirRefs(ref, raiz)}
      className={cx('ay-alert', `ay-alert--${tone}`, `ay-alert--${size}`)}
    >
      <IconoTono tono={tone} lado={20} className="ay-alert__icon" />
      <div className="ay-alert__content">
        <div className="ay-alert__message" role={rol}>
          {title && <p className="ay-alert__title">{title}</p>}
          {hayContenido(children) && <p className="ay-alert__desc">{children}</p>}
        </div>
        {hayContenido(actions) && <div className="ay-alert__actions">{actions}</div>}
      </div>
      {onDismiss !== undefined && (
        <button type="button" className="ay-alert__close" aria-label="Cerrar aviso" onClick={cerrar}>
          <IconoCerrar lado={16} />
        </button>
      )}
    </div>
  )
})

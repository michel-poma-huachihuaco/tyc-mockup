import { forwardRef, useEffect, useState } from 'react'
import type { HTMLAttributes } from 'react'
import { cx } from '../../utiles.js'

export type VarianteSkeleton = 'text' | 'block' | 'circle'

export interface PropsSkeleton extends Omit<HTMLAttributes<HTMLSpanElement>, 'className'> {
  /** Forma: `text` para líneas con la altura de línea real, `block` para media o una
   *  superficie, `circle` para avatares. La silueta replica la caja del contenido final. */
  variant?: VarianteSkeleton
  /** Número de líneas en la variante `text`. Con más de una, la última queda al 60% para
   *  que el bloque se lea como un párrafo y no como una rejilla. */
  lines?: number
  /** Ancho; admite cualquier longitud CSS. En `circle` sin ancho propio toma el alto. */
  width?: string
  /** Alto en las variantes `block` y `circle`; `text` usa la altura de línea real. */
  height?: string
  /** Radio; por defecto el del elemento sustituido (`sm` en texto, `md` en bloque,
   *  `full` en círculo). */
  radius?: string
}

/** Ancho de la última línea de un texto de varias: la silueta de un párrafo real. */
const ULTIMA_LINEA = '60%'

/**
 * Silueta del contenido mientras carga, con la misma forma que tendrá, para que la
 * interfaz no salte al llegar los datos. Es siempre `aria-hidden`: el contenedor que
 * carga lleva `aria-busy="true"` y el aviso de carga va una sola vez en una live region
 * que ya estaba vacía en el DOM, nunca dentro de la silueta. Para esperas sin forma
 * conocida, Spinner; por debajo de 300 ms, nada (ver `useSkeletonDelay`).
 */
export const Skeleton = forwardRef<HTMLSpanElement, PropsSkeleton>(function Skeleton(
  { variant = 'text', lines = 1, width = '100%', height, radius, style, ...resto },
  ref,
) {
  if (variant === 'text' && lines > 1) {
    return (
      <span {...resto} ref={ref} style={style} className="ay-skel__group" aria-hidden="true">
        {Array.from({ length: lines }, (_, i) => (
          <span
            key={i}
            className="ay-skel ay-skel--text"
            style={{ inlineSize: i === lines - 1 ? ULTIMA_LINEA : width, borderRadius: radius }}
          />
        ))}
      </span>
    )
  }
  // Un círculo sin ancho propio toma el alto, o el diámetro de avatar de la hoja: con
  // «width=100%» sería un disco del ancho del contenedor.
  const ancho = variant === 'circle' && width === '100%' ? height : width
  return (
    <span
      {...resto}
      ref={ref}
      className={cx('ay-skel', `ay-skel--${variant}`)}
      style={{ ...style, inlineSize: ancho, blockSize: variant === 'text' ? undefined : height, borderRadius: radius }}
      aria-hidden="true"
    />
  )
})

/**
 * Retrasa la aparición del Skeleton para evitar el parpadeo en cargas rápidas: devuelve
 * `true` solo cuando `cargando` lleva `ms` milisegundos activo.
 */
export function useSkeletonDelay(cargando: boolean, ms = 300): boolean {
  const [visible, setVisible] = useState(false)
  useEffect(() => {
    if (!cargando) {
      setVisible(false)
      return
    }
    const t = setTimeout(() => setVisible(true), ms)
    return () => clearTimeout(t)
  }, [cargando, ms])
  return visible
}

/**
 * Índice de @aybarcorp/ui. Cada familia del Aybar Design System V1 vive en
 * src/familias/<familia>/ y exporta su API desde su propio index.ts.
 */
export * from './familias/foundations/index.js'
export * from './familias/layout/index.js'
export * from './familias/actions/index.js'
export * from './familias/form-architecture/index.js'
export * from './familias/form-controls/index.js'
export * from './familias/form-pickers/index.js'
export * from './familias/surfaces/index.js'
export * from './familias/data/index.js'
export * from './familias/feedback/index.js'
export * from './familias/overlays/index.js'
export * from './familias/navigation/index.js'
export * from './familias/media/index.js'
export * from './familias/specialized/index.js'
export * from './familias/errors/index.js'
export { cx } from './utiles.js'
/** Re-exporta el cambio de tema para que un remoto no tenga que importar @aybarcorp/tokens. */
export { setTheme } from '@aybarcorp/tokens'
export type { Theme } from '@aybarcorp/tokens'
/** Y los metadatos y tipos de la apariencia, que es lo que necesita un panel de apariencia. */
export { APPEARANCE } from '@aybarcorp/tokens'
export type {
  AccentId,
  AppearanceAxis,
  AppearanceValues,
  DepthId,
  FontId,
  NeutralId,
  PaletteId,
  RadiusId,
  StyleId,
} from '@aybarcorp/tokens'

#!/usr/bin/env node
/**
 * Emite `dist/props.json`: la API de los seis componentes tal como la declaran los
 * `.d.ts` del build. Es el insumo que consume `npx @aybarcorp/cli docs` para la tabla de props, y el
 * subpath público `@aybarcorp/ui/props`.
 *
 * Corre dentro del build de este paquete, después de `tsc`. Que sea un paso del build y
 * no un comando que alguien recuerde ejecutar es lo que evita que el JSON publicado
 * describa la versión anterior de los componentes.
 *
 * Reporta al final las props sin descripción y sin valor por omisión. No falla por
 * ellas —la falta de un JSDoc no rompe a nadie— pero las deja a la vista en cada build:
 * una deuda de documentación que no se ve no se paga nunca.
 */
import { writeFileSync } from 'node:fs'
import { dirname, join, relative } from 'node:path'
import { fileURLToPath } from 'node:url'

import { extraerComponentes } from './props-desde-tipos.mjs'

const raiz = dirname(fileURLToPath(import.meta.url))
const salida = join(raiz, 'dist', 'props.json')

let componentes
try {
  componentes = extraerComponentes()
} catch (error) {
  console.error(`\nERROR  ${error.message}\n`)
  process.exit(1)
}

// `todasLasProps` es del validador y no del contrato: fuera del JSON.
const documento = {
  componentes: componentes.map(({ nombre, descripcion, props }) => ({ nombre, descripcion, props })),
}
writeFileSync(salida, `${JSON.stringify(documento, null, 2)}\n`)

const total = componentes.reduce((n, c) => n + c.props.length, 0)
console.log(
  `@aybarcorp/ui · ${relative(raiz, salida)}: ${componentes.length} componentes, ${total} props propias\n` +
    `  ${componentes.map((c) => `${c.nombre} (${c.props.length})`).join(', ')}`,
)

const sinDescripcion = []
const sinPorOmision = []
for (const componente of componentes) {
  if (!componente.descripcion) sinDescripcion.push(componente.nombre)
  for (const prop of componente.props) {
    if (!prop.descripcion) sinDescripcion.push(`${componente.nombre}.${prop.nombre}`)
    // Una prop obligatoria no puede tener valor por omisión, así que no es deuda.
    if (!prop.requerido && prop.porOmision === null) sinPorOmision.push(`${componente.nombre}.${prop.nombre}`)
  }
}

if (sinDescripcion.length) {
  console.log(`\n  deuda · sin JSDoc (${sinDescripcion.length}): ${sinDescripcion.join(', ')}`)
}
if (sinPorOmision.length) {
  console.log(
    `  deuda · opcional sin valor por omisión en la desestructuración (${sinPorOmision.length}): ` +
      `${sinPorOmision.join(', ')}\n` +
      '           (varias son `undefined` por diseño: un subtítulo o un icono que no se pasa\n' +
      '            simplemente no se pinta; el catálogo lo muestra y aquí no se inventa un valor)',
  )
}
